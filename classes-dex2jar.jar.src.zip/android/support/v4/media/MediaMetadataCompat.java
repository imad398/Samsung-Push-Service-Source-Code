package android.support.v4.media;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;

public final class MediaMetadataCompat implements Parcelable {
  public static final Parcelable.Creator<MediaMetadataCompat> CREATOR;
  
  static final f.a METADATA_KEYS_TYPE;
  
  public static final String METADATA_KEY_ADVERTISEMENT = "android.media.metadata.ADVERTISEMENT";
  
  public static final String METADATA_KEY_ALBUM = "android.media.metadata.ALBUM";
  
  public static final String METADATA_KEY_ALBUM_ART = "android.media.metadata.ALBUM_ART";
  
  public static final String METADATA_KEY_ALBUM_ARTIST = "android.media.metadata.ALBUM_ARTIST";
  
  public static final String METADATA_KEY_ALBUM_ART_URI = "android.media.metadata.ALBUM_ART_URI";
  
  public static final String METADATA_KEY_ART = "android.media.metadata.ART";
  
  public static final String METADATA_KEY_ARTIST = "android.media.metadata.ARTIST";
  
  public static final String METADATA_KEY_ART_URI = "android.media.metadata.ART_URI";
  
  public static final String METADATA_KEY_AUTHOR = "android.media.metadata.AUTHOR";
  
  public static final String METADATA_KEY_BT_FOLDER_TYPE = "android.media.metadata.BT_FOLDER_TYPE";
  
  public static final String METADATA_KEY_COMPILATION = "android.media.metadata.COMPILATION";
  
  public static final String METADATA_KEY_COMPOSER = "android.media.metadata.COMPOSER";
  
  public static final String METADATA_KEY_DATE = "android.media.metadata.DATE";
  
  public static final String METADATA_KEY_DISC_NUMBER = "android.media.metadata.DISC_NUMBER";
  
  public static final String METADATA_KEY_DISPLAY_DESCRIPTION = "android.media.metadata.DISPLAY_DESCRIPTION";
  
  public static final String METADATA_KEY_DISPLAY_ICON = "android.media.metadata.DISPLAY_ICON";
  
  public static final String METADATA_KEY_DISPLAY_ICON_URI = "android.media.metadata.DISPLAY_ICON_URI";
  
  public static final String METADATA_KEY_DISPLAY_SUBTITLE = "android.media.metadata.DISPLAY_SUBTITLE";
  
  public static final String METADATA_KEY_DISPLAY_TITLE = "android.media.metadata.DISPLAY_TITLE";
  
  public static final String METADATA_KEY_DOWNLOAD_STATUS = "android.media.metadata.DOWNLOAD_STATUS";
  
  public static final String METADATA_KEY_DURATION = "android.media.metadata.DURATION";
  
  public static final String METADATA_KEY_GENRE = "android.media.metadata.GENRE";
  
  public static final String METADATA_KEY_MEDIA_ID = "android.media.metadata.MEDIA_ID";
  
  public static final String METADATA_KEY_MEDIA_URI = "android.media.metadata.MEDIA_URI";
  
  public static final String METADATA_KEY_NUM_TRACKS = "android.media.metadata.NUM_TRACKS";
  
  public static final String METADATA_KEY_RATING = "android.media.metadata.RATING";
  
  public static final String METADATA_KEY_TITLE = "android.media.metadata.TITLE";
  
  public static final String METADATA_KEY_TRACK_NUMBER = "android.media.metadata.TRACK_NUMBER";
  
  public static final String METADATA_KEY_USER_RATING = "android.media.metadata.USER_RATING";
  
  public static final String METADATA_KEY_WRITER = "android.media.metadata.WRITER";
  
  public static final String METADATA_KEY_YEAR = "android.media.metadata.YEAR";
  
  static final int METADATA_TYPE_BITMAP = 2;
  
  static final int METADATA_TYPE_LONG = 0;
  
  static final int METADATA_TYPE_RATING = 3;
  
  static final int METADATA_TYPE_TEXT = 1;
  
  private static final String[] PREFERRED_BITMAP_ORDER;
  
  private static final String[] PREFERRED_DESCRIPTION_ORDER = new String[] { "android.media.metadata.TITLE", "android.media.metadata.ARTIST", "android.media.metadata.ALBUM", "android.media.metadata.ALBUM_ARTIST", "android.media.metadata.WRITER", "android.media.metadata.AUTHOR", "android.media.metadata.COMPOSER" };
  
  private static final String[] PREFERRED_URI_ORDER;
  
  private static final String TAG = "MediaMetadata";
  
  final Bundle mBundle;
  
  private MediaDescriptionCompat mDescription;
  
  private Object mMetadataObj;
  
  static {
    PREFERRED_BITMAP_ORDER = new String[] { "android.media.metadata.DISPLAY_ICON", "android.media.metadata.ART", "android.media.metadata.ALBUM_ART" };
    PREFERRED_URI_ORDER = new String[] { "android.media.metadata.DISPLAY_ICON_URI", "android.media.metadata.ART_URI", "android.media.metadata.ALBUM_ART_URI" };
    CREATOR = new a();
  }
  
  public MediaMetadataCompat(Parcel paramParcel) {
    this.mBundle = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeBundle(this.mBundle);
  }
  
  static {
    f.a a1 = new f.a();
    METADATA_KEYS_TYPE = a1;
    Integer integer1 = Integer.valueOf(1);
    a1.put("android.media.metadata.TITLE", integer1);
    a1.put("android.media.metadata.ARTIST", integer1);
    Integer integer2 = Integer.valueOf(0);
    a1.put("android.media.metadata.DURATION", integer2);
    a1.put("android.media.metadata.ALBUM", integer1);
    a1.put("android.media.metadata.AUTHOR", integer1);
    a1.put("android.media.metadata.WRITER", integer1);
    a1.put("android.media.metadata.COMPOSER", integer1);
    a1.put("android.media.metadata.COMPILATION", integer1);
    a1.put("android.media.metadata.DATE", integer1);
    a1.put("android.media.metadata.YEAR", integer2);
    a1.put("android.media.metadata.GENRE", integer1);
    a1.put("android.media.metadata.TRACK_NUMBER", integer2);
    a1.put("android.media.metadata.NUM_TRACKS", integer2);
    a1.put("android.media.metadata.DISC_NUMBER", integer2);
    a1.put("android.media.metadata.ALBUM_ARTIST", integer1);
    Integer integer3 = Integer.valueOf(2);
    a1.put("android.media.metadata.ART", integer3);
    a1.put("android.media.metadata.ART_URI", integer1);
    a1.put("android.media.metadata.ALBUM_ART", integer3);
    a1.put("android.media.metadata.ALBUM_ART_URI", integer1);
    Integer integer4 = Integer.valueOf(3);
    a1.put("android.media.metadata.USER_RATING", integer4);
    a1.put("android.media.metadata.RATING", integer4);
    a1.put("android.media.metadata.DISPLAY_TITLE", integer1);
    a1.put("android.media.metadata.DISPLAY_SUBTITLE", integer1);
    a1.put("android.media.metadata.DISPLAY_DESCRIPTION", integer1);
    a1.put("android.media.metadata.DISPLAY_ICON", integer3);
    a1.put("android.media.metadata.DISPLAY_ICON_URI", integer1);
    a1.put("android.media.metadata.MEDIA_ID", integer1);
    a1.put("android.media.metadata.BT_FOLDER_TYPE", integer2);
    a1.put("android.media.metadata.MEDIA_URI", integer1);
    a1.put("android.media.metadata.ADVERTISEMENT", integer2);
    a1.put("android.media.metadata.DOWNLOAD_STATUS", integer2);
  }
  
  public static final class a implements Parcelable.Creator {
    public MediaMetadataCompat a(Parcel param1Parcel) {
      return new MediaMetadataCompat(param1Parcel);
    }
    
    public MediaMetadataCompat[] b(int param1Int) {
      return new MediaMetadataCompat[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/MediaMetadataCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */