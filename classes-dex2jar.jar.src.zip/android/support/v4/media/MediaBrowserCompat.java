package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.os.BadParcelableException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.b;
import android.support.v4.os.ResultReceiver;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public final class MediaBrowserCompat {
  public static final boolean b = Log.isLoggable("MediaBrowserCompat", 3);
  
  public final e a;
  
  public MediaBrowserCompat(Context paramContext, ComponentName paramComponentName, b paramb, Bundle paramBundle) {
    g g;
    if (Build.VERSION.SDK_INT >= 26) {
      g = new h(paramContext, paramComponentName, paramb, paramBundle);
    } else {
      g = new g((Context)g, paramComponentName, paramb, paramBundle);
    } 
    this.a = g;
  }
  
  public void a() {
    this.a.i();
  }
  
  public void b() {
    this.a.d();
  }
  
  public MediaSessionCompat.Token c() {
    return this.a.f();
  }
  
  public static class CustomActionResultReceiver extends ResultReceiver {
    private final String mAction;
    
    private final MediaBrowserCompat.c mCallback;
    
    private final Bundle mExtras;
    
    public void a(int param1Int, Bundle param1Bundle) {}
  }
  
  public static class ItemReceiver extends ResultReceiver {
    private final MediaBrowserCompat.d mCallback;
    
    private final String mMediaId;
    
    public void a(int param1Int, Bundle param1Bundle) {
      MediaSessionCompat.a(param1Bundle);
      if (param1Int == 0 && param1Bundle != null && param1Bundle.containsKey("media_item")) {
        Parcelable parcelable = param1Bundle.getParcelable("media_item");
        if (parcelable == null || parcelable instanceof MediaBrowserCompat.MediaItem) {
          parcelable = parcelable;
          throw null;
        } 
        throw null;
      } 
      throw null;
    }
  }
  
  public static class MediaItem implements Parcelable {
    public static final Parcelable.Creator<MediaItem> CREATOR = new a();
    
    public static final int FLAG_BROWSABLE = 1;
    
    public static final int FLAG_PLAYABLE = 2;
    
    private final MediaDescriptionCompat mDescription;
    
    private final int mFlags;
    
    public MediaItem(Parcel param1Parcel) {
      this.mFlags = param1Parcel.readInt();
      this.mDescription = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("MediaItem{");
      stringBuilder.append("mFlags=");
      stringBuilder.append(this.mFlags);
      stringBuilder.append(", mDescription=");
      stringBuilder.append(this.mDescription);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.mFlags);
      this.mDescription.writeToParcel(param1Parcel, param1Int);
    }
    
    public static final class a implements Parcelable.Creator {
      public MediaBrowserCompat.MediaItem a(Parcel param2Parcel) {
        return new MediaBrowserCompat.MediaItem(param2Parcel);
      }
      
      public MediaBrowserCompat.MediaItem[] b(int param2Int) {
        return new MediaBrowserCompat.MediaItem[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public MediaBrowserCompat.MediaItem a(Parcel param1Parcel) {
      return new MediaBrowserCompat.MediaItem(param1Parcel);
    }
    
    public MediaBrowserCompat.MediaItem[] b(int param1Int) {
      return new MediaBrowserCompat.MediaItem[param1Int];
    }
  }
  
  public static class SearchResultReceiver extends ResultReceiver {
    private final MediaBrowserCompat.j mCallback;
    
    private final Bundle mExtras;
    
    private final String mQuery;
    
    public void a(int param1Int, Bundle param1Bundle) {
      MediaSessionCompat.a(param1Bundle);
      if (param1Int == 0 && param1Bundle != null && param1Bundle.containsKey("search_results")) {
        Parcelable[] arrayOfParcelable = param1Bundle.getParcelableArray("search_results");
        if (arrayOfParcelable != null) {
          ArrayList<MediaBrowserCompat.MediaItem> arrayList = new ArrayList();
          int i = arrayOfParcelable.length;
          for (param1Int = 0; param1Int < i; param1Int++)
            arrayList.add((MediaBrowserCompat.MediaItem)arrayOfParcelable[param1Int]); 
        } 
        throw null;
      } 
      throw null;
    }
  }
  
  public static class a extends Handler {
    public final WeakReference a;
    
    public WeakReference b;
    
    public a(MediaBrowserCompat.i param1i) {
      this.a = new WeakReference<MediaBrowserCompat.i>(param1i);
    }
    
    public void a(Messenger param1Messenger) {
      this.b = new WeakReference<Messenger>(param1Messenger);
    }
    
    public void handleMessage(Message param1Message) {
      WeakReference weakReference = this.b;
      if (weakReference != null && weakReference.get() != null && this.a.get() != null) {
        Bundle bundle = param1Message.getData();
        MediaSessionCompat.a(bundle);
        MediaBrowserCompat.i i = this.a.get();
        Messenger messenger = this.b.get();
        try {
          StringBuilder stringBuilder;
          int j = param1Message.what;
          if (j != 1) {
            if (j != 2) {
              if (j != 3) {
                stringBuilder = new StringBuilder();
                this();
                stringBuilder.append("Unhandled message: ");
                stringBuilder.append(param1Message);
                stringBuilder.append("\n  Client version: ");
                stringBuilder.append(1);
                stringBuilder.append("\n  Service version: ");
                stringBuilder.append(param1Message.arg1);
                Log.w("MediaBrowserCompat", stringBuilder.toString());
              } else {
                Bundle bundle1 = stringBuilder.getBundle("data_options");
                MediaSessionCompat.a(bundle1);
                Bundle bundle2 = stringBuilder.getBundle("data_notify_children_changed_options");
                MediaSessionCompat.a(bundle2);
                i.h(messenger, stringBuilder.getString("data_media_item_id"), stringBuilder.getParcelableArrayList("data_media_item_list"), bundle1, bundle2);
              } 
            } else {
              i.e(messenger);
            } 
          } else {
            Bundle bundle1 = stringBuilder.getBundle("data_root_hints");
            MediaSessionCompat.a(bundle1);
            i.g(messenger, stringBuilder.getString("data_media_item_id"), (MediaSessionCompat.Token)stringBuilder.getParcelable("data_media_session_token"), bundle1);
          } 
        } catch (BadParcelableException badParcelableException) {
          Log.e("MediaBrowserCompat", "Could not unparcel the data.");
          if (param1Message.what == 1)
            i.e(messenger); 
        } 
      } 
    }
  }
  
  public static abstract class b {
    public final Object a = b.c(new b(this));
    
    public a b;
    
    public abstract void a();
    
    public abstract void b();
    
    public abstract void c();
    
    public void d(a param1a) {
      this.b = param1a;
    }
    
    public static interface a {
      void a();
      
      void b();
      
      void c();
    }
    
    public class b implements b.a {
      public b(MediaBrowserCompat.b this$0) {}
      
      public void a() {
        MediaBrowserCompat.b.a a1 = this.a.b;
        if (a1 != null)
          a1.a(); 
        this.a.a();
      }
      
      public void b() {
        MediaBrowserCompat.b.a a1 = this.a.b;
        if (a1 != null)
          a1.b(); 
        this.a.b();
      }
      
      public void c() {
        MediaBrowserCompat.b.a a1 = this.a.b;
        if (a1 != null)
          a1.c(); 
        this.a.c();
      }
    }
  }
  
  public static interface a {
    void a();
    
    void b();
    
    void c();
  }
  
  public class b implements b.a {
    public b(MediaBrowserCompat this$0) {}
    
    public void a() {
      MediaBrowserCompat.b.a a1 = this.a.b;
      if (a1 != null)
        a1.a(); 
      this.a.a();
    }
    
    public void b() {
      MediaBrowserCompat.b.a a1 = this.a.b;
      if (a1 != null)
        a1.b(); 
      this.a.b();
    }
    
    public void c() {
      MediaBrowserCompat.b.a a1 = this.a.b;
      if (a1 != null)
        a1.c(); 
      this.a.c();
    }
  }
  
  public static abstract class c {}
  
  public static abstract class d {}
  
  public static interface e {
    void d();
    
    MediaSessionCompat.Token f();
    
    void i();
  }
  
  public static abstract class f implements e, i, b.a {
    public final Context a;
    
    public final Object b;
    
    public final Bundle c;
    
    public final MediaBrowserCompat.a d = new MediaBrowserCompat.a(this);
    
    public final f.a e = new f.a();
    
    public int f;
    
    public MediaBrowserCompat.k g;
    
    public Messenger h;
    
    public MediaSessionCompat.Token i;
    
    public f(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.b param1b, Bundle param1Bundle) {
      this.a = param1Context;
      Bundle bundle = new Bundle();
      if (param1Bundle != null) {
        this(param1Bundle);
      } else {
        this();
      } 
      this.c = bundle;
      bundle.putInt("extra_client_version", 1);
      param1b.d(this);
      this.b = b.b(param1Context, param1ComponentName, param1b.a, bundle);
    }
    
    public void a() {
      Bundle bundle = b.e(this.b);
      if (bundle == null)
        return; 
      this.f = bundle.getInt("extra_service_version", 0);
      IBinder iBinder = i.c.a(bundle, "extra_messenger");
      if (iBinder != null) {
        this.g = new MediaBrowserCompat.k(iBinder, this.c);
        Messenger messenger = new Messenger(this.d);
        this.h = messenger;
        this.d.a(messenger);
        try {
          this.g.a(this.a, this.h);
        } catch (RemoteException remoteException) {
          Log.i("MediaBrowserCompat", "Remote error registering client messenger.");
        } 
      } 
      b b = b.a.v(i.c.a(bundle, "extra_session_binder"));
      if (b != null)
        this.i = MediaSessionCompat.Token.b(b.f(this.b), b); 
    }
    
    public void b() {}
    
    public void c() {
      this.g = null;
      this.h = null;
      this.i = null;
      this.d.a(null);
    }
    
    public void d() {
      MediaBrowserCompat.k k1 = this.g;
      if (k1 != null) {
        Messenger messenger = this.h;
        if (messenger != null)
          try {
            k1.c(messenger);
          } catch (RemoteException remoteException) {
            Log.i("MediaBrowserCompat", "Remote error unregistering client messenger.");
          }  
      } 
      b.d(this.b);
    }
    
    public void e(Messenger param1Messenger) {}
    
    public MediaSessionCompat.Token f() {
      if (this.i == null)
        this.i = MediaSessionCompat.Token.a(b.f(this.b)); 
      return this.i;
    }
    
    public void g(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) {}
    
    public void h(Messenger param1Messenger, String param1String, List param1List, Bundle param1Bundle1, Bundle param1Bundle2) {
      if (this.h != param1Messenger)
        return; 
      a.a(this.e.get(param1String));
      if (MediaBrowserCompat.b) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onLoadChildren for id that isn't subscribed id=");
        stringBuilder.append(param1String);
        Log.d("MediaBrowserCompat", stringBuilder.toString());
      } 
    }
    
    public void i() {
      b.a(this.b);
    }
  }
  
  public static class g extends f {
    public g(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.b param1b, Bundle param1Bundle) {
      super(param1Context, param1ComponentName, param1b, param1Bundle);
    }
  }
  
  public static class h extends g {
    public h(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.b param1b, Bundle param1Bundle) {
      super(param1Context, param1ComponentName, param1b, param1Bundle);
    }
  }
  
  public static interface i {
    void e(Messenger param1Messenger);
    
    void g(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle);
    
    void h(Messenger param1Messenger, String param1String, List param1List, Bundle param1Bundle1, Bundle param1Bundle2);
  }
  
  public static abstract class j {}
  
  public static class k {
    public Messenger a;
    
    public Bundle b;
    
    public k(IBinder param1IBinder, Bundle param1Bundle) {
      this.a = new Messenger(param1IBinder);
      this.b = param1Bundle;
    }
    
    public void a(Context param1Context, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_package_name", param1Context.getPackageName());
      bundle.putBundle("data_root_hints", this.b);
      b(6, bundle, param1Messenger);
    }
    
    public final void b(int param1Int, Bundle param1Bundle, Messenger param1Messenger) {
      Message message = Message.obtain();
      message.what = param1Int;
      message.arg1 = 1;
      message.setData(param1Bundle);
      message.replyTo = param1Messenger;
      this.a.send(message);
    }
    
    public void c(Messenger param1Messenger) {
      b(7, null, param1Messenger);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */