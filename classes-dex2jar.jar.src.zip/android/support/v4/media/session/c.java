package android.support.v4.media.session;

import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.view.KeyEvent;

public abstract class c {
  public static boolean a(Object paramObject, KeyEvent paramKeyEvent) {
    return ((MediaController)paramObject).dispatchMediaButtonEvent(paramKeyEvent);
  }
  
  public static Object b(Context paramContext, Object paramObject) {
    return new MediaController(paramContext, (MediaSession.Token)paramObject);
  }
  
  public static void c(Object paramObject, String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver) {
    ((MediaController)paramObject).sendCommand(paramString, paramBundle, paramResultReceiver);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/session/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */