package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;

public abstract class MediaSessionCompat {
  public static void a(Bundle paramBundle) {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader()); 
  }
  
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new a();
    
    public static final int UNKNOWN_ID = -1;
    
    private final MediaDescriptionCompat mDescription;
    
    private final long mId;
    
    private Object mItem;
    
    public QueueItem(Parcel param1Parcel) {
      this.mDescription = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.mId = param1Parcel.readLong();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.mDescription);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.mId);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.mDescription.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.mId);
    }
    
    public static final class a implements Parcelable.Creator {
      public MediaSessionCompat.QueueItem a(Parcel param2Parcel) {
        return new MediaSessionCompat.QueueItem(param2Parcel);
      }
      
      public MediaSessionCompat.QueueItem[] b(int param2Int) {
        return new MediaSessionCompat.QueueItem[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public MediaSessionCompat.QueueItem a(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public MediaSessionCompat.QueueItem[] b(int param1Int) {
      return new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  public static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();
    
    ResultReceiver mResultReceiver;
    
    public ResultReceiverWrapper(Parcel param1Parcel) {
      this.mResultReceiver = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.mResultReceiver.writeToParcel(param1Parcel, param1Int);
    }
    
    public static final class a implements Parcelable.Creator {
      public MediaSessionCompat.ResultReceiverWrapper a(Parcel param2Parcel) {
        return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
      }
      
      public MediaSessionCompat.ResultReceiverWrapper[] b(int param2Int) {
        return new MediaSessionCompat.ResultReceiverWrapper[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public MediaSessionCompat.ResultReceiverWrapper a(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public MediaSessionCompat.ResultReceiverWrapper[] b(int param1Int) {
      return new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new a();
    
    private b mExtraBinder;
    
    private final Object mInner;
    
    private Bundle mSessionToken2Bundle;
    
    public Token(Object param1Object) {
      this(param1Object, null, null);
    }
    
    public Token(Object param1Object, b param1b) {
      this(param1Object, param1b, null);
    }
    
    public Token(Object param1Object, b param1b, Bundle param1Bundle) {
      this.mInner = param1Object;
      this.mExtraBinder = param1b;
      this.mSessionToken2Bundle = param1Bundle;
    }
    
    public static Token a(Object param1Object) {
      return b(param1Object, null);
    }
    
    public static Token b(Object param1Object, b param1b) {
      return (param1Object != null) ? new Token(d.a(param1Object), param1b) : null;
    }
    
    public b c() {
      return this.mExtraBinder;
    }
    
    public Object d() {
      return this.mInner;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void e(b param1b) {
      this.mExtraBinder = param1b;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = true;
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      param1Object = this.mInner;
      Object object = token.mInner;
      if (param1Object == null) {
        if (object != null)
          bool = false; 
        return bool;
      } 
      return (object == null) ? false : param1Object.equals(object);
    }
    
    public void f(Bundle param1Bundle) {
      this.mSessionToken2Bundle = param1Bundle;
    }
    
    public int hashCode() {
      Object object = this.mInner;
      return (object == null) ? 0 : object.hashCode();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable((Parcelable)this.mInner, param1Int);
    }
    
    public static final class a implements Parcelable.Creator {
      public MediaSessionCompat.Token a(Parcel param2Parcel) {
        return new MediaSessionCompat.Token(param2Parcel.readParcelable(null));
      }
      
      public MediaSessionCompat.Token[] b(int param2Int) {
        return new MediaSessionCompat.Token[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public MediaSessionCompat.Token a(Parcel param1Parcel) {
      return new MediaSessionCompat.Token(param1Parcel.readParcelable(null));
    }
    
    public MediaSessionCompat.Token[] b(int param1Int) {
      return new MediaSessionCompat.Token[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/session/MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */