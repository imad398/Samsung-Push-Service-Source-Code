package android.support.v4.media.session;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.view.KeyEvent;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public final class MediaControllerCompat {
  public final b a;
  
  public final MediaSessionCompat.Token b;
  
  public final HashSet c = new HashSet();
  
  public MediaControllerCompat(Context paramContext, MediaSessionCompat.Token paramToken) {
    if (paramToken != null) {
      c c;
      this.b = paramToken;
      if (Build.VERSION.SDK_INT >= 24) {
        c = new d(paramContext, paramToken);
      } else {
        c = new c((Context)c, paramToken);
      } 
      this.a = c;
      return;
    } 
    throw new IllegalArgumentException("sessionToken must not be null");
  }
  
  public boolean a(KeyEvent paramKeyEvent) {
    if (paramKeyEvent != null)
      return this.a.a(paramKeyEvent); 
    throw new IllegalArgumentException("KeyEvent may not be null");
  }
  
  public static abstract class MediaControllerImplApi21 implements b {
    public final Object a;
    
    public final Object b = new Object();
    
    public final List c = new ArrayList();
    
    public HashMap d = new HashMap<Object, Object>();
    
    public final MediaSessionCompat.Token e;
    
    public MediaControllerImplApi21(Context param1Context, MediaSessionCompat.Token param1Token) {
      this.e = param1Token;
      Object object = c.b(param1Context, param1Token.d());
      this.a = object;
      if (object != null) {
        if (param1Token.c() == null)
          c(); 
        return;
      } 
      throw new RemoteException();
    }
    
    public boolean a(KeyEvent param1KeyEvent) {
      return c.a(this.a, param1KeyEvent);
    }
    
    public void b() {
      if (this.e.c() == null)
        return; 
      Iterator iterator = this.c.iterator();
      if (!iterator.hasNext()) {
        this.c.clear();
        return;
      } 
      android.support.v4.media.a.a(iterator.next());
      a a = new a(null);
      this.d.put(null, a);
      throw null;
    }
    
    public final void c() {
      d("android.support.v4.media.session.command.GET_EXTRA_BINDER", null, new ExtraBinderRequestResultReceiver(this));
    }
    
    public void d(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {
      c.c(this.a, param1String, param1Bundle, param1ResultReceiver);
    }
    
    public static class ExtraBinderRequestResultReceiver extends ResultReceiver {
      private WeakReference<MediaControllerCompat.MediaControllerImplApi21> mMediaControllerImpl;
      
      public ExtraBinderRequestResultReceiver(MediaControllerCompat.MediaControllerImplApi21 param2MediaControllerImplApi21) {
        super(null);
        this.mMediaControllerImpl = new WeakReference<MediaControllerCompat.MediaControllerImplApi21>(param2MediaControllerImplApi21);
      }
      
      public void onReceiveResult(int param2Int, Bundle param2Bundle) {
        MediaControllerCompat.MediaControllerImplApi21 mediaControllerImplApi21 = this.mMediaControllerImpl.get();
        if (mediaControllerImplApi21 == null || param2Bundle == null)
          return; 
        synchronized (mediaControllerImplApi21.b) {
          mediaControllerImplApi21.e.e(b.a.v(i.c.a(param2Bundle, "android.support.v4.media.session.EXTRA_BINDER")));
          mediaControllerImplApi21.e.f(param2Bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
          mediaControllerImplApi21.b();
          return;
        } 
      }
    }
    
    public static class a extends MediaControllerCompat.a.a {
      public a(MediaControllerCompat.a param2a) {
        super(param2a);
      }
      
      public void C1() {
        throw new AssertionError();
      }
      
      public void F4(List param2List) {
        throw new AssertionError();
      }
      
      public void I1(MediaMetadataCompat param2MediaMetadataCompat) {
        throw new AssertionError();
      }
      
      public void T3(Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void d1(CharSequence param2CharSequence) {
        throw new AssertionError();
      }
      
      public void r8(ParcelableVolumeInfo param2ParcelableVolumeInfo) {
        throw new AssertionError();
      }
    }
  }
  
  public static class ExtraBinderRequestResultReceiver extends ResultReceiver {
    private WeakReference<MediaControllerCompat.MediaControllerImplApi21> mMediaControllerImpl;
    
    public ExtraBinderRequestResultReceiver(MediaControllerCompat.MediaControllerImplApi21 param1MediaControllerImplApi21) {
      super(null);
      this.mMediaControllerImpl = new WeakReference<MediaControllerCompat.MediaControllerImplApi21>(param1MediaControllerImplApi21);
    }
    
    public void onReceiveResult(int param1Int, Bundle param1Bundle) {
      MediaControllerCompat.MediaControllerImplApi21 mediaControllerImplApi21 = this.mMediaControllerImpl.get();
      if (mediaControllerImplApi21 == null || param1Bundle == null)
        return; 
      synchronized (mediaControllerImplApi21.b) {
        mediaControllerImplApi21.e.e(b.a.v(i.c.a(param1Bundle, "android.support.v4.media.session.EXTRA_BINDER")));
        mediaControllerImplApi21.e.f(param1Bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
        mediaControllerImplApi21.b();
        return;
      } 
    }
  }
  
  public static class a extends a.a {
    public a(MediaControllerCompat.a param1a) {
      super(param1a);
    }
    
    public void C1() {
      throw new AssertionError();
    }
    
    public void F4(List param1List) {
      throw new AssertionError();
    }
    
    public void I1(MediaMetadataCompat param1MediaMetadataCompat) {
      throw new AssertionError();
    }
    
    public void T3(Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void d1(CharSequence param1CharSequence) {
      throw new AssertionError();
    }
    
    public void r8(ParcelableVolumeInfo param1ParcelableVolumeInfo) {
      throw new AssertionError();
    }
  }
  
  public static abstract class a implements IBinder.DeathRecipient {
    public static abstract class a extends a.a {
      public final WeakReference a;
      
      public a(MediaControllerCompat.a param2a) {
        this.a = new WeakReference<MediaControllerCompat.a>(param2a);
      }
      
      public void K7(PlaybackStateCompat param2PlaybackStateCompat) {
        android.support.v4.media.a.a(this.a.get());
      }
      
      public void M7(String param2String, Bundle param2Bundle) {
        android.support.v4.media.a.a(this.a.get());
      }
      
      public void P3(int param2Int) {
        android.support.v4.media.a.a(this.a.get());
      }
      
      public void S3() {
        android.support.v4.media.a.a(this.a.get());
      }
      
      public void V0(boolean param2Boolean) {}
      
      public void a7(boolean param2Boolean) {
        android.support.v4.media.a.a(this.a.get());
      }
      
      public void z2(int param2Int) {
        android.support.v4.media.a.a(this.a.get());
      }
    }
  }
  
  public static abstract class a extends a.a {
    public final WeakReference a;
    
    public a(MediaControllerCompat.a param1a) {
      this.a = new WeakReference<MediaControllerCompat.a>(param1a);
    }
    
    public void K7(PlaybackStateCompat param1PlaybackStateCompat) {
      android.support.v4.media.a.a(this.a.get());
    }
    
    public void M7(String param1String, Bundle param1Bundle) {
      android.support.v4.media.a.a(this.a.get());
    }
    
    public void P3(int param1Int) {
      android.support.v4.media.a.a(this.a.get());
    }
    
    public void S3() {
      android.support.v4.media.a.a(this.a.get());
    }
    
    public void V0(boolean param1Boolean) {}
    
    public void a7(boolean param1Boolean) {
      android.support.v4.media.a.a(this.a.get());
    }
    
    public void z2(int param1Int) {
      android.support.v4.media.a.a(this.a.get());
    }
  }
  
  public static interface b {
    boolean a(KeyEvent param1KeyEvent);
  }
  
  public static class c extends MediaControllerImplApi21 {
    public c(Context param1Context, MediaSessionCompat.Token param1Token) {
      super(param1Context, param1Token);
    }
  }
  
  public static class d extends c {
    public d(Context param1Context, MediaSessionCompat.Token param1Token) {
      super(param1Context, param1Token);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/session/MediaControllerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */