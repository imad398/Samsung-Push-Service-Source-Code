package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final long ACTION_FAST_FORWARD = 64L;
  
  public static final long ACTION_PAUSE = 2L;
  
  public static final long ACTION_PLAY = 4L;
  
  public static final long ACTION_PLAY_FROM_MEDIA_ID = 1024L;
  
  public static final long ACTION_PLAY_FROM_SEARCH = 2048L;
  
  public static final long ACTION_PLAY_FROM_URI = 8192L;
  
  public static final long ACTION_PLAY_PAUSE = 512L;
  
  public static final long ACTION_PREPARE = 16384L;
  
  public static final long ACTION_PREPARE_FROM_MEDIA_ID = 32768L;
  
  public static final long ACTION_PREPARE_FROM_SEARCH = 65536L;
  
  public static final long ACTION_PREPARE_FROM_URI = 131072L;
  
  public static final long ACTION_REWIND = 8L;
  
  public static final long ACTION_SEEK_TO = 256L;
  
  public static final long ACTION_SET_CAPTIONING_ENABLED = 1048576L;
  
  public static final long ACTION_SET_RATING = 128L;
  
  public static final long ACTION_SET_REPEAT_MODE = 262144L;
  
  public static final long ACTION_SET_SHUFFLE_MODE = 2097152L;
  
  @Deprecated
  public static final long ACTION_SET_SHUFFLE_MODE_ENABLED = 524288L;
  
  public static final long ACTION_SKIP_TO_NEXT = 32L;
  
  public static final long ACTION_SKIP_TO_PREVIOUS = 16L;
  
  public static final long ACTION_SKIP_TO_QUEUE_ITEM = 4096L;
  
  public static final long ACTION_STOP = 1L;
  
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  public static final int ERROR_CODE_ACTION_ABORTED = 10;
  
  public static final int ERROR_CODE_APP_ERROR = 1;
  
  public static final int ERROR_CODE_AUTHENTICATION_EXPIRED = 3;
  
  public static final int ERROR_CODE_CONCURRENT_STREAM_LIMIT = 5;
  
  public static final int ERROR_CODE_CONTENT_ALREADY_PLAYING = 8;
  
  public static final int ERROR_CODE_END_OF_QUEUE = 11;
  
  public static final int ERROR_CODE_NOT_AVAILABLE_IN_REGION = 7;
  
  public static final int ERROR_CODE_NOT_SUPPORTED = 2;
  
  public static final int ERROR_CODE_PARENTAL_CONTROL_RESTRICTED = 6;
  
  public static final int ERROR_CODE_PREMIUM_ACCOUNT_REQUIRED = 4;
  
  public static final int ERROR_CODE_SKIP_LIMIT_REACHED = 9;
  
  public static final int ERROR_CODE_UNKNOWN_ERROR = 0;
  
  private static final int KEYCODE_MEDIA_PAUSE = 127;
  
  private static final int KEYCODE_MEDIA_PLAY = 126;
  
  public static final long PLAYBACK_POSITION_UNKNOWN = -1L;
  
  public static final int REPEAT_MODE_ALL = 2;
  
  public static final int REPEAT_MODE_GROUP = 3;
  
  public static final int REPEAT_MODE_INVALID = -1;
  
  public static final int REPEAT_MODE_NONE = 0;
  
  public static final int REPEAT_MODE_ONE = 1;
  
  public static final int SHUFFLE_MODE_ALL = 1;
  
  public static final int SHUFFLE_MODE_GROUP = 2;
  
  public static final int SHUFFLE_MODE_INVALID = -1;
  
  public static final int SHUFFLE_MODE_NONE = 0;
  
  public static final int STATE_BUFFERING = 6;
  
  public static final int STATE_CONNECTING = 8;
  
  public static final int STATE_ERROR = 7;
  
  public static final int STATE_FAST_FORWARDING = 4;
  
  public static final int STATE_NONE = 0;
  
  public static final int STATE_PAUSED = 2;
  
  public static final int STATE_PLAYING = 3;
  
  public static final int STATE_REWINDING = 5;
  
  public static final int STATE_SKIPPING_TO_NEXT = 10;
  
  public static final int STATE_SKIPPING_TO_PREVIOUS = 9;
  
  public static final int STATE_SKIPPING_TO_QUEUE_ITEM = 11;
  
  public static final int STATE_STOPPED = 1;
  
  final long mActions;
  
  final long mActiveItemId;
  
  final long mBufferedPosition;
  
  List<CustomAction> mCustomActions;
  
  final int mErrorCode;
  
  final CharSequence mErrorMessage;
  
  final Bundle mExtras;
  
  final long mPosition;
  
  final float mSpeed;
  
  final int mState;
  
  private Object mStateObj;
  
  final long mUpdateTime;
  
  public PlaybackStateCompat(Parcel paramParcel) {
    this.mState = paramParcel.readInt();
    this.mPosition = paramParcel.readLong();
    this.mSpeed = paramParcel.readFloat();
    this.mUpdateTime = paramParcel.readLong();
    this.mBufferedPosition = paramParcel.readLong();
    this.mActions = paramParcel.readLong();
    this.mErrorMessage = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.mCustomActions = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.mActiveItemId = paramParcel.readLong();
    this.mExtras = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.mErrorCode = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.mState);
    stringBuilder.append(", position=");
    stringBuilder.append(this.mPosition);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.mBufferedPosition);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.mSpeed);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.mUpdateTime);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.mActions);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.mErrorCode);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.mErrorMessage);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.mCustomActions);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.mActiveItemId);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.mState);
    paramParcel.writeLong(this.mPosition);
    paramParcel.writeFloat(this.mSpeed);
    paramParcel.writeLong(this.mUpdateTime);
    paramParcel.writeLong(this.mBufferedPosition);
    paramParcel.writeLong(this.mActions);
    TextUtils.writeToParcel(this.mErrorMessage, paramParcel, paramInt);
    paramParcel.writeTypedList(this.mCustomActions);
    paramParcel.writeLong(this.mActiveItemId);
    paramParcel.writeBundle(this.mExtras);
    paramParcel.writeInt(this.mErrorCode);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    private final String mAction;
    
    private Object mCustomActionObj;
    
    private final Bundle mExtras;
    
    private final int mIcon;
    
    private final CharSequence mName;
    
    public CustomAction(Parcel param1Parcel) {
      this.mAction = param1Parcel.readString();
      this.mName = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.mIcon = param1Parcel.readInt();
      this.mExtras = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action:mName='");
      stringBuilder.append(this.mName);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.mIcon);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.mExtras);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.mAction);
      TextUtils.writeToParcel(this.mName, param1Parcel, param1Int);
      param1Parcel.writeInt(this.mIcon);
      param1Parcel.writeBundle(this.mExtras);
    }
    
    public static final class a implements Parcelable.Creator {
      public PlaybackStateCompat.CustomAction a(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public PlaybackStateCompat.CustomAction[] b(int param2Int) {
        return new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public PlaybackStateCompat.CustomAction a(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] b(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public PlaybackStateCompat a(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public PlaybackStateCompat[] b(int param1Int) {
      return new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/session/PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */