package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

public final class MediaDescriptionCompat implements Parcelable {
  public static final long BT_FOLDER_TYPE_ALBUMS = 2L;
  
  public static final long BT_FOLDER_TYPE_ARTISTS = 3L;
  
  public static final long BT_FOLDER_TYPE_GENRES = 4L;
  
  public static final long BT_FOLDER_TYPE_MIXED = 0L;
  
  public static final long BT_FOLDER_TYPE_PLAYLISTS = 5L;
  
  public static final long BT_FOLDER_TYPE_TITLES = 1L;
  
  public static final long BT_FOLDER_TYPE_YEARS = 6L;
  
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  public static final String DESCRIPTION_KEY_MEDIA_URI = "android.support.v4.media.description.MEDIA_URI";
  
  public static final String DESCRIPTION_KEY_NULL_BUNDLE_FLAG = "android.support.v4.media.description.NULL_BUNDLE_FLAG";
  
  public static final String EXTRA_BT_FOLDER_TYPE = "android.media.extra.BT_FOLDER_TYPE";
  
  public static final String EXTRA_DOWNLOAD_STATUS = "android.media.extra.DOWNLOAD_STATUS";
  
  public static final long STATUS_DOWNLOADED = 2L;
  
  public static final long STATUS_DOWNLOADING = 1L;
  
  public static final long STATUS_NOT_DOWNLOADED = 0L;
  
  private final CharSequence mDescription;
  
  private Object mDescriptionObj;
  
  private final Bundle mExtras;
  
  private final Bitmap mIcon;
  
  private final Uri mIconUri;
  
  private final String mMediaId;
  
  private final Uri mMediaUri;
  
  private final CharSequence mSubtitle;
  
  private final CharSequence mTitle;
  
  public MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.mMediaId = paramString;
    this.mTitle = paramCharSequence1;
    this.mSubtitle = paramCharSequence2;
    this.mDescription = paramCharSequence3;
    this.mIcon = paramBitmap;
    this.mIconUri = paramUri1;
    this.mExtras = paramBundle;
    this.mMediaUri = paramUri2;
  }
  
  public static MediaDescriptionCompat a(Object paramObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aconst_null
    //   3: astore_2
    //   4: aload_0
    //   5: ifnull -> 183
    //   8: new android/support/v4/media/MediaDescriptionCompat$b
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore_3
    //   16: aload_3
    //   17: aload_0
    //   18: invokestatic f : (Ljava/lang/Object;)Ljava/lang/String;
    //   21: invokevirtual f : (Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   24: pop
    //   25: aload_3
    //   26: aload_0
    //   27: invokestatic h : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   30: invokevirtual i : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   33: pop
    //   34: aload_3
    //   35: aload_0
    //   36: invokestatic g : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   39: invokevirtual h : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   42: pop
    //   43: aload_3
    //   44: aload_0
    //   45: invokestatic b : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   48: invokevirtual b : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   51: pop
    //   52: aload_3
    //   53: aload_0
    //   54: invokestatic d : (Ljava/lang/Object;)Landroid/graphics/Bitmap;
    //   57: invokevirtual d : (Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   60: pop
    //   61: aload_3
    //   62: aload_0
    //   63: invokestatic e : (Ljava/lang/Object;)Landroid/net/Uri;
    //   66: invokevirtual e : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   69: pop
    //   70: aload_0
    //   71: invokestatic c : (Ljava/lang/Object;)Landroid/os/Bundle;
    //   74: astore #4
    //   76: aload #4
    //   78: ifnull -> 100
    //   81: aload #4
    //   83: invokestatic a : (Landroid/os/Bundle;)V
    //   86: aload #4
    //   88: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   90: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   93: checkcast android/net/Uri
    //   96: astore_1
    //   97: goto -> 102
    //   100: aconst_null
    //   101: astore_1
    //   102: aload_1
    //   103: ifnull -> 142
    //   106: aload #4
    //   108: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   110: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   113: ifeq -> 128
    //   116: aload #4
    //   118: invokevirtual size : ()I
    //   121: iconst_2
    //   122: if_icmpne -> 128
    //   125: goto -> 145
    //   128: aload #4
    //   130: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   132: invokevirtual remove : (Ljava/lang/String;)V
    //   135: aload #4
    //   137: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   139: invokevirtual remove : (Ljava/lang/String;)V
    //   142: aload #4
    //   144: astore_2
    //   145: aload_3
    //   146: aload_2
    //   147: invokevirtual c : (Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   150: pop
    //   151: aload_1
    //   152: ifnull -> 164
    //   155: aload_3
    //   156: aload_1
    //   157: invokevirtual g : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   160: pop
    //   161: goto -> 173
    //   164: aload_3
    //   165: aload_0
    //   166: invokestatic a : (Ljava/lang/Object;)Landroid/net/Uri;
    //   169: invokevirtual g : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   172: pop
    //   173: aload_3
    //   174: invokevirtual a : ()Landroid/support/v4/media/MediaDescriptionCompat;
    //   177: astore_1
    //   178: aload_1
    //   179: aload_0
    //   180: putfield mDescriptionObj : Ljava/lang/Object;
    //   183: aload_1
    //   184: areturn
  }
  
  public Object b() {
    Object object1 = this.mDescriptionObj;
    Object object2 = object1;
    if (object1 == null) {
      object2 = c.a.b();
      c.a.g(object2, this.mMediaId);
      c.a.i(object2, this.mTitle);
      c.a.h(object2, this.mSubtitle);
      c.a.c(object2, this.mDescription);
      c.a.e(object2, this.mIcon);
      c.a.f(object2, this.mIconUri);
      c.a.d(object2, this.mExtras);
      d.a.a(object2, this.mMediaUri);
      object2 = c.a.a(object2);
      this.mDescriptionObj = object2;
    } 
    return object2;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mTitle);
    stringBuilder.append(", ");
    stringBuilder.append(this.mSubtitle);
    stringBuilder.append(", ");
    stringBuilder.append(this.mDescription);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    c.i(b(), paramParcel, paramInt);
  }
  
  public static final class a implements Parcelable.Creator {
    public MediaDescriptionCompat a(Parcel param1Parcel) {
      return MediaDescriptionCompat.a(c.a(param1Parcel));
    }
    
    public MediaDescriptionCompat[] b(int param1Int) {
      return new MediaDescriptionCompat[param1Int];
    }
  }
  
  public static final class b {
    public String a;
    
    public CharSequence b;
    
    public CharSequence c;
    
    public CharSequence d;
    
    public Bitmap e;
    
    public Uri f;
    
    public Bundle g;
    
    public Uri h;
    
    public MediaDescriptionCompat a() {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public b b(CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
    
    public b c(Bundle param1Bundle) {
      this.g = param1Bundle;
      return this;
    }
    
    public b d(Bitmap param1Bitmap) {
      this.e = param1Bitmap;
      return this;
    }
    
    public b e(Uri param1Uri) {
      this.f = param1Uri;
      return this;
    }
    
    public b f(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public b g(Uri param1Uri) {
      this.h = param1Uri;
      return this;
    }
    
    public b h(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      return this;
    }
    
    public b i(CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */