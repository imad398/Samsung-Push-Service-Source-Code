package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.media.browse.MediaBrowser;
import android.os.Bundle;

public abstract class b {
  public static void a(Object paramObject) {
    ((MediaBrowser)paramObject).connect();
  }
  
  public static Object b(Context paramContext, ComponentName paramComponentName, Object paramObject, Bundle paramBundle) {
    return new MediaBrowser(paramContext, paramComponentName, (MediaBrowser.ConnectionCallback)paramObject, paramBundle);
  }
  
  public static Object c(a parama) {
    return new b(parama);
  }
  
  public static void d(Object paramObject) {
    ((MediaBrowser)paramObject).disconnect();
  }
  
  public static Bundle e(Object paramObject) {
    return ((MediaBrowser)paramObject).getExtras();
  }
  
  public static Object f(Object paramObject) {
    return ((MediaBrowser)paramObject).getSessionToken();
  }
  
  public static interface a {
    void a();
    
    void b();
    
    void c();
  }
  
  public static class b extends MediaBrowser.ConnectionCallback {
    public final b.a a;
    
    public b(b.a param1a) {
      this.a = param1a;
    }
    
    public void onConnected() {
      this.a.a();
    }
    
    public void onConnectionFailed() {
      this.a.b();
    }
    
    public void onConnectionSuspended() {
      this.a.c();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/android/support/v4/media/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */