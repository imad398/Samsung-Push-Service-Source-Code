package a4;

public class b {
  public String a;
  
  public String b;
  
  public String c;
  
  public String a() {
    return this.a;
  }
  
  public String b() {
    return this.c;
  }
  
  public String c() {
    return this.b;
  }
  
  public void d(String paramString) {
    this.a = paramString;
  }
  
  public void e(String paramString) {
    this.c = paramString;
  }
  
  public void f(String paramString) {
    this.b = paramString;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("appId : ");
    stringBuilder.append(this.a);
    stringBuilder.append(", userId : ");
    stringBuilder.append(this.b);
    stringBuilder.append(", pkgname : ");
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a4/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */