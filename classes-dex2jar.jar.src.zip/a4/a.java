package a4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import b4.k;
import java.util.ArrayList;
import l3.f;

public class a {
  public static final String c = "a";
  
  public a a;
  
  public SQLiteDatabase b;
  
  public a() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: monitorenter
    //   6: new a4/a$a
    //   9: astore_1
    //   10: aload_1
    //   11: invokestatic c : ()Landroid/content/Context;
    //   14: invokespecial <init> : (Landroid/content/Context;)V
    //   17: aload_0
    //   18: aload_1
    //   19: putfield a : La4/a$a;
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   6	24	25	finally
    //   26	28	25	finally
  }
  
  public void b() {
    try {
      this.a.close();
    } catch (Exception exception) {
      String str = c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception is occured when close DB : ");
      stringBuilder.append(exception.getMessage());
      f.b(str, stringBuilder.toString());
    } 
  }
  
  public boolean c() {
    boolean bool = false;
    try {
      n();
      if (this.b.delete("app_info_table", null, null) > 0)
        bool = true; 
      return bool;
    } catch (SQLException sQLException) {
      String str = c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("deleteAll. SQLException caught. e:");
      stringBuilder.append(sQLException);
      f.b(str, stringBuilder.toString());
      return false;
    } 
  }
  
  public int d(String paramString1, String paramString2) {
    String str = c;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("d: [");
    stringBuilder.append(paramString2);
    stringBuilder.append("]");
    stringBuilder.append(k.m(paramString1));
    f.b(str, stringBuilder.toString());
    SQLiteDatabase sQLiteDatabase = this.b;
    stringBuilder = new StringBuilder();
    stringBuilder.append("app_id='");
    stringBuilder.append(paramString1);
    stringBuilder.append("' AND ");
    stringBuilder.append("user_sn");
    stringBuilder.append("='");
    stringBuilder.append(paramString2);
    stringBuilder.append("'");
    return sQLiteDatabase.delete("app_info_table", stringBuilder.toString(), null);
  }
  
  public Cursor e() {
    return this.b.query("app_info_table", new String[] { "app_id", "reg_id", "user_data", "pack_name", "de_registered", "user_sn" }, null, null, null, null, null);
  }
  
  public Cursor f() {
    return this.b.query(true, "app_info_table", new String[] { "user_sn" }, null, null, null, null, null, null);
  }
  
  public ArrayList g() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("de_registered");
    stringBuilder.append("= 'true'");
    ArrayList<b> arrayList = new ArrayList();
    SQLiteDatabase sQLiteDatabase = this.b;
    String str = stringBuilder.toString();
    Cursor cursor = sQLiteDatabase.query(true, "app_info_table", new String[] { "app_id", "user_sn", "user_data" }, str, null, null, null, null, null);
    while (cursor != null && cursor.moveToNext() == true) {
      b b = new b();
      b.d(cursor.getString(cursor.getColumnIndex("app_id")));
      b.f(cursor.getString(cursor.getColumnIndex("user_sn")));
      b.e(cursor.getString(cursor.getColumnIndex("user_data")));
      arrayList.add(b);
      String str1 = c;
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("[DeReg] ");
      stringBuilder1.append(b.toString());
      f.a(str1, stringBuilder1.toString());
    } 
    if (cursor != null)
      cursor.close(); 
    return arrayList;
  }
  
  public Cursor h(String paramString1, String paramString2) {
    SQLiteDatabase sQLiteDatabase = this.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("app_id='");
    stringBuilder.append(paramString1);
    stringBuilder.append("' AND ");
    stringBuilder.append("user_sn");
    stringBuilder.append("='");
    stringBuilder.append(paramString2);
    stringBuilder.append("'");
    paramString1 = stringBuilder.toString();
    Cursor cursor = sQLiteDatabase.query(true, "app_info_table", new String[] { "app_id", "reg_id", "user_data", "pack_name", "de_registered", "user_sn" }, paramString1, null, null, null, null, null);
    if (cursor != null)
      cursor.moveToFirst(); 
    return cursor;
  }
  
  public Cursor i(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("reg_id='");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    paramString = stringBuilder.toString();
    Cursor cursor = sQLiteDatabase.query(true, "app_info_table", new String[] { "app_id", "reg_id", "user_data", "pack_name", "de_registered" }, paramString, null, null, null, null, null);
    if (cursor != null)
      cursor.moveToFirst(); 
    return cursor;
  }
  
  public Cursor j(String paramString1, String paramString2) {
    SQLiteDatabase sQLiteDatabase = this.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("pack_name='");
    stringBuilder.append(paramString1);
    stringBuilder.append("' AND ");
    stringBuilder.append("user_sn");
    stringBuilder.append("='");
    stringBuilder.append(paramString2);
    stringBuilder.append("'");
    paramString1 = stringBuilder.toString();
    Cursor cursor = sQLiteDatabase.query(true, "app_info_table", new String[] { "app_id", "reg_id", "user_data", "pack_name", "de_registered" }, paramString1, null, null, null, null, null);
    if (cursor != null)
      cursor.moveToFirst(); 
    return cursor;
  }
  
  public Cursor k(String paramString1, String paramString2, String paramString3) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("app_id");
    stringBuilder.append("= '");
    stringBuilder.append(paramString1);
    stringBuilder.append("' AND ");
    stringBuilder.append("user_sn");
    stringBuilder.append("= '");
    stringBuilder.append(paramString2);
    stringBuilder.append("'");
    SQLiteDatabase sQLiteDatabase = this.b;
    paramString2 = stringBuilder.toString();
    Cursor cursor = sQLiteDatabase.query(true, "app_info_table", new String[] { paramString3 }, paramString2, null, null, null, null, null);
    if (cursor == null)
      return null; 
    if (cursor.moveToFirst() == true)
      return cursor; 
    cursor.close();
    return null;
  }
  
  public final String l(String paramString) {
    String[] arrayOfString = paramString.split(";");
    if (arrayOfString != null) {
      int i = arrayOfString.length;
      for (byte b = 0; b < i; b++) {
        String str1 = arrayOfString[b];
        if (str1.contains("packageName=")) {
          f.a(c, "getPackageName. value contaions packageName=");
          str1 = str1.replaceFirst("packageName=", "");
          // Byte code: goto -> 70
        } 
      } 
    } 
    String str = paramString;
    if (str.length() >= 1)
      paramString = str; 
    return paramString;
  }
  
  public long m(String paramString1, String paramString2, String paramString3, String paramString4) {
    ContentValues contentValues = new ContentValues();
    contentValues.put("app_id", paramString1);
    contentValues.put("reg_id", paramString2);
    contentValues.put("user_data", paramString3);
    contentValues.put("pack_name", l(paramString3));
    contentValues.put("de_registered", "false");
    contentValues.put("user_sn", paramString4);
    paramString2 = c;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("i: [");
    stringBuilder.append(paramString4);
    stringBuilder.append("]");
    stringBuilder.append(k.m(paramString1));
    f.b(paramString2, stringBuilder.toString());
    return this.b.insert("app_info_table", null, contentValues);
  }
  
  public a n() {
    this.b = this.a.getWritableDatabase();
    return this;
  }
  
  public int o(String paramString1, String paramString2, String paramString3, String paramString4) {
    ContentValues contentValues = new ContentValues();
    contentValues.put(paramString3, paramString4);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("app_id");
    stringBuilder2.append("=? AND ");
    stringBuilder2.append("user_sn");
    stringBuilder2.append("=? ");
    String str = c;
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("u: [");
    stringBuilder3.append(paramString2);
    stringBuilder3.append("]");
    stringBuilder3.append(k.m(paramString1));
    stringBuilder3.append(",");
    stringBuilder3.append(paramString3);
    stringBuilder3.append(":");
    stringBuilder3.append(paramString4);
    f.a(str, stringBuilder3.toString());
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("u: [");
    stringBuilder1.append(paramString2);
    stringBuilder1.append("]");
    stringBuilder1.append(k.m(paramString1));
    f.b(str, stringBuilder1.toString());
    return this.b.update("app_info_table", contentValues, stringBuilder2.toString(), new String[] { paramString1, paramString2 });
  }
  
  public static class a extends SQLiteOpenHelper {
    public a(Context param1Context) {
      super(param1Context, "registration_db", null, 2);
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      param1SQLiteDatabase.execSQL("create table app_info_table (app_id text not null , reg_id text not null,  user_data text not null,  pack_name text not null,  de_registered text not null, user_sn text not null, PRIMARY KEY (app_id, user_sn));");
    }
    
    public void onDowngrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      String str = a.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[onDowngrade] oldVersino : ");
      stringBuilder.append(param1Int1);
      stringBuilder.append(", newVersion : ");
      stringBuilder.append(param1Int2);
      f.g(str, stringBuilder.toString());
      super.onDowngrade(param1SQLiteDatabase, param1Int1, param1Int2);
      param1SQLiteDatabase.execSQL("DROP TABLE IF EXISTS app_info_table");
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {
      String str = a.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[onUpgrade] oldVersino : ");
      stringBuilder.append(param1Int1);
      stringBuilder.append(", newVersion : ");
      stringBuilder.append(param1Int2);
      f.g(str, stringBuilder.toString());
      try {
        f.g(a.a(), "[onUpgrade] ALTER TABLE app_info_table ADD COLUMN user_sn VARCHAR(5) NOT NULL DEFAULT '0'");
        param1SQLiteDatabase.execSQL("ALTER TABLE app_info_table ADD COLUMN user_sn VARCHAR(5) NOT NULL DEFAULT '0'");
        c.w().o();
      } catch (SQLException sQLException) {
        str = a.a();
        stringBuilder = new StringBuilder();
        stringBuilder.append("[onUpgrade] ");
        stringBuilder.append(sQLException.getMessage());
        f.b(str, stringBuilder.toString());
      } 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a4/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */