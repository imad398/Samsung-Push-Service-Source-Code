package a4;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import b4.d;
import b4.e;
import b4.g;
import b4.k;
import b4.m;
import b4.o;
import com.sec.spp.common.pref.CommonPreferences;
import com.sec.spp.push.PushClientApplication;
import com.sec.spp.push.PushClientService;
import com.sec.spp.push.provisioning.ProvisioningInfo;
import com.sec.spp.push.receiver.RegistrationNotiReceiver;
import java.util.ArrayList;
import l3.f;
import l3.p;

public class c {
  public static final String d = "c";
  
  public static final Object e = new Object();
  
  public static c f;
  
  public final Object a = new Object();
  
  public a b = new a();
  
  public p3.b c = new p3.b();
  
  public static c w() {
    // Byte code:
    //   0: ldc a4/c
    //   2: monitorenter
    //   3: getstatic a4/c.f : La4/c;
    //   6: ifnonnull -> 21
    //   9: new a4/c
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic a4/c.f : La4/c;
    //   21: getstatic a4/c.f : La4/c;
    //   24: astore_0
    //   25: ldc a4/c
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc a4/c
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  public ArrayList A() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: astore_1
    //   6: aload_1
    //   7: invokespecial <init> : ()V
    //   10: aconst_null
    //   11: astore_2
    //   12: aconst_null
    //   13: astore_3
    //   14: aload_3
    //   15: astore #4
    //   17: aload_2
    //   18: astore #5
    //   20: aload_0
    //   21: getfield b : La4/a;
    //   24: astore #6
    //   26: aload #6
    //   28: ifnonnull -> 65
    //   31: aload_3
    //   32: astore #4
    //   34: aload_2
    //   35: astore #5
    //   37: getstatic a4/c.d : Ljava/lang/String;
    //   40: ldc '[getRegisteredPkgLists] mDbHandler is null'
    //   42: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   45: aload_0
    //   46: getfield b : La4/a;
    //   49: astore #4
    //   51: aload #4
    //   53: ifnull -> 61
    //   56: aload #4
    //   58: invokevirtual b : ()V
    //   61: aload_0
    //   62: monitorexit
    //   63: aconst_null
    //   64: areturn
    //   65: aload_3
    //   66: astore #4
    //   68: aload_2
    //   69: astore #5
    //   71: aload #6
    //   73: invokevirtual n : ()La4/a;
    //   76: pop
    //   77: aload_3
    //   78: astore #4
    //   80: aload_2
    //   81: astore #5
    //   83: aload_0
    //   84: getfield b : La4/a;
    //   87: invokevirtual e : ()Landroid/database/Cursor;
    //   90: astore_3
    //   91: aload_3
    //   92: ifnull -> 180
    //   95: aload_3
    //   96: astore #4
    //   98: aload_3
    //   99: astore #5
    //   101: aload_3
    //   102: invokeinterface moveToNext : ()Z
    //   107: ifeq -> 180
    //   110: aload_3
    //   111: astore #4
    //   113: aload_3
    //   114: astore #5
    //   116: aload_3
    //   117: iconst_2
    //   118: invokeinterface getString : (I)Ljava/lang/String;
    //   123: astore #6
    //   125: aload_3
    //   126: astore #4
    //   128: aload_3
    //   129: astore #5
    //   131: aload_3
    //   132: iconst_4
    //   133: invokeinterface getString : (I)Ljava/lang/String;
    //   138: astore_2
    //   139: aload_3
    //   140: astore #4
    //   142: aload_3
    //   143: astore #5
    //   145: new android/util/Pair
    //   148: astore #7
    //   150: aload_3
    //   151: astore #4
    //   153: aload_3
    //   154: astore #5
    //   156: aload #7
    //   158: aload #6
    //   160: aload_2
    //   161: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   164: aload_3
    //   165: astore #4
    //   167: aload_3
    //   168: astore #5
    //   170: aload_1
    //   171: aload #7
    //   173: invokevirtual add : (Ljava/lang/Object;)Z
    //   176: pop
    //   177: goto -> 95
    //   180: aload_3
    //   181: ifnull -> 190
    //   184: aload_3
    //   185: invokeinterface close : ()V
    //   190: aload_0
    //   191: getfield b : La4/a;
    //   194: astore #4
    //   196: aload #4
    //   198: ifnull -> 303
    //   201: aload #4
    //   203: invokevirtual b : ()V
    //   206: goto -> 303
    //   209: astore #5
    //   211: goto -> 307
    //   214: astore #6
    //   216: aload #5
    //   218: astore #4
    //   220: getstatic a4/c.d : Ljava/lang/String;
    //   223: astore_2
    //   224: aload #5
    //   226: astore #4
    //   228: new java/lang/StringBuilder
    //   231: astore_3
    //   232: aload #5
    //   234: astore #4
    //   236: aload_3
    //   237: invokespecial <init> : ()V
    //   240: aload #5
    //   242: astore #4
    //   244: aload_3
    //   245: ldc '[getRegisteredAPPLists()] Exception with message ='
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: pop
    //   251: aload #5
    //   253: astore #4
    //   255: aload_3
    //   256: aload #6
    //   258: invokevirtual getMessage : ()Ljava/lang/String;
    //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: pop
    //   265: aload #5
    //   267: astore #4
    //   269: aload_2
    //   270: aload_3
    //   271: invokevirtual toString : ()Ljava/lang/String;
    //   274: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   277: aload #5
    //   279: ifnull -> 289
    //   282: aload #5
    //   284: invokeinterface close : ()V
    //   289: aload_0
    //   290: getfield b : La4/a;
    //   293: astore #4
    //   295: aload #4
    //   297: ifnull -> 303
    //   300: goto -> 201
    //   303: aload_0
    //   304: monitorexit
    //   305: aload_1
    //   306: areturn
    //   307: aload #4
    //   309: ifnull -> 319
    //   312: aload #4
    //   314: invokeinterface close : ()V
    //   319: aload_0
    //   320: getfield b : La4/a;
    //   323: astore #4
    //   325: aload #4
    //   327: ifnull -> 335
    //   330: aload #4
    //   332: invokevirtual b : ()V
    //   335: aload #5
    //   337: athrow
    //   338: astore #4
    //   340: aload_0
    //   341: monitorexit
    //   342: aload #4
    //   344: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	338	finally
    //   20	26	214	java/lang/Exception
    //   20	26	209	finally
    //   37	45	214	java/lang/Exception
    //   37	45	209	finally
    //   45	51	338	finally
    //   56	61	338	finally
    //   71	77	214	java/lang/Exception
    //   71	77	209	finally
    //   83	91	214	java/lang/Exception
    //   83	91	209	finally
    //   101	110	214	java/lang/Exception
    //   101	110	209	finally
    //   116	125	214	java/lang/Exception
    //   116	125	209	finally
    //   131	139	214	java/lang/Exception
    //   131	139	209	finally
    //   145	150	214	java/lang/Exception
    //   145	150	209	finally
    //   156	164	214	java/lang/Exception
    //   156	164	209	finally
    //   170	177	214	java/lang/Exception
    //   170	177	209	finally
    //   184	190	338	finally
    //   190	196	338	finally
    //   201	206	338	finally
    //   220	224	209	finally
    //   228	232	209	finally
    //   236	240	209	finally
    //   244	251	209	finally
    //   255	265	209	finally
    //   269	277	209	finally
    //   282	289	338	finally
    //   289	295	338	finally
    //   312	319	338	finally
    //   319	325	338	finally
    //   330	335	338	finally
    //   335	338	338	finally
  }
  
  public void B() {
    synchronized (this.a) {
      int i = CommonPreferences.getInstance().getRegAppCount();
      CommonPreferences.getInstance().setRegAppCount(i + 1);
      String str = d;
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("Reg App Count Inc : ");
      stringBuilder.append(CommonPreferences.getInstance().getRegAppCount());
      f.a(str, stringBuilder.toString());
      return;
    } 
  }
  
  public boolean C() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore_1
    //   4: aconst_null
    //   5: astore_2
    //   6: aload_2
    //   7: astore_3
    //   8: aload_1
    //   9: astore #4
    //   11: aload_0
    //   12: getfield b : La4/a;
    //   15: astore #5
    //   17: aload #5
    //   19: ifnonnull -> 55
    //   22: aload_2
    //   23: astore_3
    //   24: aload_1
    //   25: astore #4
    //   27: getstatic a4/c.d : Ljava/lang/String;
    //   30: ldc '[isAnichRegistered] mDbHandler is null'
    //   32: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   35: aload_0
    //   36: getfield b : La4/a;
    //   39: astore #4
    //   41: aload #4
    //   43: ifnull -> 51
    //   46: aload #4
    //   48: invokevirtual b : ()V
    //   51: aload_0
    //   52: monitorexit
    //   53: iconst_0
    //   54: ireturn
    //   55: aload_2
    //   56: astore_3
    //   57: aload_1
    //   58: astore #4
    //   60: aload #5
    //   62: invokevirtual n : ()La4/a;
    //   65: pop
    //   66: aload_2
    //   67: astore_3
    //   68: aload_1
    //   69: astore #4
    //   71: aload_0
    //   72: getfield b : La4/a;
    //   75: invokevirtual e : ()Landroid/database/Cursor;
    //   78: astore_2
    //   79: aload_2
    //   80: ifnull -> 275
    //   83: aload_2
    //   84: astore_3
    //   85: aload_2
    //   86: astore #4
    //   88: aload_2
    //   89: invokeinterface moveToNext : ()Z
    //   94: ifeq -> 275
    //   97: aload_2
    //   98: astore_3
    //   99: aload_2
    //   100: astore #4
    //   102: aload_2
    //   103: iconst_1
    //   104: invokeinterface getString : (I)Ljava/lang/String;
    //   109: astore_1
    //   110: aload_2
    //   111: astore_3
    //   112: aload_2
    //   113: astore #4
    //   115: aload_1
    //   116: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   119: ifeq -> 125
    //   122: goto -> 83
    //   125: aload_2
    //   126: astore_3
    //   127: aload_2
    //   128: astore #4
    //   130: aload_1
    //   131: iconst_0
    //   132: iconst_2
    //   133: invokevirtual substring : (II)Ljava/lang/String;
    //   136: astore #6
    //   138: aload_2
    //   139: astore_3
    //   140: aload_2
    //   141: astore #4
    //   143: getstatic a4/c.d : Ljava/lang/String;
    //   146: astore #5
    //   148: aload_2
    //   149: astore_3
    //   150: aload_2
    //   151: astore #4
    //   153: new java/lang/StringBuilder
    //   156: astore_1
    //   157: aload_2
    //   158: astore_3
    //   159: aload_2
    //   160: astore #4
    //   162: aload_1
    //   163: invokespecial <init> : ()V
    //   166: aload_2
    //   167: astore_3
    //   168: aload_2
    //   169: astore #4
    //   171: aload_1
    //   172: ldc 'Test ServerID :'
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: pop
    //   178: aload_2
    //   179: astore_3
    //   180: aload_2
    //   181: astore #4
    //   183: aload_1
    //   184: aload #6
    //   186: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   189: pop
    //   190: aload_2
    //   191: astore_3
    //   192: aload_2
    //   193: astore #4
    //   195: aload #5
    //   197: aload_1
    //   198: invokevirtual toString : ()Ljava/lang/String;
    //   201: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   204: aload_2
    //   205: astore_3
    //   206: aload_2
    //   207: astore #4
    //   209: ldc '06'
    //   211: aload #6
    //   213: invokevirtual equals : (Ljava/lang/Object;)Z
    //   216: istore #7
    //   218: iload #7
    //   220: ifeq -> 249
    //   223: aload_0
    //   224: getfield b : La4/a;
    //   227: astore #4
    //   229: aload #4
    //   231: ifnull -> 239
    //   234: aload #4
    //   236: invokevirtual b : ()V
    //   239: aload_2
    //   240: invokeinterface close : ()V
    //   245: aload_0
    //   246: monitorexit
    //   247: iconst_1
    //   248: ireturn
    //   249: aload_0
    //   250: getfield b : La4/a;
    //   253: astore #4
    //   255: aload #4
    //   257: ifnull -> 265
    //   260: aload #4
    //   262: invokevirtual b : ()V
    //   265: aload_2
    //   266: invokeinterface close : ()V
    //   271: aload_0
    //   272: monitorexit
    //   273: iconst_0
    //   274: ireturn
    //   275: aload_0
    //   276: getfield b : La4/a;
    //   279: astore #4
    //   281: aload #4
    //   283: ifnull -> 291
    //   286: aload #4
    //   288: invokevirtual b : ()V
    //   291: aload_2
    //   292: ifnull -> 347
    //   295: aload_2
    //   296: astore #4
    //   298: aload #4
    //   300: invokeinterface close : ()V
    //   305: goto -> 347
    //   308: astore_2
    //   309: goto -> 351
    //   312: astore_2
    //   313: aload #4
    //   315: astore_3
    //   316: getstatic a4/c.d : Ljava/lang/String;
    //   319: aload_2
    //   320: invokevirtual getMessage : ()Ljava/lang/String;
    //   323: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   326: aload_0
    //   327: getfield b : La4/a;
    //   330: astore_3
    //   331: aload_3
    //   332: ifnull -> 339
    //   335: aload_3
    //   336: invokevirtual b : ()V
    //   339: aload #4
    //   341: ifnull -> 347
    //   344: goto -> 298
    //   347: aload_0
    //   348: monitorexit
    //   349: iconst_0
    //   350: ireturn
    //   351: aload_0
    //   352: getfield b : La4/a;
    //   355: astore #4
    //   357: aload #4
    //   359: ifnull -> 367
    //   362: aload #4
    //   364: invokevirtual b : ()V
    //   367: aload_3
    //   368: ifnull -> 377
    //   371: aload_3
    //   372: invokeinterface close : ()V
    //   377: aload_2
    //   378: athrow
    //   379: astore #4
    //   381: aload_0
    //   382: monitorexit
    //   383: aload #4
    //   385: athrow
    // Exception table:
    //   from	to	target	type
    //   11	17	312	java/lang/Exception
    //   11	17	308	finally
    //   27	35	312	java/lang/Exception
    //   27	35	308	finally
    //   35	41	379	finally
    //   46	51	379	finally
    //   60	66	312	java/lang/Exception
    //   60	66	308	finally
    //   71	79	312	java/lang/Exception
    //   71	79	308	finally
    //   88	97	312	java/lang/Exception
    //   88	97	308	finally
    //   102	110	312	java/lang/Exception
    //   102	110	308	finally
    //   115	122	312	java/lang/Exception
    //   115	122	308	finally
    //   130	138	312	java/lang/Exception
    //   130	138	308	finally
    //   143	148	312	java/lang/Exception
    //   143	148	308	finally
    //   153	157	312	java/lang/Exception
    //   153	157	308	finally
    //   162	166	312	java/lang/Exception
    //   162	166	308	finally
    //   171	178	312	java/lang/Exception
    //   171	178	308	finally
    //   183	190	312	java/lang/Exception
    //   183	190	308	finally
    //   195	204	312	java/lang/Exception
    //   195	204	308	finally
    //   209	218	312	java/lang/Exception
    //   209	218	308	finally
    //   223	229	379	finally
    //   234	239	379	finally
    //   239	245	379	finally
    //   249	255	379	finally
    //   260	265	379	finally
    //   265	271	379	finally
    //   275	281	379	finally
    //   286	291	379	finally
    //   298	305	379	finally
    //   316	326	308	finally
    //   326	331	379	finally
    //   335	339	379	finally
    //   351	357	379	finally
    //   362	367	379	finally
    //   371	377	379	finally
    //   377	379	379	finally
  }
  
  public boolean D(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic a4/c.d : Ljava/lang/String;
    //   5: astore_3
    //   6: new java/lang/StringBuilder
    //   9: astore #4
    //   11: aload #4
    //   13: invokespecial <init> : ()V
    //   16: aload #4
    //   18: ldc '[isAppAlreadyRegistered] userSN : '
    //   20: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: pop
    //   24: aload #4
    //   26: aload_2
    //   27: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: pop
    //   31: aload_3
    //   32: aload #4
    //   34: invokevirtual toString : ()Ljava/lang/String;
    //   37: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   40: aload_1
    //   41: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   44: ifeq -> 57
    //   47: aload_3
    //   48: ldc '[isAppAlreadyRegistered()] appId is NULL'
    //   50: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   53: aload_0
    //   54: monitorexit
    //   55: iconst_0
    //   56: ireturn
    //   57: aload_2
    //   58: astore #5
    //   60: aload_2
    //   61: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   64: ifeq -> 71
    //   67: ldc '0'
    //   69: astore #5
    //   71: aconst_null
    //   72: astore #6
    //   74: aconst_null
    //   75: astore #7
    //   77: aload #7
    //   79: astore_2
    //   80: aload #6
    //   82: astore #4
    //   84: aload_0
    //   85: getfield b : La4/a;
    //   88: astore #8
    //   90: aload #8
    //   92: ifnonnull -> 125
    //   95: aload #7
    //   97: astore_2
    //   98: aload #6
    //   100: astore #4
    //   102: aload_3
    //   103: ldc '[isAppRegistered] mDbHandler is null'
    //   105: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   108: aload_0
    //   109: getfield b : La4/a;
    //   112: astore_1
    //   113: aload_1
    //   114: ifnull -> 121
    //   117: aload_1
    //   118: invokevirtual b : ()V
    //   121: aload_0
    //   122: monitorexit
    //   123: iconst_0
    //   124: ireturn
    //   125: aload #7
    //   127: astore_2
    //   128: aload #6
    //   130: astore #4
    //   132: aload #8
    //   134: invokevirtual n : ()La4/a;
    //   137: pop
    //   138: aload #7
    //   140: astore_2
    //   141: aload #6
    //   143: astore #4
    //   145: aload_0
    //   146: getfield b : La4/a;
    //   149: aload_1
    //   150: aload #5
    //   152: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   155: astore_1
    //   156: aload_1
    //   157: ifnonnull -> 187
    //   160: aload_1
    //   161: ifnull -> 170
    //   164: aload_1
    //   165: invokeinterface close : ()V
    //   170: aload_0
    //   171: getfield b : La4/a;
    //   174: astore_1
    //   175: aload_1
    //   176: ifnull -> 183
    //   179: aload_1
    //   180: invokevirtual b : ()V
    //   183: aload_0
    //   184: monitorexit
    //   185: iconst_0
    //   186: ireturn
    //   187: aload_1
    //   188: astore_2
    //   189: aload_1
    //   190: astore #4
    //   192: aload_1
    //   193: invokeinterface moveToFirst : ()Z
    //   198: istore #9
    //   200: iload #9
    //   202: ifne -> 228
    //   205: aload_1
    //   206: invokeinterface close : ()V
    //   211: aload_0
    //   212: getfield b : La4/a;
    //   215: astore_1
    //   216: aload_1
    //   217: ifnull -> 224
    //   220: aload_1
    //   221: invokevirtual b : ()V
    //   224: aload_0
    //   225: monitorexit
    //   226: iconst_0
    //   227: ireturn
    //   228: aload_1
    //   229: astore_2
    //   230: aload_1
    //   231: astore #4
    //   233: ldc 'true'
    //   235: aload_1
    //   236: aload_1
    //   237: ldc 'de_registered'
    //   239: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   244: invokeinterface getString : (I)Ljava/lang/String;
    //   249: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   252: istore #9
    //   254: iload #9
    //   256: ifeq -> 282
    //   259: aload_1
    //   260: invokeinterface close : ()V
    //   265: aload_0
    //   266: getfield b : La4/a;
    //   269: astore_1
    //   270: aload_1
    //   271: ifnull -> 278
    //   274: aload_1
    //   275: invokevirtual b : ()V
    //   278: aload_0
    //   279: monitorexit
    //   280: iconst_0
    //   281: ireturn
    //   282: aload_1
    //   283: invokeinterface close : ()V
    //   288: aload_0
    //   289: getfield b : La4/a;
    //   292: astore_1
    //   293: aload_1
    //   294: ifnull -> 391
    //   297: aload_1
    //   298: invokevirtual b : ()V
    //   301: goto -> 391
    //   304: astore_1
    //   305: goto -> 395
    //   308: astore #5
    //   310: aload #4
    //   312: astore_2
    //   313: getstatic a4/c.d : Ljava/lang/String;
    //   316: astore #7
    //   318: aload #4
    //   320: astore_2
    //   321: new java/lang/StringBuilder
    //   324: astore_1
    //   325: aload #4
    //   327: astore_2
    //   328: aload_1
    //   329: invokespecial <init> : ()V
    //   332: aload #4
    //   334: astore_2
    //   335: aload_1
    //   336: ldc '[isAppAlreadyRegistered()] Exception with message ='
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: aload #4
    //   344: astore_2
    //   345: aload_1
    //   346: aload #5
    //   348: invokevirtual getMessage : ()Ljava/lang/String;
    //   351: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: pop
    //   355: aload #4
    //   357: astore_2
    //   358: aload #7
    //   360: aload_1
    //   361: invokevirtual toString : ()Ljava/lang/String;
    //   364: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   367: aload #4
    //   369: ifnull -> 379
    //   372: aload #4
    //   374: invokeinterface close : ()V
    //   379: aload_0
    //   380: getfield b : La4/a;
    //   383: astore_1
    //   384: aload_1
    //   385: ifnull -> 391
    //   388: goto -> 297
    //   391: aload_0
    //   392: monitorexit
    //   393: iconst_1
    //   394: ireturn
    //   395: aload_2
    //   396: ifnull -> 405
    //   399: aload_2
    //   400: invokeinterface close : ()V
    //   405: aload_0
    //   406: getfield b : La4/a;
    //   409: astore_2
    //   410: aload_2
    //   411: ifnull -> 418
    //   414: aload_2
    //   415: invokevirtual b : ()V
    //   418: aload_1
    //   419: athrow
    //   420: astore_1
    //   421: aload_0
    //   422: monitorexit
    //   423: aload_1
    //   424: athrow
    // Exception table:
    //   from	to	target	type
    //   2	53	420	finally
    //   60	67	420	finally
    //   84	90	308	java/lang/Exception
    //   84	90	304	finally
    //   102	108	308	java/lang/Exception
    //   102	108	304	finally
    //   108	113	420	finally
    //   117	121	420	finally
    //   132	138	308	java/lang/Exception
    //   132	138	304	finally
    //   145	156	308	java/lang/Exception
    //   145	156	304	finally
    //   164	170	420	finally
    //   170	175	420	finally
    //   179	183	420	finally
    //   192	200	308	java/lang/Exception
    //   192	200	304	finally
    //   205	216	420	finally
    //   220	224	420	finally
    //   233	254	308	java/lang/Exception
    //   233	254	304	finally
    //   259	270	420	finally
    //   274	278	420	finally
    //   282	293	420	finally
    //   297	301	420	finally
    //   313	318	304	finally
    //   321	325	304	finally
    //   328	332	304	finally
    //   335	342	304	finally
    //   345	355	304	finally
    //   358	367	304	finally
    //   372	379	420	finally
    //   379	384	420	finally
    //   399	405	420	finally
    //   405	410	420	finally
    //   414	418	420	finally
    //   418	420	420	finally
  }
  
  public boolean E(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore_3
    //   4: aconst_null
    //   5: astore #4
    //   7: aload #4
    //   9: astore #5
    //   11: aload_3
    //   12: astore #6
    //   14: aload_0
    //   15: getfield b : La4/a;
    //   18: astore #7
    //   20: aload #7
    //   22: ifnonnull -> 57
    //   25: aload #4
    //   27: astore #5
    //   29: aload_3
    //   30: astore #6
    //   32: getstatic a4/c.d : Ljava/lang/String;
    //   35: ldc '[isDeregisteredApp] mDbHandler is null'
    //   37: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   40: aload_0
    //   41: getfield b : La4/a;
    //   44: astore_1
    //   45: aload_1
    //   46: ifnull -> 53
    //   49: aload_1
    //   50: invokevirtual b : ()V
    //   53: aload_0
    //   54: monitorexit
    //   55: iconst_0
    //   56: ireturn
    //   57: aload #4
    //   59: astore #5
    //   61: aload_3
    //   62: astore #6
    //   64: aload #7
    //   66: invokevirtual n : ()La4/a;
    //   69: pop
    //   70: aload #4
    //   72: astore #5
    //   74: aload_3
    //   75: astore #6
    //   77: aload_0
    //   78: getfield b : La4/a;
    //   81: aload_1
    //   82: aload_2
    //   83: ldc 'de_registered'
    //   85: invokevirtual k : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   88: astore_1
    //   89: aload_1
    //   90: ifnonnull -> 134
    //   93: aload_1
    //   94: astore #5
    //   96: aload_1
    //   97: astore #6
    //   99: getstatic a4/c.d : Ljava/lang/String;
    //   102: ldc 'isDeregisteredApp : cursor null'
    //   104: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   107: aload_1
    //   108: ifnull -> 117
    //   111: aload_1
    //   112: invokeinterface close : ()V
    //   117: aload_0
    //   118: getfield b : La4/a;
    //   121: astore_1
    //   122: aload_1
    //   123: ifnull -> 130
    //   126: aload_1
    //   127: invokevirtual b : ()V
    //   130: aload_0
    //   131: monitorexit
    //   132: iconst_0
    //   133: ireturn
    //   134: aload_1
    //   135: astore #5
    //   137: aload_1
    //   138: astore #6
    //   140: aload_1
    //   141: aload_1
    //   142: ldc 'de_registered'
    //   144: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   149: invokeinterface getString : (I)Ljava/lang/String;
    //   154: astore_2
    //   155: aload_1
    //   156: astore #5
    //   158: aload_1
    //   159: astore #6
    //   161: getstatic a4/c.d : Ljava/lang/String;
    //   164: astore_3
    //   165: aload_1
    //   166: astore #5
    //   168: aload_1
    //   169: astore #6
    //   171: new java/lang/StringBuilder
    //   174: astore #4
    //   176: aload_1
    //   177: astore #5
    //   179: aload_1
    //   180: astore #6
    //   182: aload #4
    //   184: invokespecial <init> : ()V
    //   187: aload_1
    //   188: astore #5
    //   190: aload_1
    //   191: astore #6
    //   193: aload #4
    //   195: ldc 'isDeregisteredApp : '
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: pop
    //   201: aload_1
    //   202: astore #5
    //   204: aload_1
    //   205: astore #6
    //   207: aload #4
    //   209: aload_2
    //   210: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   213: pop
    //   214: aload_1
    //   215: astore #5
    //   217: aload_1
    //   218: astore #6
    //   220: aload_3
    //   221: aload #4
    //   223: invokevirtual toString : ()Ljava/lang/String;
    //   226: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   229: aload_1
    //   230: astore #5
    //   232: aload_1
    //   233: astore #6
    //   235: ldc 'false'
    //   237: aload_2
    //   238: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   241: istore #8
    //   243: iload #8
    //   245: ifeq -> 271
    //   248: aload_1
    //   249: invokeinterface close : ()V
    //   254: aload_0
    //   255: getfield b : La4/a;
    //   258: astore_1
    //   259: aload_1
    //   260: ifnull -> 267
    //   263: aload_1
    //   264: invokevirtual b : ()V
    //   267: aload_0
    //   268: monitorexit
    //   269: iconst_0
    //   270: ireturn
    //   271: aload_1
    //   272: invokeinterface close : ()V
    //   277: aload_0
    //   278: getfield b : La4/a;
    //   281: astore_1
    //   282: aload_1
    //   283: ifnull -> 387
    //   286: aload_1
    //   287: invokevirtual b : ()V
    //   290: goto -> 387
    //   293: astore_1
    //   294: goto -> 391
    //   297: astore_1
    //   298: aload #6
    //   300: astore #5
    //   302: getstatic a4/c.d : Ljava/lang/String;
    //   305: astore_2
    //   306: aload #6
    //   308: astore #5
    //   310: new java/lang/StringBuilder
    //   313: astore #4
    //   315: aload #6
    //   317: astore #5
    //   319: aload #4
    //   321: invokespecial <init> : ()V
    //   324: aload #6
    //   326: astore #5
    //   328: aload #4
    //   330: ldc '[isDeregisteredApp] Exception with message ='
    //   332: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   335: pop
    //   336: aload #6
    //   338: astore #5
    //   340: aload #4
    //   342: aload_1
    //   343: invokevirtual getMessage : ()Ljava/lang/String;
    //   346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: aload #6
    //   352: astore #5
    //   354: aload_2
    //   355: aload #4
    //   357: invokevirtual toString : ()Ljava/lang/String;
    //   360: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   363: aload #6
    //   365: ifnull -> 375
    //   368: aload #6
    //   370: invokeinterface close : ()V
    //   375: aload_0
    //   376: getfield b : La4/a;
    //   379: astore_1
    //   380: aload_1
    //   381: ifnull -> 387
    //   384: goto -> 286
    //   387: aload_0
    //   388: monitorexit
    //   389: iconst_1
    //   390: ireturn
    //   391: aload #5
    //   393: ifnull -> 403
    //   396: aload #5
    //   398: invokeinterface close : ()V
    //   403: aload_0
    //   404: getfield b : La4/a;
    //   407: astore_2
    //   408: aload_2
    //   409: ifnull -> 416
    //   412: aload_2
    //   413: invokevirtual b : ()V
    //   416: aload_1
    //   417: athrow
    //   418: astore_1
    //   419: aload_0
    //   420: monitorexit
    //   421: aload_1
    //   422: athrow
    // Exception table:
    //   from	to	target	type
    //   14	20	297	java/lang/Exception
    //   14	20	293	finally
    //   32	40	297	java/lang/Exception
    //   32	40	293	finally
    //   40	45	418	finally
    //   49	53	418	finally
    //   64	70	297	java/lang/Exception
    //   64	70	293	finally
    //   77	89	297	java/lang/Exception
    //   77	89	293	finally
    //   99	107	297	java/lang/Exception
    //   99	107	293	finally
    //   111	117	418	finally
    //   117	122	418	finally
    //   126	130	418	finally
    //   140	155	297	java/lang/Exception
    //   140	155	293	finally
    //   161	165	297	java/lang/Exception
    //   161	165	293	finally
    //   171	176	297	java/lang/Exception
    //   171	176	293	finally
    //   182	187	297	java/lang/Exception
    //   182	187	293	finally
    //   193	201	297	java/lang/Exception
    //   193	201	293	finally
    //   207	214	297	java/lang/Exception
    //   207	214	293	finally
    //   220	229	297	java/lang/Exception
    //   220	229	293	finally
    //   235	243	297	java/lang/Exception
    //   235	243	293	finally
    //   248	259	418	finally
    //   263	267	418	finally
    //   271	282	418	finally
    //   286	290	418	finally
    //   302	306	293	finally
    //   310	315	293	finally
    //   319	324	293	finally
    //   328	336	293	finally
    //   340	350	293	finally
    //   354	363	293	finally
    //   368	375	418	finally
    //   375	380	418	finally
    //   396	403	418	finally
    //   403	408	418	finally
    //   412	416	418	finally
    //   416	418	418	finally
  }
  
  public boolean F() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore_1
    //   4: aconst_null
    //   5: astore_2
    //   6: aload_2
    //   7: astore_3
    //   8: aload_1
    //   9: astore #4
    //   11: aload_0
    //   12: getfield b : La4/a;
    //   15: astore #5
    //   17: aload #5
    //   19: ifnonnull -> 52
    //   22: aload_2
    //   23: astore_3
    //   24: aload_1
    //   25: astore #4
    //   27: getstatic a4/c.d : Ljava/lang/String;
    //   30: ldc '[isFotaOnlyRegistered] mDbHandler is null'
    //   32: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   35: aload_0
    //   36: getfield b : La4/a;
    //   39: astore_3
    //   40: aload_3
    //   41: ifnull -> 48
    //   44: aload_3
    //   45: invokevirtual b : ()V
    //   48: aload_0
    //   49: monitorexit
    //   50: iconst_0
    //   51: ireturn
    //   52: aload_2
    //   53: astore_3
    //   54: aload_1
    //   55: astore #4
    //   57: aload #5
    //   59: invokevirtual n : ()La4/a;
    //   62: pop
    //   63: aload_2
    //   64: astore_3
    //   65: aload_1
    //   66: astore #4
    //   68: aload_0
    //   69: getfield b : La4/a;
    //   72: invokevirtual e : ()Landroid/database/Cursor;
    //   75: astore_2
    //   76: aload_2
    //   77: ifnonnull -> 107
    //   80: aload_0
    //   81: getfield b : La4/a;
    //   84: astore_3
    //   85: aload_3
    //   86: ifnull -> 93
    //   89: aload_3
    //   90: invokevirtual b : ()V
    //   93: aload_2
    //   94: ifnull -> 103
    //   97: aload_2
    //   98: invokeinterface close : ()V
    //   103: aload_0
    //   104: monitorexit
    //   105: iconst_0
    //   106: ireturn
    //   107: aload_2
    //   108: astore_3
    //   109: aload_2
    //   110: astore #4
    //   112: aload_2
    //   113: invokeinterface getCount : ()I
    //   118: istore #6
    //   120: aload_2
    //   121: astore_3
    //   122: aload_2
    //   123: astore #4
    //   125: aload_0
    //   126: iload #6
    //   128: invokevirtual S : (I)V
    //   131: iload #6
    //   133: iconst_3
    //   134: if_icmpgt -> 284
    //   137: iload #6
    //   139: ifne -> 145
    //   142: goto -> 284
    //   145: aload_2
    //   146: astore_3
    //   147: aload_2
    //   148: astore #4
    //   150: aload_2
    //   151: invokeinterface moveToNext : ()Z
    //   156: ifeq -> 248
    //   159: aload_2
    //   160: astore_3
    //   161: aload_2
    //   162: astore #4
    //   164: aload_2
    //   165: aload_2
    //   166: ldc 'app_id'
    //   168: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   173: invokeinterface getString : (I)Ljava/lang/String;
    //   178: astore_1
    //   179: aload_2
    //   180: astore_3
    //   181: aload_2
    //   182: astore #4
    //   184: ldc '2f233f9093de9dbc'
    //   186: aload_1
    //   187: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   190: ifne -> 145
    //   193: aload_2
    //   194: astore_3
    //   195: aload_2
    //   196: astore #4
    //   198: ldc 'e668374785e8ac2a'
    //   200: aload_1
    //   201: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   204: ifne -> 145
    //   207: aload_2
    //   208: astore_3
    //   209: aload_2
    //   210: astore #4
    //   212: ldc 'b2a6009911a68ef6'
    //   214: aload_1
    //   215: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   218: istore #7
    //   220: iload #7
    //   222: ifne -> 145
    //   225: aload_0
    //   226: getfield b : La4/a;
    //   229: astore_3
    //   230: aload_3
    //   231: ifnull -> 238
    //   234: aload_3
    //   235: invokevirtual b : ()V
    //   238: aload_2
    //   239: invokeinterface close : ()V
    //   244: aload_0
    //   245: monitorexit
    //   246: iconst_0
    //   247: ireturn
    //   248: aload_2
    //   249: astore_3
    //   250: aload_2
    //   251: astore #4
    //   253: getstatic a4/c.d : Ljava/lang/String;
    //   256: ldc 'FO state : true'
    //   258: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   261: aload_0
    //   262: getfield b : La4/a;
    //   265: astore_3
    //   266: aload_3
    //   267: ifnull -> 274
    //   270: aload_3
    //   271: invokevirtual b : ()V
    //   274: aload_2
    //   275: invokeinterface close : ()V
    //   280: aload_0
    //   281: monitorexit
    //   282: iconst_1
    //   283: ireturn
    //   284: aload_0
    //   285: getfield b : La4/a;
    //   288: astore_3
    //   289: aload_3
    //   290: ifnull -> 297
    //   293: aload_3
    //   294: invokevirtual b : ()V
    //   297: aload_2
    //   298: invokeinterface close : ()V
    //   303: aload_0
    //   304: monitorexit
    //   305: iconst_0
    //   306: ireturn
    //   307: astore #4
    //   309: goto -> 398
    //   312: astore_1
    //   313: aload #4
    //   315: astore_3
    //   316: getstatic a4/c.d : Ljava/lang/String;
    //   319: astore #5
    //   321: aload #4
    //   323: astore_3
    //   324: new java/lang/StringBuilder
    //   327: astore_2
    //   328: aload #4
    //   330: astore_3
    //   331: aload_2
    //   332: invokespecial <init> : ()V
    //   335: aload #4
    //   337: astore_3
    //   338: aload_2
    //   339: ldc '[getAppId()] Exception with message ='
    //   341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   344: pop
    //   345: aload #4
    //   347: astore_3
    //   348: aload_2
    //   349: aload_1
    //   350: invokevirtual getMessage : ()Ljava/lang/String;
    //   353: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   356: pop
    //   357: aload #4
    //   359: astore_3
    //   360: aload #5
    //   362: aload_2
    //   363: invokevirtual toString : ()Ljava/lang/String;
    //   366: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   369: aload_0
    //   370: getfield b : La4/a;
    //   373: astore_3
    //   374: aload_3
    //   375: ifnull -> 382
    //   378: aload_3
    //   379: invokevirtual b : ()V
    //   382: aload #4
    //   384: ifnull -> 394
    //   387: aload #4
    //   389: invokeinterface close : ()V
    //   394: aload_0
    //   395: monitorexit
    //   396: iconst_0
    //   397: ireturn
    //   398: aload_0
    //   399: getfield b : La4/a;
    //   402: astore_2
    //   403: aload_2
    //   404: ifnull -> 411
    //   407: aload_2
    //   408: invokevirtual b : ()V
    //   411: aload_3
    //   412: ifnull -> 421
    //   415: aload_3
    //   416: invokeinterface close : ()V
    //   421: aload #4
    //   423: athrow
    //   424: astore_3
    //   425: aload_0
    //   426: monitorexit
    //   427: aload_3
    //   428: athrow
    // Exception table:
    //   from	to	target	type
    //   11	17	312	java/lang/Exception
    //   11	17	307	finally
    //   27	35	312	java/lang/Exception
    //   27	35	307	finally
    //   35	40	424	finally
    //   44	48	424	finally
    //   57	63	312	java/lang/Exception
    //   57	63	307	finally
    //   68	76	312	java/lang/Exception
    //   68	76	307	finally
    //   80	85	424	finally
    //   89	93	424	finally
    //   97	103	424	finally
    //   112	120	312	java/lang/Exception
    //   112	120	307	finally
    //   125	131	312	java/lang/Exception
    //   125	131	307	finally
    //   150	159	312	java/lang/Exception
    //   150	159	307	finally
    //   164	179	312	java/lang/Exception
    //   164	179	307	finally
    //   184	193	312	java/lang/Exception
    //   184	193	307	finally
    //   198	207	312	java/lang/Exception
    //   198	207	307	finally
    //   212	220	312	java/lang/Exception
    //   212	220	307	finally
    //   225	230	424	finally
    //   234	238	424	finally
    //   238	244	424	finally
    //   253	261	312	java/lang/Exception
    //   253	261	307	finally
    //   261	266	424	finally
    //   270	274	424	finally
    //   274	280	424	finally
    //   284	289	424	finally
    //   293	297	424	finally
    //   297	303	424	finally
    //   316	321	307	finally
    //   324	328	307	finally
    //   331	335	307	finally
    //   338	345	307	finally
    //   348	357	307	finally
    //   360	369	307	finally
    //   369	374	424	finally
    //   378	382	424	finally
    //   387	394	424	finally
    //   398	403	424	finally
    //   407	411	424	finally
    //   415	421	424	finally
    //   421	424	424	finally
  }
  
  public boolean G() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_1
    //   4: iconst_0
    //   5: istore_2
    //   6: iconst_0
    //   7: istore_3
    //   8: aconst_null
    //   9: astore #4
    //   11: aconst_null
    //   12: astore #5
    //   14: aload #5
    //   16: astore #6
    //   18: aload #4
    //   20: astore #7
    //   22: aload_0
    //   23: getfield b : La4/a;
    //   26: astore #8
    //   28: aload #8
    //   30: ifnonnull -> 69
    //   33: aload #5
    //   35: astore #6
    //   37: aload #4
    //   39: astore #7
    //   41: getstatic a4/c.d : Ljava/lang/String;
    //   44: ldc '[isRegistrationTableEmpty] mDbHandler is null'
    //   46: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   49: aload_0
    //   50: getfield b : La4/a;
    //   53: astore #6
    //   55: aload #6
    //   57: ifnull -> 65
    //   60: aload #6
    //   62: invokevirtual b : ()V
    //   65: aload_0
    //   66: monitorexit
    //   67: iconst_0
    //   68: ireturn
    //   69: aload #5
    //   71: astore #6
    //   73: aload #4
    //   75: astore #7
    //   77: aload #8
    //   79: invokevirtual n : ()La4/a;
    //   82: pop
    //   83: aload #5
    //   85: astore #6
    //   87: aload #4
    //   89: astore #7
    //   91: aload_0
    //   92: getfield b : La4/a;
    //   95: invokevirtual e : ()Landroid/database/Cursor;
    //   98: astore #5
    //   100: iload_3
    //   101: istore #9
    //   103: aload #5
    //   105: ifnull -> 150
    //   108: aload #5
    //   110: astore #6
    //   112: aload #5
    //   114: astore #7
    //   116: aload #5
    //   118: invokeinterface getCount : ()I
    //   123: istore #10
    //   125: aload #5
    //   127: astore #6
    //   129: aload #5
    //   131: astore #7
    //   133: aload_0
    //   134: iload #10
    //   136: invokevirtual S : (I)V
    //   139: iload_3
    //   140: istore #9
    //   142: iload #10
    //   144: ifne -> 150
    //   147: iconst_1
    //   148: istore #9
    //   150: aload #5
    //   152: ifnull -> 162
    //   155: aload #5
    //   157: invokeinterface close : ()V
    //   162: aload_0
    //   163: getfield b : La4/a;
    //   166: astore #6
    //   168: iload #9
    //   170: istore_3
    //   171: aload #6
    //   173: ifnull -> 293
    //   176: aload #6
    //   178: invokevirtual b : ()V
    //   181: iload #9
    //   183: istore_3
    //   184: goto -> 293
    //   187: astore #7
    //   189: goto -> 297
    //   192: astore #4
    //   194: aload #7
    //   196: astore #6
    //   198: getstatic a4/c.d : Ljava/lang/String;
    //   201: astore #5
    //   203: aload #7
    //   205: astore #6
    //   207: new java/lang/StringBuilder
    //   210: astore #8
    //   212: aload #7
    //   214: astore #6
    //   216: aload #8
    //   218: invokespecial <init> : ()V
    //   221: aload #7
    //   223: astore #6
    //   225: aload #8
    //   227: ldc 'isRegistrationTableEmpty. Exception with message ='
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #7
    //   235: astore #6
    //   237: aload #8
    //   239: aload #4
    //   241: invokevirtual getMessage : ()Ljava/lang/String;
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: pop
    //   248: aload #7
    //   250: astore #6
    //   252: aload #5
    //   254: aload #8
    //   256: invokevirtual toString : ()Ljava/lang/String;
    //   259: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   262: aload #7
    //   264: ifnull -> 274
    //   267: aload #7
    //   269: invokeinterface close : ()V
    //   274: aload_0
    //   275: getfield b : La4/a;
    //   278: astore #6
    //   280: iload_2
    //   281: istore_3
    //   282: aload #6
    //   284: ifnull -> 293
    //   287: iload_1
    //   288: istore #9
    //   290: goto -> 176
    //   293: aload_0
    //   294: monitorexit
    //   295: iload_3
    //   296: ireturn
    //   297: aload #6
    //   299: ifnull -> 309
    //   302: aload #6
    //   304: invokeinterface close : ()V
    //   309: aload_0
    //   310: getfield b : La4/a;
    //   313: astore #6
    //   315: aload #6
    //   317: ifnull -> 325
    //   320: aload #6
    //   322: invokevirtual b : ()V
    //   325: aload #7
    //   327: athrow
    //   328: astore #6
    //   330: aload_0
    //   331: monitorexit
    //   332: aload #6
    //   334: athrow
    // Exception table:
    //   from	to	target	type
    //   22	28	192	java/lang/Exception
    //   22	28	187	finally
    //   41	49	192	java/lang/Exception
    //   41	49	187	finally
    //   49	55	328	finally
    //   60	65	328	finally
    //   77	83	192	java/lang/Exception
    //   77	83	187	finally
    //   91	100	192	java/lang/Exception
    //   91	100	187	finally
    //   116	125	192	java/lang/Exception
    //   116	125	187	finally
    //   133	139	192	java/lang/Exception
    //   133	139	187	finally
    //   155	162	328	finally
    //   162	168	328	finally
    //   176	181	328	finally
    //   198	203	187	finally
    //   207	212	187	finally
    //   216	221	187	finally
    //   225	233	187	finally
    //   237	248	187	finally
    //   252	262	187	finally
    //   267	274	328	finally
    //   274	280	328	finally
    //   302	309	328	finally
    //   309	315	328	finally
    //   320	325	328	finally
    //   325	328	328	finally
  }
  
  public final void H(String paramString) {
    l();
    int i = CommonPreferences.getInstance().getRegAppCount();
    if (f.h) {
      Context context = PushClientApplication.c();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Reg App Count : ");
      stringBuilder.append(i);
      Toast.makeText(context, stringBuilder.toString(), 1).show();
    } 
  }
  
  public final void I(String paramString1, String paramString2, boolean paramBoolean) {
    if (!paramBoolean) {
      B();
      if (f.h) {
        Context context = PushClientApplication.c();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Reg App Count : ");
        stringBuilder.append(CommonPreferences.getInstance().getRegAppCount());
        Toast.makeText(context, stringBuilder.toString(), 0).show();
      } 
    } 
  }
  
  public final void J(String paramString1, String paramString2, String paramString3) {
    String str = d;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[TC_21_03]");
    stringBuilder.append(paramString2);
    stringBuilder.append(" [");
    stringBuilder.append(paramString1);
    stringBuilder.append("] is already registered : ");
    stringBuilder.append(paramString3);
    f.a(str, stringBuilder.toString());
    if (f.h) {
      Context context = PushClientApplication.c();
      stringBuilder = new StringBuilder();
      stringBuilder.append(paramString2);
      stringBuilder.append(" [");
      stringBuilder.append(paramString1);
      stringBuilder.append("] is already registered");
      Toast.makeText(context, stringBuilder.toString(), 0).show();
    } 
  }
  
  public final void K(g paramg) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[DEREGISTRATION] onSuccess.");
    stringBuilder.append(", resultCode : ");
    stringBuilder.append(paramg.a());
    stringBuilder.append(", resultMsg : ");
    stringBuilder.append(paramg.b());
    stringBuilder.append(", appId : ");
    stringBuilder.append(((d)paramg).f());
    f.a(d, stringBuilder.toString());
  }
  
  public void L() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : La4/a;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull -> 36
    //   11: getstatic a4/c.d : Ljava/lang/String;
    //   14: ldc_w '[processAppDeregistration] mDbHandler is null'
    //   17: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   20: aload_0
    //   21: getfield b : La4/a;
    //   24: astore_1
    //   25: aload_1
    //   26: ifnull -> 33
    //   29: aload_1
    //   30: invokevirtual b : ()V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: aload_1
    //   37: invokevirtual n : ()La4/a;
    //   40: pop
    //   41: aload_0
    //   42: getfield b : La4/a;
    //   45: invokevirtual g : ()Ljava/util/ArrayList;
    //   48: invokevirtual iterator : ()Ljava/util/Iterator;
    //   51: astore_2
    //   52: aload_2
    //   53: invokeinterface hasNext : ()Z
    //   58: ifeq -> 135
    //   61: aload_2
    //   62: invokeinterface next : ()Ljava/lang/Object;
    //   67: checkcast a4/b
    //   70: astore_3
    //   71: getstatic a4/c.d : Ljava/lang/String;
    //   74: astore_1
    //   75: new java/lang/StringBuilder
    //   78: astore #4
    //   80: aload #4
    //   82: invokespecial <init> : ()V
    //   85: aload #4
    //   87: ldc_w 'de:'
    //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: pop
    //   94: aload #4
    //   96: aload_3
    //   97: invokevirtual a : ()Ljava/lang/String;
    //   100: invokestatic m : (Ljava/lang/String;)Ljava/lang/String;
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload_1
    //   108: aload #4
    //   110: invokevirtual toString : ()Ljava/lang/String;
    //   113: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   116: aload_0
    //   117: aload_3
    //   118: invokevirtual a : ()Ljava/lang/String;
    //   121: aload_3
    //   122: invokevirtual b : ()Ljava/lang/String;
    //   125: aload_3
    //   126: invokevirtual c : ()Ljava/lang/String;
    //   129: invokevirtual p : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   132: goto -> 52
    //   135: aload_0
    //   136: getfield b : La4/a;
    //   139: astore_1
    //   140: aload_1
    //   141: ifnull -> 207
    //   144: aload_1
    //   145: invokevirtual b : ()V
    //   148: goto -> 207
    //   151: astore_1
    //   152: goto -> 210
    //   155: astore #4
    //   157: getstatic a4/c.d : Ljava/lang/String;
    //   160: astore_3
    //   161: new java/lang/StringBuilder
    //   164: astore_1
    //   165: aload_1
    //   166: invokespecial <init> : ()V
    //   169: aload_1
    //   170: ldc_w '[DeReg] '
    //   173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: pop
    //   177: aload_1
    //   178: aload #4
    //   180: invokevirtual getMessage : ()Ljava/lang/String;
    //   183: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: pop
    //   187: aload_3
    //   188: aload_1
    //   189: invokevirtual toString : ()Ljava/lang/String;
    //   192: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   195: aload_0
    //   196: getfield b : La4/a;
    //   199: astore_1
    //   200: aload_1
    //   201: ifnull -> 207
    //   204: goto -> 144
    //   207: aload_0
    //   208: monitorexit
    //   209: return
    //   210: aload_0
    //   211: getfield b : La4/a;
    //   214: astore #4
    //   216: aload #4
    //   218: ifnull -> 226
    //   221: aload #4
    //   223: invokevirtual b : ()V
    //   226: aload_1
    //   227: athrow
    //   228: astore_1
    //   229: aload_0
    //   230: monitorexit
    //   231: aload_1
    //   232: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	155	java/lang/Exception
    //   2	7	151	finally
    //   11	20	155	java/lang/Exception
    //   11	20	151	finally
    //   20	25	228	finally
    //   29	33	228	finally
    //   36	52	155	java/lang/Exception
    //   36	52	151	finally
    //   52	132	155	java/lang/Exception
    //   52	132	151	finally
    //   135	140	228	finally
    //   144	148	228	finally
    //   157	195	151	finally
    //   195	200	228	finally
    //   210	216	228	finally
    //   221	226	228	finally
    //   226	228	228	finally
  }
  
  public void M() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic w : ()La4/c;
    //   5: invokevirtual r : ()Ljava/util/ArrayList;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnull -> 139
    //   13: aload_1
    //   14: invokevirtual isEmpty : ()Z
    //   17: ifeq -> 23
    //   20: goto -> 139
    //   23: aload_1
    //   24: invokevirtual iterator : ()Ljava/util/Iterator;
    //   27: astore_2
    //   28: aload_2
    //   29: invokeinterface hasNext : ()Z
    //   34: ifeq -> 136
    //   37: aload_2
    //   38: invokeinterface next : ()Ljava/lang/Object;
    //   43: checkcast b4/n
    //   46: astore_3
    //   47: aload_3
    //   48: invokevirtual a : ()Ljava/lang/String;
    //   51: astore #4
    //   53: aload_3
    //   54: invokevirtual e : ()Ljava/lang/String;
    //   57: astore_1
    //   58: aload_0
    //   59: aload #4
    //   61: aload_1
    //   62: invokevirtual n : (Ljava/lang/String;Ljava/lang/String;)Z
    //   65: ifne -> 80
    //   68: getstatic a4/c.d : Ljava/lang/String;
    //   71: ldc_w 'processClearAppRegistrationInfo. deleteRegTableEntryByAppId failed'
    //   74: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   77: goto -> 28
    //   80: ldc 'false'
    //   82: aload_3
    //   83: invokevirtual b : ()Ljava/lang/String;
    //   86: invokevirtual equals : (Ljava/lang/Object;)Z
    //   89: ifeq -> 107
    //   92: aload_0
    //   93: aload #4
    //   95: aload_3
    //   96: invokevirtual c : ()Ljava/lang/String;
    //   99: aload_1
    //   100: iconst_1
    //   101: sipush #4017
    //   104: invokevirtual g : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZI)V
    //   107: aload_1
    //   108: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   111: ifne -> 28
    //   114: aload_1
    //   115: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Long;
    //   118: invokevirtual longValue : ()J
    //   121: lconst_0
    //   122: lcmp
    //   123: ifeq -> 28
    //   126: aload_0
    //   127: aload #4
    //   129: aload_1
    //   130: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;)V
    //   133: goto -> 28
    //   136: aload_0
    //   137: monitorexit
    //   138: return
    //   139: getstatic a4/c.d : Ljava/lang/String;
    //   142: ldc_w 'processClearAppRegistrationInfo. empty table'
    //   145: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   148: aload_0
    //   149: monitorexit
    //   150: return
    //   151: astore_1
    //   152: aload_0
    //   153: monitorexit
    //   154: aload_1
    //   155: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	151	finally
    //   13	20	151	finally
    //   23	28	151	finally
    //   28	77	151	finally
    //   80	107	151	finally
    //   107	133	151	finally
    //   139	148	151	finally
  }
  
  public boolean N(String paramString1, String paramString2, String paramString3, String paramString4) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic a4/c.d : Ljava/lang/String;
    //   5: astore #5
    //   7: new java/lang/StringBuilder
    //   10: astore #6
    //   12: aload #6
    //   14: invokespecial <init> : ()V
    //   17: aload #6
    //   19: ldc_w '[saveRegInfo] appId : '
    //   22: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   25: pop
    //   26: aload #6
    //   28: aload_1
    //   29: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: pop
    //   33: aload #6
    //   35: ldc_w ' regId '
    //   38: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: pop
    //   42: aload #6
    //   44: aload_2
    //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: pop
    //   49: aload #6
    //   51: ldc_w ' userData : '
    //   54: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: aload #6
    //   60: aload_3
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload #6
    //   67: ldc_w ' userSN : '
    //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: pop
    //   74: aload #6
    //   76: aload #4
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload #5
    //   84: aload #6
    //   86: invokevirtual toString : ()Ljava/lang/String;
    //   89: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   92: iconst_0
    //   93: istore #7
    //   95: iconst_0
    //   96: istore #8
    //   98: aconst_null
    //   99: astore #9
    //   101: aconst_null
    //   102: astore #10
    //   104: aload #10
    //   106: astore #6
    //   108: iload #7
    //   110: istore #11
    //   112: aload #9
    //   114: astore #12
    //   116: aload_0
    //   117: getfield b : La4/a;
    //   120: astore #13
    //   122: aload #13
    //   124: ifnonnull -> 164
    //   127: aload #10
    //   129: astore #6
    //   131: iload #7
    //   133: istore #11
    //   135: aload #9
    //   137: astore #12
    //   139: aload #5
    //   141: ldc_w '[saveRegInfo] mDbHandler is null'
    //   144: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   147: aload_0
    //   148: getfield b : La4/a;
    //   151: astore_1
    //   152: aload_1
    //   153: ifnull -> 160
    //   156: aload_1
    //   157: invokevirtual b : ()V
    //   160: aload_0
    //   161: monitorexit
    //   162: iconst_0
    //   163: ireturn
    //   164: aload #10
    //   166: astore #6
    //   168: iload #7
    //   170: istore #11
    //   172: aload #9
    //   174: astore #12
    //   176: aload #13
    //   178: invokevirtual n : ()La4/a;
    //   181: pop
    //   182: aload #10
    //   184: astore #6
    //   186: iload #7
    //   188: istore #11
    //   190: aload #9
    //   192: astore #12
    //   194: aload_0
    //   195: getfield b : La4/a;
    //   198: aload_1
    //   199: aload #4
    //   201: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   204: astore #10
    //   206: aload #10
    //   208: ifnull -> 263
    //   211: aload #10
    //   213: astore #6
    //   215: iload #7
    //   217: istore #11
    //   219: aload #10
    //   221: astore #12
    //   223: aload #10
    //   225: invokeinterface getCount : ()I
    //   230: iconst_1
    //   231: if_icmplt -> 263
    //   234: aload #10
    //   236: astore #6
    //   238: iload #7
    //   240: istore #11
    //   242: aload #10
    //   244: astore #12
    //   246: aload_0
    //   247: getfield b : La4/a;
    //   250: aload_1
    //   251: aload #4
    //   253: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;)I
    //   256: pop
    //   257: iconst_1
    //   258: istore #14
    //   260: goto -> 266
    //   263: iconst_0
    //   264: istore #14
    //   266: aload #10
    //   268: astore #6
    //   270: iload #7
    //   272: istore #11
    //   274: aload #10
    //   276: astore #12
    //   278: aload_0
    //   279: getfield b : La4/a;
    //   282: aload_1
    //   283: aload_2
    //   284: aload_3
    //   285: aload #4
    //   287: invokevirtual m : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)J
    //   290: lconst_0
    //   291: lcmp
    //   292: iflt -> 298
    //   295: iconst_1
    //   296: istore #8
    //   298: aload #10
    //   300: astore #6
    //   302: iload #8
    //   304: istore #11
    //   306: aload #10
    //   308: astore #12
    //   310: aload_0
    //   311: aload_1
    //   312: aload_2
    //   313: iload #14
    //   315: invokevirtual I : (Ljava/lang/String;Ljava/lang/String;Z)V
    //   318: aload #10
    //   320: ifnull -> 330
    //   323: aload #10
    //   325: invokeinterface close : ()V
    //   330: aload_0
    //   331: getfield b : La4/a;
    //   334: astore_1
    //   335: iload #8
    //   337: istore #14
    //   339: aload_1
    //   340: ifnull -> 452
    //   343: aload_1
    //   344: invokevirtual b : ()V
    //   347: iload #8
    //   349: istore #14
    //   351: goto -> 452
    //   354: astore_1
    //   355: goto -> 457
    //   358: astore_1
    //   359: aload #12
    //   361: astore #6
    //   363: getstatic a4/c.d : Ljava/lang/String;
    //   366: astore_3
    //   367: aload #12
    //   369: astore #6
    //   371: new java/lang/StringBuilder
    //   374: astore_2
    //   375: aload #12
    //   377: astore #6
    //   379: aload_2
    //   380: invokespecial <init> : ()V
    //   383: aload #12
    //   385: astore #6
    //   387: aload_2
    //   388: ldc_w '[saveRegInfo()] Exception with message ='
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: pop
    //   395: aload #12
    //   397: astore #6
    //   399: aload_2
    //   400: aload_1
    //   401: invokevirtual getMessage : ()Ljava/lang/String;
    //   404: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   407: pop
    //   408: aload #12
    //   410: astore #6
    //   412: aload_3
    //   413: aload_2
    //   414: invokevirtual toString : ()Ljava/lang/String;
    //   417: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   420: aload #12
    //   422: ifnull -> 432
    //   425: aload #12
    //   427: invokeinterface close : ()V
    //   432: aload_0
    //   433: getfield b : La4/a;
    //   436: astore_1
    //   437: iload #11
    //   439: istore #14
    //   441: aload_1
    //   442: ifnull -> 452
    //   445: iload #11
    //   447: istore #8
    //   449: goto -> 343
    //   452: aload_0
    //   453: monitorexit
    //   454: iload #14
    //   456: ireturn
    //   457: aload #6
    //   459: ifnull -> 469
    //   462: aload #6
    //   464: invokeinterface close : ()V
    //   469: aload_0
    //   470: getfield b : La4/a;
    //   473: astore_2
    //   474: aload_2
    //   475: ifnull -> 482
    //   478: aload_2
    //   479: invokevirtual b : ()V
    //   482: aload_1
    //   483: athrow
    //   484: astore_1
    //   485: aload_0
    //   486: monitorexit
    //   487: aload_1
    //   488: athrow
    // Exception table:
    //   from	to	target	type
    //   2	92	484	finally
    //   116	122	358	java/lang/Exception
    //   116	122	354	finally
    //   139	147	358	java/lang/Exception
    //   139	147	354	finally
    //   147	152	484	finally
    //   156	160	484	finally
    //   176	182	358	java/lang/Exception
    //   176	182	354	finally
    //   194	206	358	java/lang/Exception
    //   194	206	354	finally
    //   223	234	358	java/lang/Exception
    //   223	234	354	finally
    //   246	257	358	java/lang/Exception
    //   246	257	354	finally
    //   278	295	358	java/lang/Exception
    //   278	295	354	finally
    //   310	318	358	java/lang/Exception
    //   310	318	354	finally
    //   323	330	484	finally
    //   330	335	484	finally
    //   343	347	484	finally
    //   363	367	354	finally
    //   371	375	354	finally
    //   379	383	354	finally
    //   387	395	354	finally
    //   399	408	354	finally
    //   412	420	354	finally
    //   425	432	484	finally
    //   432	437	484	finally
    //   462	469	484	finally
    //   469	474	484	finally
    //   478	482	484	finally
    //   482	484	484	finally
  }
  
  public void O(String paramString1, String paramString2) {
    r3.b.o().Z(paramString1, paramString2, new b(this, paramString2));
  }
  
  public void P(String paramString1, String paramString2, String paramString3) {
    r3.b.o().a0(paramString1, paramString2, paramString3, new c(this, paramString3));
  }
  
  public final void Q(String paramString) {
    synchronized (e) {
      b4.c.a a1 = b4.c.e().c();
      b4.c.a a2 = b4.c.a.a;
      if (a1 == a2)
        return; 
      if (paramString.equalsIgnoreCase("2f233f9093de9dbc") || paramString.equalsIgnoreCase("e668374785e8ac2a"))
        return; 
      b4.c.e().j(a2);
      boolean bool1 = u3.b.u().z();
      boolean bool2 = u3.b.u().y();
      boolean bool3 = u3.c.n().s();
      boolean bool4 = u3.c.n().t();
      boolean bool5 = u3.c.n().o();
      String str = d;
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("PV : ");
      stringBuilder.append(bool1);
      stringBuilder.append(", ");
      stringBuilder.append(bool2);
      stringBuilder.append(", INIT : ");
      stringBuilder.append(bool3);
      stringBuilder.append(", ");
      stringBuilder.append(bool4);
      stringBuilder.append(", ");
      stringBuilder.append(bool5);
      f.a(str, stringBuilder.toString());
      u3.c.n().u();
      u3.b.u().A();
      return;
    } 
  }
  
  public final void R(String paramString1, String paramString2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : La4/a;
    //   6: astore #4
    //   8: aload #4
    //   10: ifnonnull -> 38
    //   13: getstatic a4/c.d : Ljava/lang/String;
    //   16: ldc_w '[setDeregisteredApp] mDbHandler is null'
    //   19: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   22: aload_0
    //   23: getfield b : La4/a;
    //   26: astore_1
    //   27: aload_1
    //   28: ifnull -> 35
    //   31: aload_1
    //   32: invokevirtual b : ()V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: aload #4
    //   40: invokevirtual n : ()La4/a;
    //   43: pop
    //   44: iload_3
    //   45: iconst_1
    //   46: if_icmpne -> 74
    //   49: aload_0
    //   50: getfield b : La4/a;
    //   53: astore #4
    //   55: ldc 'true'
    //   57: astore #5
    //   59: aload #4
    //   61: aload_1
    //   62: aload_2
    //   63: ldc 'de_registered'
    //   65: aload #5
    //   67: invokevirtual o : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   70: pop
    //   71: goto -> 87
    //   74: aload_0
    //   75: getfield b : La4/a;
    //   78: astore #4
    //   80: ldc 'false'
    //   82: astore #5
    //   84: goto -> 59
    //   87: aload_0
    //   88: getfield b : La4/a;
    //   91: astore_1
    //   92: aload_1
    //   93: ifnull -> 162
    //   96: aload_1
    //   97: invokevirtual b : ()V
    //   100: goto -> 162
    //   103: astore_2
    //   104: goto -> 165
    //   107: astore_1
    //   108: getstatic a4/c.d : Ljava/lang/String;
    //   111: astore_2
    //   112: new java/lang/StringBuilder
    //   115: astore #4
    //   117: aload #4
    //   119: invokespecial <init> : ()V
    //   122: aload #4
    //   124: ldc_w '[setDeregisteredApp] '
    //   127: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: pop
    //   131: aload #4
    //   133: aload_1
    //   134: invokevirtual getMessage : ()Ljava/lang/String;
    //   137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: pop
    //   141: aload_2
    //   142: aload #4
    //   144: invokevirtual toString : ()Ljava/lang/String;
    //   147: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   150: aload_0
    //   151: getfield b : La4/a;
    //   154: astore_1
    //   155: aload_1
    //   156: ifnull -> 162
    //   159: goto -> 96
    //   162: aload_0
    //   163: monitorexit
    //   164: return
    //   165: aload_0
    //   166: getfield b : La4/a;
    //   169: astore_1
    //   170: aload_1
    //   171: ifnull -> 178
    //   174: aload_1
    //   175: invokevirtual b : ()V
    //   178: aload_2
    //   179: athrow
    //   180: astore_1
    //   181: aload_0
    //   182: monitorexit
    //   183: aload_1
    //   184: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	107	java/lang/Exception
    //   2	8	103	finally
    //   13	22	107	java/lang/Exception
    //   13	22	103	finally
    //   22	27	180	finally
    //   31	35	180	finally
    //   38	44	107	java/lang/Exception
    //   38	44	103	finally
    //   49	55	107	java/lang/Exception
    //   49	55	103	finally
    //   59	71	107	java/lang/Exception
    //   59	71	103	finally
    //   74	80	107	java/lang/Exception
    //   74	80	103	finally
    //   87	92	180	finally
    //   96	100	180	finally
    //   108	150	103	finally
    //   150	155	180	finally
    //   165	170	180	finally
    //   174	178	180	finally
    //   178	180	180	finally
  }
  
  public final void S(int paramInt) {
    synchronized (this.a) {
      CommonPreferences.getInstance().setRegAppCount(paramInt);
      return;
    } 
  }
  
  public final void T() {
    if (o.e()) {
      f.g(d, "startConnectionChecker. Connection stopped.");
      return;
    } 
    if (b4.c.e().c() != b4.c.a.b)
      b4.c.e().i(SystemClock.elapsedRealtime() + b4.c.e().f()); 
  }
  
  public void f(d paramd, String paramString, boolean paramBoolean) {
    int i;
    Intent intent = new Intent("com.sec.spp.RegistrationChangedAction");
    if (paramBoolean) {
      i = 2;
    } else {
      i = 3;
    } 
    intent.putExtra("com.sec.spp.Status", i);
    if (paramd != null) {
      String str1 = paramd.f();
      i = paramd.a();
      String str2 = paramd.g();
      String str3 = d;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[DeregReply] appid : ");
      stringBuilder.append(str1);
      stringBuilder.append(", pkg : ");
      stringBuilder.append(str2);
      stringBuilder.append(", rCode : ");
      stringBuilder.append(i);
      f.g(str3, stringBuilder.toString());
      if (Build.VERSION.SDK_INT >= 26) {
        if (TextUtils.isEmpty(str2)) {
          f.b(str3, "broadcastDeRegistrationResult. No mapping PkgName");
          return;
        } 
        intent.setPackage(str2);
      } 
      intent.putExtra("appId", str1);
      intent.putExtra("Error", i);
      intent.putExtra("userSN", paramString);
    } 
    b4.a.b(intent, paramString);
  }
  
  public void g(String paramString1, String paramString2, String paramString3, boolean paramBoolean, int paramInt) {
    d d = new d();
    d.h(paramInt, null, paramString2, paramString1);
    f(d, paramString3, paramBoolean);
  }
  
  public void h(String paramString1, String paramString2) {
    String str = d;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[broadcastDeleteRegInfoNoti] appID : ");
    stringBuilder.append(paramString1);
    stringBuilder.append(" userSN");
    stringBuilder.append(paramString2);
    f.a(str, stringBuilder.toString());
    Intent intent = new Intent(PushClientApplication.c(), RegistrationNotiReceiver.class);
    intent.setAction("com.sec.spp.push.ACTION_DEREGISTRATION_RESULT");
    intent.putExtra("appId", paramString1);
    intent.putExtra("userSN", paramString2);
    b4.a.b(intent, paramString2);
  }
  
  public void i(m paramm, String paramString, boolean paramBoolean) {
    int i;
    Intent intent = new Intent("com.sec.spp.RegistrationChangedAction");
    if (paramBoolean) {
      i = 0;
    } else {
      i = 1;
    } 
    intent.putExtra("com.sec.spp.Status", i);
    if (paramm != null) {
      String str2 = paramm.f();
      String str3 = paramm.g();
      String str4 = paramm.h();
      i = paramm.a();
      String str1 = d;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[RegReply] appid : ");
      stringBuilder.append(str2);
      stringBuilder.append(", regId : ");
      stringBuilder.append(str3);
      stringBuilder.append(", pkg : ");
      stringBuilder.append(str4);
      stringBuilder.append(", rCode : ");
      stringBuilder.append(i);
      f.g(str1, stringBuilder.toString());
      if (Build.VERSION.SDK_INT >= 26) {
        if (TextUtils.isEmpty(str4)) {
          f.b(str1, "broadcastRegistrationResult. No mapping PkgName");
          return;
        } 
        intent.setPackage(str4);
      } 
      intent.putExtra("appId", str2);
      intent.putExtra("RegistrationID", str3);
      intent.putExtra("Error", i);
      intent.putExtra("userSN", paramString);
      b4.a.b(intent, paramString);
    } 
  }
  
  public final void j(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean, int paramInt) {
    m m = new m();
    m.i(paramInt, null, paramString2, paramString3, paramString1);
    i(m, paramString4, paramBoolean);
  }
  
  public void k(String paramString1, String paramString2, String paramString3, String paramString4) {
    String str = paramString1;
    if (paramString1 == null)
      str = "com.sec.spp.RegistrationFail"; 
    Intent intent = new Intent(PushClientApplication.c(), RegistrationNotiReceiver.class);
    intent.setAction("com.sec.spp.push.ACTION_REGISTRATION_RESULT");
    intent.putExtra("appId", str);
    intent.putExtra("RegistrationID", paramString2);
    intent.putExtra("userdata", paramString3);
    intent.putExtra("userSN", paramString4);
    b4.a.b(intent, paramString4);
  }
  
  public void l() {
    synchronized (this.a) {
      int i = CommonPreferences.getInstance().getRegAppCount();
      CommonPreferences.getInstance().setRegAppCount(i - 1);
      String str = d;
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("Reg App Count Dec : ");
      stringBuilder.append(CommonPreferences.getInstance().getRegAppCount());
      f.a(str, stringBuilder.toString());
      return;
    } 
  }
  
  public void m() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : La4/a;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull -> 36
    //   11: getstatic a4/c.d : Ljava/lang/String;
    //   14: ldc_w '[deleteAll] mDbHandler is null'
    //   17: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   20: aload_0
    //   21: getfield b : La4/a;
    //   24: astore_1
    //   25: aload_1
    //   26: ifnull -> 33
    //   29: aload_1
    //   30: invokevirtual b : ()V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: aload_1
    //   37: invokevirtual n : ()La4/a;
    //   40: pop
    //   41: aload_0
    //   42: getfield b : La4/a;
    //   45: invokevirtual c : ()Z
    //   48: pop
    //   49: aload_0
    //   50: getfield b : La4/a;
    //   53: astore_1
    //   54: aload_1
    //   55: ifnull -> 92
    //   58: aload_1
    //   59: invokevirtual b : ()V
    //   62: goto -> 92
    //   65: astore_1
    //   66: goto -> 95
    //   69: astore_1
    //   70: getstatic a4/c.d : Ljava/lang/String;
    //   73: aload_1
    //   74: invokevirtual getMessage : ()Ljava/lang/String;
    //   77: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   80: aload_0
    //   81: getfield b : La4/a;
    //   84: astore_1
    //   85: aload_1
    //   86: ifnull -> 92
    //   89: goto -> 58
    //   92: aload_0
    //   93: monitorexit
    //   94: return
    //   95: aload_0
    //   96: getfield b : La4/a;
    //   99: astore_2
    //   100: aload_2
    //   101: ifnull -> 108
    //   104: aload_2
    //   105: invokevirtual b : ()V
    //   108: aload_1
    //   109: athrow
    //   110: astore_1
    //   111: aload_0
    //   112: monitorexit
    //   113: aload_1
    //   114: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	69	java/lang/Exception
    //   2	7	65	finally
    //   11	20	69	java/lang/Exception
    //   11	20	65	finally
    //   20	25	110	finally
    //   29	33	110	finally
    //   36	49	69	java/lang/Exception
    //   36	49	65	finally
    //   49	54	110	finally
    //   58	62	110	finally
    //   70	80	65	finally
    //   80	85	110	finally
    //   95	100	110	finally
    //   104	108	110	finally
    //   108	110	110	finally
  }
  
  public boolean n(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_3
    //   4: iconst_0
    //   5: istore #4
    //   7: iload_3
    //   8: istore #5
    //   10: aload_0
    //   11: getfield b : La4/a;
    //   14: astore #6
    //   16: aload #6
    //   18: ifnonnull -> 50
    //   21: iload_3
    //   22: istore #5
    //   24: getstatic a4/c.d : Ljava/lang/String;
    //   27: ldc_w '[deleteRegTableEntryByAppId] mDbHandler is null'
    //   30: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   33: aload_0
    //   34: getfield b : La4/a;
    //   37: astore_1
    //   38: aload_1
    //   39: ifnull -> 46
    //   42: aload_1
    //   43: invokevirtual b : ()V
    //   46: aload_0
    //   47: monitorexit
    //   48: iconst_0
    //   49: ireturn
    //   50: iload_3
    //   51: istore #5
    //   53: aload #6
    //   55: invokevirtual n : ()La4/a;
    //   58: pop
    //   59: iload_3
    //   60: istore #5
    //   62: aload_0
    //   63: getfield b : La4/a;
    //   66: aload_1
    //   67: aload_2
    //   68: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;)I
    //   71: iflt -> 77
    //   74: iconst_1
    //   75: istore #4
    //   77: iload #4
    //   79: istore #5
    //   81: aload_0
    //   82: aload_1
    //   83: invokevirtual H : (Ljava/lang/String;)V
    //   86: aload_0
    //   87: getfield b : La4/a;
    //   90: astore_1
    //   91: iload #4
    //   93: istore_3
    //   94: aload_1
    //   95: ifnull -> 171
    //   98: aload_1
    //   99: invokevirtual b : ()V
    //   102: iload #4
    //   104: istore_3
    //   105: goto -> 171
    //   108: astore_2
    //   109: goto -> 209
    //   112: astore #6
    //   114: getstatic a4/c.d : Ljava/lang/String;
    //   117: astore_2
    //   118: new java/lang/StringBuilder
    //   121: astore_1
    //   122: aload_1
    //   123: invokespecial <init> : ()V
    //   126: aload_1
    //   127: ldc_w '[deleteRegTableEntryByAppId] Exception with message ='
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: aload_1
    //   135: aload #6
    //   137: invokevirtual getMessage : ()Ljava/lang/String;
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: aload_2
    //   145: aload_1
    //   146: invokevirtual toString : ()Ljava/lang/String;
    //   149: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   152: aload_0
    //   153: getfield b : La4/a;
    //   156: astore_1
    //   157: iload #5
    //   159: istore_3
    //   160: aload_1
    //   161: ifnull -> 171
    //   164: iload #5
    //   166: istore #4
    //   168: goto -> 98
    //   171: getstatic a4/c.d : Ljava/lang/String;
    //   174: astore_1
    //   175: new java/lang/StringBuilder
    //   178: astore_2
    //   179: aload_2
    //   180: invokespecial <init> : ()V
    //   183: aload_2
    //   184: ldc_w 'deleteRegTableEntryByAppId(appId) returns '
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: aload_2
    //   192: iload_3
    //   193: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   196: pop
    //   197: aload_1
    //   198: aload_2
    //   199: invokevirtual toString : ()Ljava/lang/String;
    //   202: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   205: aload_0
    //   206: monitorexit
    //   207: iload_3
    //   208: ireturn
    //   209: aload_0
    //   210: getfield b : La4/a;
    //   213: astore_1
    //   214: aload_1
    //   215: ifnull -> 222
    //   218: aload_1
    //   219: invokevirtual b : ()V
    //   222: aload_2
    //   223: athrow
    //   224: astore_1
    //   225: aload_0
    //   226: monitorexit
    //   227: aload_1
    //   228: athrow
    // Exception table:
    //   from	to	target	type
    //   10	16	112	java/lang/Exception
    //   10	16	108	finally
    //   24	33	112	java/lang/Exception
    //   24	33	108	finally
    //   33	38	224	finally
    //   42	46	224	finally
    //   53	59	112	java/lang/Exception
    //   53	59	108	finally
    //   62	74	112	java/lang/Exception
    //   62	74	108	finally
    //   81	86	112	java/lang/Exception
    //   81	86	108	finally
    //   86	91	224	finally
    //   98	102	224	finally
    //   114	152	108	finally
    //   152	157	224	finally
    //   171	205	224	finally
    //   209	214	224	finally
    //   218	222	224	finally
    //   222	224	224	finally
  }
  
  public void o() {
    // Byte code:
    //   0: getstatic a4/c.d : Ljava/lang/String;
    //   3: ldc_w 'registrationManager Destroying'
    //   6: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   9: aload_0
    //   10: monitorenter
    //   11: aload_0
    //   12: getfield b : La4/a;
    //   15: ifnull -> 23
    //   18: aload_0
    //   19: aconst_null
    //   20: putfield b : La4/a;
    //   23: aload_0
    //   24: monitorexit
    //   25: ldc a4/c
    //   27: monitorenter
    //   28: getstatic a4/c.f : La4/c;
    //   31: ifnull -> 38
    //   34: aconst_null
    //   35: putstatic a4/c.f : La4/c;
    //   38: ldc a4/c
    //   40: monitorexit
    //   41: return
    //   42: astore_1
    //   43: ldc a4/c
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    //   48: astore_1
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_1
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   11	23	48	finally
    //   23	25	48	finally
    //   28	38	42	finally
    //   38	41	42	finally
    //   43	46	42	finally
    //   49	51	48	finally
  }
  
  public void p(String paramString1, String paramString2, String paramString3) {
    char c1;
    if (TextUtils.isEmpty(paramString1)) {
      f.b(d, "[DEREGISTRATION] appid shouldn't be empty.");
      g(paramString1, paramString2, paramString3, false, 4003);
      return;
    } 
    if (TextUtils.isEmpty(paramString3)) {
      f.b(d, "[DEREGISTRATION] userSN is empty.");
      g(paramString1, paramString2, paramString3, false, 4008);
      return;
    } 
    if (TextUtils.isEmpty(ProvisioningInfo.getDeviceId())) {
      f.b(d, "[DEREGISTRATION] Device ID is empty. Do nothing");
      g(paramString1, paramString2, paramString3, false, -106);
      return;
    } 
    R(paramString1, paramString3, true);
    String str = y(paramString1, paramString3);
    if (!TextUtils.isEmpty(str) && str.startsWith("sppeos_")) {
      c1 = 'ྱ';
    } else {
      c1 = 'Ϩ';
    } 
    g(paramString1, paramString2, paramString3, true, c1);
    P(paramString1, paramString2, paramString3);
  }
  
  public void q(String paramString1, String paramString2, String paramString3) {
    if (k.k) {
      Log.e("SPPC", paramString2);
      f.e(paramString2);
    } 
    if (!p.l()) {
      f.b(d, "[REGISTRATION] Network is not available.");
      j(paramString1, null, paramString2, paramString3, false, 4007);
      return;
    } 
    if (TextUtils.isEmpty(ProvisioningInfo.getDeviceId())) {
      f.b(d, "[REGISTRATION] Device ID is empty. Do nothing");
      j(paramString1, null, paramString2, paramString3, false, -106);
      return;
    } 
    if (TextUtils.isEmpty(paramString1) || TextUtils.isEmpty(paramString2)) {
      f.b(d, "[REGISTRATION] AppId or userData shouldn't be empty.");
      j(paramString1, null, paramString2, paramString3, false, 4003);
      return;
    } 
    Q(paramString1);
    String str = y(paramString1, paramString3);
    boolean bool = E(paramString1, paramString3);
    if (!TextUtils.isEmpty(str) && bool != true) {
      char c1;
      if (str.startsWith("sppeos_")) {
        c1 = 'ྱ';
      } else {
        c1 = 'Ϩ';
      } 
      j(paramString1, str, paramString2, paramString3, true, c1);
      if (f.f() > f.a)
        J(paramString1, paramString2, str); 
      paramString2 = d;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("g: [");
      stringBuilder.append(paramString3);
      stringBuilder.append("]");
      stringBuilder.append(k.m(paramString1));
      f.b(paramString2, stringBuilder.toString());
      return;
    } 
    r3.b.o().g0(paramString1, paramString2, paramString3, new a(this, paramString3, paramString2));
  }
  
  public ArrayList r() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: astore_1
    //   6: aload_1
    //   7: invokespecial <init> : ()V
    //   10: aconst_null
    //   11: astore_2
    //   12: aconst_null
    //   13: astore_3
    //   14: aload_3
    //   15: astore #4
    //   17: aload_2
    //   18: astore #5
    //   20: aload_0
    //   21: getfield b : La4/a;
    //   24: astore #6
    //   26: aload #6
    //   28: ifnonnull -> 66
    //   31: aload_3
    //   32: astore #4
    //   34: aload_2
    //   35: astore #5
    //   37: getstatic a4/c.d : Ljava/lang/String;
    //   40: ldc_w '[getAllRegisteredLists] mDbHandler is null'
    //   43: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   46: aload_0
    //   47: getfield b : La4/a;
    //   50: astore #4
    //   52: aload #4
    //   54: ifnull -> 62
    //   57: aload #4
    //   59: invokevirtual b : ()V
    //   62: aload_0
    //   63: monitorexit
    //   64: aconst_null
    //   65: areturn
    //   66: aload_3
    //   67: astore #4
    //   69: aload_2
    //   70: astore #5
    //   72: aload #6
    //   74: invokevirtual n : ()La4/a;
    //   77: pop
    //   78: aload_3
    //   79: astore #4
    //   81: aload_2
    //   82: astore #5
    //   84: aload_0
    //   85: getfield b : La4/a;
    //   88: invokevirtual e : ()Landroid/database/Cursor;
    //   91: astore_3
    //   92: aload_3
    //   93: ifnull -> 232
    //   96: aload_3
    //   97: astore #4
    //   99: aload_3
    //   100: astore #5
    //   102: aload_3
    //   103: invokeinterface moveToNext : ()Z
    //   108: ifeq -> 232
    //   111: aload_3
    //   112: astore #4
    //   114: aload_3
    //   115: astore #5
    //   117: aload_3
    //   118: iconst_0
    //   119: invokeinterface getString : (I)Ljava/lang/String;
    //   124: astore #7
    //   126: aload_3
    //   127: astore #4
    //   129: aload_3
    //   130: astore #5
    //   132: aload_3
    //   133: iconst_3
    //   134: invokeinterface getString : (I)Ljava/lang/String;
    //   139: astore #8
    //   141: aload_3
    //   142: astore #4
    //   144: aload_3
    //   145: astore #5
    //   147: aload_3
    //   148: iconst_1
    //   149: invokeinterface getString : (I)Ljava/lang/String;
    //   154: astore_2
    //   155: aload_3
    //   156: astore #4
    //   158: aload_3
    //   159: astore #5
    //   161: aload_3
    //   162: iconst_5
    //   163: invokeinterface getString : (I)Ljava/lang/String;
    //   168: astore #9
    //   170: aload_3
    //   171: astore #4
    //   173: aload_3
    //   174: astore #5
    //   176: aload_3
    //   177: iconst_4
    //   178: invokeinterface getString : (I)Ljava/lang/String;
    //   183: astore #6
    //   185: aload_3
    //   186: astore #4
    //   188: aload_3
    //   189: astore #5
    //   191: new b4/n
    //   194: astore #10
    //   196: aload_3
    //   197: astore #4
    //   199: aload_3
    //   200: astore #5
    //   202: aload #10
    //   204: aload #7
    //   206: aload_2
    //   207: aload #8
    //   209: aload #9
    //   211: aload #6
    //   213: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   216: aload_3
    //   217: astore #4
    //   219: aload_3
    //   220: astore #5
    //   222: aload_1
    //   223: aload #10
    //   225: invokevirtual add : (Ljava/lang/Object;)Z
    //   228: pop
    //   229: goto -> 96
    //   232: aload_3
    //   233: ifnull -> 242
    //   236: aload_3
    //   237: invokeinterface close : ()V
    //   242: aload_0
    //   243: getfield b : La4/a;
    //   246: astore #4
    //   248: aload #4
    //   250: ifnull -> 356
    //   253: aload #4
    //   255: invokevirtual b : ()V
    //   258: goto -> 356
    //   261: astore #5
    //   263: goto -> 404
    //   266: astore #6
    //   268: aload #5
    //   270: astore #4
    //   272: getstatic a4/c.d : Ljava/lang/String;
    //   275: astore_3
    //   276: aload #5
    //   278: astore #4
    //   280: new java/lang/StringBuilder
    //   283: astore_2
    //   284: aload #5
    //   286: astore #4
    //   288: aload_2
    //   289: invokespecial <init> : ()V
    //   292: aload #5
    //   294: astore #4
    //   296: aload_2
    //   297: ldc_w '[getAllRegisteredLists()] Exception with message ='
    //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: pop
    //   304: aload #5
    //   306: astore #4
    //   308: aload_2
    //   309: aload #6
    //   311: invokevirtual getMessage : ()Ljava/lang/String;
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: aload #5
    //   320: astore #4
    //   322: aload_3
    //   323: aload_2
    //   324: invokevirtual toString : ()Ljava/lang/String;
    //   327: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   330: aload #5
    //   332: ifnull -> 342
    //   335: aload #5
    //   337: invokeinterface close : ()V
    //   342: aload_0
    //   343: getfield b : La4/a;
    //   346: astore #4
    //   348: aload #4
    //   350: ifnull -> 356
    //   353: goto -> 253
    //   356: getstatic a4/c.d : Ljava/lang/String;
    //   359: astore #4
    //   361: new java/lang/StringBuilder
    //   364: astore #5
    //   366: aload #5
    //   368: invokespecial <init> : ()V
    //   371: aload #5
    //   373: ldc_w '[Reg App] Number of Reg Apps : '
    //   376: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   379: pop
    //   380: aload #5
    //   382: aload_1
    //   383: invokevirtual size : ()I
    //   386: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   389: pop
    //   390: aload #4
    //   392: aload #5
    //   394: invokevirtual toString : ()Ljava/lang/String;
    //   397: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   400: aload_0
    //   401: monitorexit
    //   402: aload_1
    //   403: areturn
    //   404: aload #4
    //   406: ifnull -> 416
    //   409: aload #4
    //   411: invokeinterface close : ()V
    //   416: aload_0
    //   417: getfield b : La4/a;
    //   420: astore #4
    //   422: aload #4
    //   424: ifnull -> 432
    //   427: aload #4
    //   429: invokevirtual b : ()V
    //   432: aload #5
    //   434: athrow
    //   435: astore #4
    //   437: aload_0
    //   438: monitorexit
    //   439: aload #4
    //   441: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	435	finally
    //   20	26	266	java/lang/Exception
    //   20	26	261	finally
    //   37	46	266	java/lang/Exception
    //   37	46	261	finally
    //   46	52	435	finally
    //   57	62	435	finally
    //   72	78	266	java/lang/Exception
    //   72	78	261	finally
    //   84	92	266	java/lang/Exception
    //   84	92	261	finally
    //   102	111	266	java/lang/Exception
    //   102	111	261	finally
    //   117	126	266	java/lang/Exception
    //   117	126	261	finally
    //   132	141	266	java/lang/Exception
    //   132	141	261	finally
    //   147	155	266	java/lang/Exception
    //   147	155	261	finally
    //   161	170	266	java/lang/Exception
    //   161	170	261	finally
    //   176	185	266	java/lang/Exception
    //   176	185	261	finally
    //   191	196	266	java/lang/Exception
    //   191	196	261	finally
    //   202	216	266	java/lang/Exception
    //   202	216	261	finally
    //   222	229	266	java/lang/Exception
    //   222	229	261	finally
    //   236	242	435	finally
    //   242	248	435	finally
    //   253	258	435	finally
    //   272	276	261	finally
    //   280	284	261	finally
    //   288	292	261	finally
    //   296	304	261	finally
    //   308	318	261	finally
    //   322	330	261	finally
    //   335	342	435	finally
    //   342	348	435	finally
    //   356	400	435	finally
    //   409	416	435	finally
    //   416	422	435	finally
    //   427	432	435	finally
    //   432	435	435	finally
  }
  
  public void s(Handler paramHandler) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore_2
    //   4: aconst_null
    //   5: astore_3
    //   6: aload_3
    //   7: astore #4
    //   9: aload_2
    //   10: astore #5
    //   12: aload_0
    //   13: getfield b : La4/a;
    //   16: astore #6
    //   18: aload #6
    //   20: ifnonnull -> 54
    //   23: aload_3
    //   24: astore #4
    //   26: aload_2
    //   27: astore #5
    //   29: getstatic a4/c.d : Ljava/lang/String;
    //   32: ldc_w '[getAllRegisteredLists] mDbHandler is null'
    //   35: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   38: aload_0
    //   39: getfield b : La4/a;
    //   42: astore_1
    //   43: aload_1
    //   44: ifnull -> 51
    //   47: aload_1
    //   48: invokevirtual b : ()V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: aload_3
    //   55: astore #4
    //   57: aload_2
    //   58: astore #5
    //   60: aload #6
    //   62: invokevirtual n : ()La4/a;
    //   65: pop
    //   66: aload_3
    //   67: astore #4
    //   69: aload_2
    //   70: astore #5
    //   72: aload_0
    //   73: getfield b : La4/a;
    //   76: invokevirtual e : ()Landroid/database/Cursor;
    //   79: astore_3
    //   80: aload_3
    //   81: ifnull -> 472
    //   84: aload_3
    //   85: astore #4
    //   87: aload_3
    //   88: astore #5
    //   90: new java/lang/StringBuilder
    //   93: astore_2
    //   94: aload_3
    //   95: astore #4
    //   97: aload_3
    //   98: astore #5
    //   100: aload_2
    //   101: invokespecial <init> : ()V
    //   104: iconst_0
    //   105: istore #7
    //   107: aload_3
    //   108: astore #4
    //   110: aload_3
    //   111: astore #5
    //   113: aload_3
    //   114: invokeinterface moveToNext : ()Z
    //   119: ifeq -> 365
    //   122: aload_3
    //   123: astore #4
    //   125: aload_3
    //   126: astore #5
    //   128: aload_3
    //   129: iconst_0
    //   130: invokeinterface getString : (I)Ljava/lang/String;
    //   135: astore #8
    //   137: aload_3
    //   138: astore #4
    //   140: aload_3
    //   141: astore #5
    //   143: aload_3
    //   144: iconst_3
    //   145: invokeinterface getString : (I)Ljava/lang/String;
    //   150: astore #6
    //   152: aload_3
    //   153: astore #4
    //   155: aload_3
    //   156: astore #5
    //   158: aload_3
    //   159: iconst_5
    //   160: invokeinterface getString : (I)Ljava/lang/String;
    //   165: astore #9
    //   167: aload_3
    //   168: astore #4
    //   170: aload_3
    //   171: astore #5
    //   173: aload_3
    //   174: iconst_1
    //   175: invokeinterface getString : (I)Ljava/lang/String;
    //   180: astore #10
    //   182: aload_3
    //   183: astore #4
    //   185: aload_3
    //   186: astore #5
    //   188: aload_3
    //   189: iconst_4
    //   190: invokeinterface getString : (I)Ljava/lang/String;
    //   195: astore #11
    //   197: iinc #7, 1
    //   200: aload_3
    //   201: astore #4
    //   203: aload_3
    //   204: astore #5
    //   206: aload_2
    //   207: iload #7
    //   209: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload_3
    //   214: astore #4
    //   216: aload_3
    //   217: astore #5
    //   219: aload_2
    //   220: ldc_w '] '
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload_3
    //   228: astore #4
    //   230: aload_3
    //   231: astore #5
    //   233: aload_2
    //   234: aload #6
    //   236: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   239: pop
    //   240: aload_3
    //   241: astore #4
    //   243: aload_3
    //   244: astore #5
    //   246: aload_2
    //   247: ldc_w ', \\n'
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload_3
    //   255: astore #4
    //   257: aload_3
    //   258: astore #5
    //   260: aload_2
    //   261: aload #8
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: pop
    //   267: aload_3
    //   268: astore #4
    //   270: aload_3
    //   271: astore #5
    //   273: aload_2
    //   274: ldc_w ', '
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: pop
    //   281: aload_3
    //   282: astore #4
    //   284: aload_3
    //   285: astore #5
    //   287: aload_2
    //   288: aload #9
    //   290: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   293: pop
    //   294: aload_3
    //   295: astore #4
    //   297: aload_3
    //   298: astore #5
    //   300: aload_2
    //   301: ldc_w ', Dereg : '
    //   304: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   307: pop
    //   308: aload_3
    //   309: astore #4
    //   311: aload_3
    //   312: astore #5
    //   314: aload_2
    //   315: aload #11
    //   317: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   320: pop
    //   321: aload_3
    //   322: astore #4
    //   324: aload_3
    //   325: astore #5
    //   327: aload_2
    //   328: ldc_w ', \\n'
    //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload_3
    //   336: astore #4
    //   338: aload_3
    //   339: astore #5
    //   341: aload_2
    //   342: aload #10
    //   344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   347: pop
    //   348: aload_3
    //   349: astore #4
    //   351: aload_3
    //   352: astore #5
    //   354: aload_2
    //   355: ldc_w '\\n\\n'
    //   358: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   361: pop
    //   362: goto -> 107
    //   365: aload_3
    //   366: astore #4
    //   368: aload_3
    //   369: astore #5
    //   371: aload_1
    //   372: invokestatic obtain : (Landroid/os/Handler;)Landroid/os/Message;
    //   375: astore #8
    //   377: aload_3
    //   378: astore #4
    //   380: aload_3
    //   381: astore #5
    //   383: aload #8
    //   385: bipush #11
    //   387: putfield what : I
    //   390: aload_3
    //   391: astore #4
    //   393: aload_3
    //   394: astore #5
    //   396: new android/os/Bundle
    //   399: astore #6
    //   401: aload_3
    //   402: astore #4
    //   404: aload_3
    //   405: astore #5
    //   407: aload #6
    //   409: invokespecial <init> : ()V
    //   412: aload_3
    //   413: astore #4
    //   415: aload_3
    //   416: astore #5
    //   418: aload #6
    //   420: ldc_w 'MSG_BUNDLE_STRING_DATA'
    //   423: aload_2
    //   424: invokevirtual toString : ()Ljava/lang/String;
    //   427: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
    //   430: aload_3
    //   431: astore #4
    //   433: aload_3
    //   434: astore #5
    //   436: getstatic a4/c.d : Ljava/lang/String;
    //   439: aload_2
    //   440: invokevirtual toString : ()Ljava/lang/String;
    //   443: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   446: aload_3
    //   447: astore #4
    //   449: aload_3
    //   450: astore #5
    //   452: aload #8
    //   454: aload #6
    //   456: invokevirtual setData : (Landroid/os/Bundle;)V
    //   459: aload_3
    //   460: astore #4
    //   462: aload_3
    //   463: astore #5
    //   465: aload_1
    //   466: aload #8
    //   468: invokevirtual sendMessage : (Landroid/os/Message;)Z
    //   471: pop
    //   472: aload_3
    //   473: ifnull -> 482
    //   476: aload_3
    //   477: invokeinterface close : ()V
    //   482: aload_0
    //   483: getfield b : La4/a;
    //   486: astore_1
    //   487: aload_1
    //   488: ifnull -> 541
    //   491: aload_1
    //   492: invokevirtual b : ()V
    //   495: goto -> 541
    //   498: astore_1
    //   499: goto -> 544
    //   502: astore_1
    //   503: aload #5
    //   505: astore #4
    //   507: getstatic a4/c.d : Ljava/lang/String;
    //   510: aload_1
    //   511: invokevirtual getMessage : ()Ljava/lang/String;
    //   514: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   517: aload #5
    //   519: ifnull -> 529
    //   522: aload #5
    //   524: invokeinterface close : ()V
    //   529: aload_0
    //   530: getfield b : La4/a;
    //   533: astore_1
    //   534: aload_1
    //   535: ifnull -> 541
    //   538: goto -> 491
    //   541: aload_0
    //   542: monitorexit
    //   543: return
    //   544: aload #4
    //   546: ifnull -> 556
    //   549: aload #4
    //   551: invokeinterface close : ()V
    //   556: aload_0
    //   557: getfield b : La4/a;
    //   560: astore #4
    //   562: aload #4
    //   564: ifnull -> 572
    //   567: aload #4
    //   569: invokevirtual b : ()V
    //   572: aload_1
    //   573: athrow
    //   574: astore_1
    //   575: aload_0
    //   576: monitorexit
    //   577: aload_1
    //   578: athrow
    // Exception table:
    //   from	to	target	type
    //   12	18	502	java/lang/Exception
    //   12	18	498	finally
    //   29	38	502	java/lang/Exception
    //   29	38	498	finally
    //   38	43	574	finally
    //   47	51	574	finally
    //   60	66	502	java/lang/Exception
    //   60	66	498	finally
    //   72	80	502	java/lang/Exception
    //   72	80	498	finally
    //   90	94	502	java/lang/Exception
    //   90	94	498	finally
    //   100	104	502	java/lang/Exception
    //   100	104	498	finally
    //   113	122	502	java/lang/Exception
    //   113	122	498	finally
    //   128	137	502	java/lang/Exception
    //   128	137	498	finally
    //   143	152	502	java/lang/Exception
    //   143	152	498	finally
    //   158	167	502	java/lang/Exception
    //   158	167	498	finally
    //   173	182	502	java/lang/Exception
    //   173	182	498	finally
    //   188	197	502	java/lang/Exception
    //   188	197	498	finally
    //   206	213	502	java/lang/Exception
    //   206	213	498	finally
    //   219	227	502	java/lang/Exception
    //   219	227	498	finally
    //   233	240	502	java/lang/Exception
    //   233	240	498	finally
    //   246	254	502	java/lang/Exception
    //   246	254	498	finally
    //   260	267	502	java/lang/Exception
    //   260	267	498	finally
    //   273	281	502	java/lang/Exception
    //   273	281	498	finally
    //   287	294	502	java/lang/Exception
    //   287	294	498	finally
    //   300	308	502	java/lang/Exception
    //   300	308	498	finally
    //   314	321	502	java/lang/Exception
    //   314	321	498	finally
    //   327	335	502	java/lang/Exception
    //   327	335	498	finally
    //   341	348	502	java/lang/Exception
    //   341	348	498	finally
    //   354	362	502	java/lang/Exception
    //   354	362	498	finally
    //   371	377	502	java/lang/Exception
    //   371	377	498	finally
    //   383	390	502	java/lang/Exception
    //   383	390	498	finally
    //   396	401	502	java/lang/Exception
    //   396	401	498	finally
    //   407	412	502	java/lang/Exception
    //   407	412	498	finally
    //   418	430	502	java/lang/Exception
    //   418	430	498	finally
    //   436	446	502	java/lang/Exception
    //   436	446	498	finally
    //   452	459	502	java/lang/Exception
    //   452	459	498	finally
    //   465	472	502	java/lang/Exception
    //   465	472	498	finally
    //   476	482	574	finally
    //   482	487	574	finally
    //   491	495	574	finally
    //   507	517	498	finally
    //   522	529	574	finally
    //   529	534	574	finally
    //   549	556	574	finally
    //   556	562	574	finally
    //   567	572	574	finally
    //   572	574	574	finally
  }
  
  public ArrayList t() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/ArrayList
    //   5: astore_1
    //   6: aload_1
    //   7: invokespecial <init> : ()V
    //   10: aconst_null
    //   11: astore_2
    //   12: aconst_null
    //   13: astore_3
    //   14: aload_3
    //   15: astore #4
    //   17: aload_2
    //   18: astore #5
    //   20: aload_0
    //   21: getfield b : La4/a;
    //   24: astore #6
    //   26: aload #6
    //   28: ifnonnull -> 66
    //   31: aload_3
    //   32: astore #4
    //   34: aload_2
    //   35: astore #5
    //   37: getstatic a4/c.d : Ljava/lang/String;
    //   40: ldc_w '[getAllUserSN] mDbHandler is null'
    //   43: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   46: aload_0
    //   47: getfield b : La4/a;
    //   50: astore #4
    //   52: aload #4
    //   54: ifnull -> 62
    //   57: aload #4
    //   59: invokevirtual b : ()V
    //   62: aload_0
    //   63: monitorexit
    //   64: aconst_null
    //   65: areturn
    //   66: aload_3
    //   67: astore #4
    //   69: aload_2
    //   70: astore #5
    //   72: aload #6
    //   74: invokevirtual n : ()La4/a;
    //   77: pop
    //   78: aload_3
    //   79: astore #4
    //   81: aload_2
    //   82: astore #5
    //   84: aload_0
    //   85: getfield b : La4/a;
    //   88: invokevirtual f : ()Landroid/database/Cursor;
    //   91: astore_3
    //   92: aload_3
    //   93: ifnull -> 168
    //   96: aload_3
    //   97: astore #4
    //   99: aload_3
    //   100: astore #5
    //   102: aload_3
    //   103: invokeinterface moveToFirst : ()Z
    //   108: ifeq -> 168
    //   111: aload_3
    //   112: astore #4
    //   114: aload_3
    //   115: astore #5
    //   117: aload_3
    //   118: iconst_0
    //   119: invokeinterface getLong : (I)J
    //   124: lstore #7
    //   126: lload #7
    //   128: lconst_0
    //   129: lcmp
    //   130: ifeq -> 149
    //   133: aload_3
    //   134: astore #4
    //   136: aload_3
    //   137: astore #5
    //   139: aload_1
    //   140: lload #7
    //   142: invokestatic valueOf : (J)Ljava/lang/Long;
    //   145: invokevirtual add : (Ljava/lang/Object;)Z
    //   148: pop
    //   149: aload_3
    //   150: astore #4
    //   152: aload_3
    //   153: astore #5
    //   155: aload_3
    //   156: invokeinterface moveToNext : ()Z
    //   161: istore #9
    //   163: iload #9
    //   165: ifne -> 111
    //   168: aload_3
    //   169: ifnull -> 178
    //   172: aload_3
    //   173: invokeinterface close : ()V
    //   178: aload_0
    //   179: getfield b : La4/a;
    //   182: astore #4
    //   184: aload #4
    //   186: ifnull -> 292
    //   189: aload #4
    //   191: invokevirtual b : ()V
    //   194: goto -> 292
    //   197: astore #5
    //   199: goto -> 296
    //   202: astore_2
    //   203: aload #5
    //   205: astore #4
    //   207: getstatic a4/c.d : Ljava/lang/String;
    //   210: astore #6
    //   212: aload #5
    //   214: astore #4
    //   216: new java/lang/StringBuilder
    //   219: astore_3
    //   220: aload #5
    //   222: astore #4
    //   224: aload_3
    //   225: invokespecial <init> : ()V
    //   228: aload #5
    //   230: astore #4
    //   232: aload_3
    //   233: ldc_w '[getAllUserSN()] Exception with message ='
    //   236: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   239: pop
    //   240: aload #5
    //   242: astore #4
    //   244: aload_3
    //   245: aload_2
    //   246: invokevirtual getMessage : ()Ljava/lang/String;
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload #5
    //   255: astore #4
    //   257: aload #6
    //   259: aload_3
    //   260: invokevirtual toString : ()Ljava/lang/String;
    //   263: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   266: aload #5
    //   268: ifnull -> 278
    //   271: aload #5
    //   273: invokeinterface close : ()V
    //   278: aload_0
    //   279: getfield b : La4/a;
    //   282: astore #4
    //   284: aload #4
    //   286: ifnull -> 292
    //   289: goto -> 189
    //   292: aload_0
    //   293: monitorexit
    //   294: aload_1
    //   295: areturn
    //   296: aload #4
    //   298: ifnull -> 308
    //   301: aload #4
    //   303: invokeinterface close : ()V
    //   308: aload_0
    //   309: getfield b : La4/a;
    //   312: astore #4
    //   314: aload #4
    //   316: ifnull -> 324
    //   319: aload #4
    //   321: invokevirtual b : ()V
    //   324: aload #5
    //   326: athrow
    //   327: astore #4
    //   329: aload_0
    //   330: monitorexit
    //   331: aload #4
    //   333: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	327	finally
    //   20	26	202	java/lang/Exception
    //   20	26	197	finally
    //   37	46	202	java/lang/Exception
    //   37	46	197	finally
    //   46	52	327	finally
    //   57	62	327	finally
    //   72	78	202	java/lang/Exception
    //   72	78	197	finally
    //   84	92	202	java/lang/Exception
    //   84	92	197	finally
    //   102	111	202	java/lang/Exception
    //   102	111	197	finally
    //   117	126	202	java/lang/Exception
    //   117	126	197	finally
    //   139	149	202	java/lang/Exception
    //   139	149	197	finally
    //   155	163	202	java/lang/Exception
    //   155	163	197	finally
    //   172	178	327	finally
    //   178	184	327	finally
    //   189	194	327	finally
    //   207	212	197	finally
    //   216	220	197	finally
    //   224	228	197	finally
    //   232	240	197	finally
    //   244	253	197	finally
    //   257	266	197	finally
    //   271	278	327	finally
    //   278	284	327	finally
    //   301	308	327	finally
    //   308	314	327	finally
    //   319	324	327	finally
    //   324	327	327	finally
  }
  
  public String u(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: istore_3
    //   7: aconst_null
    //   8: astore #4
    //   10: aconst_null
    //   11: astore #5
    //   13: aconst_null
    //   14: astore #6
    //   16: aconst_null
    //   17: astore #7
    //   19: iload_3
    //   20: ifne -> 502
    //   23: aload_2
    //   24: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   27: istore_3
    //   28: iload_3
    //   29: ifeq -> 35
    //   32: goto -> 502
    //   35: aload #5
    //   37: astore #8
    //   39: aload_0
    //   40: getfield b : La4/a;
    //   43: astore #9
    //   45: aload #9
    //   47: ifnonnull -> 80
    //   50: aload #5
    //   52: astore #8
    //   54: getstatic a4/c.d : Ljava/lang/String;
    //   57: ldc_w '[getAppId] mDbHandler is null'
    //   60: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   63: aload_0
    //   64: getfield b : La4/a;
    //   67: astore_1
    //   68: aload_1
    //   69: ifnull -> 76
    //   72: aload_1
    //   73: invokevirtual b : ()V
    //   76: aload_0
    //   77: monitorexit
    //   78: aconst_null
    //   79: areturn
    //   80: aload #5
    //   82: astore #8
    //   84: aload #9
    //   86: invokevirtual n : ()La4/a;
    //   89: pop
    //   90: aload #5
    //   92: astore #8
    //   94: aload_0
    //   95: getfield b : La4/a;
    //   98: aload_1
    //   99: aload_2
    //   100: invokevirtual j : (Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 139
    //   110: aload #5
    //   112: ifnull -> 122
    //   115: aload #5
    //   117: invokeinterface close : ()V
    //   122: aload_0
    //   123: getfield b : La4/a;
    //   126: astore_1
    //   127: aload_1
    //   128: ifnull -> 135
    //   131: aload_1
    //   132: invokevirtual b : ()V
    //   135: aload_0
    //   136: monitorexit
    //   137: aconst_null
    //   138: areturn
    //   139: aload #4
    //   141: astore #8
    //   143: aload #5
    //   145: invokeinterface moveToFirst : ()Z
    //   150: istore_3
    //   151: aload #7
    //   153: astore #8
    //   155: iload_3
    //   156: ifne -> 183
    //   159: aload #5
    //   161: invokeinterface close : ()V
    //   166: aload_0
    //   167: getfield b : La4/a;
    //   170: astore_1
    //   171: aload_1
    //   172: ifnull -> 179
    //   175: aload_1
    //   176: invokevirtual b : ()V
    //   179: aload_0
    //   180: monitorexit
    //   181: aconst_null
    //   182: areturn
    //   183: aload #5
    //   185: iconst_0
    //   186: invokeinterface getString : (I)Ljava/lang/String;
    //   191: astore #7
    //   193: aload #7
    //   195: astore #8
    //   197: getstatic a4/c.d : Ljava/lang/String;
    //   200: astore #4
    //   202: aload #7
    //   204: astore #8
    //   206: new java/lang/StringBuilder
    //   209: astore #6
    //   211: aload #7
    //   213: astore #8
    //   215: aload #6
    //   217: invokespecial <init> : ()V
    //   220: aload #7
    //   222: astore #8
    //   224: aload #6
    //   226: ldc_w 'pkgName : '
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #7
    //   235: astore #8
    //   237: aload #6
    //   239: aload_1
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload #7
    //   246: astore #8
    //   248: aload #6
    //   250: ldc_w ' userSN : '
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload #7
    //   259: astore #8
    //   261: aload #6
    //   263: aload_2
    //   264: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   267: pop
    //   268: aload #7
    //   270: astore #8
    //   272: aload #6
    //   274: ldc_w ' appID :'
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: pop
    //   281: aload #7
    //   283: astore #8
    //   285: aload #6
    //   287: aload #7
    //   289: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   292: pop
    //   293: aload #7
    //   295: astore #8
    //   297: aload #4
    //   299: aload #6
    //   301: invokevirtual toString : ()Ljava/lang/String;
    //   304: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   307: aload #7
    //   309: astore #8
    //   311: aload #5
    //   313: invokeinterface moveToNext : ()Z
    //   318: istore_3
    //   319: aload #7
    //   321: astore #8
    //   323: iload_3
    //   324: ifne -> 183
    //   327: aload #5
    //   329: invokeinterface close : ()V
    //   334: aload_0
    //   335: getfield b : La4/a;
    //   338: astore_2
    //   339: aload #7
    //   341: astore_1
    //   342: aload_2
    //   343: ifnull -> 471
    //   346: aload_2
    //   347: invokevirtual b : ()V
    //   350: aload #7
    //   352: astore_1
    //   353: goto -> 471
    //   356: astore_1
    //   357: aload #5
    //   359: astore #8
    //   361: goto -> 475
    //   364: astore #7
    //   366: aload #8
    //   368: astore_1
    //   369: aload #5
    //   371: astore_2
    //   372: goto -> 386
    //   375: astore_1
    //   376: goto -> 475
    //   379: astore #7
    //   381: aconst_null
    //   382: astore_1
    //   383: aload #6
    //   385: astore_2
    //   386: aload_2
    //   387: astore #8
    //   389: getstatic a4/c.d : Ljava/lang/String;
    //   392: astore #5
    //   394: aload_2
    //   395: astore #8
    //   397: new java/lang/StringBuilder
    //   400: astore #6
    //   402: aload_2
    //   403: astore #8
    //   405: aload #6
    //   407: invokespecial <init> : ()V
    //   410: aload_2
    //   411: astore #8
    //   413: aload #6
    //   415: ldc '[getAppId()] Exception with message ='
    //   417: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   420: pop
    //   421: aload_2
    //   422: astore #8
    //   424: aload #6
    //   426: aload #7
    //   428: invokevirtual getMessage : ()Ljava/lang/String;
    //   431: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   434: pop
    //   435: aload_2
    //   436: astore #8
    //   438: aload #5
    //   440: aload #6
    //   442: invokevirtual toString : ()Ljava/lang/String;
    //   445: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   448: aload_2
    //   449: ifnull -> 458
    //   452: aload_2
    //   453: invokeinterface close : ()V
    //   458: aload_0
    //   459: getfield b : La4/a;
    //   462: astore_2
    //   463: aload_2
    //   464: ifnull -> 471
    //   467: aload_2
    //   468: invokevirtual b : ()V
    //   471: aload_0
    //   472: monitorexit
    //   473: aload_1
    //   474: areturn
    //   475: aload #8
    //   477: ifnull -> 487
    //   480: aload #8
    //   482: invokeinterface close : ()V
    //   487: aload_0
    //   488: getfield b : La4/a;
    //   491: astore_2
    //   492: aload_2
    //   493: ifnull -> 500
    //   496: aload_2
    //   497: invokevirtual b : ()V
    //   500: aload_1
    //   501: athrow
    //   502: aload_0
    //   503: monitorexit
    //   504: aconst_null
    //   505: areturn
    //   506: astore_1
    //   507: aload_0
    //   508: monitorexit
    //   509: aload_1
    //   510: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	506	finally
    //   23	28	506	finally
    //   39	45	379	java/lang/Exception
    //   39	45	375	finally
    //   54	63	379	java/lang/Exception
    //   54	63	375	finally
    //   63	68	506	finally
    //   72	76	506	finally
    //   84	90	379	java/lang/Exception
    //   84	90	375	finally
    //   94	105	379	java/lang/Exception
    //   94	105	375	finally
    //   115	122	506	finally
    //   122	127	506	finally
    //   131	135	506	finally
    //   143	151	364	java/lang/Exception
    //   143	151	356	finally
    //   159	171	506	finally
    //   175	179	506	finally
    //   183	193	364	java/lang/Exception
    //   183	193	356	finally
    //   197	202	364	java/lang/Exception
    //   197	202	356	finally
    //   206	211	364	java/lang/Exception
    //   206	211	356	finally
    //   215	220	364	java/lang/Exception
    //   215	220	356	finally
    //   224	233	364	java/lang/Exception
    //   224	233	356	finally
    //   237	244	364	java/lang/Exception
    //   237	244	356	finally
    //   248	257	364	java/lang/Exception
    //   248	257	356	finally
    //   261	268	364	java/lang/Exception
    //   261	268	356	finally
    //   272	281	364	java/lang/Exception
    //   272	281	356	finally
    //   285	293	364	java/lang/Exception
    //   285	293	356	finally
    //   297	307	364	java/lang/Exception
    //   297	307	356	finally
    //   311	319	364	java/lang/Exception
    //   311	319	356	finally
    //   327	339	506	finally
    //   346	350	506	finally
    //   389	394	375	finally
    //   397	402	375	finally
    //   405	410	375	finally
    //   413	421	375	finally
    //   424	435	375	finally
    //   438	448	375	finally
    //   452	458	506	finally
    //   458	463	506	finally
    //   467	471	506	finally
    //   480	487	506	finally
    //   487	492	506	finally
    //   496	500	506	finally
    //   500	502	506	finally
  }
  
  public String v(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: istore_2
    //   7: aconst_null
    //   8: astore_3
    //   9: aconst_null
    //   10: astore #4
    //   12: aconst_null
    //   13: astore #5
    //   15: aconst_null
    //   16: astore #6
    //   18: iload_2
    //   19: ifeq -> 26
    //   22: aload_0
    //   23: monitorexit
    //   24: aconst_null
    //   25: areturn
    //   26: aload_0
    //   27: getfield b : La4/a;
    //   30: astore #7
    //   32: aload #7
    //   34: ifnonnull -> 63
    //   37: getstatic a4/c.d : Ljava/lang/String;
    //   40: ldc_w '[getAppIdWithRegId] mDbHandler is null'
    //   43: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   46: aload_0
    //   47: getfield b : La4/a;
    //   50: astore_1
    //   51: aload_1
    //   52: ifnull -> 59
    //   55: aload_1
    //   56: invokevirtual b : ()V
    //   59: aload_0
    //   60: monitorexit
    //   61: aconst_null
    //   62: areturn
    //   63: aload #7
    //   65: invokevirtual n : ()La4/a;
    //   68: pop
    //   69: aload_0
    //   70: getfield b : La4/a;
    //   73: aload_1
    //   74: invokevirtual i : (Ljava/lang/String;)Landroid/database/Cursor;
    //   77: astore #7
    //   79: aload #7
    //   81: ifnull -> 126
    //   84: aload #7
    //   86: invokeinterface moveToFirst : ()Z
    //   91: pop
    //   92: aload #7
    //   94: iconst_0
    //   95: invokeinterface getString : (I)Ljava/lang/String;
    //   100: astore #6
    //   102: goto -> 126
    //   105: astore #6
    //   107: aload #7
    //   109: astore_1
    //   110: goto -> 327
    //   113: astore #5
    //   115: aload #7
    //   117: astore #6
    //   119: aload #5
    //   121: astore #7
    //   123: goto -> 179
    //   126: aload #7
    //   128: ifnull -> 138
    //   131: aload #7
    //   133: invokeinterface close : ()V
    //   138: aload_0
    //   139: getfield b : La4/a;
    //   142: astore_3
    //   143: aload #6
    //   145: astore #7
    //   147: aload_3
    //   148: ifnull -> 260
    //   151: aload_3
    //   152: astore #7
    //   154: aload #7
    //   156: invokevirtual b : ()V
    //   159: aload #6
    //   161: astore #7
    //   163: goto -> 260
    //   166: astore #6
    //   168: aload #5
    //   170: astore_1
    //   171: goto -> 327
    //   174: astore #7
    //   176: aconst_null
    //   177: astore #6
    //   179: getstatic a4/c.d : Ljava/lang/String;
    //   182: astore #5
    //   184: new java/lang/StringBuilder
    //   187: astore #8
    //   189: aload #8
    //   191: invokespecial <init> : ()V
    //   194: aload #8
    //   196: ldc '[getAppId()] Exception with message ='
    //   198: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   201: pop
    //   202: aload #8
    //   204: aload #7
    //   206: invokevirtual getMessage : ()Ljava/lang/String;
    //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload #5
    //   215: aload #8
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   223: aload #6
    //   225: ifnull -> 235
    //   228: aload #6
    //   230: invokeinterface close : ()V
    //   235: aload_0
    //   236: getfield b : La4/a;
    //   239: astore #6
    //   241: aload #4
    //   243: astore #7
    //   245: aload #6
    //   247: ifnull -> 260
    //   250: aload #6
    //   252: astore #7
    //   254: aload_3
    //   255: astore #6
    //   257: goto -> 154
    //   260: getstatic a4/c.d : Ljava/lang/String;
    //   263: astore #6
    //   265: new java/lang/StringBuilder
    //   268: astore_3
    //   269: aload_3
    //   270: invokespecial <init> : ()V
    //   273: aload_3
    //   274: ldc_w 'RegID: '
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: pop
    //   281: aload_3
    //   282: aload_1
    //   283: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: pop
    //   287: aload_3
    //   288: ldc_w ', appId : '
    //   291: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   294: pop
    //   295: aload_3
    //   296: aload #7
    //   298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   301: pop
    //   302: aload #6
    //   304: aload_3
    //   305: invokevirtual toString : ()Ljava/lang/String;
    //   308: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   311: aload_0
    //   312: monitorexit
    //   313: aload #7
    //   315: areturn
    //   316: astore_1
    //   317: aload #6
    //   319: astore #7
    //   321: aload_1
    //   322: astore #6
    //   324: aload #7
    //   326: astore_1
    //   327: aload_1
    //   328: ifnull -> 337
    //   331: aload_1
    //   332: invokeinterface close : ()V
    //   337: aload_0
    //   338: getfield b : La4/a;
    //   341: astore_1
    //   342: aload_1
    //   343: ifnull -> 350
    //   346: aload_1
    //   347: invokevirtual b : ()V
    //   350: aload #6
    //   352: athrow
    //   353: astore_1
    //   354: aload_0
    //   355: monitorexit
    //   356: aload_1
    //   357: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	353	finally
    //   26	32	174	java/lang/Exception
    //   26	32	166	finally
    //   37	46	174	java/lang/Exception
    //   37	46	166	finally
    //   46	51	353	finally
    //   55	59	353	finally
    //   63	79	174	java/lang/Exception
    //   63	79	166	finally
    //   84	102	113	java/lang/Exception
    //   84	102	105	finally
    //   131	138	353	finally
    //   138	143	353	finally
    //   154	159	353	finally
    //   179	223	316	finally
    //   228	235	353	finally
    //   235	241	353	finally
    //   260	311	353	finally
    //   331	337	353	finally
    //   337	342	353	finally
    //   346	350	353	finally
    //   350	353	353	finally
  }
  
  public String x(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore_3
    //   4: aconst_null
    //   5: astore #4
    //   7: aconst_null
    //   8: astore #5
    //   10: aconst_null
    //   11: astore #6
    //   13: aload #4
    //   15: astore #7
    //   17: aload_0
    //   18: getfield b : La4/a;
    //   21: astore #8
    //   23: aload #8
    //   25: ifnonnull -> 58
    //   28: aload #4
    //   30: astore #7
    //   32: getstatic a4/c.d : Ljava/lang/String;
    //   35: ldc_w '[getPackageName] mDbHandler is null'
    //   38: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   41: aload_0
    //   42: getfield b : La4/a;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 54
    //   50: aload_1
    //   51: invokevirtual b : ()V
    //   54: aload_0
    //   55: monitorexit
    //   56: aconst_null
    //   57: areturn
    //   58: aload #4
    //   60: astore #7
    //   62: aload #8
    //   64: invokevirtual n : ()La4/a;
    //   67: pop
    //   68: aload #4
    //   70: astore #7
    //   72: aload_0
    //   73: getfield b : La4/a;
    //   76: aload_1
    //   77: aload_2
    //   78: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   81: astore #4
    //   83: aload #6
    //   85: astore_2
    //   86: aload #4
    //   88: ifnull -> 120
    //   91: aload #6
    //   93: astore_2
    //   94: aload_3
    //   95: astore #7
    //   97: aload #4
    //   99: invokeinterface moveToFirst : ()Z
    //   104: iconst_1
    //   105: if_icmpne -> 120
    //   108: aload_3
    //   109: astore #7
    //   111: aload #4
    //   113: iconst_3
    //   114: invokeinterface getString : (I)Ljava/lang/String;
    //   119: astore_2
    //   120: aload_2
    //   121: astore #7
    //   123: getstatic a4/c.d : Ljava/lang/String;
    //   126: astore #5
    //   128: aload_2
    //   129: astore #7
    //   131: new java/lang/StringBuilder
    //   134: astore_3
    //   135: aload_2
    //   136: astore #7
    //   138: aload_3
    //   139: invokespecial <init> : ()V
    //   142: aload_2
    //   143: astore #7
    //   145: aload_3
    //   146: ldc_w 'appID : '
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: pop
    //   153: aload_2
    //   154: astore #7
    //   156: aload_3
    //   157: aload_1
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: aload_2
    //   163: astore #7
    //   165: aload_3
    //   166: ldc_w ', pkgName : '
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_2
    //   174: astore #7
    //   176: aload_3
    //   177: aload_2
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: aload_2
    //   183: astore #7
    //   185: aload #5
    //   187: aload_3
    //   188: invokevirtual toString : ()Ljava/lang/String;
    //   191: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   194: aload #4
    //   196: ifnull -> 206
    //   199: aload #4
    //   201: invokeinterface close : ()V
    //   206: aload_0
    //   207: getfield b : La4/a;
    //   210: astore #7
    //   212: aload_2
    //   213: astore_1
    //   214: aload #7
    //   216: ifnull -> 345
    //   219: aload #7
    //   221: invokevirtual b : ()V
    //   224: aload_2
    //   225: astore_1
    //   226: goto -> 345
    //   229: astore_1
    //   230: aload #4
    //   232: astore #7
    //   234: goto -> 349
    //   237: astore_1
    //   238: aload #4
    //   240: astore_2
    //   241: aload_1
    //   242: astore #4
    //   244: aload #7
    //   246: astore_1
    //   247: goto -> 261
    //   250: astore_1
    //   251: goto -> 349
    //   254: astore #4
    //   256: aconst_null
    //   257: astore_1
    //   258: aload #5
    //   260: astore_2
    //   261: aload_2
    //   262: astore #7
    //   264: getstatic a4/c.d : Ljava/lang/String;
    //   267: astore_3
    //   268: aload_2
    //   269: astore #7
    //   271: new java/lang/StringBuilder
    //   274: astore #5
    //   276: aload_2
    //   277: astore #7
    //   279: aload #5
    //   281: invokespecial <init> : ()V
    //   284: aload_2
    //   285: astore #7
    //   287: aload #5
    //   289: ldc_w '[getPackageName()] Exception with message ='
    //   292: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   295: pop
    //   296: aload_2
    //   297: astore #7
    //   299: aload #5
    //   301: aload #4
    //   303: invokevirtual getMessage : ()Ljava/lang/String;
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: aload_2
    //   311: astore #7
    //   313: aload_3
    //   314: aload #5
    //   316: invokevirtual toString : ()Ljava/lang/String;
    //   319: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   322: aload_2
    //   323: ifnull -> 332
    //   326: aload_2
    //   327: invokeinterface close : ()V
    //   332: aload_0
    //   333: getfield b : La4/a;
    //   336: astore_2
    //   337: aload_2
    //   338: ifnull -> 345
    //   341: aload_2
    //   342: invokevirtual b : ()V
    //   345: aload_0
    //   346: monitorexit
    //   347: aload_1
    //   348: areturn
    //   349: aload #7
    //   351: ifnull -> 361
    //   354: aload #7
    //   356: invokeinterface close : ()V
    //   361: aload_0
    //   362: getfield b : La4/a;
    //   365: astore_2
    //   366: aload_2
    //   367: ifnull -> 374
    //   370: aload_2
    //   371: invokevirtual b : ()V
    //   374: aload_1
    //   375: athrow
    //   376: astore_1
    //   377: aload_0
    //   378: monitorexit
    //   379: aload_1
    //   380: athrow
    // Exception table:
    //   from	to	target	type
    //   17	23	254	java/lang/Exception
    //   17	23	250	finally
    //   32	41	254	java/lang/Exception
    //   32	41	250	finally
    //   41	46	376	finally
    //   50	54	376	finally
    //   62	68	254	java/lang/Exception
    //   62	68	250	finally
    //   72	83	254	java/lang/Exception
    //   72	83	250	finally
    //   97	108	237	java/lang/Exception
    //   97	108	229	finally
    //   111	120	237	java/lang/Exception
    //   111	120	229	finally
    //   123	128	237	java/lang/Exception
    //   123	128	229	finally
    //   131	135	237	java/lang/Exception
    //   131	135	229	finally
    //   138	142	237	java/lang/Exception
    //   138	142	229	finally
    //   145	153	237	java/lang/Exception
    //   145	153	229	finally
    //   156	162	237	java/lang/Exception
    //   156	162	229	finally
    //   165	173	237	java/lang/Exception
    //   165	173	229	finally
    //   176	182	237	java/lang/Exception
    //   176	182	229	finally
    //   185	194	237	java/lang/Exception
    //   185	194	229	finally
    //   199	206	376	finally
    //   206	212	376	finally
    //   219	224	376	finally
    //   264	268	250	finally
    //   271	276	250	finally
    //   279	284	250	finally
    //   287	296	250	finally
    //   299	310	250	finally
    //   313	322	250	finally
    //   326	332	376	finally
    //   332	337	376	finally
    //   341	345	376	finally
    //   354	361	376	finally
    //   361	366	376	finally
    //   370	374	376	finally
    //   374	376	376	finally
  }
  
  public String y(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: istore_3
    //   7: aconst_null
    //   8: astore #4
    //   10: aconst_null
    //   11: astore #5
    //   13: aconst_null
    //   14: astore #6
    //   16: aconst_null
    //   17: astore #7
    //   19: iload_3
    //   20: ifne -> 291
    //   23: aload_2
    //   24: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   27: istore_3
    //   28: iload_3
    //   29: ifeq -> 35
    //   32: goto -> 291
    //   35: aload_0
    //   36: getfield b : La4/a;
    //   39: astore #8
    //   41: aload #8
    //   43: ifnonnull -> 72
    //   46: getstatic a4/c.d : Ljava/lang/String;
    //   49: ldc_w '[getRegId] mDbHandler is null'
    //   52: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   55: aload_0
    //   56: getfield b : La4/a;
    //   59: astore_1
    //   60: aload_1
    //   61: ifnull -> 68
    //   64: aload_1
    //   65: invokevirtual b : ()V
    //   68: aload_0
    //   69: monitorexit
    //   70: aconst_null
    //   71: areturn
    //   72: aload #8
    //   74: invokevirtual n : ()La4/a;
    //   77: pop
    //   78: aload_0
    //   79: getfield b : La4/a;
    //   82: aload_1
    //   83: aload_2
    //   84: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   87: astore_2
    //   88: aload #7
    //   90: astore_1
    //   91: aload_2
    //   92: ifnull -> 139
    //   95: aload #7
    //   97: astore_1
    //   98: aload_2
    //   99: invokeinterface moveToFirst : ()Z
    //   104: iconst_1
    //   105: if_icmpne -> 139
    //   108: aload_2
    //   109: iconst_1
    //   110: invokeinterface getString : (I)Ljava/lang/String;
    //   115: astore_1
    //   116: goto -> 139
    //   119: astore #4
    //   121: aload_2
    //   122: astore_1
    //   123: aload #4
    //   125: astore_2
    //   126: goto -> 266
    //   129: astore #6
    //   131: aload_2
    //   132: astore_1
    //   133: aload #6
    //   135: astore_2
    //   136: goto -> 184
    //   139: aload_2
    //   140: ifnull -> 149
    //   143: aload_2
    //   144: invokeinterface close : ()V
    //   149: aload_0
    //   150: getfield b : La4/a;
    //   153: astore #4
    //   155: aload_1
    //   156: astore_2
    //   157: aload #4
    //   159: ifnull -> 261
    //   162: aload #4
    //   164: astore_2
    //   165: aload_2
    //   166: invokevirtual b : ()V
    //   169: aload_1
    //   170: astore_2
    //   171: goto -> 261
    //   174: astore_2
    //   175: aload #6
    //   177: astore_1
    //   178: goto -> 266
    //   181: astore_2
    //   182: aconst_null
    //   183: astore_1
    //   184: getstatic a4/c.d : Ljava/lang/String;
    //   187: astore #7
    //   189: new java/lang/StringBuilder
    //   192: astore #6
    //   194: aload #6
    //   196: invokespecial <init> : ()V
    //   199: aload #6
    //   201: ldc_w '[getRegId()] Exception with message ='
    //   204: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   207: pop
    //   208: aload #6
    //   210: aload_2
    //   211: invokevirtual getMessage : ()Ljava/lang/String;
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: pop
    //   218: aload #7
    //   220: aload #6
    //   222: invokevirtual toString : ()Ljava/lang/String;
    //   225: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   228: aload_1
    //   229: ifnull -> 238
    //   232: aload_1
    //   233: invokeinterface close : ()V
    //   238: aload_0
    //   239: getfield b : La4/a;
    //   242: astore #6
    //   244: aload #5
    //   246: astore_2
    //   247: aload #6
    //   249: ifnull -> 261
    //   252: aload #4
    //   254: astore_1
    //   255: aload #6
    //   257: astore_2
    //   258: goto -> 165
    //   261: aload_0
    //   262: monitorexit
    //   263: aload_2
    //   264: areturn
    //   265: astore_2
    //   266: aload_1
    //   267: ifnull -> 276
    //   270: aload_1
    //   271: invokeinterface close : ()V
    //   276: aload_0
    //   277: getfield b : La4/a;
    //   280: astore_1
    //   281: aload_1
    //   282: ifnull -> 289
    //   285: aload_1
    //   286: invokevirtual b : ()V
    //   289: aload_2
    //   290: athrow
    //   291: getstatic a4/c.d : Ljava/lang/String;
    //   294: ldc_w 'getRegId() argument is empty.'
    //   297: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   300: aload_0
    //   301: monitorexit
    //   302: aconst_null
    //   303: areturn
    //   304: astore_1
    //   305: aload_0
    //   306: monitorexit
    //   307: aload_1
    //   308: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	304	finally
    //   23	28	304	finally
    //   35	41	181	java/lang/Exception
    //   35	41	174	finally
    //   46	55	181	java/lang/Exception
    //   46	55	174	finally
    //   55	60	304	finally
    //   64	68	304	finally
    //   72	88	181	java/lang/Exception
    //   72	88	174	finally
    //   98	116	129	java/lang/Exception
    //   98	116	119	finally
    //   143	149	304	finally
    //   149	155	304	finally
    //   165	169	304	finally
    //   184	228	265	finally
    //   232	238	304	finally
    //   238	244	304	finally
    //   270	276	304	finally
    //   276	281	304	finally
    //   285	289	304	finally
    //   289	291	304	finally
    //   291	300	304	finally
  }
  
  public String z(String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: istore_3
    //   7: aconst_null
    //   8: astore #4
    //   10: aconst_null
    //   11: astore #5
    //   13: aconst_null
    //   14: astore #6
    //   16: aconst_null
    //   17: astore #7
    //   19: iload_3
    //   20: ifne -> 316
    //   23: aload_2
    //   24: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   27: istore_3
    //   28: iload_3
    //   29: ifeq -> 35
    //   32: goto -> 316
    //   35: aload_0
    //   36: getfield b : La4/a;
    //   39: astore #8
    //   41: aload #8
    //   43: ifnonnull -> 72
    //   46: getstatic a4/c.d : Ljava/lang/String;
    //   49: ldc_w '[getRegIdExceptDereged] mDbHandler is null'
    //   52: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   55: aload_0
    //   56: getfield b : La4/a;
    //   59: astore_1
    //   60: aload_1
    //   61: ifnull -> 68
    //   64: aload_1
    //   65: invokevirtual b : ()V
    //   68: aload_0
    //   69: monitorexit
    //   70: aconst_null
    //   71: areturn
    //   72: aload #8
    //   74: invokevirtual n : ()La4/a;
    //   77: pop
    //   78: aload_0
    //   79: getfield b : La4/a;
    //   82: aload_1
    //   83: aload_2
    //   84: invokevirtual h : (Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   87: astore_2
    //   88: aload #7
    //   90: astore_1
    //   91: aload_2
    //   92: ifnull -> 158
    //   95: aload #7
    //   97: astore_1
    //   98: aload_2
    //   99: invokeinterface moveToFirst : ()Z
    //   104: iconst_1
    //   105: if_icmpne -> 158
    //   108: aload #7
    //   110: astore_1
    //   111: ldc 'false'
    //   113: aload_2
    //   114: aload_2
    //   115: ldc 'de_registered'
    //   117: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   122: invokeinterface getString : (I)Ljava/lang/String;
    //   127: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   130: ifeq -> 158
    //   133: aload_2
    //   134: iconst_1
    //   135: invokeinterface getString : (I)Ljava/lang/String;
    //   140: astore_1
    //   141: goto -> 158
    //   144: astore_1
    //   145: goto -> 291
    //   148: astore #6
    //   150: aload_2
    //   151: astore_1
    //   152: aload #6
    //   154: astore_2
    //   155: goto -> 203
    //   158: aload_2
    //   159: ifnull -> 168
    //   162: aload_2
    //   163: invokeinterface close : ()V
    //   168: aload_0
    //   169: getfield b : La4/a;
    //   172: astore #4
    //   174: aload_1
    //   175: astore_2
    //   176: aload #4
    //   178: ifnull -> 280
    //   181: aload #4
    //   183: astore_2
    //   184: aload_2
    //   185: invokevirtual b : ()V
    //   188: aload_1
    //   189: astore_2
    //   190: goto -> 280
    //   193: astore_1
    //   194: aload #6
    //   196: astore_2
    //   197: goto -> 291
    //   200: astore_2
    //   201: aconst_null
    //   202: astore_1
    //   203: getstatic a4/c.d : Ljava/lang/String;
    //   206: astore #6
    //   208: new java/lang/StringBuilder
    //   211: astore #7
    //   213: aload #7
    //   215: invokespecial <init> : ()V
    //   218: aload #7
    //   220: ldc_w '[getRegIdExceptDereged] Exception with message ='
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload #7
    //   229: aload_2
    //   230: invokevirtual getMessage : ()Ljava/lang/String;
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload #6
    //   239: aload #7
    //   241: invokevirtual toString : ()Ljava/lang/String;
    //   244: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   247: aload_1
    //   248: ifnull -> 257
    //   251: aload_1
    //   252: invokeinterface close : ()V
    //   257: aload_0
    //   258: getfield b : La4/a;
    //   261: astore #6
    //   263: aload #5
    //   265: astore_2
    //   266: aload #6
    //   268: ifnull -> 280
    //   271: aload #4
    //   273: astore_1
    //   274: aload #6
    //   276: astore_2
    //   277: goto -> 184
    //   280: aload_0
    //   281: monitorexit
    //   282: aload_2
    //   283: areturn
    //   284: astore #4
    //   286: aload_1
    //   287: astore_2
    //   288: aload #4
    //   290: astore_1
    //   291: aload_2
    //   292: ifnull -> 301
    //   295: aload_2
    //   296: invokeinterface close : ()V
    //   301: aload_0
    //   302: getfield b : La4/a;
    //   305: astore_2
    //   306: aload_2
    //   307: ifnull -> 314
    //   310: aload_2
    //   311: invokevirtual b : ()V
    //   314: aload_1
    //   315: athrow
    //   316: getstatic a4/c.d : Ljava/lang/String;
    //   319: ldc_w 'getRegId() argument is empty.'
    //   322: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   325: aload_0
    //   326: monitorexit
    //   327: aconst_null
    //   328: areturn
    //   329: astore_1
    //   330: aload_0
    //   331: monitorexit
    //   332: aload_1
    //   333: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	329	finally
    //   23	28	329	finally
    //   35	41	200	java/lang/Exception
    //   35	41	193	finally
    //   46	55	200	java/lang/Exception
    //   46	55	193	finally
    //   55	60	329	finally
    //   64	68	329	finally
    //   72	88	200	java/lang/Exception
    //   72	88	193	finally
    //   98	108	148	java/lang/Exception
    //   98	108	144	finally
    //   111	141	148	java/lang/Exception
    //   111	141	144	finally
    //   162	168	329	finally
    //   168	174	329	finally
    //   184	188	329	finally
    //   203	247	284	finally
    //   251	257	329	finally
    //   257	263	329	finally
    //   295	301	329	finally
    //   301	306	329	finally
    //   310	314	329	finally
    //   314	316	329	finally
    //   316	325	329	finally
  }
  
  public class a implements e {
    public a(c this$0, String param1String1, String param1String2) {}
    
    public void a(g param1g) {
      if (f.f() > f.a)
        e(param1g, this.a); 
      if (param1g.a() == 1000 || param1g.a() == 4017) {
        m m = (m)param1g;
        String str = m.g();
        if (TextUtils.isEmpty(str) == true) {
          f.b(c.a(), "Reg ID from Server is empty ");
          this.c.i(m, this.a, false);
          return;
        } 
        if (this.c.N(m.f(), str, m.h(), this.a) == true) {
          d(param1g);
          c.b(this.c);
        } else {
          c(param1g);
        } 
        if (r3.b.o().M())
          r3.b.o().h(); 
        return;
      } 
      f.a(c.a(), "[REGISTRATION] onSuccess. But Error status");
      param1g.a();
      c.c(this.c).j(param1g.a());
      this.c.i((m)param1g, this.a, false);
    }
    
    public void b(int param1Int, String param1String) {
      String str = c.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[REGISTRATION] onFail. errorCode=");
      stringBuilder.append(param1Int);
      stringBuilder.append(", appId=");
      stringBuilder.append(param1String);
      f.a(str, stringBuilder.toString());
      c.d(this.c, param1String, null, this.b, this.a, false, param1Int);
      if (param1Int == -1)
        (new p3.b()).j(param1Int); 
    }
    
    public final void c(g param1g) {
      param1g.d(-107);
      this.c.i((m)param1g, this.a, false);
    }
    
    public final void d(g param1g) {
      if (!TextUtils.isEmpty(this.a) && !this.a.equalsIgnoreCase("0")) {
        c c1 = this.c;
        m m = (m)param1g;
        c1.k(m.f(), m.g(), m.h(), this.a);
      } 
      this.c.i((m)param1g, this.a, true);
    }
    
    public final void e(g param1g, String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[REGISTRATION] onSuccess");
      stringBuilder.append(" regId : ");
      m m = (m)param1g;
      stringBuilder.append(m.g());
      stringBuilder.append(", appId : ");
      stringBuilder.append(m.f());
      stringBuilder.append(", userData : ");
      stringBuilder.append(m.h());
      stringBuilder.append(", ResultCode : ");
      stringBuilder.append(m.a());
      stringBuilder.append(", userSN : ");
      stringBuilder.append(param1String);
      f.a(c.a(), stringBuilder.toString());
    }
  }
  
  public class b implements e {
    public b(c this$0, String param1String) {}
    
    public void a(g param1g) {
      if (f.f() > f.a)
        c.e(this.b, param1g); 
      int i = param1g.a();
      if (i != 1000 && i != 4011) {
        f.a(c.a(), "[DEREGISTRATION] onSuccess. But Error status");
        c.c(this.b).j(param1g.a());
      } else {
        if (this.b.n(((d)param1g).f(), this.a))
          c(param1g); 
        if (r3.b.o().M()) {
          f.a(c.a(), "[DEREGISTRATION] About to execute next task in pending queue");
          r3.b.o().h();
        } 
      } 
    }
    
    public void b(int param1Int, String param1String) {
      String str = c.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[DEREGISTRATION] onFail. errorCode=");
      stringBuilder.append(param1Int);
      stringBuilder.append(", appId=");
      stringBuilder.append(param1String);
      f.a(str, stringBuilder.toString());
      if (param1Int == -1)
        c.c(this.b).j(param1Int); 
    }
    
    public final void c(g param1g) {
      if (!TextUtils.isEmpty(this.a) && Long.valueOf(this.a).longValue() != 0L)
        this.b.h(((d)param1g).f(), this.a); 
    }
  }
  
  public class c implements e {
    public c(c this$0, String param1String) {}
    
    public void a(g param1g) {
      if (f.f() > f.a)
        c.e(this.b, param1g); 
      int i = param1g.a();
      if (i != 1000 && i != 4011 && i != 4017) {
        f.a(c.a(), "[DEREGISTRATION] onSuccess. But Error status");
        c.c(this.b).j(param1g.a());
      } else {
        if (this.b.n(((d)param1g).f(), this.a))
          c(param1g); 
        if (r3.b.o().M()) {
          f.a(c.a(), "[DEREGISTRATION] About to execute next task in pending queue");
          r3.b.o().h();
        } 
      } 
      if (this.b.G() == true) {
        f.a(c.a(), "[DEREGISTRATION] Now RegistrationTable is Empty. STOP push module");
        Context context = PushClientApplication.c();
        if (context == null) {
          f.b(c.a(), "[DEREGISTRATION] Can't Stop Service Context==null");
          return;
        } 
        context.stopService(new Intent(context, PushClientService.class));
      } 
    }
    
    public void b(int param1Int, String param1String) {
      String str = c.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[DEREGISTRATION] onFail. errorCode=");
      stringBuilder.append(param1Int);
      stringBuilder.append(", appId=");
      stringBuilder.append(param1String);
      f.a(str, stringBuilder.toString());
      if (param1Int == -1)
        c.c(this.b).j(param1Int); 
    }
    
    public final void c(g param1g) {
      if (!TextUtils.isEmpty(this.a) && Long.valueOf(this.a).longValue() != 0L)
        this.b.h(((d)param1g).f(), this.a); 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a4/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */