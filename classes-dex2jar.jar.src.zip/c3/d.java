package c3;

import a3.b;
import b3.c;
import com.google.gson.reflect.TypeToken;
import z2.n;
import z2.o;

public final class d implements o {
  public final c a;
  
  public d(c paramc) {
    this.a = paramc;
  }
  
  public n a(z2.d paramd, TypeToken paramTypeToken) {
    b b = (b)paramTypeToken.getRawType().getAnnotation(b.class);
    return (b == null) ? null : b(this.a, paramd, paramTypeToken, b);
  }
  
  public n b(c paramc, z2.d paramd, TypeToken paramTypeToken, b paramb) {
    Object object1 = paramc.a(TypeToken.get(paramb.value())).a();
    if (object1 instanceof n) {
      object1 = object1;
    } else if (object1 instanceof o) {
      object1 = ((o)object1).a(paramd, paramTypeToken);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid attempt to bind an instance of ");
      stringBuilder.append(object1.getClass().getName());
      stringBuilder.append(" as a @JsonAdapter for ");
      stringBuilder.append(paramTypeToken.toString());
      stringBuilder.append(". @JsonAdapter value must be a TypeAdapter, TypeAdapterFactory,");
      stringBuilder.append(" JsonSerializer or JsonDeserializer.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    Object object2 = object1;
    if (object1 != null) {
      object2 = object1;
      if (paramb.nullSafe())
        object2 = object1.a(); 
    } 
    return (n)object2;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */