package c3;

import e3.c;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import z2.f;
import z2.h;
import z2.i;
import z2.k;

public final class e extends c {
  public static final Writer o = new a();
  
  public static final k p = new k("closed");
  
  public final List l = new ArrayList();
  
  public String m;
  
  public f n = (f)h.a;
  
  public e() {
    super(o);
  }
  
  public c Q(String paramString) {
    if (!this.l.isEmpty() && this.m == null) {
      if (j0() instanceof i) {
        this.m = paramString;
        return this;
      } 
      throw new IllegalStateException();
    } 
    throw new IllegalStateException();
  }
  
  public c S() {
    k0((f)h.a);
    return this;
  }
  
  public c c0(long paramLong) {
    k0((f)new k(Long.valueOf(paramLong)));
    return this;
  }
  
  public void close() {
    if (this.l.isEmpty()) {
      this.l.add(p);
      return;
    } 
    throw new IOException("Incomplete document");
  }
  
  public c d0(Boolean paramBoolean) {
    if (paramBoolean == null)
      return S(); 
    k0((f)new k(paramBoolean));
    return this;
  }
  
  public c e0(Number paramNumber) {
    if (paramNumber == null)
      return S(); 
    if (!K()) {
      double d = paramNumber.doubleValue();
      if (Double.isNaN(d) || Double.isInfinite(d)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("JSON forbids NaN and infinities: ");
        stringBuilder.append(paramNumber);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    k0((f)new k(paramNumber));
    return this;
  }
  
  public c f() {
    z2.e e1 = new z2.e();
    k0((f)e1);
    this.l.add(e1);
    return this;
  }
  
  public c f0(String paramString) {
    if (paramString == null)
      return S(); 
    k0((f)new k(paramString));
    return this;
  }
  
  public void flush() {}
  
  public c g0(boolean paramBoolean) {
    k0((f)new k(Boolean.valueOf(paramBoolean)));
    return this;
  }
  
  public f i0() {
    if (this.l.isEmpty())
      return this.n; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Expected one JSON element but was ");
    stringBuilder.append(this.l);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final f j0() {
    List<f> list = this.l;
    return list.get(list.size() - 1);
  }
  
  public final void k0(f paramf) {
    if (this.m != null) {
      if (!paramf.g() || F())
        ((i)j0()).j(this.m, paramf); 
      this.m = null;
    } else if (this.l.isEmpty()) {
      this.n = paramf;
    } else {
      f f1 = j0();
      if (f1 instanceof z2.e) {
        ((z2.e)f1).j(paramf);
        return;
      } 
      throw new IllegalStateException();
    } 
  }
  
  public c m() {
    i i = new i();
    k0((f)i);
    this.l.add(i);
    return this;
  }
  
  public c v() {
    if (!this.l.isEmpty() && this.m == null) {
      if (j0() instanceof z2.e) {
        List list = this.l;
        list.remove(list.size() - 1);
        return this;
      } 
      throw new IllegalStateException();
    } 
    throw new IllegalStateException();
  }
  
  public c x() {
    if (!this.l.isEmpty() && this.m == null) {
      if (j0() instanceof i) {
        List list = this.l;
        list.remove(list.size() - 1);
        return this;
      } 
      throw new IllegalStateException();
    } 
    throw new IllegalStateException();
  }
  
  public static final class a extends Writer {
    public void close() {
      throw new AssertionError();
    }
    
    public void flush() {
      throw new AssertionError();
    }
    
    public void write(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
      throw new AssertionError();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */