package c3;

import b3.b;
import b3.c;
import b3.e;
import b3.h;
import b3.j;
import com.google.gson.reflect.TypeToken;
import e3.b;
import e3.c;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import z2.d;
import z2.k;
import z2.l;
import z2.n;
import z2.o;

public final class f implements o {
  public final c a;
  
  public final boolean b;
  
  public f(c paramc, boolean paramBoolean) {
    this.a = paramc;
    this.b = paramBoolean;
  }
  
  public n a(d paramd, TypeToken paramTypeToken) {
    Type type = paramTypeToken.getType();
    if (!Map.class.isAssignableFrom(paramTypeToken.getRawType()))
      return null; 
    Type[] arrayOfType = b.j(type, b.k(type));
    n n1 = b(paramd, arrayOfType[0]);
    n n2 = paramd.k(TypeToken.get(arrayOfType[1]));
    h h = this.a.a(paramTypeToken);
    return new a(this, paramd, arrayOfType[0], n1, arrayOfType[1], n2, h);
  }
  
  public final n b(d paramd, Type paramType) {
    return (paramType == boolean.class || paramType == Boolean.class) ? l.f : paramd.k(TypeToken.get(paramType));
  }
  
  public final class a extends n {
    public final n a;
    
    public final n b;
    
    public final h c;
    
    public a(f this$0, d param1d, Type param1Type1, n param1n1, Type param1Type2, n param1n2, h param1h) {
      this.a = new k(param1d, param1n1, param1Type1);
      this.b = new k(param1d, param1n2, param1Type2);
      this.c = param1h;
    }
    
    public final String e(z2.f param1f) {
      k k;
      if (param1f.i()) {
        k = param1f.d();
        if (k.r())
          return String.valueOf(k.l()); 
        if (k.o())
          return Boolean.toString(k.j()); 
        if (k.u())
          return k.n(); 
        throw new AssertionError();
      } 
      if (k.g())
        return "null"; 
      throw new AssertionError();
    }
    
    public Map f(e3.a param1a) {
      StringBuilder stringBuilder;
      b b = param1a.c0();
      if (b == b.i) {
        param1a.Y();
        return null;
      } 
      Map<Object, Object> map = (Map)this.c.a();
      if (b == b.a) {
        param1a.a();
        while (param1a.G()) {
          param1a.a();
          Object object = this.a.b(param1a);
          if (map.put(object, this.b.b(param1a)) == null) {
            param1a.v();
            continue;
          } 
          stringBuilder = new StringBuilder();
          stringBuilder.append("duplicate key: ");
          stringBuilder.append(object);
          throw new l(stringBuilder.toString());
        } 
        stringBuilder.v();
      } else {
        stringBuilder.c();
        while (stringBuilder.G()) {
          e.a.a((e3.a)stringBuilder);
          Object object = this.a.b((e3.a)stringBuilder);
          if (map.put(object, this.b.b((e3.a)stringBuilder)) == null)
            continue; 
          stringBuilder = new StringBuilder();
          stringBuilder.append("duplicate key: ");
          stringBuilder.append(object);
          throw new l(stringBuilder.toString());
        } 
        stringBuilder.x();
      } 
      return map;
    }
    
    public void g(c param1c, Map param1Map) {
      if (param1Map == null) {
        param1c.S();
        return;
      } 
      if (!this.d.b) {
        param1c.m();
        for (Map.Entry entry : param1Map.entrySet()) {
          param1c.Q(String.valueOf(entry.getKey()));
          this.b.d(param1c, entry.getValue());
        } 
        param1c.x();
        return;
      } 
      ArrayList<z2.f> arrayList = new ArrayList(entry.size());
      ArrayList arrayList1 = new ArrayList(entry.size());
      Iterator<Map.Entry> iterator = entry.entrySet().iterator();
      boolean bool1 = false;
      boolean bool2 = false;
      int i;
      for (i = 0; iterator.hasNext(); i |= b) {
        byte b;
        Map.Entry entry1 = iterator.next();
        z2.f f1 = this.a.c(entry1.getKey());
        arrayList.add(f1);
        arrayList1.add(entry1.getValue());
        if (f1.e() || f1.h()) {
          b = 1;
        } else {
          b = 0;
        } 
      } 
      if (i != 0) {
        param1c.f();
        int j = arrayList.size();
        for (i = bool2; i < j; i++) {
          param1c.f();
          j.a(arrayList.get(i), param1c);
          this.b.d(param1c, arrayList1.get(i));
          param1c.v();
        } 
        param1c.v();
      } else {
        param1c.m();
        int j = arrayList.size();
        for (i = bool1; i < j; i++) {
          param1c.Q(e(arrayList.get(i)));
          this.b.d(param1c, arrayList1.get(i));
        } 
        param1c.x();
      } 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */