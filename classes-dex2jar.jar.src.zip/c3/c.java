package c3;

import com.google.gson.reflect.TypeToken;
import e3.b;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Date;
import java.util.Locale;
import z2.d;
import z2.l;
import z2.n;
import z2.o;

public final class c extends n {
  public static final o c = new a();
  
  public final DateFormat a = DateFormat.getDateTimeInstance(2, 2, Locale.US);
  
  public final DateFormat b = DateFormat.getDateTimeInstance(2, 2);
  
  public final Date e(String paramString) {
    /* monitor enter ThisExpression{ObjectType{c3/c}} */
    try {
      Date date = this.b.parse(paramString);
      /* monitor exit ThisExpression{ObjectType{c3/c}} */
      return date;
    } catch (ParseException parseException) {
      try {
        Date date = this.a.parse(paramString);
        /* monitor exit ThisExpression{ObjectType{c3/c}} */
        return date;
      } catch (ParseException parseException1) {
        try {
          ParsePosition parsePosition = new ParsePosition();
          this(0);
          Date date = d3.a.c(paramString, parsePosition);
          /* monitor exit ThisExpression{ObjectType{c3/c}} */
          return date;
        } catch (ParseException parseException2) {
          l l = new l();
          this(paramString, parseException2);
          throw l;
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{c3/c}} */
    throw paramString;
  }
  
  public Date f(e3.a parama) {
    if (parama.c0() == b.i) {
      parama.Y();
      return null;
    } 
    return e(parama.a0());
  }
  
  public void g(e3.c paramc, Date paramDate) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: ifnonnull -> 14
    //   6: aload_1
    //   7: invokevirtual S : ()Le3/c;
    //   10: pop
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_1
    //   15: aload_0
    //   16: getfield a : Ljava/text/DateFormat;
    //   19: aload_2
    //   20: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   23: invokevirtual f0 : (Ljava/lang/String;)Le3/c;
    //   26: pop
    //   27: aload_0
    //   28: monitorexit
    //   29: return
    //   30: astore_1
    //   31: aload_0
    //   32: monitorexit
    //   33: aload_1
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   6	11	30	finally
    //   14	27	30	finally
  }
  
  public static final class a implements o {
    public n a(d param1d, TypeToken param1TypeToken) {
      if (param1TypeToken.getRawType() == Date.class) {
        c c = new c();
      } else {
        param1d = null;
      } 
      return (n)param1d;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */