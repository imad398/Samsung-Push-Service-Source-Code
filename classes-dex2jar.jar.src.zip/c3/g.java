package c3;

import com.google.gson.reflect.TypeToken;
import e3.c;
import java.util.ArrayList;
import z2.d;
import z2.n;
import z2.o;

public final class g extends n {
  public static final o b = new a();
  
  public final d a;
  
  public g(d paramd) {
    this.a = paramd;
  }
  
  public Object b(e3.a parama) {
    b3.g<String, Object> g1;
    e3.b b = parama.c0();
    switch (b.a[b.ordinal()]) {
      default:
        throw new IllegalStateException();
      case 6:
        parama.Y();
        return null;
      case 5:
        return Boolean.valueOf(parama.S());
      case 4:
        return Double.valueOf(parama.T());
      case 3:
        return parama.a0();
      case 2:
        g1 = new b3.g();
        parama.c();
        while (parama.G())
          g1.put(parama.W(), b(parama)); 
        parama.x();
        return g1;
      case 1:
        break;
    } 
    ArrayList<Object> arrayList = new ArrayList();
    parama.a();
    while (parama.G())
      arrayList.add(b(parama)); 
    parama.v();
    return arrayList;
  }
  
  public void d(c paramc, Object paramObject) {
    if (paramObject == null) {
      paramc.S();
      return;
    } 
    n n1 = this.a.l(paramObject.getClass());
    if (n1 instanceof g) {
      paramc.m();
      paramc.x();
      return;
    } 
    n1.d(paramc, paramObject);
  }
  
  public static final class a implements o {
    public n a(d param1d, TypeToken param1TypeToken) {
      return (param1TypeToken.getRawType() == Object.class) ? new g(param1d) : null;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */