package c3;

import com.google.gson.reflect.TypeToken;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

public abstract class l {
  public static final z2.n A;
  
  public static final z2.n B;
  
  public static final z2.n C;
  
  public static final z2.o D;
  
  public static final z2.n E;
  
  public static final z2.o F;
  
  public static final z2.n G;
  
  public static final z2.o H;
  
  public static final z2.n I;
  
  public static final z2.o J;
  
  public static final z2.n K;
  
  public static final z2.o L;
  
  public static final z2.n M;
  
  public static final z2.o N;
  
  public static final z2.n O;
  
  public static final z2.o P;
  
  public static final z2.n Q;
  
  public static final z2.o R;
  
  public static final z2.o S;
  
  public static final z2.n T;
  
  public static final z2.o U;
  
  public static final z2.n V;
  
  public static final z2.o W;
  
  public static final z2.n X;
  
  public static final z2.o Y;
  
  public static final z2.o Z;
  
  public static final z2.n a;
  
  public static final z2.o b;
  
  public static final z2.n c;
  
  public static final z2.o d;
  
  public static final z2.n e;
  
  public static final z2.n f = new d0();
  
  public static final z2.o g;
  
  public static final z2.n h;
  
  public static final z2.o i;
  
  public static final z2.n j;
  
  public static final z2.o k;
  
  public static final z2.n l;
  
  public static final z2.o m;
  
  public static final z2.n n;
  
  public static final z2.o o;
  
  public static final z2.n p;
  
  public static final z2.o q;
  
  public static final z2.n r;
  
  public static final z2.o s;
  
  public static final z2.n t = new b();
  
  public static final z2.n u = new c();
  
  public static final z2.n v = new d();
  
  public static final z2.n w;
  
  public static final z2.o x;
  
  public static final z2.n y;
  
  public static final z2.o z;
  
  static {
    n1 = new e();
    w = n1;
    x = b(Number.class, n1);
    n1 = new f();
    y = n1;
    z = a(char.class, Character.class, n1);
    n1 = new g();
    A = n1;
    B = new h();
    C = new i();
    D = b(String.class, n1);
    n1 = new j();
    E = n1;
    F = b(StringBuilder.class, n1);
    n1 = new l();
    G = n1;
    H = b(StringBuffer.class, n1);
    n1 = new m();
    I = n1;
    J = b(URL.class, n1);
    n1 = new n();
    K = n1;
    L = b(URI.class, n1);
    n1 = new o();
    M = n1;
    N = d(InetAddress.class, n1);
    n1 = new p();
    O = n1;
    P = b(UUID.class, n1);
    n1 = (new q()).a();
    Q = n1;
    R = b(Currency.class, n1);
    S = new r();
    n1 = new s();
    T = n1;
    U = c(Calendar.class, GregorianCalendar.class, n1);
    n1 = new t();
    V = n1;
    W = b(Locale.class, n1);
    n1 = new u();
    X = n1;
    Y = d(z2.f.class, n1);
    Z = new w();
  }
  
  public static z2.o a(Class paramClass1, Class paramClass2, z2.n paramn) {
    return new y(paramClass1, paramClass2, paramn);
  }
  
  public static z2.o b(Class paramClass, z2.n paramn) {
    return new x(paramClass, paramn);
  }
  
  public static z2.o c(Class paramClass1, Class paramClass2, z2.n paramn) {
    return new z(paramClass1, paramClass2, paramn);
  }
  
  public static z2.o d(Class paramClass, z2.n paramn) {
    return new a0(paramClass, paramn);
  }
  
  static {
    z2.n n1 = (new k()).a();
    a = n1;
    b = b(Class.class, n1);
    n1 = (new v()).a();
    c = n1;
    d = b(BitSet.class, n1);
    n1 = new c0();
    e = n1;
  }
  
  static {
    g = a(boolean.class, Boolean.class, n1);
    n1 = new e0();
    h = n1;
    i = a(byte.class, Byte.class, n1);
    n1 = new f0();
    j = n1;
    k = a(short.class, Short.class, n1);
    n1 = new g0();
    l = n1;
    m = a(int.class, Integer.class, n1);
    n1 = (new h0()).a();
    n = n1;
    o = b(AtomicInteger.class, n1);
    n1 = (new i0()).a();
    p = n1;
    q = b(AtomicBoolean.class, n1);
    n1 = (new a()).a();
    r = n1;
    s = b(AtomicIntegerArray.class, n1);
  }
  
  public static final class a extends z2.n {
    public AtomicIntegerArray e(e3.a param1a) {
      ArrayList<Integer> arrayList = new ArrayList();
      param1a.a();
      while (param1a.G()) {
        try {
          arrayList.add(Integer.valueOf(param1a.U()));
        } catch (NumberFormatException numberFormatException) {
          throw new z2.l(numberFormatException);
        } 
      } 
      numberFormatException.v();
      int i = arrayList.size();
      AtomicIntegerArray atomicIntegerArray = new AtomicIntegerArray(i);
      for (byte b = 0; b < i; b++)
        atomicIntegerArray.set(b, ((Integer)arrayList.get(b)).intValue()); 
      return atomicIntegerArray;
    }
    
    public void f(e3.c param1c, AtomicIntegerArray param1AtomicIntegerArray) {
      param1c.f();
      int i = param1AtomicIntegerArray.length();
      for (byte b = 0; b < i; b++)
        param1c.c0(param1AtomicIntegerArray.get(b)); 
      param1c.v();
    }
  }
  
  public static final class a0 implements z2.o {
    public a0(Class param1Class, z2.n param1n) {}
    
    public z2.n a(z2.d param1d, TypeToken param1TypeToken) {
      Class<?> clazz = param1TypeToken.getRawType();
      return !this.a.isAssignableFrom(clazz) ? null : new a(this, clazz);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Factory[typeHierarchy=");
      stringBuilder.append(this.a.getName());
      stringBuilder.append(",adapter=");
      stringBuilder.append(this.b);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
    
    public class a extends z2.n {
      public a(l.a0 this$0, Class param2Class) {}
      
      public Object b(e3.a param2a) {
        Object object = this.b.b.b(param2a);
        if (object == null || this.a.isInstance(object))
          return object; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Expected a ");
        stringBuilder.append(this.a.getName());
        stringBuilder.append(" but was ");
        stringBuilder.append(object.getClass().getName());
        throw new z2.l(stringBuilder.toString());
      }
      
      public void d(e3.c param2c, Object param2Object) {
        this.b.b.d(param2c, param2Object);
      }
    }
  }
  
  public class a extends z2.n {
    public a(l this$0, Class param1Class) {}
    
    public Object b(e3.a param1a) {
      Object object = this.b.b.b(param1a);
      if (object == null || this.a.isInstance(object))
        return object; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expected a ");
      stringBuilder.append(this.a.getName());
      stringBuilder.append(" but was ");
      stringBuilder.append(object.getClass().getName());
      throw new z2.l(stringBuilder.toString());
    }
    
    public void d(e3.c param1c, Object param1Object) {
      this.b.b.d(param1c, param1Object);
    }
  }
  
  public static final class b extends z2.n {
    public Number e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      try {
        long l = param1a.V();
        return Long.valueOf(l);
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class c extends z2.n {
    public Number e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return Float.valueOf((float)param1a.T());
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class c0 extends z2.n {
    public Boolean e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return (param1a.c0() == e3.b.f) ? Boolean.valueOf(Boolean.parseBoolean(param1a.a0())) : Boolean.valueOf(param1a.S());
    }
    
    public void f(e3.c param1c, Boolean param1Boolean) {
      param1c.d0(param1Boolean);
    }
  }
  
  public static final class d extends z2.n {
    public Number e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return Double.valueOf(param1a.T());
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class d0 extends z2.n {
    public Boolean e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return Boolean.valueOf(param1a.a0());
    }
    
    public void f(e3.c param1c, Boolean param1Boolean) {
      String str;
      if (param1Boolean == null) {
        str = "null";
      } else {
        str = str.toString();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class e extends z2.n {
    public Number e(e3.a param1a) {
      StringBuilder stringBuilder;
      e3.b b = param1a.c0();
      int i = l.b0.a[b.ordinal()];
      if (i != 1 && i != 3) {
        if (i == 4) {
          param1a.Y();
          return null;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Expecting number, got: ");
        stringBuilder.append(b);
        throw new z2.l(stringBuilder.toString());
      } 
      return (Number)new b3.f(stringBuilder.a0());
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class e0 extends z2.n {
    public Number e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      try {
        byte b = (byte)param1a.U();
        return Byte.valueOf(b);
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class f extends z2.n {
    public Character e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      String str = param1a.a0();
      if (str.length() == 1)
        return Character.valueOf(str.charAt(0)); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Expecting character, got: ");
      stringBuilder.append(str);
      throw new z2.l(stringBuilder.toString());
    }
    
    public void f(e3.c param1c, Character param1Character) {
      String str;
      if (param1Character == null) {
        param1Character = null;
      } else {
        str = String.valueOf(param1Character);
      } 
      param1c.f0(str);
    }
  }
  
  public static final class f0 extends z2.n {
    public Number e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      try {
        short s = (short)param1a.U();
        return Short.valueOf(s);
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class g extends z2.n {
    public String e(e3.a param1a) {
      e3.b b = param1a.c0();
      if (b == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return (b == e3.b.h) ? Boolean.toString(param1a.S()) : param1a.a0();
    }
    
    public void f(e3.c param1c, String param1String) {
      param1c.f0(param1String);
    }
  }
  
  public static final class g0 extends z2.n {
    public Number e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      try {
        int i = param1a.U();
        return Integer.valueOf(i);
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, Number param1Number) {
      param1c.e0(param1Number);
    }
  }
  
  public static final class h extends z2.n {
    public BigDecimal e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      try {
        return new BigDecimal(param1a.a0());
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, BigDecimal param1BigDecimal) {
      param1c.e0(param1BigDecimal);
    }
  }
  
  public static final class h0 extends z2.n {
    public AtomicInteger e(e3.a param1a) {
      try {
        return new AtomicInteger(param1a.U());
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, AtomicInteger param1AtomicInteger) {
      param1c.c0(param1AtomicInteger.get());
    }
  }
  
  public static final class i extends z2.n {
    public BigInteger e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      try {
        return new BigInteger(param1a.a0());
      } catch (NumberFormatException numberFormatException) {
        throw new z2.l(numberFormatException);
      } 
    }
    
    public void f(e3.c param1c, BigInteger param1BigInteger) {
      param1c.e0(param1BigInteger);
    }
  }
  
  public static final class i0 extends z2.n {
    public AtomicBoolean e(e3.a param1a) {
      return new AtomicBoolean(param1a.S());
    }
    
    public void f(e3.c param1c, AtomicBoolean param1AtomicBoolean) {
      param1c.g0(param1AtomicBoolean.get());
    }
  }
  
  public static final class j extends z2.n {
    public StringBuilder e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return new StringBuilder(param1a.a0());
    }
    
    public void f(e3.c param1c, StringBuilder param1StringBuilder) {
      String str;
      if (param1StringBuilder == null) {
        param1StringBuilder = null;
      } else {
        str = param1StringBuilder.toString();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class j0 extends z2.n {
    public final Map a = new HashMap<Object, Object>();
    
    public final Map b = new HashMap<Object, Object>();
    
    public j0(Class<Enum> param1Class) {
      try {
        for (Enum enum_ : (Enum[])param1Class.getEnumConstants()) {
          String str = enum_.name();
          a3.c c = param1Class.getField(str).<a3.c>getAnnotation(a3.c.class);
          if (c != null) {
            String str1 = c.value();
            String[] arrayOfString = c.alternate();
            int i = arrayOfString.length;
            byte b = 0;
            while (true) {
              str = str1;
              if (b < i) {
                str = arrayOfString[b];
                this.a.put(str, enum_);
                b++;
                continue;
              } 
              break;
            } 
          } 
          this.a.put(str, enum_);
          this.b.put(enum_, str);
        } 
        return;
      } catch (NoSuchFieldException noSuchFieldException) {
        throw new AssertionError(noSuchFieldException);
      } 
    }
    
    public Enum e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return (Enum)this.a.get(param1a.a0());
    }
    
    public void f(e3.c param1c, Enum param1Enum) {
      String str;
      if (param1Enum == null) {
        param1Enum = null;
      } else {
        str = (String)this.b.get(param1Enum);
      } 
      param1c.f0(str);
    }
  }
  
  public static final class k extends z2.n {
    public Class e(e3.a param1a) {
      throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
    }
    
    public void f(e3.c param1c, Class param1Class) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempted to serialize java.lang.Class: ");
      stringBuilder.append(param1Class.getName());
      stringBuilder.append(". Forgot to register a type adapter?");
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
  }
  
  public static final class l extends z2.n {
    public StringBuffer e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return new StringBuffer(param1a.a0());
    }
    
    public void f(e3.c param1c, StringBuffer param1StringBuffer) {
      String str;
      if (param1StringBuffer == null) {
        param1StringBuffer = null;
      } else {
        str = param1StringBuffer.toString();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class m extends z2.n {
    public URL e(e3.a param1a) {
      URL uRL;
      e3.b b1 = param1a.c0();
      e3.b b2 = e3.b.i;
      String str2 = null;
      if (b1 == b2) {
        param1a.Y();
        return null;
      } 
      String str1 = param1a.a0();
      if ("null".equals(str1)) {
        str1 = str2;
      } else {
        uRL = new URL(str1);
      } 
      return uRL;
    }
    
    public void f(e3.c param1c, URL param1URL) {
      String str;
      if (param1URL == null) {
        param1URL = null;
      } else {
        str = param1URL.toExternalForm();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class n extends z2.n {
    public URI e(e3.a param1a) {
      e3.b b1 = param1a.c0();
      e3.b b2 = e3.b.i;
      String str = null;
      if (b1 == b2) {
        param1a.Y();
        return null;
      } 
      try {
        URI uRI;
        String str1 = param1a.a0();
        if ("null".equals(str1)) {
          str1 = str;
        } else {
          uRI = new URI(str1);
        } 
        return uRI;
      } catch (URISyntaxException uRISyntaxException) {
        throw new z2.g(uRISyntaxException);
      } 
    }
    
    public void f(e3.c param1c, URI param1URI) {
      String str;
      if (param1URI == null) {
        param1URI = null;
      } else {
        str = param1URI.toASCIIString();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class o extends z2.n {
    public InetAddress e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return InetAddress.getByName(param1a.a0());
    }
    
    public void f(e3.c param1c, InetAddress param1InetAddress) {
      String str;
      if (param1InetAddress == null) {
        param1InetAddress = null;
      } else {
        str = param1InetAddress.getHostAddress();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class p extends z2.n {
    public UUID e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      return UUID.fromString(param1a.a0());
    }
    
    public void f(e3.c param1c, UUID param1UUID) {
      String str;
      if (param1UUID == null) {
        param1UUID = null;
      } else {
        str = param1UUID.toString();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class q extends z2.n {
    public Currency e(e3.a param1a) {
      return Currency.getInstance(param1a.a0());
    }
    
    public void f(e3.c param1c, Currency param1Currency) {
      param1c.f0(param1Currency.getCurrencyCode());
    }
  }
  
  public static final class r implements z2.o {
    public z2.n a(z2.d param1d, TypeToken param1TypeToken) {
      return (param1TypeToken.getRawType() != Timestamp.class) ? null : new a(this, param1d.l(Date.class));
    }
    
    public class a extends z2.n {
      public a(l.r this$0, z2.n param2n) {}
      
      public Timestamp e(e3.a param2a) {
        Date date = (Date)this.a.b(param2a);
        if (date != null) {
          date = new Timestamp(date.getTime());
        } else {
          date = null;
        } 
        return (Timestamp)date;
      }
      
      public void f(e3.c param2c, Timestamp param2Timestamp) {
        this.a.d(param2c, param2Timestamp);
      }
    }
  }
  
  public class a extends z2.n {
    public a(l this$0, z2.n param1n) {}
    
    public Timestamp e(e3.a param1a) {
      Date date = (Date)this.a.b(param1a);
      if (date != null) {
        date = new Timestamp(date.getTime());
      } else {
        date = null;
      } 
      return (Timestamp)date;
    }
    
    public void f(e3.c param1c, Timestamp param1Timestamp) {
      this.a.d(param1c, param1Timestamp);
    }
  }
  
  public static final class s extends z2.n {
    public Calendar e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      param1a.c();
      int i = 0;
      int j = i;
      int k = j;
      int m = k;
      int i1 = m;
      int i2 = i1;
      int i3 = j;
      while (param1a.c0() != e3.b.d) {
        String str = param1a.W();
        j = param1a.U();
        if ("year".equals(str)) {
          i = j;
          continue;
        } 
        if ("month".equals(str)) {
          i3 = j;
          continue;
        } 
        if ("dayOfMonth".equals(str)) {
          k = j;
          continue;
        } 
        if ("hourOfDay".equals(str)) {
          m = j;
          continue;
        } 
        if ("minute".equals(str)) {
          i1 = j;
          continue;
        } 
        if ("second".equals(str))
          i2 = j; 
      } 
      param1a.x();
      return new GregorianCalendar(i, i3, k, m, i1, i2);
    }
    
    public void f(e3.c param1c, Calendar param1Calendar) {
      if (param1Calendar == null) {
        param1c.S();
        return;
      } 
      param1c.m();
      param1c.Q("year");
      param1c.c0(param1Calendar.get(1));
      param1c.Q("month");
      param1c.c0(param1Calendar.get(2));
      param1c.Q("dayOfMonth");
      param1c.c0(param1Calendar.get(5));
      param1c.Q("hourOfDay");
      param1c.c0(param1Calendar.get(11));
      param1c.Q("minute");
      param1c.c0(param1Calendar.get(12));
      param1c.Q("second");
      param1c.c0(param1Calendar.get(13));
      param1c.x();
    }
  }
  
  public static final class t extends z2.n {
    public Locale e(e3.a param1a) {
      e3.b b1 = param1a.c0();
      e3.b b2 = e3.b.i;
      String str = null;
      if (b1 == b2) {
        param1a.Y();
        return null;
      } 
      StringTokenizer stringTokenizer = new StringTokenizer(param1a.a0(), "_");
      if (stringTokenizer.hasMoreElements()) {
        String str1 = stringTokenizer.nextToken();
      } else {
        param1a = null;
      } 
      if (stringTokenizer.hasMoreElements()) {
        String str1 = stringTokenizer.nextToken();
      } else {
        b2 = null;
      } 
      if (stringTokenizer.hasMoreElements())
        str = stringTokenizer.nextToken(); 
      if (b2 == null && str == null)
        return new Locale((String)param1a); 
      Locale locale = new Locale();
      if (str == null) {
        this((String)param1a, (String)b2);
        return locale;
      } 
      this((String)param1a, (String)b2, str);
      return locale;
    }
    
    public void f(e3.c param1c, Locale param1Locale) {
      String str;
      if (param1Locale == null) {
        param1Locale = null;
      } else {
        str = param1Locale.toString();
      } 
      param1c.f0(str);
    }
  }
  
  public static final class u extends z2.n {
    public z2.f e(e3.a param1a) {
      z2.i i;
      z2.e e;
      switch (l.b0.a[param1a.c0().ordinal()]) {
        default:
          throw new IllegalArgumentException();
        case 6:
          i = new z2.i();
          param1a.c();
          while (param1a.G())
            i.j(param1a.W(), e(param1a)); 
          param1a.x();
          return (z2.f)i;
        case 5:
          e = new z2.e();
          param1a.a();
          while (param1a.G())
            e.j(e(param1a)); 
          param1a.v();
          return (z2.f)e;
        case 4:
          param1a.Y();
          return (z2.f)z2.h.a;
        case 3:
          return (z2.f)new z2.k(param1a.a0());
        case 2:
          return (z2.f)new z2.k(Boolean.valueOf(param1a.S()));
        case 1:
          break;
      } 
      return (z2.f)new z2.k((Number)new b3.f(param1a.a0()));
    }
    
    public void f(e3.c param1c, z2.f param1f) {
      z2.k k;
      if (param1f == null || param1f.g()) {
        param1c.S();
        return;
      } 
      if (param1f.i()) {
        k = param1f.d();
        if (k.r()) {
          param1c.e0(k.l());
        } else if (k.o()) {
          param1c.g0(k.j());
        } else {
          param1c.f0(k.n());
        } 
      } else {
        Iterator<z2.f> iterator;
        if (k.e()) {
          param1c.f();
          iterator = k.a().iterator();
          while (iterator.hasNext())
            f(param1c, iterator.next()); 
          param1c.v();
        } else if (iterator.h()) {
          param1c.m();
          for (Map.Entry entry : iterator.b().k()) {
            param1c.Q((String)entry.getKey());
            f(param1c, (z2.f)entry.getValue());
          } 
          param1c.x();
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Couldn't write ");
          stringBuilder.append(iterator.getClass());
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } 
    }
  }
  
  public static final class v extends z2.n {
    public BitSet e(e3.a param1a) {
      // Byte code:
      //   0: new java/util/BitSet
      //   3: dup
      //   4: invokespecial <init> : ()V
      //   7: astore_2
      //   8: aload_1
      //   9: invokevirtual a : ()V
      //   12: aload_1
      //   13: invokevirtual c0 : ()Le3/b;
      //   16: astore_3
      //   17: iconst_0
      //   18: istore #4
      //   20: aload_3
      //   21: getstatic e3/b.b : Le3/b;
      //   24: if_acmpeq -> 188
      //   27: getstatic c3/l$b0.a : [I
      //   30: aload_3
      //   31: invokevirtual ordinal : ()I
      //   34: iaload
      //   35: istore #5
      //   37: iconst_1
      //   38: istore #6
      //   40: iload #5
      //   42: iconst_1
      //   43: if_icmpeq -> 159
      //   46: iload #5
      //   48: iconst_2
      //   49: if_icmpeq -> 150
      //   52: iload #5
      //   54: iconst_3
      //   55: if_icmpne -> 117
      //   58: aload_1
      //   59: invokevirtual a0 : ()Ljava/lang/String;
      //   62: astore_3
      //   63: aload_3
      //   64: invokestatic parseInt : (Ljava/lang/String;)I
      //   67: istore #5
      //   69: iload #5
      //   71: ifeq -> 77
      //   74: goto -> 166
      //   77: iconst_0
      //   78: istore #6
      //   80: goto -> 166
      //   83: astore_1
      //   84: new java/lang/StringBuilder
      //   87: dup
      //   88: invokespecial <init> : ()V
      //   91: astore_1
      //   92: aload_1
      //   93: ldc 'Error: Expecting: bitset number value (1, 0), Found: '
      //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   98: pop
      //   99: aload_1
      //   100: aload_3
      //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   104: pop
      //   105: new z2/l
      //   108: dup
      //   109: aload_1
      //   110: invokevirtual toString : ()Ljava/lang/String;
      //   113: invokespecial <init> : (Ljava/lang/String;)V
      //   116: athrow
      //   117: new java/lang/StringBuilder
      //   120: dup
      //   121: invokespecial <init> : ()V
      //   124: astore_1
      //   125: aload_1
      //   126: ldc 'Invalid bitset value type: '
      //   128: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   131: pop
      //   132: aload_1
      //   133: aload_3
      //   134: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   137: pop
      //   138: new z2/l
      //   141: dup
      //   142: aload_1
      //   143: invokevirtual toString : ()Ljava/lang/String;
      //   146: invokespecial <init> : (Ljava/lang/String;)V
      //   149: athrow
      //   150: aload_1
      //   151: invokevirtual S : ()Z
      //   154: istore #6
      //   156: goto -> 166
      //   159: aload_1
      //   160: invokevirtual U : ()I
      //   163: ifeq -> 77
      //   166: iload #6
      //   168: ifeq -> 177
      //   171: aload_2
      //   172: iload #4
      //   174: invokevirtual set : (I)V
      //   177: iinc #4, 1
      //   180: aload_1
      //   181: invokevirtual c0 : ()Le3/b;
      //   184: astore_3
      //   185: goto -> 20
      //   188: aload_1
      //   189: invokevirtual v : ()V
      //   192: aload_2
      //   193: areturn
      // Exception table:
      //   from	to	target	type
      //   63	69	83	java/lang/NumberFormatException
    }
    
    public void f(e3.c param1c, BitSet param1BitSet) {
      param1c.f();
      int i = param1BitSet.length();
      for (byte b = 0; b < i; b++)
        param1c.c0(param1BitSet.get(b)); 
      param1c.v();
    }
  }
  
  public static final class w implements z2.o {
    public z2.n a(z2.d param1d, TypeToken param1TypeToken) {
      Class<?> clazz2 = param1TypeToken.getRawType();
      if (!Enum.class.isAssignableFrom(clazz2) || clazz2 == Enum.class)
        return null; 
      Class<?> clazz1 = clazz2;
      if (!clazz2.isEnum())
        clazz1 = clazz2.getSuperclass(); 
      return new l.j0(clazz1);
    }
  }
  
  public static final class x implements z2.o {
    public x(Class param1Class, z2.n param1n) {}
    
    public z2.n a(z2.d param1d, TypeToken param1TypeToken) {
      if (param1TypeToken.getRawType() == this.a) {
        z2.n n1 = this.b;
      } else {
        param1d = null;
      } 
      return (z2.n)param1d;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Factory[type=");
      stringBuilder.append(this.a.getName());
      stringBuilder.append(",adapter=");
      stringBuilder.append(this.b);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static final class y implements z2.o {
    public y(Class param1Class1, Class param1Class2, z2.n param1n) {}
    
    public z2.n a(z2.d param1d, TypeToken param1TypeToken) {
      null = param1TypeToken.getRawType();
      return (null == this.a || null == this.b) ? this.c : null;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Factory[type=");
      stringBuilder.append(this.b.getName());
      stringBuilder.append("+");
      stringBuilder.append(this.a.getName());
      stringBuilder.append(",adapter=");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static final class z implements z2.o {
    public z(Class param1Class1, Class param1Class2, z2.n param1n) {}
    
    public z2.n a(z2.d param1d, TypeToken param1TypeToken) {
      null = param1TypeToken.getRawType();
      return (null == this.a || null == this.b) ? this.c : null;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Factory[type=");
      stringBuilder.append(this.a.getName());
      stringBuilder.append("+");
      stringBuilder.append(this.b.getName());
      stringBuilder.append(",adapter=");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */