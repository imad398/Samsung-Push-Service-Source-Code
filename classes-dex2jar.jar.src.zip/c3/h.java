package c3;

import b3.d;
import b3.i;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import z2.d;
import z2.l;
import z2.n;
import z2.o;

public final class h implements o {
  public final b3.c a;
  
  public final z2.c b;
  
  public final d c;
  
  public final d d;
  
  public h(b3.c paramc, z2.c paramc1, d paramd, d paramd1) {
    this.a = paramc;
    this.b = paramc1;
    this.c = paramd;
    this.d = paramd1;
  }
  
  public static boolean d(Field paramField, boolean paramBoolean, d paramd) {
    if (!paramd.d(paramField.getType(), paramBoolean) && !paramd.f(paramField, paramBoolean)) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public n a(d paramd, TypeToken paramTypeToken) {
    Class<?> clazz = paramTypeToken.getRawType();
    return !Object.class.isAssignableFrom(clazz) ? null : new b(this.a.a(paramTypeToken), e(paramd, paramTypeToken, clazz));
  }
  
  public final c b(d paramd, Field paramField, String paramString, TypeToken paramTypeToken, boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool1;
    n n;
    boolean bool = i.b(paramTypeToken.getRawType());
    a3.b b1 = paramField.<a3.b>getAnnotation(a3.b.class);
    if (b1 != null) {
      n n1 = this.d.b(this.a, paramd, paramTypeToken, b1);
    } else {
      b1 = null;
    } 
    if (b1 != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    a3.b b2 = b1;
    if (b1 == null)
      n = paramd.k(paramTypeToken); 
    return new a(this, paramString, paramBoolean1, paramBoolean2, paramField, bool1, n, paramd, paramTypeToken, bool);
  }
  
  public boolean c(Field paramField, boolean paramBoolean) {
    return d(paramField, paramBoolean, this.c);
  }
  
  public final Map e(d paramd, TypeToken paramTypeToken, Class<Object> paramClass) {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<Object, Object>();
    if (paramClass.isInterface())
      return linkedHashMap; 
    Type type = paramTypeToken.getType();
    Class<Object> clazz = paramClass;
    TypeToken typeToken = paramTypeToken;
    while (clazz != Object.class) {
      for (Field field : clazz.getDeclaredFields()) {
        boolean bool1 = c(field, true);
        boolean bool2 = c(field, false);
        if (bool1 || bool2) {
          c c1;
          field.setAccessible(true);
          Type type1 = b3.b.p(typeToken.getType(), clazz, field.getGenericType());
          List<String> list = f(field);
          int i = list.size();
          paramTypeToken = null;
          for (byte b = 0; b < i; b++) {
            String str = list.get(b);
            if (b != 0)
              bool1 = false; 
            c c2 = (c)linkedHashMap.put(str, b(paramd, field, str, TypeToken.get(type1), bool1, bool2));
            if (paramTypeToken == null)
              c1 = c2; 
          } 
          if (c1 != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(type);
            stringBuilder.append(" declares multiple JSON fields named ");
            stringBuilder.append(c1.a);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } 
      } 
      typeToken = TypeToken.get(b3.b.p(typeToken.getType(), clazz, clazz.getGenericSuperclass()));
      clazz = typeToken.getRawType();
    } 
    return linkedHashMap;
  }
  
  public final List f(Field paramField) {
    a3.c c1 = paramField.<a3.c>getAnnotation(a3.c.class);
    if (c1 == null)
      return Collections.singletonList(this.b.a(paramField)); 
    String str = c1.value();
    String[] arrayOfString = c1.alternate();
    if (arrayOfString.length == 0)
      return Collections.singletonList(str); 
    ArrayList<String> arrayList = new ArrayList(arrayOfString.length + 1);
    arrayList.add(str);
    int i = arrayOfString.length;
    for (byte b = 0; b < i; b++)
      arrayList.add(arrayOfString[b]); 
    return arrayList;
  }
  
  public class a extends c {
    public a(h this$0, String param1String, boolean param1Boolean1, boolean param1Boolean2, Field param1Field, boolean param1Boolean3, n param1n, d param1d, TypeToken param1TypeToken, boolean param1Boolean4) {
      super(param1String, param1Boolean1, param1Boolean2);
    }
    
    public void a(e3.a param1a, Object param1Object) {
      Object object = this.f.b(param1a);
      if (object != null || !this.i)
        this.d.set(param1Object, object); 
    }
    
    public void b(e3.c param1c, Object param1Object) {
      Object object = this.d.get(param1Object);
      if (this.e) {
        param1Object = this.f;
      } else {
        param1Object = new k(this.g, this.f, this.h.getType());
      } 
      param1Object.d(param1c, object);
    }
    
    public boolean c(Object param1Object) {
      boolean bool = this.b;
      boolean bool1 = false;
      if (!bool)
        return false; 
      if (this.d.get(param1Object) != param1Object)
        bool1 = true; 
      return bool1;
    }
  }
  
  public static final class b extends n {
    public final b3.h a;
    
    public final Map b;
    
    public b(b3.h param1h, Map param1Map) {
      this.a = param1h;
      this.b = param1Map;
    }
    
    public Object b(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      Object object = this.a.a();
      try {
        param1a.c();
        while (param1a.G()) {
          String str = param1a.W();
          h.c c = (h.c)this.b.get(str);
          if (c == null || !c.c) {
            param1a.m0();
            continue;
          } 
          c.a(param1a, object);
        } 
        param1a.x();
        return object;
      } catch (IllegalStateException illegalStateException) {
        throw new l(illegalStateException);
      } catch (IllegalAccessException illegalAccessException) {
        throw new AssertionError(illegalAccessException);
      } 
    }
    
    public void d(e3.c param1c, Object param1Object) {
      if (param1Object == null) {
        param1c.S();
        return;
      } 
      param1c.m();
      try {
        for (h.c c1 : this.b.values()) {
          if (c1.c(param1Object)) {
            param1c.Q(c1.a);
            c1.b(param1c, param1Object);
          } 
        } 
        param1c.x();
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new AssertionError(illegalAccessException);
      } 
    }
  }
  
  public static abstract class c {
    public final String a;
    
    public final boolean b;
    
    public final boolean c;
    
    public c(String param1String, boolean param1Boolean1, boolean param1Boolean2) {
      this.a = param1String;
      this.b = param1Boolean1;
      this.c = param1Boolean2;
    }
    
    public abstract void a(e3.a param1a, Object param1Object);
    
    public abstract void b(e3.c param1c, Object param1Object);
    
    public abstract boolean c(Object param1Object);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */