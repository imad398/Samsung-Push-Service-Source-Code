package c3;

import b3.c;
import b3.h;
import com.google.gson.reflect.TypeToken;
import e3.c;
import java.lang.reflect.Type;
import java.util.Collection;
import z2.d;
import z2.n;
import z2.o;

public final class b implements o {
  public final c a;
  
  public b(c paramc) {
    this.a = paramc;
  }
  
  public n a(d paramd, TypeToken paramTypeToken) {
    Type type1 = paramTypeToken.getType();
    Class<?> clazz = paramTypeToken.getRawType();
    if (!Collection.class.isAssignableFrom(clazz))
      return null; 
    Type type2 = b3.b.h(type1, clazz);
    return new a(paramd, type2, paramd.k(TypeToken.get(type2)), this.a.a(paramTypeToken));
  }
  
  public static final class a extends n {
    public final n a;
    
    public final h b;
    
    public a(d param1d, Type param1Type, n param1n, h param1h) {
      this.a = new k(param1d, param1n, param1Type);
      this.b = param1h;
    }
    
    public Collection e(e3.a param1a) {
      if (param1a.c0() == e3.b.i) {
        param1a.Y();
        return null;
      } 
      Collection<Object> collection = (Collection)this.b.a();
      param1a.a();
      while (param1a.G())
        collection.add(this.a.b(param1a)); 
      param1a.v();
      return collection;
    }
    
    public void f(c param1c, Collection param1Collection) {
      if (param1Collection == null) {
        param1c.S();
        return;
      } 
      param1c.f();
      for (Object object : param1Collection)
        this.a.d(param1c, object); 
      param1c.v();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */