package c3;

import b3.b;
import com.google.gson.reflect.TypeToken;
import e3.b;
import e3.c;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.ArrayList;
import z2.d;
import z2.n;
import z2.o;

public final class a extends n {
  public static final o c = new a();
  
  public final Class a;
  
  public final n b;
  
  public a(d paramd, n paramn, Class paramClass) {
    this.b = new k(paramd, paramn, paramClass);
    this.a = paramClass;
  }
  
  public Object b(e3.a parama) {
    if (parama.c0() == b.i) {
      parama.Y();
      return null;
    } 
    ArrayList<Object> arrayList = new ArrayList();
    parama.a();
    while (parama.G())
      arrayList.add(this.b.b(parama)); 
    parama.v();
    int i = arrayList.size();
    Object object = Array.newInstance(this.a, i);
    for (byte b = 0; b < i; b++)
      Array.set(object, b, arrayList.get(b)); 
    return object;
  }
  
  public void d(c paramc, Object paramObject) {
    if (paramObject == null) {
      paramc.S();
      return;
    } 
    paramc.f();
    int i = Array.getLength(paramObject);
    for (byte b = 0; b < i; b++) {
      Object object = Array.get(paramObject, b);
      this.b.d(paramc, object);
    } 
    paramc.v();
  }
  
  public static final class a implements o {
    public n a(d param1d, TypeToken param1TypeToken) {
      Type type = param1TypeToken.getType();
      if (!(type instanceof java.lang.reflect.GenericArrayType) && (!(type instanceof Class) || !((Class)type).isArray()))
        return null; 
      type = b.g(type);
      return new a(param1d, param1d.k(TypeToken.get(type)), b.k(type));
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */