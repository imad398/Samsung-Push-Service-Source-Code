package c3;

import com.google.gson.reflect.TypeToken;
import e3.a;
import e3.c;
import java.lang.reflect.Type;
import z2.d;
import z2.n;

public final class k extends n {
  public final d a;
  
  public final n b;
  
  public final Type c;
  
  public k(d paramd, n paramn, Type paramType) {
    this.a = paramd;
    this.b = paramn;
    this.c = paramType;
  }
  
  public Object b(a parama) {
    return this.b.b(parama);
  }
  
  public void d(c paramc, Object paramObject) {
    n n1 = this.b;
    Type type = e(this.c, paramObject);
    if (type != this.c) {
      n1 = this.a.k(TypeToken.get(type));
      if (n1 instanceof h.b) {
        n n2 = this.b;
        if (!(n2 instanceof h.b))
          n1 = n2; 
      } 
    } 
    n1.d(paramc, paramObject);
  }
  
  public final Type e(Type<?> paramType, Object paramObject) {
    null = paramType;
    if (paramObject != null) {
      if (paramType != Object.class && !(paramType instanceof java.lang.reflect.TypeVariable)) {
        null = paramType;
        return (paramType instanceof Class) ? paramObject.getClass() : null;
      } 
    } else {
      return null;
    } 
    return paramObject.getClass();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c3/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */