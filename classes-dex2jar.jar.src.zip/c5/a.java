package c5;

import java.util.Iterator;

public abstract class a implements Iterator {
  public abstract int b();
  
  public void remove() {
    throw new UnsupportedOperationException("Operation is not supported for read-only collection");
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c5/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */