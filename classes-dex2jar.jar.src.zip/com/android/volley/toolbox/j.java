package com.android.volley.toolbox;

import java.io.ByteArrayOutputStream;

public class j extends ByteArrayOutputStream {
  public final c a;
  
  public j(c paramc, int paramInt) {
    this.a = paramc;
    this.buf = paramc.a(Math.max(paramInt, 256));
  }
  
  public final void a(int paramInt) {
    int i = this.count;
    if (i + paramInt <= this.buf.length)
      return; 
    byte[] arrayOfByte = this.a.a((i + paramInt) * 2);
    System.arraycopy(this.buf, 0, arrayOfByte, 0, this.count);
    this.a.b(this.buf);
    this.buf = arrayOfByte;
  }
  
  public void close() {
    this.a.b(this.buf);
    this.buf = null;
    super.close();
  }
  
  public void finalize() {
    this.a.b(this.buf);
  }
  
  public void write(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: invokevirtual a : (I)V
    //   7: aload_0
    //   8: iload_1
    //   9: invokespecial write : (I)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_2
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_2
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_3
    //   4: invokevirtual a : (I)V
    //   7: aload_0
    //   8: aload_1
    //   9: iload_2
    //   10: iload_3
    //   11: invokespecial write : ([BII)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */