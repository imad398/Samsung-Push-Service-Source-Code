package com.android.volley.toolbox;

import java.io.UnsupportedEncodingException;
import z.n;
import z.p;
import z.v;

public abstract class i extends n {
  protected static final String PROTOCOL_CHARSET = "utf-8";
  
  private static final String PROTOCOL_CONTENT_TYPE = String.format("application/json; charset=%s", new Object[] { "utf-8" });
  
  private p.b mListener;
  
  private final Object mLock = new Object();
  
  private final String mRequestBody;
  
  public i(int paramInt, String paramString1, String paramString2, p.b paramb, p.a parama) {
    super(paramInt, paramString1, parama);
    this.mListener = paramb;
    this.mRequestBody = paramString2;
  }
  
  public void cancel() {
    super.cancel();
    synchronized (this.mLock) {
      this.mListener = null;
      return;
    } 
  }
  
  public void deliverResponse(Object paramObject) {
    synchronized (this.mLock) {
      p.b b1 = this.mListener;
      if (b1 != null)
        b1.a(paramObject); 
      return;
    } 
  }
  
  public byte[] getBody() {
    byte[] arrayOfByte = null;
    try {
      String str = this.mRequestBody;
      if (str != null)
        arrayOfByte = str.getBytes("utf-8"); 
      return arrayOfByte;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      v.f("Unsupported Encoding while trying to get the bytes of %s using %s", new Object[] { this.mRequestBody, "utf-8" });
      return null;
    } 
  }
  
  public String getBodyContentType() {
    return PROTOCOL_CONTENT_TYPE;
  }
  
  @Deprecated
  public byte[] getPostBody() {
    return getBody();
  }
  
  @Deprecated
  public String getPostBodyContentType() {
    return getBodyContentType();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */