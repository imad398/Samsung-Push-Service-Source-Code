package com.android.volley.toolbox;

import java.io.UnsupportedEncodingException;
import z.k;
import z.n;
import z.p;

public abstract class l extends n {
  private p.b mListener;
  
  private final Object mLock = new Object();
  
  public l(int paramInt, String paramString, p.b paramb, p.a parama) {
    super(paramInt, paramString, parama);
    this.mListener = paramb;
  }
  
  public void cancel() {
    super.cancel();
    synchronized (this.mLock) {
      this.mListener = null;
      return;
    } 
  }
  
  public void deliverResponse(String paramString) {
    synchronized (this.mLock) {
      p.b b1 = this.mListener;
      if (b1 != null)
        b1.a(paramString); 
      return;
    } 
  }
  
  public p parseNetworkResponse(k paramk) {
    String str;
    try {
      str = new String();
      this(paramk.b, e.d(paramk.c));
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      str = new String(paramk.b);
    } 
    return p.c(str, e.c(paramk));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */