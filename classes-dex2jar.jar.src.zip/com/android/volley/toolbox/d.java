package com.android.volley.toolbox;

import android.os.SystemClock;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import z.b;
import z.g;
import z.v;

public class d implements b {
  public final Map a = new LinkedHashMap<Object, Object>(16, 0.75F, true);
  
  public long b = 0L;
  
  public final File c;
  
  public final int d;
  
  public d(File paramFile) {
    this(paramFile, 5242880);
  }
  
  public d(File paramFile, int paramInt) {
    this.c = paramFile;
    this.d = paramInt;
  }
  
  public static int j(InputStream paramInputStream) {
    int i = paramInputStream.read();
    if (i != -1)
      return i; 
    throw new EOFException();
  }
  
  public static List k(b paramb) {
    int i = l(paramb);
    if (i >= 0) {
      List<?> list;
      if (i == 0) {
        list = Collections.emptyList();
      } else {
        list = new ArrayList();
      } 
      for (byte b1 = 0; b1 < i; b1++)
        list.add(new g(n(paramb).intern(), n(paramb).intern())); 
      return list;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("readHeaderList size=");
    stringBuilder.append(i);
    throw new IOException(stringBuilder.toString());
  }
  
  public static int l(InputStream paramInputStream) {
    int i = j(paramInputStream);
    int j = j(paramInputStream);
    int k = j(paramInputStream);
    return j(paramInputStream) << 24 | i << 0 | 0x0 | j << 8 | k << 16;
  }
  
  public static long m(InputStream paramInputStream) {
    return (j(paramInputStream) & 0xFFL) << 0L | 0x0L | (j(paramInputStream) & 0xFFL) << 8L | (j(paramInputStream) & 0xFFL) << 16L | (j(paramInputStream) & 0xFFL) << 24L | (j(paramInputStream) & 0xFFL) << 32L | (j(paramInputStream) & 0xFFL) << 40L | (j(paramInputStream) & 0xFFL) << 48L | (0xFFL & j(paramInputStream)) << 56L;
  }
  
  public static String n(b paramb) {
    return new String(q(paramb, m(paramb)), "UTF-8");
  }
  
  public static byte[] q(b paramb, long paramLong) {
    long l = paramb.a();
    if (paramLong >= 0L && paramLong <= l) {
      int i = (int)paramLong;
      if (i == paramLong) {
        byte[] arrayOfByte = new byte[i];
        (new DataInputStream(paramb)).readFully(arrayOfByte);
        return arrayOfByte;
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("streamToBytes length=");
    stringBuilder.append(paramLong);
    stringBuilder.append(", maxLength=");
    stringBuilder.append(l);
    throw new IOException(stringBuilder.toString());
  }
  
  public static void r(List paramList, OutputStream paramOutputStream) {
    if (paramList != null) {
      s(paramOutputStream, paramList.size());
      for (g g : paramList) {
        u(paramOutputStream, g.a());
        u(paramOutputStream, g.b());
      } 
    } else {
      s(paramOutputStream, 0);
    } 
  }
  
  public static void s(OutputStream paramOutputStream, int paramInt) {
    paramOutputStream.write(paramInt >> 0 & 0xFF);
    paramOutputStream.write(paramInt >> 8 & 0xFF);
    paramOutputStream.write(paramInt >> 16 & 0xFF);
    paramOutputStream.write(paramInt >> 24 & 0xFF);
  }
  
  public static void t(OutputStream paramOutputStream, long paramLong) {
    paramOutputStream.write((byte)(int)(paramLong >>> 0L));
    paramOutputStream.write((byte)(int)(paramLong >>> 8L));
    paramOutputStream.write((byte)(int)(paramLong >>> 16L));
    paramOutputStream.write((byte)(int)(paramLong >>> 24L));
    paramOutputStream.write((byte)(int)(paramLong >>> 32L));
    paramOutputStream.write((byte)(int)(paramLong >>> 40L));
    paramOutputStream.write((byte)(int)(paramLong >>> 48L));
    paramOutputStream.write((byte)(int)(paramLong >>> 56L));
  }
  
  public static void u(OutputStream paramOutputStream, String paramString) {
    byte[] arrayOfByte = paramString.getBytes("UTF-8");
    t(paramOutputStream, arrayOfByte.length);
    paramOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
  }
  
  public b.a a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/Map;
    //   6: aload_1
    //   7: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   12: checkcast com/android/volley/toolbox/d$a
    //   15: astore_2
    //   16: aload_2
    //   17: ifnonnull -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: aconst_null
    //   23: areturn
    //   24: aload_0
    //   25: aload_1
    //   26: invokevirtual f : (Ljava/lang/String;)Ljava/io/File;
    //   29: astore_3
    //   30: new com/android/volley/toolbox/d$b
    //   33: astore #4
    //   35: new java/io/BufferedInputStream
    //   38: astore #5
    //   40: aload #5
    //   42: aload_0
    //   43: aload_3
    //   44: invokevirtual d : (Ljava/io/File;)Ljava/io/InputStream;
    //   47: invokespecial <init> : (Ljava/io/InputStream;)V
    //   50: aload #4
    //   52: aload #5
    //   54: aload_3
    //   55: invokevirtual length : ()J
    //   58: invokespecial <init> : (Ljava/io/InputStream;J)V
    //   61: aload #4
    //   63: invokestatic b : (Lcom/android/volley/toolbox/d$b;)Lcom/android/volley/toolbox/d$a;
    //   66: astore #5
    //   68: aload_1
    //   69: aload #5
    //   71: getfield b : Ljava/lang/String;
    //   74: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   77: ifne -> 122
    //   80: ldc '%s: key=%s, found=%s'
    //   82: iconst_3
    //   83: anewarray java/lang/Object
    //   86: dup
    //   87: iconst_0
    //   88: aload_3
    //   89: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   92: aastore
    //   93: dup
    //   94: iconst_1
    //   95: aload_1
    //   96: aastore
    //   97: dup
    //   98: iconst_2
    //   99: aload #5
    //   101: getfield b : Ljava/lang/String;
    //   104: aastore
    //   105: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   108: aload_0
    //   109: aload_1
    //   110: invokevirtual p : (Ljava/lang/String;)V
    //   113: aload #4
    //   115: invokevirtual close : ()V
    //   118: aload_0
    //   119: monitorexit
    //   120: aconst_null
    //   121: areturn
    //   122: aload_2
    //   123: aload #4
    //   125: aload #4
    //   127: invokevirtual a : ()J
    //   130: invokestatic q : (Lcom/android/volley/toolbox/d$b;J)[B
    //   133: invokevirtual c : ([B)Lz/b$a;
    //   136: astore_2
    //   137: aload #4
    //   139: invokevirtual close : ()V
    //   142: aload_0
    //   143: monitorexit
    //   144: aload_2
    //   145: areturn
    //   146: astore_2
    //   147: aload #4
    //   149: invokevirtual close : ()V
    //   152: aload_2
    //   153: athrow
    //   154: astore #4
    //   156: ldc '%s: %s'
    //   158: iconst_2
    //   159: anewarray java/lang/Object
    //   162: dup
    //   163: iconst_0
    //   164: aload_3
    //   165: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   168: aastore
    //   169: dup
    //   170: iconst_1
    //   171: aload #4
    //   173: invokevirtual toString : ()Ljava/lang/String;
    //   176: aastore
    //   177: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   180: aload_0
    //   181: aload_1
    //   182: invokevirtual o : (Ljava/lang/String;)V
    //   185: aload_0
    //   186: monitorexit
    //   187: aconst_null
    //   188: areturn
    //   189: astore_1
    //   190: aload_0
    //   191: monitorexit
    //   192: aload_1
    //   193: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	189	finally
    //   24	30	189	finally
    //   30	61	154	java/io/IOException
    //   30	61	189	finally
    //   61	113	146	finally
    //   113	118	154	java/io/IOException
    //   113	118	189	finally
    //   122	137	146	finally
    //   137	142	154	java/io/IOException
    //   137	142	189	finally
    //   147	154	154	java/io/IOException
    //   147	154	189	finally
    //   156	185	189	finally
  }
  
  public void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Ljava/io/File;
    //   6: invokevirtual exists : ()Z
    //   9: istore_1
    //   10: iconst_0
    //   11: istore_2
    //   12: iload_1
    //   13: ifne -> 49
    //   16: aload_0
    //   17: getfield c : Ljava/io/File;
    //   20: invokevirtual mkdirs : ()Z
    //   23: ifne -> 46
    //   26: ldc_w 'Unable to create cache dir %s'
    //   29: iconst_1
    //   30: anewarray java/lang/Object
    //   33: dup
    //   34: iconst_0
    //   35: aload_0
    //   36: getfield c : Ljava/io/File;
    //   39: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   42: aastore
    //   43: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   46: aload_0
    //   47: monitorexit
    //   48: return
    //   49: aload_0
    //   50: getfield c : Ljava/io/File;
    //   53: invokevirtual listFiles : ()[Ljava/io/File;
    //   56: astore_3
    //   57: aload_3
    //   58: ifnonnull -> 64
    //   61: aload_0
    //   62: monitorexit
    //   63: return
    //   64: aload_3
    //   65: arraylength
    //   66: istore #4
    //   68: iload_2
    //   69: iload #4
    //   71: if_icmpge -> 173
    //   74: aload_3
    //   75: iload_2
    //   76: aaload
    //   77: astore #5
    //   79: aload #5
    //   81: invokevirtual length : ()J
    //   84: lstore #6
    //   86: new com/android/volley/toolbox/d$b
    //   89: astore #8
    //   91: new java/io/BufferedInputStream
    //   94: astore #9
    //   96: aload #9
    //   98: aload_0
    //   99: aload #5
    //   101: invokevirtual d : (Ljava/io/File;)Ljava/io/InputStream;
    //   104: invokespecial <init> : (Ljava/io/InputStream;)V
    //   107: aload #8
    //   109: aload #9
    //   111: lload #6
    //   113: invokespecial <init> : (Ljava/io/InputStream;J)V
    //   116: aload #8
    //   118: invokestatic b : (Lcom/android/volley/toolbox/d$b;)Lcom/android/volley/toolbox/d$a;
    //   121: astore #9
    //   123: aload #9
    //   125: lload #6
    //   127: putfield a : J
    //   130: aload_0
    //   131: aload #9
    //   133: getfield b : Ljava/lang/String;
    //   136: aload #9
    //   138: invokevirtual i : (Ljava/lang/String;Lcom/android/volley/toolbox/d$a;)V
    //   141: aload #8
    //   143: invokevirtual close : ()V
    //   146: goto -> 167
    //   149: astore #9
    //   151: aload #8
    //   153: invokevirtual close : ()V
    //   156: aload #9
    //   158: athrow
    //   159: astore #8
    //   161: aload #5
    //   163: invokevirtual delete : ()Z
    //   166: pop
    //   167: iinc #2, 1
    //   170: goto -> 68
    //   173: aload_0
    //   174: monitorexit
    //   175: return
    //   176: astore #5
    //   178: aload_0
    //   179: monitorexit
    //   180: aload #5
    //   182: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	176	finally
    //   16	46	176	finally
    //   49	57	176	finally
    //   64	68	176	finally
    //   79	116	159	java/io/IOException
    //   79	116	176	finally
    //   116	141	149	finally
    //   141	146	159	java/io/IOException
    //   141	146	176	finally
    //   151	159	159	java/io/IOException
    //   151	159	176	finally
    //   161	167	176	finally
  }
  
  public void c(String paramString, b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_2
    //   4: getfield a : [B
    //   7: arraylength
    //   8: invokevirtual h : (I)V
    //   11: aload_0
    //   12: aload_1
    //   13: invokevirtual f : (Ljava/lang/String;)Ljava/io/File;
    //   16: astore_3
    //   17: new java/io/BufferedOutputStream
    //   20: astore #4
    //   22: aload #4
    //   24: aload_0
    //   25: aload_3
    //   26: invokevirtual e : (Ljava/io/File;)Ljava/io/OutputStream;
    //   29: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   32: new com/android/volley/toolbox/d$a
    //   35: astore #5
    //   37: aload #5
    //   39: aload_1
    //   40: aload_2
    //   41: invokespecial <init> : (Ljava/lang/String;Lz/b$a;)V
    //   44: aload #5
    //   46: aload #4
    //   48: invokevirtual d : (Ljava/io/OutputStream;)Z
    //   51: ifeq -> 78
    //   54: aload #4
    //   56: aload_2
    //   57: getfield a : [B
    //   60: invokevirtual write : ([B)V
    //   63: aload #4
    //   65: invokevirtual close : ()V
    //   68: aload_0
    //   69: aload_1
    //   70: aload #5
    //   72: invokevirtual i : (Ljava/lang/String;Lcom/android/volley/toolbox/d$a;)V
    //   75: aload_0
    //   76: monitorexit
    //   77: return
    //   78: aload #4
    //   80: invokevirtual close : ()V
    //   83: ldc_w 'Failed to write header for %s'
    //   86: iconst_1
    //   87: anewarray java/lang/Object
    //   90: dup
    //   91: iconst_0
    //   92: aload_3
    //   93: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   96: aastore
    //   97: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   100: new java/io/IOException
    //   103: astore_1
    //   104: aload_1
    //   105: invokespecial <init> : ()V
    //   108: aload_1
    //   109: athrow
    //   110: astore_1
    //   111: aload_3
    //   112: invokevirtual delete : ()Z
    //   115: ifne -> 135
    //   118: ldc_w 'Could not clean up file %s'
    //   121: iconst_1
    //   122: anewarray java/lang/Object
    //   125: dup
    //   126: iconst_0
    //   127: aload_3
    //   128: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   131: aastore
    //   132: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   135: aload_0
    //   136: monitorexit
    //   137: return
    //   138: astore_1
    //   139: aload_0
    //   140: monitorexit
    //   141: aload_1
    //   142: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	138	finally
    //   17	75	110	java/io/IOException
    //   17	75	138	finally
    //   78	110	110	java/io/IOException
    //   78	110	138	finally
    //   111	135	138	finally
  }
  
  public InputStream d(File paramFile) {
    return new FileInputStream(paramFile);
  }
  
  public OutputStream e(File paramFile) {
    return new FileOutputStream(paramFile);
  }
  
  public File f(String paramString) {
    return new File(this.c, g(paramString));
  }
  
  public final String g(String paramString) {
    int i = paramString.length() / 2;
    int j = paramString.substring(0, i).hashCode();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(String.valueOf(j));
    stringBuilder.append(String.valueOf(paramString.substring(i).hashCode()));
    return stringBuilder.toString();
  }
  
  public final void h(int paramInt) {
    int i;
    long l1 = this.b;
    long l2 = paramInt;
    if (l1 + l2 < this.d)
      return; 
    if (v.b)
      v.e("Pruning old cache entries.", new Object[0]); 
    long l3 = this.b;
    l1 = SystemClock.elapsedRealtime();
    Iterator<Map.Entry> iterator = this.a.entrySet().iterator();
    paramInt = 0;
    while (true) {
      i = paramInt;
      if (iterator.hasNext()) {
        a a = (a)((Map.Entry)iterator.next()).getValue();
        if (f(a.b).delete()) {
          this.b -= a.a;
        } else {
          String str = a.b;
          v.b("Could not delete cache entry for key=%s, filename=%s", new Object[] { str, g(str) });
        } 
        iterator.remove();
        paramInt++;
        if ((float)(this.b + l2) < this.d * 0.9F) {
          i = paramInt;
          break;
        } 
        continue;
      } 
      break;
    } 
    if (v.b)
      v.e("pruned %d files, %d bytes, %d ms", new Object[] { Integer.valueOf(i), Long.valueOf(this.b - l3), Long.valueOf(SystemClock.elapsedRealtime() - l1) }); 
  }
  
  public final void i(String paramString, a parama) {
    if (!this.a.containsKey(paramString)) {
      this.b += parama.a;
    } else {
      a a1 = (a)this.a.get(paramString);
      this.b += parama.a - a1.a;
    } 
    this.a.put(paramString, parama);
  }
  
  public void o(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual f : (Ljava/lang/String;)Ljava/io/File;
    //   7: invokevirtual delete : ()Z
    //   10: istore_2
    //   11: aload_0
    //   12: aload_1
    //   13: invokevirtual p : (Ljava/lang/String;)V
    //   16: iload_2
    //   17: ifne -> 42
    //   20: ldc_w 'Could not delete cache entry for key=%s, filename=%s'
    //   23: iconst_2
    //   24: anewarray java/lang/Object
    //   27: dup
    //   28: iconst_0
    //   29: aload_1
    //   30: aastore
    //   31: dup
    //   32: iconst_1
    //   33: aload_0
    //   34: aload_1
    //   35: invokevirtual g : (Ljava/lang/String;)Ljava/lang/String;
    //   38: aastore
    //   39: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   42: aload_0
    //   43: monitorexit
    //   44: return
    //   45: astore_1
    //   46: aload_0
    //   47: monitorexit
    //   48: aload_1
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	45	finally
    //   20	42	45	finally
  }
  
  public final void p(String paramString) {
    a a = (a)this.a.remove(paramString);
    if (a != null)
      this.b -= a.a; 
  }
  
  public static class a {
    public long a;
    
    public final String b;
    
    public final String c;
    
    public final long d;
    
    public final long e;
    
    public final long f;
    
    public final long g;
    
    public final List h;
    
    public a(String param1String1, String param1String2, long param1Long1, long param1Long2, long param1Long3, long param1Long4, List param1List) {
      this.b = param1String1;
      param1String1 = param1String2;
      if ("".equals(param1String2))
        param1String1 = null; 
      this.c = param1String1;
      this.d = param1Long1;
      this.e = param1Long2;
      this.f = param1Long3;
      this.g = param1Long4;
      this.h = param1List;
    }
    
    public a(String param1String, b.a param1a) {
      this(param1String, param1a.b, param1a.c, param1a.d, param1a.e, param1a.f, a(param1a));
      this.a = param1a.a.length;
    }
    
    public static List a(b.a param1a) {
      List list = param1a.h;
      return (list != null) ? list : e.g(param1a.g);
    }
    
    public static a b(d.b param1b) {
      if (d.l(param1b) == 538247942)
        return new a(d.n(param1b), d.n(param1b), d.m(param1b), d.m(param1b), d.m(param1b), d.m(param1b), d.k(param1b)); 
      throw new IOException();
    }
    
    public b.a c(byte[] param1ArrayOfbyte) {
      b.a a1 = new b.a();
      a1.a = param1ArrayOfbyte;
      a1.b = this.c;
      a1.c = this.d;
      a1.d = this.e;
      a1.e = this.f;
      a1.f = this.g;
      a1.g = e.h(this.h);
      a1.h = Collections.unmodifiableList(this.h);
      return a1;
    }
    
    public boolean d(OutputStream param1OutputStream) {
      try {
        d.s(param1OutputStream, 538247942);
        d.u(param1OutputStream, this.b);
        String str1 = this.c;
        String str2 = str1;
        if (str1 == null)
          str2 = ""; 
        d.u(param1OutputStream, str2);
        d.t(param1OutputStream, this.d);
        d.t(param1OutputStream, this.e);
        d.t(param1OutputStream, this.f);
        d.t(param1OutputStream, this.g);
        d.r(this.h, param1OutputStream);
        param1OutputStream.flush();
        return true;
      } catch (IOException iOException) {
        v.b("%s", new Object[] { iOException.toString() });
        return false;
      } 
    }
  }
  
  public static class b extends FilterInputStream {
    public final long a;
    
    public long b;
    
    public b(InputStream param1InputStream, long param1Long) {
      super(param1InputStream);
      this.a = param1Long;
    }
    
    public long a() {
      return this.a - this.b;
    }
    
    public int read() {
      int i = super.read();
      if (i != -1)
        this.b++; 
      return i;
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      param1Int1 = super.read(param1ArrayOfbyte, param1Int1, param1Int2);
      if (param1Int1 != -1)
        this.b += param1Int1; 
      return param1Int1;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */