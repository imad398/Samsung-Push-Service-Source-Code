package com.android.volley.toolbox;

import java.io.DataOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import z.g;
import z.n;

public class h extends a {
  public final SSLSocketFactory a;
  
  public h() {
    this(null);
  }
  
  public h(b paramb) {
    this(paramb, null);
  }
  
  public h(b paramb, SSLSocketFactory paramSSLSocketFactory) {
    this.a = paramSSLSocketFactory;
  }
  
  public static void c(HttpURLConnection paramHttpURLConnection, n paramn, byte[] paramArrayOfbyte) {
    paramHttpURLConnection.setDoOutput(true);
    if (!paramHttpURLConnection.getRequestProperties().containsKey("Content-Type"))
      paramHttpURLConnection.setRequestProperty("Content-Type", paramn.getBodyContentType()); 
    DataOutputStream dataOutputStream = new DataOutputStream(paramHttpURLConnection.getOutputStream());
    dataOutputStream.write(paramArrayOfbyte);
    dataOutputStream.close();
  }
  
  public static void d(HttpURLConnection paramHttpURLConnection, n paramn) {
    byte[] arrayOfByte = paramn.getBody();
    if (arrayOfByte != null)
      c(paramHttpURLConnection, paramn, arrayOfByte); 
  }
  
  public static List e(Map paramMap) {
    ArrayList<g> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry entry : paramMap.entrySet()) {
      if (entry.getKey() != null)
        for (String str : entry.getValue())
          arrayList.add(new g((String)entry.getKey(), str));  
    } 
    return arrayList;
  }
  
  public static boolean g(int paramInt1, int paramInt2) {
    boolean bool;
    if (paramInt1 != 4 && (100 > paramInt2 || paramInt2 >= 200) && paramInt2 != 204 && paramInt2 != 304) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static InputStream h(HttpURLConnection paramHttpURLConnection) {
    InputStream inputStream;
    try {
      InputStream inputStream1 = paramHttpURLConnection.getInputStream();
      inputStream = inputStream1;
    } catch (IOException iOException) {
      inputStream = inputStream.getErrorStream();
    } 
    return inputStream;
  }
  
  public static void j(HttpURLConnection paramHttpURLConnection, n paramn) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getMethod : ()I
    //   4: tableswitch default -> 56, -1 -> 132, 0 -> 121, 1 -> 107, 2 -> 96, 3 -> 90, 4 -> 84, 5 -> 78, 6 -> 72, 7 -> 66
    //   56: new java/lang/IllegalStateException
    //   59: dup
    //   60: ldc 'Unknown method type.'
    //   62: invokespecial <init> : (Ljava/lang/String;)V
    //   65: athrow
    //   66: ldc 'PATCH'
    //   68: astore_2
    //   69: goto -> 99
    //   72: ldc 'TRACE'
    //   74: astore_1
    //   75: goto -> 124
    //   78: ldc 'OPTIONS'
    //   80: astore_1
    //   81: goto -> 124
    //   84: ldc 'HEAD'
    //   86: astore_1
    //   87: goto -> 124
    //   90: ldc 'DELETE'
    //   92: astore_1
    //   93: goto -> 124
    //   96: ldc 'PUT'
    //   98: astore_2
    //   99: aload_0
    //   100: aload_2
    //   101: invokevirtual setRequestMethod : (Ljava/lang/String;)V
    //   104: goto -> 113
    //   107: aload_0
    //   108: ldc 'POST'
    //   110: invokevirtual setRequestMethod : (Ljava/lang/String;)V
    //   113: aload_0
    //   114: aload_1
    //   115: invokestatic d : (Ljava/net/HttpURLConnection;Lz/n;)V
    //   118: goto -> 153
    //   121: ldc 'GET'
    //   123: astore_1
    //   124: aload_0
    //   125: aload_1
    //   126: invokevirtual setRequestMethod : (Ljava/lang/String;)V
    //   129: goto -> 153
    //   132: aload_1
    //   133: invokevirtual getPostBody : ()[B
    //   136: astore_2
    //   137: aload_2
    //   138: ifnull -> 153
    //   141: aload_0
    //   142: ldc 'POST'
    //   144: invokevirtual setRequestMethod : (Ljava/lang/String;)V
    //   147: aload_0
    //   148: aload_1
    //   149: aload_2
    //   150: invokestatic c : (Ljava/net/HttpURLConnection;Lz/n;[B)V
    //   153: return
  }
  
  public f a(n paramn, Map<?, ?> paramMap) {
    String str = paramn.getUrl();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.putAll(paramMap);
    hashMap.putAll(paramn.getHeaders());
    HttpURLConnection httpURLConnection = i(new URL(str), paramn);
    boolean bool1 = false;
    boolean bool2 = bool1;
    try {
      Iterator<String> iterator = hashMap.keySet().iterator();
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          bool2 = bool1;
          String str1 = iterator.next();
          bool2 = bool1;
          httpURLConnection.setRequestProperty(str1, (String)hashMap.get(str1));
          continue;
        } 
        bool2 = bool1;
        j(httpURLConnection, paramn);
        bool2 = bool1;
        int i = httpURLConnection.getResponseCode();
        if (i != -1) {
          bool2 = bool1;
          if (!g(paramn.getMethod(), i)) {
            bool2 = bool1;
            return new f(i, e(httpURLConnection.getHeaderFields()));
          } 
          bool1 = true;
          bool2 = bool1;
          List list = e(httpURLConnection.getHeaderFields());
          bool2 = bool1;
          int j = httpURLConnection.getContentLength();
          bool2 = bool1;
          a a1 = new a();
          bool2 = bool1;
          this(httpURLConnection);
          return new f(i, list, j, a1);
        } 
        bool2 = bool1;
        IOException iOException = new IOException();
        bool2 = bool1;
        this("Could not retrieve response code from HttpUrlConnection.");
        bool2 = bool1;
        throw iOException;
      } 
    } finally {
      if (!bool2)
        httpURLConnection.disconnect(); 
    } 
  }
  
  public HttpURLConnection f(URL paramURL) {
    HttpURLConnection httpURLConnection = (HttpURLConnection)paramURL.openConnection();
    httpURLConnection.setInstanceFollowRedirects(HttpURLConnection.getFollowRedirects());
    return httpURLConnection;
  }
  
  public final HttpURLConnection i(URL paramURL, n paramn) {
    HttpURLConnection httpURLConnection = f(paramURL);
    int i = paramn.getTimeoutMs();
    httpURLConnection.setConnectTimeout(i);
    httpURLConnection.setReadTimeout(i);
    httpURLConnection.setUseCaches(false);
    httpURLConnection.setDoInput(true);
    if ("https".equals(paramURL.getProtocol())) {
      SSLSocketFactory sSLSocketFactory = this.a;
      if (sSLSocketFactory != null)
        ((HttpsURLConnection)httpURLConnection).setSSLSocketFactory(sSLSocketFactory); 
    } 
    return httpURLConnection;
  }
  
  public static class a extends FilterInputStream {
    public final HttpURLConnection a;
    
    public a(HttpURLConnection param1HttpURLConnection) {
      super(h.b(param1HttpURLConnection));
      this.a = param1HttpURLConnection;
    }
    
    public void close() {
      super.close();
      this.a.disconnect();
    }
  }
  
  public static interface b {}
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */