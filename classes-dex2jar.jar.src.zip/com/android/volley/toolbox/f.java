package com.android.volley.toolbox;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public final class f {
  public final int a;
  
  public final List b;
  
  public final int c;
  
  public final InputStream d;
  
  public f(int paramInt, List paramList) {
    this(paramInt, paramList, -1, null);
  }
  
  public f(int paramInt1, List paramList, int paramInt2, InputStream paramInputStream) {
    this.a = paramInt1;
    this.b = paramList;
    this.c = paramInt2;
    this.d = paramInputStream;
  }
  
  public final InputStream a() {
    return this.d;
  }
  
  public final int b() {
    return this.c;
  }
  
  public final List c() {
    return Collections.unmodifiableList(this.b);
  }
  
  public final int d() {
    return this.a;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */