package com.android.volley.toolbox;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import z.g;
import z.h;
import z.k;
import z.n;
import z.r;
import z.u;
import z.v;

public class b implements h {
  public static final boolean d = v.b;
  
  public final g a;
  
  public final a b;
  
  public final c c;
  
  public b(a parama) {
    this(parama, new c(4096));
  }
  
  public b(a parama, c paramc) {
    this.b = parama;
    this.a = parama;
    this.c = paramc;
  }
  
  public static void b(String paramString, n paramn, u paramu) {
    r r = paramn.getRetryPolicy();
    int i = paramn.getTimeoutMs();
    try {
      r.a(paramu);
      paramn.addMarker(String.format("%s-retry [timeout=%s]", new Object[] { paramString, Integer.valueOf(i) }));
      return;
    } catch (u u1) {
      paramn.addMarker(String.format("%s-timeout-giveup [timeout=%s]", new Object[] { paramString, Integer.valueOf(i) }));
      throw u1;
    } 
  }
  
  public static List c(List<?> paramList, z.b.a parama) {
    TreeSet<String> treeSet = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
    if (!paramList.isEmpty()) {
      Iterator<g> iterator = paramList.iterator();
      while (iterator.hasNext())
        treeSet.add(((g)iterator.next()).a()); 
    } 
    paramList = new ArrayList(paramList);
    List list = parama.h;
    if (list != null) {
      if (!list.isEmpty())
        for (g g1 : parama.h) {
          if (!treeSet.contains(g1.a()))
            paramList.add(g1); 
        }  
    } else if (!parama.g.isEmpty()) {
      for (Map.Entry entry : parama.g.entrySet()) {
        if (!treeSet.contains(entry.getKey()))
          paramList.add(new g((String)entry.getKey(), (String)entry.getValue())); 
      } 
    } 
    return paramList;
  }
  
  public k a(n paramn) {
    // Byte code:
    //   0: invokestatic elapsedRealtime : ()J
    //   3: lstore_2
    //   4: invokestatic emptyList : ()Ljava/util/List;
    //   7: astore #4
    //   9: aconst_null
    //   10: astore #5
    //   12: aload_0
    //   13: aload_1
    //   14: invokevirtual getCacheEntry : ()Lz/b$a;
    //   17: invokevirtual d : (Lz/b$a;)Ljava/util/Map;
    //   20: astore #6
    //   22: aload_0
    //   23: getfield b : Lcom/android/volley/toolbox/a;
    //   26: aload_1
    //   27: aload #6
    //   29: invokevirtual a : (Lz/n;Ljava/util/Map;)Lcom/android/volley/toolbox/f;
    //   32: astore #6
    //   34: aload #6
    //   36: invokevirtual d : ()I
    //   39: istore #7
    //   41: aload #6
    //   43: invokevirtual c : ()Ljava/util/List;
    //   46: astore #5
    //   48: iload #7
    //   50: sipush #304
    //   53: if_icmpne -> 152
    //   56: aload_1
    //   57: invokevirtual getCacheEntry : ()Lz/b$a;
    //   60: astore #4
    //   62: aload #4
    //   64: ifnonnull -> 87
    //   67: new z/k
    //   70: dup
    //   71: sipush #304
    //   74: aconst_null
    //   75: iconst_1
    //   76: invokestatic elapsedRealtime : ()J
    //   79: lload_2
    //   80: lsub
    //   81: aload #5
    //   83: invokespecial <init> : (I[BZJLjava/util/List;)V
    //   86: areturn
    //   87: aload #5
    //   89: aload #4
    //   91: invokestatic c : (Ljava/util/List;Lz/b$a;)Ljava/util/List;
    //   94: astore #8
    //   96: new z/k
    //   99: dup
    //   100: sipush #304
    //   103: aload #4
    //   105: getfield a : [B
    //   108: iconst_1
    //   109: invokestatic elapsedRealtime : ()J
    //   112: lload_2
    //   113: lsub
    //   114: aload #8
    //   116: invokespecial <init> : (I[BZJLjava/util/List;)V
    //   119: astore #4
    //   121: aload #4
    //   123: areturn
    //   124: astore #4
    //   126: aconst_null
    //   127: astore #9
    //   129: aload #6
    //   131: astore #10
    //   133: aload #5
    //   135: astore #8
    //   137: aload #4
    //   139: astore #6
    //   141: aload #10
    //   143: astore #5
    //   145: aload #9
    //   147: astore #4
    //   149: goto -> 332
    //   152: aload #6
    //   154: invokevirtual a : ()Ljava/io/InputStream;
    //   157: astore #4
    //   159: aload #4
    //   161: ifnull -> 180
    //   164: aload_0
    //   165: aload #4
    //   167: aload #6
    //   169: invokevirtual b : ()I
    //   172: invokevirtual e : (Ljava/io/InputStream;I)[B
    //   175: astore #4
    //   177: goto -> 185
    //   180: iconst_0
    //   181: newarray byte
    //   183: astore #4
    //   185: aload_0
    //   186: invokestatic elapsedRealtime : ()J
    //   189: lload_2
    //   190: lsub
    //   191: aload_1
    //   192: aload #4
    //   194: iload #7
    //   196: invokevirtual f : (JLz/n;[BI)V
    //   199: iload #7
    //   201: sipush #200
    //   204: if_icmplt -> 239
    //   207: iload #7
    //   209: sipush #299
    //   212: if_icmpgt -> 239
    //   215: invokestatic elapsedRealtime : ()J
    //   218: lstore #11
    //   220: new z/k
    //   223: dup
    //   224: iload #7
    //   226: aload #4
    //   228: iconst_0
    //   229: lload #11
    //   231: lload_2
    //   232: lsub
    //   233: aload #5
    //   235: invokespecial <init> : (I[BZJLjava/util/List;)V
    //   238: areturn
    //   239: new java/io/IOException
    //   242: astore #8
    //   244: aload #8
    //   246: invokespecial <init> : ()V
    //   249: aload #8
    //   251: athrow
    //   252: astore #8
    //   254: goto -> 259
    //   257: astore #8
    //   259: aload #5
    //   261: astore #10
    //   263: aload #6
    //   265: astore #5
    //   267: aload #8
    //   269: astore #6
    //   271: aload #10
    //   273: astore #8
    //   275: goto -> 332
    //   278: astore #8
    //   280: aload #5
    //   282: astore #4
    //   284: aload #8
    //   286: astore #5
    //   288: goto -> 293
    //   291: astore #5
    //   293: aload #4
    //   295: astore #8
    //   297: aconst_null
    //   298: astore #10
    //   300: aload #6
    //   302: astore #4
    //   304: aload #5
    //   306: astore #6
    //   308: aload #4
    //   310: astore #5
    //   312: aload #10
    //   314: astore #4
    //   316: goto -> 332
    //   319: astore #6
    //   321: aconst_null
    //   322: astore #10
    //   324: aload #4
    //   326: astore #8
    //   328: aload #10
    //   330: astore #4
    //   332: aload #5
    //   334: ifnull -> 537
    //   337: aload #5
    //   339: invokevirtual d : ()I
    //   342: istore #7
    //   344: ldc 'Unexpected response code %d for %s'
    //   346: iconst_2
    //   347: anewarray java/lang/Object
    //   350: dup
    //   351: iconst_0
    //   352: iload #7
    //   354: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   357: aastore
    //   358: dup
    //   359: iconst_1
    //   360: aload_1
    //   361: invokevirtual getUrl : ()Ljava/lang/String;
    //   364: aastore
    //   365: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   368: aload #4
    //   370: ifnull -> 521
    //   373: new z/k
    //   376: dup
    //   377: iload #7
    //   379: aload #4
    //   381: iconst_0
    //   382: invokestatic elapsedRealtime : ()J
    //   385: lload_2
    //   386: lsub
    //   387: aload #8
    //   389: invokespecial <init> : (I[BZJLjava/util/List;)V
    //   392: astore #6
    //   394: iload #7
    //   396: sipush #401
    //   399: if_icmpeq -> 503
    //   402: iload #7
    //   404: sipush #403
    //   407: if_icmpne -> 413
    //   410: goto -> 503
    //   413: iload #7
    //   415: sipush #400
    //   418: if_icmplt -> 442
    //   421: iload #7
    //   423: sipush #499
    //   426: if_icmple -> 432
    //   429: goto -> 442
    //   432: new z/d
    //   435: dup
    //   436: aload #6
    //   438: invokespecial <init> : (Lz/k;)V
    //   441: athrow
    //   442: iload #7
    //   444: sipush #500
    //   447: if_icmplt -> 493
    //   450: iload #7
    //   452: sipush #599
    //   455: if_icmpgt -> 493
    //   458: aload_1
    //   459: invokevirtual shouldRetryServerErrors : ()Z
    //   462: ifeq -> 483
    //   465: new z/s
    //   468: dup
    //   469: aload #6
    //   471: invokespecial <init> : (Lz/k;)V
    //   474: astore #6
    //   476: ldc 'server'
    //   478: astore #5
    //   480: goto -> 608
    //   483: new z/s
    //   486: dup
    //   487: aload #6
    //   489: invokespecial <init> : (Lz/k;)V
    //   492: athrow
    //   493: new z/s
    //   496: dup
    //   497: aload #6
    //   499: invokespecial <init> : (Lz/k;)V
    //   502: athrow
    //   503: new z/a
    //   506: dup
    //   507: aload #6
    //   509: invokespecial <init> : (Lz/k;)V
    //   512: astore #6
    //   514: ldc 'auth'
    //   516: astore #5
    //   518: goto -> 608
    //   521: new z/j
    //   524: dup
    //   525: invokespecial <init> : ()V
    //   528: astore #6
    //   530: ldc 'network'
    //   532: astore #5
    //   534: goto -> 608
    //   537: new z/l
    //   540: dup
    //   541: aload #6
    //   543: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   546: athrow
    //   547: astore #6
    //   549: new java/lang/StringBuilder
    //   552: dup
    //   553: invokespecial <init> : ()V
    //   556: astore #5
    //   558: aload #5
    //   560: ldc_w 'Bad URL '
    //   563: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   566: pop
    //   567: aload #5
    //   569: aload_1
    //   570: invokevirtual getUrl : ()Ljava/lang/String;
    //   573: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   576: pop
    //   577: new java/lang/RuntimeException
    //   580: dup
    //   581: aload #5
    //   583: invokevirtual toString : ()Ljava/lang/String;
    //   586: aload #6
    //   588: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   591: athrow
    //   592: astore #6
    //   594: new z/t
    //   597: dup
    //   598: invokespecial <init> : ()V
    //   601: astore #6
    //   603: ldc_w 'socket'
    //   606: astore #5
    //   608: aload #5
    //   610: aload_1
    //   611: aload #6
    //   613: invokestatic b : (Ljava/lang/String;Lz/n;Lz/u;)V
    //   616: goto -> 4
    // Exception table:
    //   from	to	target	type
    //   12	34	592	java/net/SocketTimeoutException
    //   12	34	547	java/net/MalformedURLException
    //   12	34	319	java/io/IOException
    //   34	48	592	java/net/SocketTimeoutException
    //   34	48	547	java/net/MalformedURLException
    //   34	48	291	java/io/IOException
    //   56	62	592	java/net/SocketTimeoutException
    //   56	62	547	java/net/MalformedURLException
    //   56	62	124	java/io/IOException
    //   67	87	592	java/net/SocketTimeoutException
    //   67	87	547	java/net/MalformedURLException
    //   67	87	124	java/io/IOException
    //   87	121	592	java/net/SocketTimeoutException
    //   87	121	547	java/net/MalformedURLException
    //   87	121	124	java/io/IOException
    //   152	159	592	java/net/SocketTimeoutException
    //   152	159	547	java/net/MalformedURLException
    //   152	159	278	java/io/IOException
    //   164	177	592	java/net/SocketTimeoutException
    //   164	177	547	java/net/MalformedURLException
    //   164	177	124	java/io/IOException
    //   180	185	592	java/net/SocketTimeoutException
    //   180	185	547	java/net/MalformedURLException
    //   180	185	278	java/io/IOException
    //   185	199	592	java/net/SocketTimeoutException
    //   185	199	547	java/net/MalformedURLException
    //   185	199	257	java/io/IOException
    //   215	220	592	java/net/SocketTimeoutException
    //   215	220	547	java/net/MalformedURLException
    //   215	220	257	java/io/IOException
    //   220	239	592	java/net/SocketTimeoutException
    //   220	239	547	java/net/MalformedURLException
    //   220	239	252	java/io/IOException
    //   239	252	592	java/net/SocketTimeoutException
    //   239	252	547	java/net/MalformedURLException
    //   239	252	252	java/io/IOException
  }
  
  public final Map d(z.b.a parama) {
    if (parama == null)
      return Collections.emptyMap(); 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String str = parama.b;
    if (str != null)
      hashMap.put("If-None-Match", str); 
    long l = parama.d;
    if (l > 0L)
      hashMap.put("If-Modified-Since", e.a(l)); 
    return hashMap;
  }
  
  public final byte[] e(InputStream paramInputStream, int paramInt) {
    // Byte code:
    //   0: new com/android/volley/toolbox/j
    //   3: dup
    //   4: aload_0
    //   5: getfield c : Lcom/android/volley/toolbox/c;
    //   8: iload_2
    //   9: invokespecial <init> : (Lcom/android/volley/toolbox/c;I)V
    //   12: astore_3
    //   13: aconst_null
    //   14: astore #4
    //   16: aload_1
    //   17: ifnull -> 116
    //   20: aload #4
    //   22: astore #5
    //   24: aload_0
    //   25: getfield c : Lcom/android/volley/toolbox/c;
    //   28: sipush #1024
    //   31: invokevirtual a : (I)[B
    //   34: astore #4
    //   36: aload #4
    //   38: astore #5
    //   40: aload_1
    //   41: aload #4
    //   43: invokevirtual read : ([B)I
    //   46: istore_2
    //   47: iload_2
    //   48: iconst_m1
    //   49: if_icmpeq -> 67
    //   52: aload #4
    //   54: astore #5
    //   56: aload_3
    //   57: aload #4
    //   59: iconst_0
    //   60: iload_2
    //   61: invokevirtual write : ([BII)V
    //   64: goto -> 36
    //   67: aload #4
    //   69: astore #5
    //   71: aload_3
    //   72: invokevirtual toByteArray : ()[B
    //   75: astore #6
    //   77: aload_1
    //   78: invokevirtual close : ()V
    //   81: goto -> 95
    //   84: astore_1
    //   85: ldc_w 'Error occurred when closing InputStream'
    //   88: iconst_0
    //   89: anewarray java/lang/Object
    //   92: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   95: aload_0
    //   96: getfield c : Lcom/android/volley/toolbox/c;
    //   99: aload #4
    //   101: invokevirtual b : ([B)V
    //   104: aload_3
    //   105: invokevirtual close : ()V
    //   108: aload #6
    //   110: areturn
    //   111: astore #4
    //   113: goto -> 141
    //   116: aload #4
    //   118: astore #5
    //   120: new z/s
    //   123: astore #6
    //   125: aload #4
    //   127: astore #5
    //   129: aload #6
    //   131: invokespecial <init> : ()V
    //   134: aload #4
    //   136: astore #5
    //   138: aload #6
    //   140: athrow
    //   141: aload_1
    //   142: ifnull -> 163
    //   145: aload_1
    //   146: invokevirtual close : ()V
    //   149: goto -> 163
    //   152: astore_1
    //   153: ldc_w 'Error occurred when closing InputStream'
    //   156: iconst_0
    //   157: anewarray java/lang/Object
    //   160: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   163: aload_0
    //   164: getfield c : Lcom/android/volley/toolbox/c;
    //   167: aload #5
    //   169: invokevirtual b : ([B)V
    //   172: aload_3
    //   173: invokevirtual close : ()V
    //   176: aload #4
    //   178: athrow
    // Exception table:
    //   from	to	target	type
    //   24	36	111	finally
    //   40	47	111	finally
    //   56	64	111	finally
    //   71	77	111	finally
    //   77	81	84	java/io/IOException
    //   120	125	111	finally
    //   129	134	111	finally
    //   138	141	111	finally
    //   145	149	152	java/io/IOException
  }
  
  public final void f(long paramLong, n paramn, byte[] paramArrayOfbyte, int paramInt) {
    if (d || paramLong > 3000L) {
      String str;
      if (paramArrayOfbyte != null) {
        Integer integer = Integer.valueOf(paramArrayOfbyte.length);
      } else {
        str = "null";
      } 
      v.b("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", new Object[] { paramn, Long.valueOf(paramLong), str, Integer.valueOf(paramInt), Integer.valueOf(paramn.getRetryPolicy().c()) });
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */