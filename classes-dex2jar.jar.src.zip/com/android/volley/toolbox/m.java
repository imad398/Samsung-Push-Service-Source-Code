package com.android.volley.toolbox;

import android.content.Context;
import java.io.File;
import z.h;
import z.o;

public abstract class m {
  public static o a(Context paramContext) {
    return b(paramContext, null);
  }
  
  public static o b(Context paramContext, a parama) {
    b b;
    if (parama == null) {
      b = new b(new h());
    } else {
      b = new b((a)b);
    } 
    return c(paramContext, b);
  }
  
  public static o c(Context paramContext, h paramh) {
    o o = new o(new d(new File(paramContext.getCacheDir(), "volley")), paramh);
    o.d();
    return o;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */