package com.android.volley.toolbox;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import z.n;
import z.p;
import z.u;

public class k implements Future, p.b, p.a {
  public n a;
  
  public boolean b = false;
  
  public Object c;
  
  public u d;
  
  public static k e() {
    return new k();
  }
  
  public void a(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: putfield b : Z
    //   7: aload_0
    //   8: aload_1
    //   9: putfield c : Ljava/lang/Object;
    //   12: aload_0
    //   13: invokevirtual notifyAll : ()V
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  public void b(u paramu) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield d : Lz/u;
    //   7: aload_0
    //   8: invokevirtual notifyAll : ()V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public boolean cancel(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lz/n;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnonnull -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_0
    //   14: ireturn
    //   15: aload_0
    //   16: invokevirtual isDone : ()Z
    //   19: ifne -> 33
    //   22: aload_0
    //   23: getfield a : Lz/n;
    //   26: invokevirtual cancel : ()V
    //   29: aload_0
    //   30: monitorexit
    //   31: iconst_1
    //   32: ireturn
    //   33: aload_0
    //   34: monitorexit
    //   35: iconst_0
    //   36: ireturn
    //   37: astore_2
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_2
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	37	finally
    //   15	29	37	finally
  }
  
  public final Object d(Long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Lz/u;
    //   6: ifnonnull -> 141
    //   9: aload_0
    //   10: getfield b : Z
    //   13: ifeq -> 25
    //   16: aload_0
    //   17: getfield c : Ljava/lang/Object;
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: areturn
    //   25: aload_1
    //   26: ifnonnull -> 44
    //   29: aload_0
    //   30: invokevirtual isDone : ()Z
    //   33: ifne -> 94
    //   36: aload_0
    //   37: lconst_0
    //   38: invokevirtual wait : (J)V
    //   41: goto -> 29
    //   44: aload_1
    //   45: invokevirtual longValue : ()J
    //   48: lconst_0
    //   49: lcmp
    //   50: ifle -> 94
    //   53: invokestatic uptimeMillis : ()J
    //   56: lstore_2
    //   57: aload_1
    //   58: invokevirtual longValue : ()J
    //   61: lload_2
    //   62: ladd
    //   63: lstore #4
    //   65: aload_0
    //   66: invokevirtual isDone : ()Z
    //   69: ifne -> 94
    //   72: lload_2
    //   73: lload #4
    //   75: lcmp
    //   76: ifge -> 94
    //   79: aload_0
    //   80: lload #4
    //   82: lload_2
    //   83: lsub
    //   84: invokevirtual wait : (J)V
    //   87: invokestatic uptimeMillis : ()J
    //   90: lstore_2
    //   91: goto -> 65
    //   94: aload_0
    //   95: getfield d : Lz/u;
    //   98: ifnonnull -> 127
    //   101: aload_0
    //   102: getfield b : Z
    //   105: ifeq -> 117
    //   108: aload_0
    //   109: getfield c : Ljava/lang/Object;
    //   112: astore_1
    //   113: aload_0
    //   114: monitorexit
    //   115: aload_1
    //   116: areturn
    //   117: new java/util/concurrent/TimeoutException
    //   120: astore_1
    //   121: aload_1
    //   122: invokespecial <init> : ()V
    //   125: aload_1
    //   126: athrow
    //   127: new java/util/concurrent/ExecutionException
    //   130: astore_1
    //   131: aload_1
    //   132: aload_0
    //   133: getfield d : Lz/u;
    //   136: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   139: aload_1
    //   140: athrow
    //   141: new java/util/concurrent/ExecutionException
    //   144: astore_1
    //   145: aload_1
    //   146: aload_0
    //   147: getfield d : Lz/u;
    //   150: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   153: aload_1
    //   154: athrow
    //   155: astore_1
    //   156: aload_0
    //   157: monitorexit
    //   158: aload_1
    //   159: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	155	finally
    //   29	41	155	finally
    //   44	65	155	finally
    //   65	72	155	finally
    //   79	91	155	finally
    //   94	113	155	finally
    //   117	127	155	finally
    //   127	141	155	finally
    //   141	155	155	finally
  }
  
  public Object get() {
    try {
      return d(null);
    } catch (TimeoutException timeoutException) {
      throw new AssertionError(timeoutException);
    } 
  }
  
  public Object get(long paramLong, TimeUnit paramTimeUnit) {
    return d(Long.valueOf(TimeUnit.MILLISECONDS.convert(paramLong, paramTimeUnit)));
  }
  
  public boolean isCancelled() {
    n n1 = this.a;
    return (n1 == null) ? false : n1.isCanceled();
  }
  
  public boolean isDone() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Z
    //   6: ifne -> 33
    //   9: aload_0
    //   10: getfield d : Lz/u;
    //   13: ifnonnull -> 33
    //   16: aload_0
    //   17: invokevirtual isCancelled : ()Z
    //   20: istore_1
    //   21: iload_1
    //   22: ifeq -> 28
    //   25: goto -> 33
    //   28: iconst_0
    //   29: istore_1
    //   30: goto -> 35
    //   33: iconst_1
    //   34: istore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: iload_1
    //   38: ireturn
    //   39: astore_2
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_2
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	39	finally
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */