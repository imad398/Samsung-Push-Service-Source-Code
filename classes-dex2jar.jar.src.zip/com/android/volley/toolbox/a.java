package com.android.volley.toolbox;

import java.util.Map;
import z.n;

public abstract class a implements g {
  public abstract f a(n paramn, Map paramMap);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */