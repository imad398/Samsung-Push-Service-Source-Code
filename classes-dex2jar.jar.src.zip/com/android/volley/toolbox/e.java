package com.android.volley.toolbox;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;
import z.b;
import z.g;
import z.k;
import z.v;

public abstract class e {
  public static String a(long paramLong) {
    return b().format(new Date(paramLong));
  }
  
  public static SimpleDateFormat b() {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    return simpleDateFormat;
  }
  
  public static b.a c(k paramk) {
    // Byte code:
    //   0: invokestatic currentTimeMillis : ()J
    //   3: lstore_1
    //   4: aload_0
    //   5: getfield c : Ljava/util/Map;
    //   8: astore_3
    //   9: aload_3
    //   10: ldc 'Date'
    //   12: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   17: checkcast java/lang/String
    //   20: astore #4
    //   22: aload #4
    //   24: ifnull -> 37
    //   27: aload #4
    //   29: invokestatic f : (Ljava/lang/String;)J
    //   32: lstore #5
    //   34: goto -> 40
    //   37: lconst_0
    //   38: lstore #5
    //   40: aload_3
    //   41: ldc 'Cache-Control'
    //   43: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: checkcast java/lang/String
    //   51: astore #4
    //   53: iconst_0
    //   54: istore #7
    //   56: iconst_0
    //   57: istore #8
    //   59: aload #4
    //   61: ifnull -> 243
    //   64: aload #4
    //   66: ldc ','
    //   68: iconst_0
    //   69: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   72: astore #4
    //   74: iconst_0
    //   75: istore #9
    //   77: lconst_0
    //   78: lstore #10
    //   80: lconst_0
    //   81: lstore #12
    //   83: iload #8
    //   85: aload #4
    //   87: arraylength
    //   88: if_icmpge -> 237
    //   91: aload #4
    //   93: iload #8
    //   95: aaload
    //   96: invokevirtual trim : ()Ljava/lang/String;
    //   99: astore #14
    //   101: aload #14
    //   103: ldc 'no-cache'
    //   105: invokevirtual equals : (Ljava/lang/Object;)Z
    //   108: ifne -> 235
    //   111: aload #14
    //   113: ldc 'no-store'
    //   115: invokevirtual equals : (Ljava/lang/Object;)Z
    //   118: ifeq -> 124
    //   121: goto -> 235
    //   124: aload #14
    //   126: ldc 'max-age='
    //   128: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   131: ifeq -> 153
    //   134: aload #14
    //   136: bipush #8
    //   138: invokevirtual substring : (I)Ljava/lang/String;
    //   141: invokestatic parseLong : (Ljava/lang/String;)J
    //   144: lstore #15
    //   146: lload #12
    //   148: lstore #17
    //   150: goto -> 221
    //   153: aload #14
    //   155: ldc 'stale-while-revalidate='
    //   157: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   160: ifeq -> 182
    //   163: aload #14
    //   165: bipush #23
    //   167: invokevirtual substring : (I)Ljava/lang/String;
    //   170: invokestatic parseLong : (Ljava/lang/String;)J
    //   173: lstore #17
    //   175: lload #10
    //   177: lstore #15
    //   179: goto -> 221
    //   182: aload #14
    //   184: ldc 'must-revalidate'
    //   186: invokevirtual equals : (Ljava/lang/Object;)Z
    //   189: ifne -> 210
    //   192: lload #10
    //   194: lstore #15
    //   196: lload #12
    //   198: lstore #17
    //   200: aload #14
    //   202: ldc 'proxy-revalidate'
    //   204: invokevirtual equals : (Ljava/lang/Object;)Z
    //   207: ifeq -> 221
    //   210: iconst_1
    //   211: istore #9
    //   213: lload #12
    //   215: lstore #17
    //   217: lload #10
    //   219: lstore #15
    //   221: iinc #8, 1
    //   224: lload #15
    //   226: lstore #10
    //   228: lload #17
    //   230: lstore #12
    //   232: goto -> 83
    //   235: aconst_null
    //   236: areturn
    //   237: iconst_1
    //   238: istore #8
    //   240: goto -> 256
    //   243: iconst_0
    //   244: istore #9
    //   246: lconst_0
    //   247: lstore #10
    //   249: lconst_0
    //   250: lstore #12
    //   252: iload #7
    //   254: istore #8
    //   256: aload_3
    //   257: ldc 'Expires'
    //   259: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   264: checkcast java/lang/String
    //   267: astore #4
    //   269: aload #4
    //   271: ifnull -> 284
    //   274: aload #4
    //   276: invokestatic f : (Ljava/lang/String;)J
    //   279: lstore #17
    //   281: goto -> 287
    //   284: lconst_0
    //   285: lstore #17
    //   287: aload_3
    //   288: ldc 'Last-Modified'
    //   290: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   295: checkcast java/lang/String
    //   298: astore #4
    //   300: aload #4
    //   302: ifnull -> 315
    //   305: aload #4
    //   307: invokestatic f : (Ljava/lang/String;)J
    //   310: lstore #15
    //   312: goto -> 318
    //   315: lconst_0
    //   316: lstore #15
    //   318: aload_3
    //   319: ldc 'ETag'
    //   321: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   326: checkcast java/lang/String
    //   329: astore #14
    //   331: iload #8
    //   333: ifeq -> 390
    //   336: lload_1
    //   337: lload #10
    //   339: ldc2_w 1000
    //   342: lmul
    //   343: ladd
    //   344: lstore #10
    //   346: iload #9
    //   348: ifeq -> 358
    //   351: lload #10
    //   353: lstore #12
    //   355: goto -> 375
    //   358: lload #12
    //   360: invokestatic signum : (J)I
    //   363: pop
    //   364: lload #12
    //   366: ldc2_w 1000
    //   369: lmul
    //   370: lload #10
    //   372: ladd
    //   373: lstore #12
    //   375: lload #12
    //   377: lstore #17
    //   379: lload #10
    //   381: lstore #12
    //   383: lload #17
    //   385: lstore #10
    //   387: goto -> 427
    //   390: lconst_0
    //   391: lstore #10
    //   393: lload #5
    //   395: lconst_0
    //   396: lcmp
    //   397: ifle -> 424
    //   400: lload #17
    //   402: lload #5
    //   404: lcmp
    //   405: iflt -> 424
    //   408: lload_1
    //   409: lload #17
    //   411: lload #5
    //   413: lsub
    //   414: ladd
    //   415: lstore #12
    //   417: lload #12
    //   419: lstore #10
    //   421: goto -> 427
    //   424: lconst_0
    //   425: lstore #12
    //   427: new z/b$a
    //   430: dup
    //   431: invokespecial <init> : ()V
    //   434: astore #4
    //   436: aload #4
    //   438: aload_0
    //   439: getfield b : [B
    //   442: putfield a : [B
    //   445: aload #4
    //   447: aload #14
    //   449: putfield b : Ljava/lang/String;
    //   452: aload #4
    //   454: lload #12
    //   456: putfield f : J
    //   459: aload #4
    //   461: lload #10
    //   463: putfield e : J
    //   466: aload #4
    //   468: lload #5
    //   470: putfield c : J
    //   473: aload #4
    //   475: lload #15
    //   477: putfield d : J
    //   480: aload #4
    //   482: aload_3
    //   483: putfield g : Ljava/util/Map;
    //   486: aload #4
    //   488: aload_0
    //   489: getfield d : Ljava/util/List;
    //   492: putfield h : Ljava/util/List;
    //   495: aload #4
    //   497: areturn
    //   498: astore #14
    //   500: lload #10
    //   502: lstore #15
    //   504: lload #12
    //   506: lstore #17
    //   508: goto -> 221
    // Exception table:
    //   from	to	target	type
    //   134	146	498	java/lang/Exception
    //   163	175	498	java/lang/Exception
  }
  
  public static String d(Map paramMap) {
    return e(paramMap, "ISO-8859-1");
  }
  
  public static String e(Map paramMap, String paramString) {
    String str = (String)paramMap.get("Content-Type");
    if (str != null) {
      String[] arrayOfString = str.split(";", 0);
      for (byte b = 1; b < arrayOfString.length; b++) {
        String[] arrayOfString1 = arrayOfString[b].trim().split("=", 0);
        if (arrayOfString1.length == 2 && arrayOfString1[0].equals("charset"))
          return arrayOfString1[1]; 
      } 
    } 
    return paramString;
  }
  
  public static long f(String paramString) {
    try {
      return b().parse(paramString).getTime();
    } catch (ParseException parseException) {
      v.d(parseException, "Unable to parse dateStr: %s, falling back to 0", new Object[] { paramString });
      return 0L;
    } 
  }
  
  public static List g(Map paramMap) {
    ArrayList<g> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry entry : paramMap.entrySet())
      arrayList.add(new g((String)entry.getKey(), (String)entry.getValue())); 
    return arrayList;
  }
  
  public static Map h(List paramList) {
    TreeMap<String, Object> treeMap = new TreeMap<String, Object>(String.CASE_INSENSITIVE_ORDER);
    for (g g : paramList)
      treeMap.put(g.a(), g.b()); 
    return treeMap;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/android/volley/toolbox/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */