package com.google.ads.mediation.customevent;

import android.app.Activity;
import b0.a;
import c0.b;

@Deprecated
public interface CustomEventInterstitial {
  void requestInterstitialAd(b paramb, Activity paramActivity, String paramString1, String paramString2, a parama, Object paramObject);
  
  void showInterstitial();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/ads/mediation/customevent/CustomEventInterstitial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */