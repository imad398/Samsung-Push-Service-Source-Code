package com.google.ads.mediation.customevent;

import a0.b;
import android.app.Activity;
import b0.a;
import c0.a;

@Deprecated
public interface CustomEventBanner {
  void requestBannerAd(a parama, Activity paramActivity, String paramString1, String paramString2, b paramb, a parama1, Object paramObject);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/ads/mediation/customevent/CustomEventBanner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */