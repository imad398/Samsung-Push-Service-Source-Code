package com.google.ads.mediation.customevent;

import a0.b;
import android.app.Activity;
import android.support.v4.media.a;
import android.view.View;
import b0.a;
import b0.c;
import b0.d;
import b0.e;
import b0.f;
import b1.c;
import c0.c;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.common.annotation.KeepName;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter<c, c>, MediationInterstitialAdapter<c, c> {
  public View a;
  
  public CustomEventBanner b;
  
  public CustomEventInterstitial c;
  
  public final void destroy() {
    CustomEventBanner customEventBanner = this.b;
    if (customEventBanner != null)
      customEventBanner.destroy(); 
    CustomEventInterstitial customEventInterstitial = this.c;
    if (customEventInterstitial != null)
      customEventInterstitial.destroy(); 
  }
  
  public final Class<c> getAdditionalParametersType() {
    return c.class;
  }
  
  public final View getBannerView() {
    return this.a;
  }
  
  public final Class<c> getServerParametersType() {
    return c.class;
  }
  
  public final void requestBannerAd(c paramc, Activity paramActivity, c paramc1, b paramb, a parama, c paramc2) {
    throw null;
  }
  
  public final void requestInterstitialAd(d paramd, Activity paramActivity, c paramc, a parama, c paramc1) {
    throw null;
  }
  
  public final void showInterstitial() {
    this.c.showInterstitial();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/ads/mediation/customevent/CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */