package com.google.ads.mediation;

import android.os.Bundle;
import androidx.annotation.Keep;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;

@Keep
public final class AdUrlAdapter extends AbstractAdViewAdapter implements MediationInterstitialAdapter {
  public final String getAdUnitId(Bundle paramBundle) {
    return "adurl";
  }
  
  public final Bundle zza(Bundle paramBundle1, Bundle paramBundle2) {
    if (paramBundle1 == null)
      paramBundle1 = new Bundle(); 
    paramBundle1.putBundle("sdk_less_server_data", paramBundle2);
    paramBundle1.putBoolean("_noRefresh", true);
    return paramBundle1;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/ads/mediation/AdUrlAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */