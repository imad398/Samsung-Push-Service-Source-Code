package com.google.ads.mediation;

import android.app.Activity;
import b0.a;
import b0.b;
import b0.d;

@Deprecated
public interface MediationInterstitialAdapter<ADDITIONAL_PARAMETERS extends b0.f, SERVER_PARAMETERS extends b0.e> extends b {
  void requestInterstitialAd(d paramd, Activity paramActivity, SERVER_PARAMETERS paramSERVER_PARAMETERS, a parama, ADDITIONAL_PARAMETERS paramADDITIONAL_PARAMETERS);
  
  void showInterstitial();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/ads/mediation/MediationInterstitialAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */