package com.google.ads.mediation;

import a1.g;
import a1.h;
import a1.i;
import a1.j;
import a1.k;
import a1.m;
import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import b0.g;
import b0.h;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.internal.ads.ag;
import com.google.android.gms.internal.ads.ax0;
import com.google.android.gms.internal.ads.hv0;
import com.google.android.gms.internal.ads.kp;
import com.google.android.gms.internal.ads.ou0;
import com.google.android.gms.internal.ads.vp;
import com.google.android.gms.internal.ads.zzbiy;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import s0.g;
import u0.g;

@ag
public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationNativeAdapter, j, m, MediationRewardedVideoAdAdapter, zzbiy {
  public static final String AD_UNIT_ID_PARAMETER = "pubid";
  
  private AdView zzhs;
  
  private s0.e zzht;
  
  private s0.b zzhu;
  
  private Context zzhv;
  
  private s0.e zzhw;
  
  private d1.a zzhx;
  
  private final c1.c zzhy = (c1.c)new g(this);
  
  public final s0.c a(Context paramContext, a1.a parama, Bundle paramBundle1, Bundle paramBundle2) {
    s0.c.a a1 = new s0.c.a();
    Date date = parama.d();
    if (date != null)
      a1.e(date); 
    int i = parama.m();
    if (i != 0)
      a1.f(i); 
    Set set = parama.f();
    if (set != null) {
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        a1.a(iterator.next()); 
    } 
    Location location = parama.k();
    if (location != null)
      a1.h(location); 
    if (parama.e()) {
      hv0.a();
      a1.c(kp.o(paramContext));
    } 
    if (parama.h() != -1) {
      i = parama.h();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      a1.i(bool);
    } 
    a1.g(parama.a());
    a1.b(AdMobAdapter.class, zza(paramBundle1, paramBundle2));
    return a1.d();
  }
  
  public String getAdUnitId(Bundle paramBundle) {
    return paramBundle.getString("pubid");
  }
  
  public View getBannerView() {
    return (View)this.zzhs;
  }
  
  public Bundle getInterstitialAdapterInfo() {
    return (new a1.b.a()).b(1).a();
  }
  
  public ax0 getVideoController() {
    AdView adView = this.zzhs;
    if (adView != null) {
      g g = adView.getVideoController();
      if (g != null)
        return g.b(); 
    } 
    return null;
  }
  
  public void initialize(Context paramContext, a1.a parama, String paramString, d1.a parama1, Bundle paramBundle1, Bundle paramBundle2) {
    this.zzhv = paramContext.getApplicationContext();
    this.zzhx = parama1;
    parama1.d(this);
  }
  
  public boolean isInitialized() {
    return (this.zzhx != null);
  }
  
  public void loadAd(a1.a parama, Bundle paramBundle1, Bundle paramBundle2) {
    Context context = this.zzhv;
    if (context == null || this.zzhx == null) {
      vp.a("AdMobAdapter.loadAd called before initialize.");
      return;
    } 
    s0.e e1 = new s0.e(context);
    this.zzhw = e1;
    e1.i(true);
    this.zzhw.e(getAdUnitId(paramBundle1));
    this.zzhw.g(this.zzhy);
    this.zzhw.d((c1.a)new h(this));
    this.zzhw.b(a(this.zzhv, parama, paramBundle2, paramBundle1));
  }
  
  public void onDestroy() {
    AdView adView = this.zzhs;
    if (adView != null) {
      adView.a();
      this.zzhs = null;
    } 
    if (this.zzht != null)
      this.zzht = null; 
    if (this.zzhu != null)
      this.zzhu = null; 
    if (this.zzhw != null)
      this.zzhw = null; 
  }
  
  public void onImmersiveModeUpdated(boolean paramBoolean) {
    s0.e e1 = this.zzht;
    if (e1 != null)
      e1.f(paramBoolean); 
    e1 = this.zzhw;
    if (e1 != null)
      e1.f(paramBoolean); 
  }
  
  public void onPause() {
    AdView adView = this.zzhs;
    if (adView != null)
      adView.c(); 
  }
  
  public void onResume() {
    AdView adView = this.zzhs;
    if (adView != null)
      adView.d(); 
  }
  
  public void requestBannerAd(Context paramContext, a1.c paramc, Bundle paramBundle1, s0.d paramd, a1.a parama, Bundle paramBundle2) {
    AdView adView = new AdView(paramContext);
    this.zzhs = adView;
    adView.setAdSize(new s0.d(paramd.c(), paramd.a()));
    this.zzhs.setAdUnitId(getAdUnitId(paramBundle1));
    this.zzhs.setAdListener(new d(this, paramc));
    this.zzhs.b(a(paramContext, parama, paramBundle2, paramBundle1));
  }
  
  public void requestInterstitialAd(Context paramContext, a1.d paramd, Bundle paramBundle1, a1.a parama, Bundle paramBundle2) {
    s0.e e1 = new s0.e(paramContext);
    this.zzht = e1;
    e1.e(getAdUnitId(paramBundle1));
    this.zzht.c(new e(this, paramd));
    this.zzht.b(a(paramContext, parama, paramBundle2, paramBundle1));
  }
  
  public void requestNativeAd(Context paramContext, a1.e parame, Bundle paramBundle1, i parami, Bundle paramBundle2) {
    f f = new f(this, parame);
    s0.b.a a1 = (new s0.b.a(paramContext, paramBundle1.getString("pubid"))).f(f);
    u0.b b2 = parami.g();
    if (b2 != null)
      a1.g(b2); 
    if (parami.j())
      a1.e(f); 
    if (parami.b())
      a1.b(f); 
    if (parami.l())
      a1.c(f); 
    if (parami.i())
      for (String str : parami.c().keySet()) {
        if (((Boolean)parami.c().get(str)).booleanValue()) {
          f f1 = f;
        } else {
          b2 = null;
        } 
        a1.d(str, f, (u0.f.a)b2);
      }  
    s0.b b1 = a1.a();
    this.zzhu = b1;
    b1.a(a(paramContext, (a1.a)parami, paramBundle2, paramBundle1));
  }
  
  public void showInterstitial() {
    this.zzht.h();
  }
  
  public void showVideo() {
    this.zzhw.h();
  }
  
  public abstract Bundle zza(Bundle paramBundle1, Bundle paramBundle2);
  
  public static final class a extends g {
    public final u0.d p;
    
    public a(u0.d param1d) {
      this.p = param1d;
      z(param1d.c().toString());
      B(param1d.e());
      x(param1d.a().toString());
      A(param1d.d());
      y(param1d.b().toString());
      if (param1d.g() != null)
        D(param1d.g().doubleValue()); 
      if (param1d.h() != null)
        E(param1d.h().toString()); 
      if (param1d.f() != null)
        C(param1d.f().toString()); 
      j(true);
      i(true);
      n(param1d.i());
    }
    
    public final void k(View param1View) {
      android.support.v4.media.a.a(u0.c.a.get(param1View));
    }
  }
  
  public static final class b extends h {
    public final u0.e n;
    
    public b(u0.e param1e) {
      this.n = param1e;
      y(param1e.d().toString());
      z(param1e.e());
      w(param1e.b().toString());
      if (param1e.f() != null)
        A(param1e.f()); 
      x(param1e.c().toString());
      v(param1e.a().toString());
      j(true);
      i(true);
      n(param1e.g());
    }
    
    public final void k(View param1View) {
      android.support.v4.media.a.a(u0.c.a.get(param1View));
    }
  }
  
  public static final class c extends k {
    public final g r;
    
    public c(g param1g) {
      this.r = param1g;
      u(param1g.d());
      w(param1g.f());
      s(param1g.b());
      v(param1g.e());
      t(param1g.c());
      r(param1g.a());
      A(param1g.h());
      B(param1g.i());
      z(param1g.g());
      H(param1g.k());
      y(true);
      x(true);
      E(param1g.j());
    }
    
    public final void C(View param1View, Map param1Map1, Map param1Map2) {
      android.support.v4.media.a.a(u0.c.a.get(param1View));
    }
  }
  
  public static final class d extends s0.a implements t0.a, ou0 {
    public final AbstractAdViewAdapter a;
    
    public final a1.c b;
    
    public d(AbstractAdViewAdapter param1AbstractAdViewAdapter, a1.c param1c) {
      this.a = param1AbstractAdViewAdapter;
      this.b = param1c;
    }
    
    public final void f() {
      this.b.a(this.a);
    }
    
    public final void g(int param1Int) {
      this.b.w(this.a, param1Int);
    }
    
    public final void i() {
      this.b.l(this.a);
    }
    
    public final void j() {
      this.b.h(this.a);
    }
    
    public final void k() {
      this.b.k(this.a);
    }
    
    public final void l() {
      this.b.q(this.a);
    }
    
    public final void u(String param1String1, String param1String2) {
      this.b.p(this.a, param1String1, param1String2);
    }
  }
  
  public static final class e extends s0.a implements ou0 {
    public final AbstractAdViewAdapter a;
    
    public final a1.d b;
    
    public e(AbstractAdViewAdapter param1AbstractAdViewAdapter, a1.d param1d) {
      this.a = param1AbstractAdViewAdapter;
      this.b = param1d;
    }
    
    public final void f() {
      this.b.r((MediationInterstitialAdapter)this.a);
    }
    
    public final void g(int param1Int) {
      this.b.d((MediationInterstitialAdapter)this.a, param1Int);
    }
    
    public final void i() {
      this.b.c((MediationInterstitialAdapter)this.a);
    }
    
    public final void j() {
      this.b.t((MediationInterstitialAdapter)this.a);
    }
    
    public final void k() {
      this.b.o((MediationInterstitialAdapter)this.a);
    }
    
    public final void l() {
      this.b.v((MediationInterstitialAdapter)this.a);
    }
  }
  
  public static final class f extends s0.a implements u0.d.a, u0.e.a, u0.f.a, u0.f.b, g.a {
    public final AbstractAdViewAdapter a;
    
    public final a1.e b;
    
    public f(AbstractAdViewAdapter param1AbstractAdViewAdapter, a1.e param1e) {
      this.a = param1AbstractAdViewAdapter;
      this.b = param1e;
    }
    
    public final void a(u0.d param1d) {
      this.b.g(this.a, (a1.f)new AbstractAdViewAdapter.a(param1d));
    }
    
    public final void b(u0.f param1f) {
      this.b.e(this.a, param1f);
    }
    
    public final void c(u0.e param1e) {
      this.b.g(this.a, (a1.f)new AbstractAdViewAdapter.b(param1e));
    }
    
    public final void d(u0.f param1f, String param1String) {
      this.b.f(this.a, param1f, param1String);
    }
    
    public final void e(g param1g) {
      this.b.s(this.a, new AbstractAdViewAdapter.c(param1g));
    }
    
    public final void f() {
      this.b.j(this.a);
    }
    
    public final void g(int param1Int) {
      this.b.m(this.a, param1Int);
    }
    
    public final void h() {
      this.b.u(this.a);
    }
    
    public final void i() {
      this.b.i(this.a);
    }
    
    public final void j() {
      this.b.n(this.a);
    }
    
    public final void k() {}
    
    public final void l() {
      this.b.b(this.a);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/ads/mediation/AbstractAdViewAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */