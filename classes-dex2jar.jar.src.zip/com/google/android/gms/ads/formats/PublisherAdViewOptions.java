package com.google.android.gms.ads.formats;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.ads.ag;
import com.google.android.gms.internal.ads.gw0;
import com.google.android.gms.internal.ads.hw0;
import h1.b;
import t0.a;
import u0.i;

@ag
public final class PublisherAdViewOptions extends AbstractSafeParcelable {
  public static final Parcelable.Creator<PublisherAdViewOptions> CREATOR = (Parcelable.Creator<PublisherAdViewOptions>)new i();
  
  private final boolean zzbli;
  
  private final gw0 zzblj;
  
  private a zzblk;
  
  public PublisherAdViewOptions(boolean paramBoolean, IBinder paramIBinder) {
    this.zzbli = paramBoolean;
    if (paramIBinder != null) {
      gw0 gw01 = hw0.t8(paramIBinder);
    } else {
      paramIBinder = null;
    } 
    this.zzblj = (gw0)paramIBinder;
  }
  
  public final boolean q() {
    return this.zzbli;
  }
  
  public final gw0 v() {
    return this.zzblj;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    IBinder iBinder;
    paramInt = b.a(paramParcel);
    b.c(paramParcel, 1, q());
    gw0 gw01 = this.zzblj;
    if (gw01 == null) {
      gw01 = null;
    } else {
      iBinder = gw01.asBinder();
    } 
    b.h(paramParcel, 2, iBinder, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/formats/PublisherAdViewOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */