package com.google.android.gms.ads.doubleclick;

import android.view.ViewGroup;

public abstract class PublisherAdView extends ViewGroup {}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/doubleclick/PublisherAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */