package com.google.android.gms.ads.reward.mediation;

import android.content.Context;
import android.os.Bundle;
import d1.a;
import java.util.List;

public interface InitializableMediationRewardedVideoAdAdapter extends MediationRewardedVideoAdAdapter {
  void initialize(Context paramContext, a parama, List<Bundle> paramList);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/reward/mediation/InitializableMediationRewardedVideoAdAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */