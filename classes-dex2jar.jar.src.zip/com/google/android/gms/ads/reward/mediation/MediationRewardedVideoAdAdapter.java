package com.google.android.gms.ads.reward.mediation;

import a1.a;
import a1.b;
import android.content.Context;
import android.os.Bundle;
import d1.a;

public interface MediationRewardedVideoAdAdapter extends b {
  public static final String CUSTOM_EVENT_SERVER_PARAMETER_FIELD = "parameter";
  
  void initialize(Context paramContext, a parama, String paramString, a parama1, Bundle paramBundle1, Bundle paramBundle2);
  
  boolean isInitialized();
  
  void loadAd(a parama, Bundle paramBundle1, Bundle paramBundle2);
  
  void showVideo();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/reward/mediation/MediationRewardedVideoAdAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */