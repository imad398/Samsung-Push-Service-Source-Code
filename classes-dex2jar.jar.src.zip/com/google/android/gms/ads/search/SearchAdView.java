package com.google.android.gms.ads.search;

import android.view.ViewGroup;
import com.google.android.gms.internal.ads.ag;

@ag
public abstract class SearchAdView extends ViewGroup {}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/search/SearchAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */