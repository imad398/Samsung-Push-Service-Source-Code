package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.internal.ads.ed;
import com.google.android.gms.internal.ads.hv0;
import com.google.android.gms.internal.ads.vp;
import m1.b;

public class AdActivity extends Activity {
  public ed a;
  
  public final void a() {
    ed ed1 = this.a;
    if (ed1 != null)
      try {
        ed1.B4();
        return;
      } catch (RemoteException remoteException) {
        vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      }  
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    try {
      this.a.q1(paramInt1, paramInt2, paramIntent);
    } catch (Exception exception) {
      vp.f("#007 Could not call remote method.", exception);
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onBackPressed() {
    boolean bool2;
    boolean bool1 = true;
    try {
      ed ed1 = this.a;
      bool2 = bool1;
      if (ed1 != null)
        bool2 = ed1.C3(); 
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      bool2 = bool1;
    } 
    if (bool2)
      super.onBackPressed(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    try {
      this.a.z4(b.R(paramConfiguration));
      return;
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ed ed1 = hv0.b().c(this);
    this.a = ed1;
    if (ed1 == null) {
      paramBundle = null;
    } else {
      try {
        ed1.b8(paramBundle);
        return;
      } catch (RemoteException remoteException) {}
    } 
    vp.f("#007 Could not call remote method.", (Throwable)remoteException);
    finish();
  }
  
  public void onDestroy() {
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.onDestroy(); 
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
    } 
    super.onDestroy();
  }
  
  public void onPause() {
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.onPause(); 
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
    } 
    super.onPause();
  }
  
  public void onRestart() {
    super.onRestart();
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.o4(); 
      return;
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  public void onResume() {
    super.onResume();
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.onResume(); 
      return;
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.G7(paramBundle); 
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
    } 
    super.onSaveInstanceState(paramBundle);
  }
  
  public void onStart() {
    super.onStart();
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.M0(); 
      return;
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  public void onStop() {
    try {
      ed ed1 = this.a;
      if (ed1 != null)
        ed1.R2(); 
    } catch (RemoteException remoteException) {
      vp.f("#007 Could not call remote method.", (Throwable)remoteException);
      finish();
    } 
    super.onStop();
  }
  
  public void setContentView(int paramInt) {
    super.setContentView(paramInt);
    a();
  }
  
  public void setContentView(View paramView) {
    super.setContentView(paramView);
    a();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(paramView, paramLayoutParams);
    a();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/AdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */