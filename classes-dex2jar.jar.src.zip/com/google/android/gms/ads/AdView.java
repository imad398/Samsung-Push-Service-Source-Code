package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.internal.ads.ix0;
import s0.a;
import s0.c;
import s0.d;
import s0.g;

public final class AdView extends BaseAdView {
  public AdView(Context paramContext) {
    super(paramContext, 0);
    m.j(paramContext, "Context cannot be null");
  }
  
  public final g getVideoController() {
    ix0 ix0 = this.a;
    return (ix0 != null) ? ix0.f() : null;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/AdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */