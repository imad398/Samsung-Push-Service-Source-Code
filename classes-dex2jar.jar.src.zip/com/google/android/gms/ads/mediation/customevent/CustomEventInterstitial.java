package com.google.android.gms.ads.mediation.customevent;

import a1.a;
import android.content.Context;
import android.os.Bundle;
import b1.a;
import b1.d;

public interface CustomEventInterstitial extends a {
  void requestInterstitialAd(Context paramContext, d paramd, String paramString, a parama, Bundle paramBundle);
  
  void showInterstitial();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/mediation/customevent/CustomEventInterstitial.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */