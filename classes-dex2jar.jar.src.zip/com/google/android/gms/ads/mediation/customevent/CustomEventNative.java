package com.google.android.gms.ads.mediation.customevent;

import a1.i;
import android.content.Context;
import android.os.Bundle;
import b1.a;
import b1.e;

public interface CustomEventNative extends a {
  void requestNativeAd(Context paramContext, e parame, String paramString, i parami, Bundle paramBundle);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/mediation/customevent/CustomEventNative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */