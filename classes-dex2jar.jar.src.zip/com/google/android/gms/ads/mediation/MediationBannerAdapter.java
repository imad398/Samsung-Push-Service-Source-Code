package com.google.android.gms.ads.mediation;

import a1.a;
import a1.b;
import a1.c;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import s0.d;

public interface MediationBannerAdapter extends b {
  View getBannerView();
  
  void requestBannerAd(Context paramContext, c paramc, Bundle paramBundle1, d paramd, a parama, Bundle paramBundle2);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/mediation/MediationBannerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */