package com.google.android.gms.ads.mediation;

import a1.a;
import a1.b;
import a1.d;
import android.content.Context;
import android.os.Bundle;

public interface MediationInterstitialAdapter extends b {
  void requestInterstitialAd(Context paramContext, d paramd, Bundle paramBundle1, a parama, Bundle paramBundle2);
  
  void showInterstitial();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/mediation/MediationInterstitialAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */