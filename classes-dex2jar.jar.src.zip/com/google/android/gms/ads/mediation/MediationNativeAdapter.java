package com.google.android.gms.ads.mediation;

import a1.b;
import a1.e;
import a1.i;
import android.content.Context;
import android.os.Bundle;

public interface MediationNativeAdapter extends b {
  void requestNativeAd(Context paramContext, e parame, Bundle paramBundle1, i parami, Bundle paramBundle2);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/mediation/MediationNativeAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */