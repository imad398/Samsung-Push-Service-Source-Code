package com.google.android.gms.ads;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.internal.ads.ix0;
import com.google.android.gms.internal.ads.ou0;
import com.google.android.gms.internal.ads.vp;
import s0.a;
import s0.c;
import s0.d;
import t0.a;

abstract class BaseAdView extends ViewGroup {
  public final ix0 a;
  
  public BaseAdView(Context paramContext, int paramInt) {
    super(paramContext);
    this.a = new ix0(this, paramInt);
  }
  
  public void a() {
    this.a.a();
  }
  
  public void b(c paramc) {
    this.a.p(paramc.a());
  }
  
  public void c() {
    this.a.g();
  }
  
  public void d() {
    this.a.h();
  }
  
  public a getAdListener() {
    return this.a.b();
  }
  
  public d getAdSize() {
    return this.a.c();
  }
  
  public String getAdUnitId() {
    return this.a.d();
  }
  
  public String getMediationAdapterClassName() {
    return this.a.e();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      i = view.getMeasuredWidth();
      j = view.getMeasuredHeight();
    } else {
      try {
        d d = getAdSize();
      } catch (NullPointerException nullPointerException) {
        vp.d("Unable to retrieve ad size.", nullPointerException);
        nullPointerException = null;
      } 
      if (nullPointerException != null) {
        Context context = getContext();
        i = nullPointerException.d(context);
        j = nullPointerException.b(context);
      } else {
        j = 0;
      } 
    } 
    i = Math.max(i, getSuggestedMinimumWidth());
    int j = Math.max(j, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(i, paramInt1), View.resolveSize(j, paramInt2));
  }
  
  public void setAdListener(a parama) {
    this.a.i(parama);
    if (parama == null) {
      this.a.o(null);
      this.a.l(null);
      return;
    } 
    if (parama instanceof ou0)
      this.a.o((ou0)parama); 
    if (parama instanceof a)
      this.a.l((a)parama); 
  }
  
  public void setAdSize(d paramd) {
    this.a.j(new d[] { paramd });
  }
  
  public void setAdUnitId(String paramString) {
    this.a.k(paramString);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/BaseAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */