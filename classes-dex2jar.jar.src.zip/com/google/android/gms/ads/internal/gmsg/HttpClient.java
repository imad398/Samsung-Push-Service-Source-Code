package com.google.android.gms.ads.internal.gmsg;

import android.content.Context;
import androidx.annotation.Keep;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.internal.ads.ag;
import com.google.android.gms.internal.ads.r6;
import com.google.android.gms.internal.ads.rm;
import com.google.android.gms.internal.ads.vp;
import com.google.android.gms.internal.ads.zzbbi;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import y0.c0;
import y0.d0;

@ag
@Keep
@KeepName
public class HttpClient implements c0 {
  private final Context mContext;
  
  private final zzbbi zzbob;
  
  public HttpClient(Context paramContext, zzbbi paramzzbbi) {
    this.mContext = paramContext;
    this.zzbob = paramzzbbi;
  }
  
  private final c zza(b paramb) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokevirtual b : ()Ljava/net/URL;
    //   6: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   9: checkcast java/net/HttpURLConnection
    //   12: astore_3
    //   13: aload_3
    //   14: astore_2
    //   15: invokestatic e : ()Lcom/google/android/gms/internal/ads/vm;
    //   18: aload_0
    //   19: getfield mContext : Landroid/content/Context;
    //   22: aload_0
    //   23: getfield zzbob : Lcom/google/android/gms/internal/ads/zzbbi;
    //   26: getfield zzdp : Ljava/lang/String;
    //   29: iconst_0
    //   30: aload_3
    //   31: invokevirtual o : (Landroid/content/Context;Ljava/lang/String;ZLjava/net/HttpURLConnection;)V
    //   34: aload_3
    //   35: astore_2
    //   36: aload_1
    //   37: invokevirtual c : ()Ljava/util/ArrayList;
    //   40: astore #4
    //   42: aload_3
    //   43: astore_2
    //   44: aload #4
    //   46: invokevirtual size : ()I
    //   49: istore #5
    //   51: iconst_0
    //   52: istore #6
    //   54: iload #6
    //   56: iload #5
    //   58: if_icmpge -> 103
    //   61: aload_3
    //   62: astore_2
    //   63: aload #4
    //   65: iload #6
    //   67: invokevirtual get : (I)Ljava/lang/Object;
    //   70: astore #7
    //   72: iinc #6, 1
    //   75: aload_3
    //   76: astore_2
    //   77: aload #7
    //   79: checkcast com/google/android/gms/ads/internal/gmsg/HttpClient$a
    //   82: astore #7
    //   84: aload_3
    //   85: astore_2
    //   86: aload_3
    //   87: aload #7
    //   89: invokevirtual a : ()Ljava/lang/String;
    //   92: aload #7
    //   94: invokevirtual b : ()Ljava/lang/String;
    //   97: invokevirtual addRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   100: goto -> 54
    //   103: aload_3
    //   104: astore_2
    //   105: aload_1
    //   106: invokevirtual d : ()Ljava/lang/String;
    //   109: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   112: ifne -> 179
    //   115: aload_3
    //   116: astore_2
    //   117: aload_3
    //   118: iconst_1
    //   119: invokevirtual setDoOutput : (Z)V
    //   122: aload_3
    //   123: astore_2
    //   124: aload_1
    //   125: invokevirtual d : ()Ljava/lang/String;
    //   128: invokevirtual getBytes : ()[B
    //   131: astore #4
    //   133: aload_3
    //   134: astore_2
    //   135: aload_3
    //   136: aload #4
    //   138: arraylength
    //   139: invokevirtual setFixedLengthStreamingMode : (I)V
    //   142: aload_3
    //   143: astore_2
    //   144: new java/io/BufferedOutputStream
    //   147: astore #7
    //   149: aload_3
    //   150: astore_2
    //   151: aload #7
    //   153: aload_3
    //   154: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   157: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   160: aload_3
    //   161: astore_2
    //   162: aload #7
    //   164: aload #4
    //   166: invokevirtual write : ([B)V
    //   169: aload_3
    //   170: astore_2
    //   171: aload #7
    //   173: invokevirtual close : ()V
    //   176: goto -> 182
    //   179: aconst_null
    //   180: astore #4
    //   182: aload_3
    //   183: astore_2
    //   184: new com/google/android/gms/internal/ads/op
    //   187: astore #7
    //   189: aload_3
    //   190: astore_2
    //   191: aload #7
    //   193: invokespecial <init> : ()V
    //   196: aload_3
    //   197: astore_2
    //   198: aload #7
    //   200: aload_3
    //   201: aload #4
    //   203: invokevirtual i : (Ljava/net/HttpURLConnection;[B)V
    //   206: aload_3
    //   207: astore_2
    //   208: new java/util/ArrayList
    //   211: astore #4
    //   213: aload_3
    //   214: astore_2
    //   215: aload #4
    //   217: invokespecial <init> : ()V
    //   220: aload_3
    //   221: astore_2
    //   222: aload_3
    //   223: invokevirtual getHeaderFields : ()Ljava/util/Map;
    //   226: ifnull -> 357
    //   229: aload_3
    //   230: astore_2
    //   231: aload_3
    //   232: invokevirtual getHeaderFields : ()Ljava/util/Map;
    //   235: invokeinterface entrySet : ()Ljava/util/Set;
    //   240: invokeinterface iterator : ()Ljava/util/Iterator;
    //   245: astore #8
    //   247: aload_3
    //   248: astore_2
    //   249: aload #8
    //   251: invokeinterface hasNext : ()Z
    //   256: ifeq -> 357
    //   259: aload_3
    //   260: astore_2
    //   261: aload #8
    //   263: invokeinterface next : ()Ljava/lang/Object;
    //   268: checkcast java/util/Map$Entry
    //   271: astore #9
    //   273: aload_3
    //   274: astore_2
    //   275: aload #9
    //   277: invokeinterface getValue : ()Ljava/lang/Object;
    //   282: checkcast java/util/List
    //   285: invokeinterface iterator : ()Ljava/util/Iterator;
    //   290: astore #10
    //   292: aload_3
    //   293: astore_2
    //   294: aload #10
    //   296: invokeinterface hasNext : ()Z
    //   301: ifeq -> 247
    //   304: aload_3
    //   305: astore_2
    //   306: aload #10
    //   308: invokeinterface next : ()Ljava/lang/Object;
    //   313: checkcast java/lang/String
    //   316: astore #11
    //   318: aload_3
    //   319: astore_2
    //   320: new com/google/android/gms/ads/internal/gmsg/HttpClient$a
    //   323: astore #12
    //   325: aload_3
    //   326: astore_2
    //   327: aload #12
    //   329: aload #9
    //   331: invokeinterface getKey : ()Ljava/lang/Object;
    //   336: checkcast java/lang/String
    //   339: aload #11
    //   341: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   344: aload_3
    //   345: astore_2
    //   346: aload #4
    //   348: aload #12
    //   350: invokevirtual add : (Ljava/lang/Object;)Z
    //   353: pop
    //   354: goto -> 292
    //   357: aload_3
    //   358: astore_2
    //   359: new com/google/android/gms/ads/internal/gmsg/HttpClient$d
    //   362: astore #10
    //   364: aload_3
    //   365: astore_2
    //   366: aload_1
    //   367: invokevirtual a : ()Ljava/lang/String;
    //   370: astore_1
    //   371: aload_3
    //   372: astore_2
    //   373: aload_3
    //   374: invokevirtual getResponseCode : ()I
    //   377: istore #6
    //   379: aload_3
    //   380: astore_2
    //   381: invokestatic e : ()Lcom/google/android/gms/internal/ads/vm;
    //   384: pop
    //   385: aload_3
    //   386: astore_2
    //   387: new java/io/InputStreamReader
    //   390: astore #12
    //   392: aload_3
    //   393: astore_2
    //   394: aload #12
    //   396: aload_3
    //   397: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   400: invokespecial <init> : (Ljava/io/InputStream;)V
    //   403: aload_3
    //   404: astore_2
    //   405: aload #10
    //   407: aload_1
    //   408: iload #6
    //   410: aload #4
    //   412: aload #12
    //   414: invokestatic g : (Ljava/io/InputStreamReader;)Ljava/lang/String;
    //   417: invokespecial <init> : (Ljava/lang/String;ILjava/util/List;Ljava/lang/String;)V
    //   420: aload_3
    //   421: astore_2
    //   422: aload #7
    //   424: aload_3
    //   425: aload #10
    //   427: invokevirtual b : ()I
    //   430: invokevirtual h : (Ljava/net/HttpURLConnection;I)V
    //   433: aload_3
    //   434: astore_2
    //   435: aload #7
    //   437: aload #10
    //   439: invokevirtual a : ()Ljava/lang/String;
    //   442: invokevirtual r : (Ljava/lang/String;)V
    //   445: aload_3
    //   446: astore_2
    //   447: new com/google/android/gms/ads/internal/gmsg/HttpClient$c
    //   450: dup
    //   451: aload_0
    //   452: iconst_1
    //   453: aload #10
    //   455: aconst_null
    //   456: invokespecial <init> : (Lcom/google/android/gms/ads/internal/gmsg/HttpClient;ZLcom/google/android/gms/ads/internal/gmsg/HttpClient$d;Ljava/lang/String;)V
    //   459: astore_1
    //   460: aload_3
    //   461: invokevirtual disconnect : ()V
    //   464: aload_1
    //   465: areturn
    //   466: astore_2
    //   467: aload_3
    //   468: astore_1
    //   469: aload_2
    //   470: astore_3
    //   471: goto -> 481
    //   474: astore_1
    //   475: goto -> 509
    //   478: astore_3
    //   479: aconst_null
    //   480: astore_1
    //   481: aload_1
    //   482: astore_2
    //   483: new com/google/android/gms/ads/internal/gmsg/HttpClient$c
    //   486: dup
    //   487: aload_0
    //   488: iconst_0
    //   489: aconst_null
    //   490: aload_3
    //   491: invokevirtual toString : ()Ljava/lang/String;
    //   494: invokespecial <init> : (Lcom/google/android/gms/ads/internal/gmsg/HttpClient;ZLcom/google/android/gms/ads/internal/gmsg/HttpClient$d;Ljava/lang/String;)V
    //   497: astore_3
    //   498: aload_1
    //   499: ifnull -> 506
    //   502: aload_1
    //   503: invokevirtual disconnect : ()V
    //   506: aload_3
    //   507: areturn
    //   508: astore_1
    //   509: aload_2
    //   510: ifnull -> 517
    //   513: aload_2
    //   514: invokevirtual disconnect : ()V
    //   517: aload_1
    //   518: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	478	java/lang/Exception
    //   2	13	474	finally
    //   15	34	466	java/lang/Exception
    //   15	34	508	finally
    //   36	42	466	java/lang/Exception
    //   36	42	508	finally
    //   44	51	466	java/lang/Exception
    //   44	51	508	finally
    //   63	72	466	java/lang/Exception
    //   63	72	508	finally
    //   77	84	466	java/lang/Exception
    //   77	84	508	finally
    //   86	100	466	java/lang/Exception
    //   86	100	508	finally
    //   105	115	466	java/lang/Exception
    //   105	115	508	finally
    //   117	122	466	java/lang/Exception
    //   117	122	508	finally
    //   124	133	466	java/lang/Exception
    //   124	133	508	finally
    //   135	142	466	java/lang/Exception
    //   135	142	508	finally
    //   144	149	466	java/lang/Exception
    //   144	149	508	finally
    //   151	160	466	java/lang/Exception
    //   151	160	508	finally
    //   162	169	466	java/lang/Exception
    //   162	169	508	finally
    //   171	176	466	java/lang/Exception
    //   171	176	508	finally
    //   184	189	466	java/lang/Exception
    //   184	189	508	finally
    //   191	196	466	java/lang/Exception
    //   191	196	508	finally
    //   198	206	466	java/lang/Exception
    //   198	206	508	finally
    //   208	213	466	java/lang/Exception
    //   208	213	508	finally
    //   215	220	466	java/lang/Exception
    //   215	220	508	finally
    //   222	229	466	java/lang/Exception
    //   222	229	508	finally
    //   231	247	466	java/lang/Exception
    //   231	247	508	finally
    //   249	259	466	java/lang/Exception
    //   249	259	508	finally
    //   261	273	466	java/lang/Exception
    //   261	273	508	finally
    //   275	292	466	java/lang/Exception
    //   275	292	508	finally
    //   294	304	466	java/lang/Exception
    //   294	304	508	finally
    //   306	318	466	java/lang/Exception
    //   306	318	508	finally
    //   320	325	466	java/lang/Exception
    //   320	325	508	finally
    //   327	344	466	java/lang/Exception
    //   327	344	508	finally
    //   346	354	466	java/lang/Exception
    //   346	354	508	finally
    //   359	364	466	java/lang/Exception
    //   359	364	508	finally
    //   366	371	466	java/lang/Exception
    //   366	371	508	finally
    //   373	379	466	java/lang/Exception
    //   373	379	508	finally
    //   381	385	466	java/lang/Exception
    //   381	385	508	finally
    //   387	392	466	java/lang/Exception
    //   387	392	508	finally
    //   394	403	466	java/lang/Exception
    //   394	403	508	finally
    //   405	420	466	java/lang/Exception
    //   405	420	508	finally
    //   422	433	466	java/lang/Exception
    //   422	433	508	finally
    //   435	445	466	java/lang/Exception
    //   435	445	508	finally
    //   447	460	466	java/lang/Exception
    //   447	460	508	finally
    //   483	498	508	finally
  }
  
  private static JSONObject zza(d paramd) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("http_request_id", paramd.c());
      if (paramd.a() != null)
        jSONObject.put("body", paramd.a()); 
      JSONArray jSONArray = new JSONArray();
      this();
      for (a a : paramd.d()) {
        JSONObject jSONObject1 = new JSONObject();
        this();
        jSONArray.put(jSONObject1.put("key", a.a()).put("value", a.b()));
      } 
      jSONObject.put("headers", jSONArray);
      jSONObject.put("response_code", paramd.b());
    } catch (JSONException jSONException) {
      vp.d("Error constructing JSON for http response.", (Throwable)jSONException);
    } 
    return jSONObject;
  }
  
  private static b zzc(JSONObject paramJSONObject) {
    String str1 = paramJSONObject.optString("http_request_id");
    String str2 = paramJSONObject.optString("url");
    URL uRL = null;
    String str3 = paramJSONObject.optString("post_body", null);
    try {
      URL uRL1 = new URL();
      this(str2);
      uRL = uRL1;
    } catch (MalformedURLException malformedURLException) {
      vp.d("Error constructing http request.", malformedURLException);
    } 
    ArrayList<a> arrayList = new ArrayList();
    JSONArray jSONArray2 = paramJSONObject.optJSONArray("headers");
    JSONArray jSONArray1 = jSONArray2;
    if (jSONArray2 == null)
      jSONArray1 = new JSONArray(); 
    for (byte b = 0; b < jSONArray1.length(); b++) {
      JSONObject jSONObject = jSONArray1.optJSONObject(b);
      if (jSONObject != null)
        arrayList.add(new a(jSONObject.optString("key"), jSONObject.optString("value"))); 
    } 
    return new b(str1, uRL, arrayList, str3);
  }
  
  @Keep
  @KeepName
  public JSONObject send(JSONObject paramJSONObject) {
    JSONObject jSONObject = new JSONObject();
    String str = "";
    try {
      String str1 = paramJSONObject.optString("http_request_id");
      str = str1;
      c c = zza(zzc(paramJSONObject));
      str = str1;
      if (c.b()) {
        str = str1;
        jSONObject.put("response", zza(c.c()));
        str = str1;
        jSONObject.put("success", true);
      } else {
        str = str1;
        paramJSONObject = new JSONObject();
        str = str1;
        this();
        str = str1;
        jSONObject.put("response", paramJSONObject.put("http_request_id", str1));
        str = str1;
        jSONObject.put("success", false);
        str = str1;
        jSONObject.put("reason", c.a());
      } 
    } catch (Exception exception) {
      vp.d("Error executing http request.", exception);
      try {
        JSONObject jSONObject1 = new JSONObject();
        this();
        jSONObject.put("response", jSONObject1.put("http_request_id", str));
        jSONObject.put("success", false);
        jSONObject.put("reason", exception.toString());
      } catch (JSONException jSONException) {
        vp.d("Error executing http request.", (Throwable)jSONException);
      } 
    } 
    return jSONObject;
  }
  
  public static final class a {
    public final String a;
    
    public final String b;
    
    public a(String param1String1, String param1String2) {
      this.a = param1String1;
      this.b = param1String2;
    }
    
    public final String a() {
      return this.a;
    }
    
    public final String b() {
      return this.b;
    }
  }
  
  public static final class b {
    public final String a;
    
    public final URL b;
    
    public final ArrayList c;
    
    public final String d;
    
    public b(String param1String1, URL param1URL, ArrayList param1ArrayList, String param1String2) {
      this.a = param1String1;
      this.b = param1URL;
      this.c = param1ArrayList;
      this.d = param1String2;
    }
    
    public final String a() {
      return this.a;
    }
    
    public final URL b() {
      return this.b;
    }
    
    public final ArrayList c() {
      return this.c;
    }
    
    public final String d() {
      return this.d;
    }
  }
  
  public final class c {
    public final HttpClient.d a;
    
    public final boolean b;
    
    public final String c;
    
    public c(HttpClient this$0, boolean param1Boolean, HttpClient.d param1d, String param1String) {
      this.b = param1Boolean;
      this.a = param1d;
      this.c = param1String;
    }
    
    public final String a() {
      return this.c;
    }
    
    public final boolean b() {
      return this.b;
    }
    
    public final HttpClient.d c() {
      return this.a;
    }
  }
  
  public static final class d {
    public final String a;
    
    public final int b;
    
    public final List c;
    
    public final String d;
    
    public d(String param1String1, int param1Int, List param1List, String param1String2) {
      this.a = param1String1;
      this.b = param1Int;
      this.c = param1List;
      this.d = param1String2;
    }
    
    public final String a() {
      return this.d;
    }
    
    public final int b() {
      return this.b;
    }
    
    public final String c() {
      return this.a;
    }
    
    public final Iterable d() {
      return this.c;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/internal/gmsg/HttpClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */