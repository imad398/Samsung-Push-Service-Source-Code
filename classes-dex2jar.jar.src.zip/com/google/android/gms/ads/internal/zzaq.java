package com.google.android.gms.ads.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.ads.ag;
import h1.b;
import x0.r;

@ag
public final class zzaq extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzaq> CREATOR = (Parcelable.Creator<zzaq>)new r();
  
  public final boolean zzbpa;
  
  public final boolean zzbpb;
  
  private final String zzbpc;
  
  public final boolean zzbpd;
  
  public final float zzbpe;
  
  public final int zzbpf;
  
  public final boolean zzbpg;
  
  public final boolean zzbph;
  
  public final boolean zzbpi;
  
  public zzaq(boolean paramBoolean1, boolean paramBoolean2, String paramString, boolean paramBoolean3, float paramFloat, int paramInt, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6) {
    this.zzbpa = paramBoolean1;
    this.zzbpb = paramBoolean2;
    this.zzbpc = paramString;
    this.zzbpd = paramBoolean3;
    this.zzbpe = paramFloat;
    this.zzbpf = paramInt;
    this.zzbpg = paramBoolean4;
    this.zzbph = paramBoolean5;
    this.zzbpi = paramBoolean6;
  }
  
  public zzaq(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, float paramFloat, int paramInt, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6) {
    this(paramBoolean1, paramBoolean2, null, paramBoolean3, paramFloat, paramInt, paramBoolean4, paramBoolean5, paramBoolean6);
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.c(paramParcel, 2, this.zzbpa);
    b.c(paramParcel, 3, this.zzbpb);
    b.o(paramParcel, 4, this.zzbpc, false);
    b.c(paramParcel, 5, this.zzbpd);
    b.g(paramParcel, 6, this.zzbpe);
    b.i(paramParcel, 7, this.zzbpf);
    b.c(paramParcel, 8, this.zzbpg);
    b.c(paramParcel, 9, this.zzbph);
    b.c(paramParcel, 10, this.zzbpi);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/internal/zzaq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */