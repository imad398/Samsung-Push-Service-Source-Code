package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.Keep;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.internal.ads.ag;
import com.google.android.gms.internal.ads.aj;
import com.google.android.gms.internal.ads.ed;
import com.google.android.gms.internal.ads.h2;
import com.google.android.gms.internal.ads.ha;
import com.google.android.gms.internal.ads.jj;
import com.google.android.gms.internal.ads.kw0;
import com.google.android.gms.internal.ads.l2;
import com.google.android.gms.internal.ads.od;
import com.google.android.gms.internal.ads.pw0;
import com.google.android.gms.internal.ads.s1;
import com.google.android.gms.internal.ads.tv0;
import com.google.android.gms.internal.ads.u1;
import com.google.android.gms.internal.ads.vm;
import com.google.android.gms.internal.ads.yv0;
import com.google.android.gms.internal.ads.zzbbi;
import com.google.android.gms.internal.ads.zzwf;
import java.util.HashMap;
import javax.annotation.ParametersAreNonnullByDefault;
import m1.a;
import m1.b;
import x0.l;
import x0.q0;
import x0.s1;
import x0.u1;
import x0.w0;
import x0.y;
import z0.p;
import z0.q;
import z0.r;
import z0.w;
import z0.x;

@ag
@ParametersAreNonnullByDefault
@Keep
@DynamiteApi
public class ClientApi extends kw0 {
  public tv0 createAdLoaderBuilder(a parama, String paramString, ha paramha, int paramInt) {
    Context context = (Context)b.O(parama);
    w0.e();
    return (tv0)new l(context, paramString, paramha, new zzbbi(14300000, paramInt, true, vm.L(context)), s1.a(context));
  }
  
  public ed createAdOverlay(a parama) {
    Activity activity = (Activity)b.O(parama);
    AdOverlayInfoParcel adOverlayInfoParcel = AdOverlayInfoParcel.v(activity.getIntent());
    if (adOverlayInfoParcel == null)
      return (ed)new q(activity); 
    int i = adOverlayInfoParcel.zzdsa;
    return (ed)((i != 1) ? ((i != 2) ? ((i != 3) ? ((i != 4) ? new q(activity) : new r(activity, adOverlayInfoParcel)) : new x(activity)) : new w(activity)) : new p(activity));
  }
  
  public yv0 createBannerAdManager(a parama, zzwf paramzzwf, String paramString, ha paramha, int paramInt) {
    Context context = (Context)b.O(parama);
    w0.e();
    return (yv0)new u1(context, paramzzwf, paramString, paramha, new zzbbi(14300000, paramInt, true, vm.L(context)), s1.a(context));
  }
  
  public od createInAppPurchaseManager(a parama) {
    return null;
  }
  
  public yv0 createInterstitialAdManager(a parama, zzwf paramzzwf, String paramString, ha paramha, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic O : (Lm1/a;)Ljava/lang/Object;
    //   4: checkcast android/content/Context
    //   7: astore_1
    //   8: aload_1
    //   9: invokestatic a : (Landroid/content/Context;)V
    //   12: invokestatic e : ()Lcom/google/android/gms/internal/ads/vm;
    //   15: pop
    //   16: aload_1
    //   17: invokestatic L : (Landroid/content/Context;)Z
    //   20: istore #6
    //   22: iconst_1
    //   23: istore #7
    //   25: new com/google/android/gms/internal/ads/zzbbi
    //   28: dup
    //   29: ldc 14300000
    //   31: iload #5
    //   33: iconst_1
    //   34: iload #6
    //   36: invokespecial <init> : (IIZZ)V
    //   39: astore #8
    //   41: ldc 'reward_mb'
    //   43: aload_2
    //   44: getfield zzckk : Ljava/lang/String;
    //   47: invokevirtual equals : (Ljava/lang/Object;)Z
    //   50: istore #6
    //   52: iload #6
    //   54: ifne -> 83
    //   57: getstatic com/google/android/gms/internal/ads/p.e1 : Lcom/google/android/gms/internal/ads/e;
    //   60: astore #9
    //   62: iload #7
    //   64: istore #5
    //   66: invokestatic e : ()Lcom/google/android/gms/internal/ads/m;
    //   69: aload #9
    //   71: invokevirtual c : (Lcom/google/android/gms/internal/ads/e;)Ljava/lang/Object;
    //   74: checkcast java/lang/Boolean
    //   77: invokevirtual booleanValue : ()Z
    //   80: ifne -> 120
    //   83: iload #6
    //   85: ifeq -> 117
    //   88: getstatic com/google/android/gms/internal/ads/p.f1 : Lcom/google/android/gms/internal/ads/e;
    //   91: astore #9
    //   93: invokestatic e : ()Lcom/google/android/gms/internal/ads/m;
    //   96: aload #9
    //   98: invokevirtual c : (Lcom/google/android/gms/internal/ads/e;)Ljava/lang/Object;
    //   101: checkcast java/lang/Boolean
    //   104: invokevirtual booleanValue : ()Z
    //   107: ifeq -> 117
    //   110: iload #7
    //   112: istore #5
    //   114: goto -> 120
    //   117: iconst_0
    //   118: istore #5
    //   120: iload #5
    //   122: ifeq -> 143
    //   125: new com/google/android/gms/internal/ads/o6
    //   128: dup
    //   129: aload_1
    //   130: aload_3
    //   131: aload #4
    //   133: aload #8
    //   135: aload_1
    //   136: invokestatic a : (Landroid/content/Context;)Lx0/s1;
    //   139: invokespecial <init> : (Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/internal/ads/ha;Lcom/google/android/gms/internal/ads/zzbbi;Lx0/s1;)V
    //   142: areturn
    //   143: new x0/m
    //   146: dup
    //   147: aload_1
    //   148: aload_2
    //   149: aload_3
    //   150: aload #4
    //   152: aload #8
    //   154: aload_1
    //   155: invokestatic a : (Landroid/content/Context;)Lx0/s1;
    //   158: invokespecial <init> : (Landroid/content/Context;Lcom/google/android/gms/internal/ads/zzwf;Ljava/lang/String;Lcom/google/android/gms/internal/ads/ha;Lcom/google/android/gms/internal/ads/zzbbi;Lx0/s1;)V
    //   161: areturn
  }
  
  public h2 createNativeAdViewDelegate(a parama1, a parama2) {
    return (h2)new s1((FrameLayout)b.O(parama1), (FrameLayout)b.O(parama2));
  }
  
  public l2 createNativeAdViewHolderDelegate(a parama1, a parama2, a parama3) {
    return (l2)new u1((View)b.O(parama1), (HashMap)b.O(parama2), (HashMap)b.O(parama3));
  }
  
  public jj createRewardedVideoAd(a parama, ha paramha, int paramInt) {
    Context context = (Context)b.O(parama);
    w0.e();
    zzbbi zzbbi = new zzbbi(14300000, paramInt, true, vm.L(context));
    return (jj)new aj(context, s1.a(context), paramha, zzbbi);
  }
  
  public jj createRewardedVideoAdSku(a parama, int paramInt) {
    return null;
  }
  
  public yv0 createSearchAdManager(a parama, zzwf paramzzwf, String paramString, int paramInt) {
    Context context = (Context)b.O(parama);
    w0.e();
    return (yv0)new q0(context, paramzzwf, paramString, new zzbbi(14300000, paramInt, true, vm.L(context)));
  }
  
  public pw0 getMobileAdsSettingsManager(a parama) {
    return null;
  }
  
  public pw0 getMobileAdsSettingsManagerWithClientJarVersion(a parama, int paramInt) {
    Context context = (Context)b.O(parama);
    w0.e();
    return (pw0)y.t8(context, new zzbbi(14300000, paramInt, true, vm.L(context)));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/internal/ClientApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */