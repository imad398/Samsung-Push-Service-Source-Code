package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.ads.ag;
import h1.b;
import z0.b;

@ag
public final class zzc extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzc> CREATOR = (Parcelable.Creator<zzc>)new b();
  
  public final Intent intent;
  
  public final String mimeType;
  
  public final String packageName;
  
  public final String url;
  
  private final String zzdqp;
  
  public final String zzdqq;
  
  public final String zzdqr;
  
  private final String zzdqs;
  
  public zzc(Intent paramIntent) {
    this(null, null, null, null, null, null, null, paramIntent);
  }
  
  public zzc(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    this(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, null);
  }
  
  public zzc(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, Intent paramIntent) {
    this.zzdqp = paramString1;
    this.url = paramString2;
    this.mimeType = paramString3;
    this.packageName = paramString4;
    this.zzdqq = paramString5;
    this.zzdqr = paramString6;
    this.zzdqs = paramString7;
    this.intent = paramIntent;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.o(paramParcel, 2, this.zzdqp, false);
    b.o(paramParcel, 3, this.url, false);
    b.o(paramParcel, 4, this.mimeType, false);
    b.o(paramParcel, 5, this.packageName, false);
    b.o(paramParcel, 6, this.zzdqq, false);
    b.o(paramParcel, 7, this.zzdqr, false);
    b.o(paramParcel, 8, this.zzdqs, false);
    b.n(paramParcel, 9, (Parcelable)this.intent, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/internal/overlay/zzc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */