package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.zzaq;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.internal.ads.ag;
import com.google.android.gms.internal.ads.dv;
import com.google.android.gms.internal.ads.ou0;
import com.google.android.gms.internal.ads.zzbbi;
import h1.b;
import m1.a;
import m1.b;
import y0.j;
import y0.l;
import z0.l;
import z0.m;
import z0.s;

@ag
public final class AdOverlayInfoParcel extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<AdOverlayInfoParcel> CREATOR = (Parcelable.Creator<AdOverlayInfoParcel>)new l();
  
  public final int orientation;
  
  public final String url;
  
  public final String zzbde;
  
  public final zzbbi zzbsp;
  
  public final zzc zzdrs;
  
  public final ou0 zzdrt;
  
  public final m zzdru;
  
  public final dv zzdrv;
  
  public final l zzdrw;
  
  public final boolean zzdrx;
  
  public final String zzdry;
  
  public final s zzdrz;
  
  public final int zzdsa;
  
  public final String zzdsb;
  
  public final zzaq zzdsc;
  
  public final j zzdsd;
  
  public AdOverlayInfoParcel(zzc paramzzc, IBinder paramIBinder1, IBinder paramIBinder2, IBinder paramIBinder3, IBinder paramIBinder4, String paramString1, boolean paramBoolean, String paramString2, IBinder paramIBinder5, int paramInt1, int paramInt2, String paramString3, zzbbi paramzzbbi, String paramString4, zzaq paramzzaq, IBinder paramIBinder6) {
    this.zzdrs = paramzzc;
    this.zzdrt = (ou0)b.O(a.a.N(paramIBinder1));
    this.zzdru = (m)b.O(a.a.N(paramIBinder2));
    this.zzdrv = (dv)b.O(a.a.N(paramIBinder3));
    this.zzdsd = (j)b.O(a.a.N(paramIBinder6));
    this.zzdrw = (l)b.O(a.a.N(paramIBinder4));
    this.zzbde = paramString1;
    this.zzdrx = paramBoolean;
    this.zzdry = paramString2;
    this.zzdrz = (s)b.O(a.a.N(paramIBinder5));
    this.orientation = paramInt1;
    this.zzdsa = paramInt2;
    this.url = paramString3;
    this.zzbsp = paramzzbbi;
    this.zzdsb = paramString4;
    this.zzdsc = paramzzaq;
  }
  
  public AdOverlayInfoParcel(zzc paramzzc, ou0 paramou0, m paramm, s params, zzbbi paramzzbbi) {
    this.zzdrs = paramzzc;
    this.zzdrt = paramou0;
    this.zzdru = paramm;
    this.zzdrv = null;
    this.zzdsd = null;
    this.zzdrw = null;
    this.zzbde = null;
    this.zzdrx = false;
    this.zzdry = null;
    this.zzdrz = params;
    this.orientation = -1;
    this.zzdsa = 4;
    this.url = null;
    this.zzbsp = paramzzbbi;
    this.zzdsb = null;
    this.zzdsc = null;
  }
  
  public AdOverlayInfoParcel(ou0 paramou0, m paramm, j paramj, l paraml, s params, dv paramdv, boolean paramBoolean, int paramInt, String paramString, zzbbi paramzzbbi) {
    this.zzdrs = null;
    this.zzdrt = paramou0;
    this.zzdru = paramm;
    this.zzdrv = paramdv;
    this.zzdsd = paramj;
    this.zzdrw = paraml;
    this.zzbde = null;
    this.zzdrx = paramBoolean;
    this.zzdry = null;
    this.zzdrz = params;
    this.orientation = paramInt;
    this.zzdsa = 3;
    this.url = paramString;
    this.zzbsp = paramzzbbi;
    this.zzdsb = null;
    this.zzdsc = null;
  }
  
  public AdOverlayInfoParcel(ou0 paramou0, m paramm, j paramj, l paraml, s params, dv paramdv, boolean paramBoolean, int paramInt, String paramString1, String paramString2, zzbbi paramzzbbi) {
    this.zzdrs = null;
    this.zzdrt = paramou0;
    this.zzdru = paramm;
    this.zzdrv = paramdv;
    this.zzdsd = paramj;
    this.zzdrw = paraml;
    this.zzbde = paramString2;
    this.zzdrx = paramBoolean;
    this.zzdry = paramString1;
    this.zzdrz = params;
    this.orientation = paramInt;
    this.zzdsa = 3;
    this.url = null;
    this.zzbsp = paramzzbbi;
    this.zzdsb = null;
    this.zzdsc = null;
  }
  
  public AdOverlayInfoParcel(ou0 paramou0, m paramm, s params, dv paramdv, int paramInt, zzbbi paramzzbbi, String paramString, zzaq paramzzaq) {
    this.zzdrs = null;
    this.zzdrt = paramou0;
    this.zzdru = paramm;
    this.zzdrv = paramdv;
    this.zzdsd = null;
    this.zzdrw = null;
    this.zzbde = null;
    this.zzdrx = false;
    this.zzdry = null;
    this.zzdrz = params;
    this.orientation = paramInt;
    this.zzdsa = 1;
    this.url = null;
    this.zzbsp = paramzzbbi;
    this.zzdsb = paramString;
    this.zzdsc = paramzzaq;
  }
  
  public AdOverlayInfoParcel(ou0 paramou0, m paramm, s params, dv paramdv, boolean paramBoolean, int paramInt, zzbbi paramzzbbi) {
    this.zzdrs = null;
    this.zzdrt = paramou0;
    this.zzdru = paramm;
    this.zzdrv = paramdv;
    this.zzdsd = null;
    this.zzdrw = null;
    this.zzbde = null;
    this.zzdrx = paramBoolean;
    this.zzdry = null;
    this.zzdrz = params;
    this.orientation = paramInt;
    this.zzdsa = 2;
    this.url = null;
    this.zzbsp = paramzzbbi;
    this.zzdsb = null;
    this.zzdsc = null;
  }
  
  public static void q(Intent paramIntent, AdOverlayInfoParcel paramAdOverlayInfoParcel) {
    Bundle bundle = new Bundle(1);
    bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", (Parcelable)paramAdOverlayInfoParcel);
    paramIntent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
  }
  
  public static AdOverlayInfoParcel v(Intent paramIntent) {
    try {
      Bundle bundle = paramIntent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
      bundle.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
      return (AdOverlayInfoParcel)bundle.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.n(paramParcel, 2, (Parcelable)this.zzdrs, paramInt, false);
    b.h(paramParcel, 3, b.R(this.zzdrt).asBinder(), false);
    b.h(paramParcel, 4, b.R(this.zzdru).asBinder(), false);
    b.h(paramParcel, 5, b.R(this.zzdrv).asBinder(), false);
    b.h(paramParcel, 6, b.R(this.zzdrw).asBinder(), false);
    b.o(paramParcel, 7, this.zzbde, false);
    b.c(paramParcel, 8, this.zzdrx);
    b.o(paramParcel, 9, this.zzdry, false);
    b.h(paramParcel, 10, b.R(this.zzdrz).asBinder(), false);
    b.i(paramParcel, 11, this.orientation);
    b.i(paramParcel, 12, this.zzdsa);
    b.o(paramParcel, 13, this.url, false);
    b.n(paramParcel, 14, (Parcelable)this.zzbsp, paramInt, false);
    b.o(paramParcel, 16, this.zzdsb, false);
    b.n(paramParcel, 17, (Parcelable)this.zzdsc, paramInt, false);
    b.h(paramParcel, 18, b.R(this.zzdsd).asBinder(), false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */