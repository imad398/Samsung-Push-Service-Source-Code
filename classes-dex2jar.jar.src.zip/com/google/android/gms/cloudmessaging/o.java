package com.google.android.gms.cloudmessaging;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Messenger;
import android.util.Log;
import android.util.SparseArray;
import java.util.ArrayDeque;
import java.util.Queue;
import q1.f;

public final class o implements ServiceConnection {
  public int a = 0;
  
  public final Messenger b = new Messenger((Handler)new f(Looper.getMainLooper(), new h(this)));
  
  public p c;
  
  public final Queue d = new ArrayDeque();
  
  public final SparseArray e = new SparseArray();
  
  public final void a(int paramInt, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: aload_2
    //   5: aconst_null
    //   6: invokevirtual b : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_2
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_2
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
  }
  
  public final void b(int paramInt, String paramString, Throwable paramThrowable) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'MessengerIpcClient'
    //   4: iconst_3
    //   5: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   8: ifeq -> 56
    //   11: aload_2
    //   12: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   15: astore #4
    //   17: aload #4
    //   19: invokevirtual length : ()I
    //   22: ifeq -> 37
    //   25: ldc 'Disconnected: '
    //   27: aload #4
    //   29: invokevirtual concat : (Ljava/lang/String;)Ljava/lang/String;
    //   32: astore #4
    //   34: goto -> 48
    //   37: new java/lang/String
    //   40: dup
    //   41: ldc 'Disconnected: '
    //   43: invokespecial <init> : (Ljava/lang/String;)V
    //   46: astore #4
    //   48: ldc 'MessengerIpcClient'
    //   50: aload #4
    //   52: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   55: pop
    //   56: aload_0
    //   57: getfield a : I
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 235
    //   67: iload #5
    //   69: iconst_1
    //   70: if_icmpeq -> 96
    //   73: iload #5
    //   75: iconst_2
    //   76: if_icmpeq -> 96
    //   79: iload #5
    //   81: iconst_3
    //   82: if_icmpeq -> 88
    //   85: aload_0
    //   86: monitorexit
    //   87: return
    //   88: aload_0
    //   89: iconst_4
    //   90: putfield a : I
    //   93: aload_0
    //   94: monitorexit
    //   95: return
    //   96: ldc 'MessengerIpcClient'
    //   98: iconst_2
    //   99: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   102: ifeq -> 113
    //   105: ldc 'MessengerIpcClient'
    //   107: ldc 'Unbinding service'
    //   109: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   112: pop
    //   113: aload_0
    //   114: iconst_4
    //   115: putfield a : I
    //   118: invokestatic b : ()Lcom/google/android/gms/common/stats/b;
    //   121: aload_0
    //   122: getfield f : Lcom/google/android/gms/cloudmessaging/u;
    //   125: invokestatic a : (Lcom/google/android/gms/cloudmessaging/u;)Landroid/content/Context;
    //   128: aload_0
    //   129: invokevirtual c : (Landroid/content/Context;Landroid/content/ServiceConnection;)V
    //   132: new com/google/android/gms/cloudmessaging/s
    //   135: astore #4
    //   137: aload #4
    //   139: iload_1
    //   140: aload_2
    //   141: aload_3
    //   142: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   145: aload_0
    //   146: getfield d : Ljava/util/Queue;
    //   149: invokeinterface iterator : ()Ljava/util/Iterator;
    //   154: astore_2
    //   155: aload_2
    //   156: invokeinterface hasNext : ()Z
    //   161: ifeq -> 181
    //   164: aload_2
    //   165: invokeinterface next : ()Ljava/lang/Object;
    //   170: checkcast com/google/android/gms/cloudmessaging/r
    //   173: aload #4
    //   175: invokevirtual c : (Lcom/google/android/gms/cloudmessaging/s;)V
    //   178: goto -> 155
    //   181: aload_0
    //   182: getfield d : Ljava/util/Queue;
    //   185: invokeinterface clear : ()V
    //   190: iconst_0
    //   191: istore_1
    //   192: iload_1
    //   193: aload_0
    //   194: getfield e : Landroid/util/SparseArray;
    //   197: invokevirtual size : ()I
    //   200: if_icmpge -> 225
    //   203: aload_0
    //   204: getfield e : Landroid/util/SparseArray;
    //   207: iload_1
    //   208: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   211: checkcast com/google/android/gms/cloudmessaging/r
    //   214: aload #4
    //   216: invokevirtual c : (Lcom/google/android/gms/cloudmessaging/s;)V
    //   219: iinc #1, 1
    //   222: goto -> 192
    //   225: aload_0
    //   226: getfield e : Landroid/util/SparseArray;
    //   229: invokevirtual clear : ()V
    //   232: aload_0
    //   233: monitorexit
    //   234: return
    //   235: new java/lang/IllegalStateException
    //   238: astore_2
    //   239: aload_2
    //   240: invokespecial <init> : ()V
    //   243: aload_2
    //   244: athrow
    //   245: astore_2
    //   246: aload_0
    //   247: monitorexit
    //   248: aload_2
    //   249: athrow
    // Exception table:
    //   from	to	target	type
    //   2	34	245	finally
    //   37	48	245	finally
    //   48	56	245	finally
    //   56	62	245	finally
    //   88	93	245	finally
    //   96	113	245	finally
    //   113	155	245	finally
    //   155	178	245	finally
    //   181	190	245	finally
    //   192	219	245	finally
    //   225	232	245	finally
    //   235	245	245	finally
  }
  
  public final void c() {
    u.e(this.f).execute(new j(this));
  }
  
  public final void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : I
    //   6: iconst_1
    //   7: if_icmpne -> 20
    //   10: aload_0
    //   11: iconst_1
    //   12: ldc 'Timed out while binding'
    //   14: invokevirtual a : (ILjava/lang/String;)V
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	23	finally
  }
  
  public final void e(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield e : Landroid/util/SparseArray;
    //   6: iload_1
    //   7: invokevirtual get : (I)Ljava/lang/Object;
    //   10: checkcast com/google/android/gms/cloudmessaging/r
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 83
    //   18: new java/lang/StringBuilder
    //   21: astore_3
    //   22: aload_3
    //   23: bipush #31
    //   25: invokespecial <init> : (I)V
    //   28: aload_3
    //   29: ldc 'Timing out request: '
    //   31: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: pop
    //   35: aload_3
    //   36: iload_1
    //   37: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   40: pop
    //   41: ldc 'MessengerIpcClient'
    //   43: aload_3
    //   44: invokevirtual toString : ()Ljava/lang/String;
    //   47: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   50: pop
    //   51: aload_0
    //   52: getfield e : Landroid/util/SparseArray;
    //   55: iload_1
    //   56: invokevirtual remove : (I)V
    //   59: new com/google/android/gms/cloudmessaging/s
    //   62: astore_3
    //   63: aload_3
    //   64: iconst_3
    //   65: ldc 'Timed out waiting for response'
    //   67: aconst_null
    //   68: invokespecial <init> : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   71: aload_2
    //   72: aload_3
    //   73: invokevirtual c : (Lcom/google/android/gms/cloudmessaging/s;)V
    //   76: aload_0
    //   77: invokevirtual f : ()V
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: aload_0
    //   84: monitorexit
    //   85: return
    //   86: astore_2
    //   87: aload_0
    //   88: monitorexit
    //   89: aload_2
    //   90: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	86	finally
    //   18	80	86	finally
  }
  
  public final void f() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : I
    //   6: iconst_2
    //   7: if_icmpne -> 71
    //   10: aload_0
    //   11: getfield d : Ljava/util/Queue;
    //   14: invokeinterface isEmpty : ()Z
    //   19: ifeq -> 71
    //   22: aload_0
    //   23: getfield e : Landroid/util/SparseArray;
    //   26: invokevirtual size : ()I
    //   29: ifne -> 71
    //   32: ldc 'MessengerIpcClient'
    //   34: iconst_2
    //   35: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   38: ifeq -> 49
    //   41: ldc 'MessengerIpcClient'
    //   43: ldc 'Finished handling requests, unbinding'
    //   45: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   48: pop
    //   49: aload_0
    //   50: iconst_3
    //   51: putfield a : I
    //   54: invokestatic b : ()Lcom/google/android/gms/common/stats/b;
    //   57: aload_0
    //   58: getfield f : Lcom/google/android/gms/cloudmessaging/u;
    //   61: invokestatic a : (Lcom/google/android/gms/cloudmessaging/u;)Landroid/content/Context;
    //   64: aload_0
    //   65: invokevirtual c : (Landroid/content/Context;Landroid/content/ServiceConnection;)V
    //   68: aload_0
    //   69: monitorexit
    //   70: return
    //   71: aload_0
    //   72: monitorexit
    //   73: return
    //   74: astore_1
    //   75: aload_0
    //   76: monitorexit
    //   77: aload_1
    //   78: athrow
    // Exception table:
    //   from	to	target	type
    //   2	49	74	finally
    //   49	68	74	finally
  }
  
  public final boolean g(r paramr) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : I
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq -> 59
    //   11: iload_2
    //   12: iconst_1
    //   13: if_icmpeq -> 44
    //   16: iload_2
    //   17: iconst_2
    //   18: if_icmpeq -> 25
    //   21: aload_0
    //   22: monitorexit
    //   23: iconst_0
    //   24: ireturn
    //   25: aload_0
    //   26: getfield d : Ljava/util/Queue;
    //   29: aload_1
    //   30: invokeinterface add : (Ljava/lang/Object;)Z
    //   35: pop
    //   36: aload_0
    //   37: invokevirtual c : ()V
    //   40: aload_0
    //   41: monitorexit
    //   42: iconst_1
    //   43: ireturn
    //   44: aload_0
    //   45: getfield d : Ljava/util/Queue;
    //   48: aload_1
    //   49: invokeinterface add : (Ljava/lang/Object;)Z
    //   54: pop
    //   55: aload_0
    //   56: monitorexit
    //   57: iconst_1
    //   58: ireturn
    //   59: aload_0
    //   60: getfield d : Ljava/util/Queue;
    //   63: aload_1
    //   64: invokeinterface add : (Ljava/lang/Object;)Z
    //   69: pop
    //   70: aload_0
    //   71: getfield a : I
    //   74: ifne -> 82
    //   77: iconst_1
    //   78: istore_3
    //   79: goto -> 84
    //   82: iconst_0
    //   83: istore_3
    //   84: iload_3
    //   85: invokestatic k : (Z)V
    //   88: ldc 'MessengerIpcClient'
    //   90: iconst_2
    //   91: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   94: ifeq -> 105
    //   97: ldc 'MessengerIpcClient'
    //   99: ldc 'Starting bind to GmsCore'
    //   101: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   104: pop
    //   105: aload_0
    //   106: iconst_1
    //   107: putfield a : I
    //   110: new android/content/Intent
    //   113: astore_1
    //   114: aload_1
    //   115: ldc 'com.google.android.c2dm.intent.REGISTER'
    //   117: invokespecial <init> : (Ljava/lang/String;)V
    //   120: aload_1
    //   121: ldc 'com.google.android.gms'
    //   123: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   126: pop
    //   127: invokestatic b : ()Lcom/google/android/gms/common/stats/b;
    //   130: aload_0
    //   131: getfield f : Lcom/google/android/gms/cloudmessaging/u;
    //   134: invokestatic a : (Lcom/google/android/gms/cloudmessaging/u;)Landroid/content/Context;
    //   137: aload_1
    //   138: aload_0
    //   139: iconst_1
    //   140: invokevirtual a : (Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   143: ifne -> 156
    //   146: aload_0
    //   147: iconst_0
    //   148: ldc 'Unable to bind to service'
    //   150: invokevirtual a : (ILjava/lang/String;)V
    //   153: goto -> 201
    //   156: aload_0
    //   157: getfield f : Lcom/google/android/gms/cloudmessaging/u;
    //   160: invokestatic e : (Lcom/google/android/gms/cloudmessaging/u;)Ljava/util/concurrent/ScheduledExecutorService;
    //   163: astore #4
    //   165: new com/google/android/gms/cloudmessaging/k
    //   168: astore_1
    //   169: aload_1
    //   170: aload_0
    //   171: invokespecial <init> : (Lcom/google/android/gms/cloudmessaging/o;)V
    //   174: aload #4
    //   176: aload_1
    //   177: ldc2_w 30
    //   180: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   183: invokeinterface schedule : (Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    //   188: pop
    //   189: goto -> 201
    //   192: astore_1
    //   193: aload_0
    //   194: iconst_0
    //   195: ldc 'Unable to bind to service'
    //   197: aload_1
    //   198: invokevirtual b : (ILjava/lang/String;Ljava/lang/Throwable;)V
    //   201: aload_0
    //   202: monitorexit
    //   203: iconst_1
    //   204: ireturn
    //   205: astore_1
    //   206: aload_0
    //   207: monitorexit
    //   208: aload_1
    //   209: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	205	finally
    //   25	40	205	finally
    //   44	55	205	finally
    //   59	77	205	finally
    //   84	105	205	finally
    //   105	127	205	finally
    //   127	153	192	java/lang/SecurityException
    //   127	153	205	finally
    //   156	189	205	finally
    //   193	201	205	finally
  }
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    if (Log.isLoggable("MessengerIpcClient", 2))
      Log.v("MessengerIpcClient", "Service connected"); 
    u.e(this.f).execute(new l(this, paramIBinder));
  }
  
  public final void onServiceDisconnected(ComponentName paramComponentName) {
    if (Log.isLoggable("MessengerIpcClient", 2))
      Log.v("MessengerIpcClient", "Service disconnected"); 
    u.e(this.f).execute(new i(this));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */