package com.google.android.gms.cloudmessaging;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.util.Map;
import javax.annotation.concurrent.GuardedBy;

public final class CloudMessage extends AbstractSafeParcelable {
  public static final Parcelable.Creator<CloudMessage> CREATOR = new c();
  
  public static final int PRIORITY_HIGH = 1;
  
  public static final int PRIORITY_NORMAL = 2;
  
  public static final int PRIORITY_UNKNOWN = 0;
  
  Intent zza;
  
  @GuardedBy("this")
  private Map<String, String> zzb;
  
  public CloudMessage(Intent paramIntent) {
    this.zza = paramIntent;
  }
  
  public Intent q() {
    return this.zza;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.n(paramParcel, 1, (Parcelable)this.zza, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/CloudMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */