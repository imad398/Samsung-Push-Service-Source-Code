package com.google.android.gms.cloudmessaging;

import android.os.Bundle;

public final class t extends r {
  public t(int paramInt1, int paramInt2, Bundle paramBundle) {
    super(paramInt1, 1, paramBundle);
  }
  
  public final void a(Bundle paramBundle) {
    Bundle bundle = paramBundle.getBundle("data");
    paramBundle = bundle;
    if (bundle == null)
      paramBundle = Bundle.EMPTY; 
    d(paramBundle);
  }
  
  public final boolean b() {
    return false;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */