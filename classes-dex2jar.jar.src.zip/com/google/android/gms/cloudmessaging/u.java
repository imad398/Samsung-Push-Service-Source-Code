package com.google.android.gms.cloudmessaging;

import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.ScheduledExecutorService;
import z1.i;

public final class u {
  public static u e;
  
  public final Context a;
  
  public final ScheduledExecutorService b;
  
  public o c = new o(this, null);
  
  public int d = 1;
  
  public u(Context paramContext, ScheduledExecutorService paramScheduledExecutorService) {
    this.b = paramScheduledExecutorService;
    this.a = paramContext.getApplicationContext();
  }
  
  public static u b(Context paramContext) {
    // Byte code:
    //   0: ldc com/google/android/gms/cloudmessaging/u
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/cloudmessaging/u.e : Lcom/google/android/gms/cloudmessaging/u;
    //   6: ifnonnull -> 44
    //   9: new com/google/android/gms/cloudmessaging/u
    //   12: astore_1
    //   13: invokestatic a : ()Lq1/b;
    //   16: pop
    //   17: new k1/a
    //   20: astore_2
    //   21: aload_2
    //   22: ldc 'MessengerIpcClient'
    //   24: invokespecial <init> : (Ljava/lang/String;)V
    //   27: aload_1
    //   28: aload_0
    //   29: iconst_1
    //   30: aload_2
    //   31: invokestatic newScheduledThreadPool : (ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;
    //   34: invokestatic unconfigurableScheduledExecutorService : (Ljava/util/concurrent/ScheduledExecutorService;)Ljava/util/concurrent/ScheduledExecutorService;
    //   37: invokespecial <init> : (Landroid/content/Context;Ljava/util/concurrent/ScheduledExecutorService;)V
    //   40: aload_1
    //   41: putstatic com/google/android/gms/cloudmessaging/u.e : Lcom/google/android/gms/cloudmessaging/u;
    //   44: getstatic com/google/android/gms/cloudmessaging/u.e : Lcom/google/android/gms/cloudmessaging/u;
    //   47: astore_0
    //   48: ldc com/google/android/gms/cloudmessaging/u
    //   50: monitorexit
    //   51: aload_0
    //   52: areturn
    //   53: astore_0
    //   54: ldc com/google/android/gms/cloudmessaging/u
    //   56: monitorexit
    //   57: aload_0
    //   58: athrow
    // Exception table:
    //   from	to	target	type
    //   3	44	53	finally
    //   44	48	53	finally
  }
  
  public final i c(int paramInt, Bundle paramBundle) {
    return g(new q(f(), 2, paramBundle));
  }
  
  public final i d(int paramInt, Bundle paramBundle) {
    return g(new t(f(), 1, paramBundle));
  }
  
  public final int f() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: istore_1
    //   7: aload_0
    //   8: iload_1
    //   9: iconst_1
    //   10: iadd
    //   11: putfield d : I
    //   14: aload_0
    //   15: monitorexit
    //   16: iload_1
    //   17: ireturn
    //   18: astore_2
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_2
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	18	finally
  }
  
  public final i g(r paramr) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'MessengerIpcClient'
    //   4: iconst_3
    //   5: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   8: ifeq -> 61
    //   11: aload_1
    //   12: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   15: astore_2
    //   16: aload_2
    //   17: invokevirtual length : ()I
    //   20: istore_3
    //   21: new java/lang/StringBuilder
    //   24: astore #4
    //   26: aload #4
    //   28: iload_3
    //   29: bipush #9
    //   31: iadd
    //   32: invokespecial <init> : (I)V
    //   35: aload #4
    //   37: ldc 'Queueing '
    //   39: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: pop
    //   43: aload #4
    //   45: aload_2
    //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: pop
    //   50: ldc 'MessengerIpcClient'
    //   52: aload #4
    //   54: invokevirtual toString : ()Ljava/lang/String;
    //   57: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   60: pop
    //   61: aload_0
    //   62: getfield c : Lcom/google/android/gms/cloudmessaging/o;
    //   65: aload_1
    //   66: invokevirtual g : (Lcom/google/android/gms/cloudmessaging/r;)Z
    //   69: ifne -> 97
    //   72: new com/google/android/gms/cloudmessaging/o
    //   75: astore #4
    //   77: aload #4
    //   79: aload_0
    //   80: aconst_null
    //   81: invokespecial <init> : (Lcom/google/android/gms/cloudmessaging/u;Lcom/google/android/gms/cloudmessaging/n;)V
    //   84: aload_0
    //   85: aload #4
    //   87: putfield c : Lcom/google/android/gms/cloudmessaging/o;
    //   90: aload #4
    //   92: aload_1
    //   93: invokevirtual g : (Lcom/google/android/gms/cloudmessaging/r;)Z
    //   96: pop
    //   97: aload_1
    //   98: getfield b : Lz1/j;
    //   101: invokevirtual a : ()Lz1/i;
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: areturn
    //   109: astore_1
    //   110: aload_0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    // Exception table:
    //   from	to	target	type
    //   2	61	109	finally
    //   61	97	109	finally
    //   97	105	109	finally
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */