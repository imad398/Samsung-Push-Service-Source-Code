package com.google.android.gms.cloudmessaging;

import android.os.IInterface;
import android.os.Message;

public interface a extends IInterface {
  void Z2(Message paramMessage);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */