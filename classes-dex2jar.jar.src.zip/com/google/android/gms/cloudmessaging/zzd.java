package com.google.android.gms.cloudmessaging;

import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;

public final class zzd implements Parcelable {
  public static final Parcelable.Creator<zzd> CREATOR = new e();
  
  Messenger zza;
  
  a zzb;
  
  public zzd(IBinder paramIBinder) {
    this.zza = new Messenger(paramIBinder);
  }
  
  public final IBinder a() {
    IBinder iBinder;
    Messenger messenger = this.zza;
    if (messenger != null) {
      iBinder = messenger.getBinder();
    } else {
      iBinder = this.zzb.asBinder();
    } 
    return iBinder;
  }
  
  public final void b(Message paramMessage) {
    Messenger messenger = this.zza;
    if (messenger != null) {
      messenger.send(paramMessage);
      return;
    } 
    this.zzb.Z2(paramMessage);
  }
  
  public final int describeContents() {
    return 0;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    try {
      return a().equals(((zzd)paramObject).a());
    } catch (ClassCastException classCastException) {
      return false;
    } 
  }
  
  public final int hashCode() {
    return a().hashCode();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    IBinder iBinder;
    Messenger messenger = this.zza;
    if (messenger != null) {
      iBinder = messenger.getBinder();
    } else {
      iBinder = this.zzb.asBinder();
    } 
    paramParcel.writeStrongBinder(iBinder);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */