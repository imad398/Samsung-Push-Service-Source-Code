package com.google.android.gms.cloudmessaging;

import android.content.Context;

public final class v {
  public final Context a;
  
  public int b;
  
  public int c = 0;
  
  public v(Context paramContext) {
    this.a = paramContext;
  }
  
  public final int a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : I
    //   6: ifne -> 86
    //   9: aload_0
    //   10: getfield a : Landroid/content/Context;
    //   13: invokestatic a : (Landroid/content/Context;)Ll1/d;
    //   16: ldc 'com.google.android.gms'
    //   18: iconst_0
    //   19: invokevirtual e : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   22: astore_1
    //   23: goto -> 74
    //   26: astore_1
    //   27: aload_1
    //   28: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   31: astore_1
    //   32: aload_1
    //   33: invokevirtual length : ()I
    //   36: istore_2
    //   37: new java/lang/StringBuilder
    //   40: astore_3
    //   41: aload_3
    //   42: iload_2
    //   43: bipush #23
    //   45: iadd
    //   46: invokespecial <init> : (I)V
    //   49: aload_3
    //   50: ldc 'Failed to find package '
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: aload_3
    //   57: aload_1
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: ldc 'Metadata'
    //   64: aload_3
    //   65: invokevirtual toString : ()Ljava/lang/String;
    //   68: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   71: pop
    //   72: aconst_null
    //   73: astore_1
    //   74: aload_1
    //   75: ifnull -> 86
    //   78: aload_0
    //   79: aload_1
    //   80: getfield versionCode : I
    //   83: putfield b : I
    //   86: aload_0
    //   87: getfield b : I
    //   90: istore_2
    //   91: aload_0
    //   92: monitorexit
    //   93: iload_2
    //   94: ireturn
    //   95: astore_1
    //   96: aload_0
    //   97: monitorexit
    //   98: aload_1
    //   99: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	95	finally
    //   9	23	26	android/content/pm/PackageManager$NameNotFoundException
    //   9	23	95	finally
    //   27	72	95	finally
    //   78	86	95	finally
    //   86	91	95	finally
  }
  
  public final int b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : I
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iload_1
    //   14: ireturn
    //   15: aload_0
    //   16: getfield a : Landroid/content/Context;
    //   19: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   22: astore_2
    //   23: aload_0
    //   24: getfield a : Landroid/content/Context;
    //   27: invokestatic a : (Landroid/content/Context;)Ll1/d;
    //   30: ldc 'com.google.android.c2dm.permission.SEND'
    //   32: ldc 'com.google.android.gms'
    //   34: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)I
    //   37: iconst_m1
    //   38: if_icmpne -> 53
    //   41: ldc 'Metadata'
    //   43: ldc 'Google Play services missing or without correct permission.'
    //   45: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   48: pop
    //   49: aload_0
    //   50: monitorexit
    //   51: iconst_0
    //   52: ireturn
    //   53: invokestatic k : ()Z
    //   56: istore_3
    //   57: iconst_1
    //   58: istore_1
    //   59: iload_3
    //   60: ifne -> 119
    //   63: new android/content/Intent
    //   66: astore #4
    //   68: aload #4
    //   70: ldc 'com.google.android.c2dm.intent.REGISTER'
    //   72: invokespecial <init> : (Ljava/lang/String;)V
    //   75: aload #4
    //   77: ldc 'com.google.android.gms'
    //   79: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   82: pop
    //   83: aload_2
    //   84: aload #4
    //   86: iconst_0
    //   87: invokevirtual queryIntentServices : (Landroid/content/Intent;I)Ljava/util/List;
    //   90: astore #4
    //   92: aload #4
    //   94: ifnull -> 119
    //   97: aload #4
    //   99: invokeinterface size : ()I
    //   104: ifgt -> 110
    //   107: goto -> 119
    //   110: aload_0
    //   111: iconst_1
    //   112: putfield c : I
    //   115: aload_0
    //   116: monitorexit
    //   117: iconst_1
    //   118: ireturn
    //   119: new android/content/Intent
    //   122: astore #4
    //   124: aload #4
    //   126: ldc 'com.google.iid.TOKEN_REQUEST'
    //   128: invokespecial <init> : (Ljava/lang/String;)V
    //   131: aload #4
    //   133: ldc 'com.google.android.gms'
    //   135: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   138: pop
    //   139: aload_2
    //   140: aload #4
    //   142: iconst_0
    //   143: invokevirtual queryBroadcastReceivers : (Landroid/content/Intent;I)Ljava/util/List;
    //   146: astore_2
    //   147: aload_2
    //   148: ifnull -> 172
    //   151: aload_2
    //   152: invokeinterface size : ()I
    //   157: ifgt -> 163
    //   160: goto -> 172
    //   163: aload_0
    //   164: iconst_2
    //   165: putfield c : I
    //   168: aload_0
    //   169: monitorexit
    //   170: iconst_2
    //   171: ireturn
    //   172: ldc 'Metadata'
    //   174: ldc 'Failed to resolve IID implementation package, falling back'
    //   176: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   179: pop
    //   180: invokestatic k : ()Z
    //   183: ifeq -> 196
    //   186: aload_0
    //   187: iconst_2
    //   188: putfield c : I
    //   191: iconst_2
    //   192: istore_1
    //   193: goto -> 201
    //   196: aload_0
    //   197: iconst_1
    //   198: putfield c : I
    //   201: aload_0
    //   202: monitorexit
    //   203: iload_1
    //   204: ireturn
    //   205: astore_2
    //   206: aload_0
    //   207: monitorexit
    //   208: aload_2
    //   209: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	205	finally
    //   15	49	205	finally
    //   53	57	205	finally
    //   63	92	205	finally
    //   97	107	205	finally
    //   110	115	205	finally
    //   119	147	205	finally
    //   151	160	205	finally
    //   163	168	205	finally
    //   172	191	205	finally
    //   196	201	205	finally
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */