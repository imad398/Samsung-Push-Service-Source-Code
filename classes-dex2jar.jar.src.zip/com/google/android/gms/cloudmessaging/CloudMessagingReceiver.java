package com.google.android.gms.cloudmessaging;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import k1.a;
import q1.e;
import z1.i;
import z1.l;

public abstract class CloudMessagingReceiver extends BroadcastReceiver {
  public final ExecutorService a;
  
  public CloudMessagingReceiver() {
    e.a();
    a a = new a("firebase-iid-executor");
    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(1, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(), (ThreadFactory)a);
    threadPoolExecutor.allowCoreThreadTimeOut(true);
    this.a = Executors.unconfigurableExecutorService(threadPoolExecutor);
  }
  
  public Executor a() {
    return this.a;
  }
  
  public abstract int b(Context paramContext, CloudMessage paramCloudMessage);
  
  public void c(Context paramContext, Bundle paramBundle) {}
  
  public final int e(Context paramContext, Intent paramIntent) {
    i i;
    if (paramIntent.getExtras() == null)
      return 500; 
    String str = paramIntent.getStringExtra("google.message_id");
    if (TextUtils.isEmpty(str)) {
      i = l.e(null);
    } else {
      Bundle bundle = new Bundle();
      bundle.putString("google.message_id", (String)i);
      i = u.b(paramContext).c(2, bundle);
    } 
    int j = b(paramContext, new CloudMessage(paramIntent));
    try {
      l.b(i, TimeUnit.SECONDS.toMillis(1L), TimeUnit.MILLISECONDS);
    } catch (ExecutionException executionException) {
      String str1 = String.valueOf(executionException);
      StringBuilder stringBuilder = new StringBuilder(str1.length() + 20);
      stringBuilder.append("Message ack failed: ");
      stringBuilder.append(str1);
      Log.w("CloudMessagingReceiver", stringBuilder.toString());
    } catch (InterruptedException interruptedException) {
    
    } catch (TimeoutException timeoutException) {}
    return j;
  }
  
  public final int f(Context paramContext, Intent paramIntent) {
    PendingIntent pendingIntent = (PendingIntent)paramIntent.getParcelableExtra("pending_intent");
    if (pendingIntent != null)
      try {
        pendingIntent.send();
      } catch (android.app.PendingIntent.CanceledException canceledException) {
        Log.e("CloudMessagingReceiver", "Notification pending intent canceled");
      }  
    Bundle bundle = paramIntent.getExtras();
    if (bundle != null) {
      bundle.remove("pending_intent");
    } else {
      bundle = new Bundle();
    } 
    if ("com.google.firebase.messaging.NOTIFICATION_DISMISS".equals(paramIntent.getAction())) {
      c(paramContext, bundle);
      return -1;
    } 
    Log.e("CloudMessagingReceiver", "Unknown notification action");
    return 500;
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    boolean bool = isOrderedBroadcast();
    BroadcastReceiver.PendingResult pendingResult = goAsync();
    a().execute(new g(this, paramIntent, paramContext, bool, pendingResult));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/CloudMessagingReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */