package com.google.android.gms.cloudmessaging;

import android.os.Bundle;
import android.util.Log;
import z1.j;

public abstract class r {
  public final int a;
  
  public final j b = new j();
  
  public final int c;
  
  public final Bundle d;
  
  public r(int paramInt1, int paramInt2, Bundle paramBundle) {
    this.a = paramInt1;
    this.c = paramInt2;
    this.d = paramBundle;
  }
  
  public abstract void a(Bundle paramBundle);
  
  public abstract boolean b();
  
  public final void c(s params) {
    if (Log.isLoggable("MessengerIpcClient", 3)) {
      String str1 = String.valueOf(this);
      String str2 = String.valueOf(params);
      StringBuilder stringBuilder = new StringBuilder(str1.length() + 14 + str2.length());
      stringBuilder.append("Failing ");
      stringBuilder.append(str1);
      stringBuilder.append(" with ");
      stringBuilder.append(str2);
      Log.d("MessengerIpcClient", stringBuilder.toString());
    } 
    this.b.b(params);
  }
  
  public final void d(Object paramObject) {
    if (Log.isLoggable("MessengerIpcClient", 3)) {
      String str1 = String.valueOf(this);
      String str2 = String.valueOf(paramObject);
      StringBuilder stringBuilder = new StringBuilder(str1.length() + 16 + str2.length());
      stringBuilder.append("Finishing ");
      stringBuilder.append(str1);
      stringBuilder.append(" with ");
      stringBuilder.append(str2);
      Log.d("MessengerIpcClient", stringBuilder.toString());
    } 
    this.b.c(paramObject);
  }
  
  public final String toString() {
    int i = this.c;
    int k = this.a;
    StringBuilder stringBuilder = new StringBuilder(55);
    stringBuilder.append("Request { what=");
    stringBuilder.append(i);
    stringBuilder.append(" id=");
    stringBuilder.append(k);
    stringBuilder.append(" oneWay=");
    stringBuilder.append(b());
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */