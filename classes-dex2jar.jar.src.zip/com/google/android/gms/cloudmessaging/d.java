package com.google.android.gms.cloudmessaging;

import android.os.Looper;
import android.os.Message;
import q1.f;

public final class d extends f {
  public d(b paramb, Looper paramLooper) {
    super(paramLooper);
  }
  
  public final void handleMessage(Message paramMessage) {
    b.d(this.a, paramMessage);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */