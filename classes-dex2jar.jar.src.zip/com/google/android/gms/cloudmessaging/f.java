package com.google.android.gms.cloudmessaging;

import android.os.Build;
import android.util.Log;

public final class f extends ClassLoader {
  public final Class loadClass(String paramString, boolean paramBoolean) {
    if ("com.google.android.gms.iid.MessengerCompat".equals(paramString)) {
      if (Log.isLoggable("CloudMessengerCompat", 3) || (Build.VERSION.SDK_INT == 23 && Log.isLoggable("CloudMessengerCompat", 3)))
        Log.d("CloudMessengerCompat", "Using renamed FirebaseIidMessengerCompat class"); 
      return zzd.class;
    } 
    return super.loadClass(paramString, paramBoolean);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */