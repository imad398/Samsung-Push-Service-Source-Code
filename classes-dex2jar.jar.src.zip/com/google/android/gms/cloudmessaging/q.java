package com.google.android.gms.cloudmessaging;

import android.os.Bundle;

public final class q extends r {
  public q(int paramInt1, int paramInt2, Bundle paramBundle) {
    super(paramInt1, 2, paramBundle);
  }
  
  public final void a(Bundle paramBundle) {
    if (paramBundle.getBoolean("ack", false)) {
      d(null);
      return;
    } 
    c(new s(4, "Invalid response to one way request", null));
  }
  
  public final boolean b() {
    return true;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */