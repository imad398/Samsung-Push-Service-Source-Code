package com.google.android.gms.cloudmessaging;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;
import f.g;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import z1.i;
import z1.j;
import z1.l;

public class b {
  public static int h;
  
  public static PendingIntent i;
  
  public static final Executor j = b0.a;
  
  public static final Pattern k = Pattern.compile("\\|ID\\|([^|]+)\\|:?+(.*)");
  
  public final g a = new g();
  
  public final Context b;
  
  public final v c;
  
  public final ScheduledExecutorService d;
  
  public Messenger e;
  
  public Messenger f;
  
  public zzd g;
  
  public b(Context paramContext) {
    this.b = paramContext;
    this.c = new v(paramContext);
    this.e = new Messenger((Handler)new d(this, Looper.getMainLooper()));
    ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1);
    scheduledThreadPoolExecutor.setKeepAliveTime(60L, TimeUnit.SECONDS);
    scheduledThreadPoolExecutor.allowCoreThreadTimeOut(true);
    this.d = scheduledThreadPoolExecutor;
  }
  
  public static String g() {
    // Byte code:
    //   0: ldc com/google/android/gms/cloudmessaging/b
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/cloudmessaging/b.h : I
    //   6: istore_0
    //   7: iload_0
    //   8: iconst_1
    //   9: iadd
    //   10: putstatic com/google/android/gms/cloudmessaging/b.h : I
    //   13: iload_0
    //   14: invokestatic toString : (I)Ljava/lang/String;
    //   17: astore_1
    //   18: ldc com/google/android/gms/cloudmessaging/b
    //   20: monitorexit
    //   21: aload_1
    //   22: areturn
    //   23: astore_1
    //   24: ldc com/google/android/gms/cloudmessaging/b
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	23	finally
  }
  
  public static void h(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: ldc com/google/android/gms/cloudmessaging/b
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/cloudmessaging/b.i : Landroid/app/PendingIntent;
    //   6: ifnonnull -> 37
    //   9: new android/content/Intent
    //   12: astore_2
    //   13: aload_2
    //   14: invokespecial <init> : ()V
    //   17: aload_2
    //   18: ldc_w 'com.google.example.invalidpackage'
    //   21: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   24: pop
    //   25: aload_0
    //   26: iconst_0
    //   27: aload_2
    //   28: getstatic q1/a.a : I
    //   31: invokestatic a : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   34: putstatic com/google/android/gms/cloudmessaging/b.i : Landroid/app/PendingIntent;
    //   37: aload_1
    //   38: ldc_w 'app'
    //   41: getstatic com/google/android/gms/cloudmessaging/b.i : Landroid/app/PendingIntent;
    //   44: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   47: pop
    //   48: ldc com/google/android/gms/cloudmessaging/b
    //   50: monitorexit
    //   51: return
    //   52: astore_0
    //   53: ldc com/google/android/gms/cloudmessaging/b
    //   55: monitorexit
    //   56: aload_0
    //   57: athrow
    // Exception table:
    //   from	to	target	type
    //   3	37	52	finally
    //   37	48	52	finally
  }
  
  public static boolean j(Bundle paramBundle) {
    return (paramBundle != null && paramBundle.containsKey("google.messenger"));
  }
  
  public i a(Bundle paramBundle) {
    i i;
    if (this.c.a() < 12000000) {
      if (this.c.b() != 0) {
        i = f(paramBundle).i(j, new w(this, paramBundle));
      } else {
        i = l.d(new IOException("MISSING_INSTANCEID_SERVICE"));
      } 
      return i;
    } 
    return u.b(this.b).d(1, (Bundle)i).h(j, x.a);
  }
  
  public final i f(Bundle paramBundle) {
    // Byte code:
    //   0: invokestatic g : ()Ljava/lang/String;
    //   3: astore_2
    //   4: new z1/j
    //   7: dup
    //   8: invokespecial <init> : ()V
    //   11: astore_3
    //   12: aload_0
    //   13: getfield a : Lf/g;
    //   16: astore #4
    //   18: aload #4
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield a : Lf/g;
    //   25: aload_2
    //   26: aload_3
    //   27: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   30: pop
    //   31: aload #4
    //   33: monitorexit
    //   34: new android/content/Intent
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #5
    //   43: aload #5
    //   45: ldc_w 'com.google.android.gms'
    //   48: invokevirtual setPackage : (Ljava/lang/String;)Landroid/content/Intent;
    //   51: pop
    //   52: aload_0
    //   53: getfield c : Lcom/google/android/gms/cloudmessaging/v;
    //   56: invokevirtual b : ()I
    //   59: iconst_2
    //   60: if_icmpne -> 71
    //   63: ldc_w 'com.google.iid.TOKEN_REQUEST'
    //   66: astore #4
    //   68: goto -> 76
    //   71: ldc_w 'com.google.android.c2dm.intent.REGISTER'
    //   74: astore #4
    //   76: aload #5
    //   78: aload #4
    //   80: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
    //   83: pop
    //   84: aload #5
    //   86: aload_1
    //   87: invokevirtual putExtras : (Landroid/os/Bundle;)Landroid/content/Intent;
    //   90: pop
    //   91: aload_0
    //   92: getfield b : Landroid/content/Context;
    //   95: aload #5
    //   97: invokestatic h : (Landroid/content/Context;Landroid/content/Intent;)V
    //   100: new java/lang/StringBuilder
    //   103: dup
    //   104: aload_2
    //   105: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   108: invokevirtual length : ()I
    //   111: iconst_5
    //   112: iadd
    //   113: invokespecial <init> : (I)V
    //   116: astore_1
    //   117: aload_1
    //   118: ldc_w '|ID|'
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: pop
    //   125: aload_1
    //   126: aload_2
    //   127: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: pop
    //   131: aload_1
    //   132: ldc '|'
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: pop
    //   138: aload #5
    //   140: ldc_w 'kid'
    //   143: aload_1
    //   144: invokevirtual toString : ()Ljava/lang/String;
    //   147: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   150: pop
    //   151: ldc 'Rpc'
    //   153: iconst_3
    //   154: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   157: ifeq -> 212
    //   160: aload #5
    //   162: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   165: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   168: astore_1
    //   169: new java/lang/StringBuilder
    //   172: dup
    //   173: aload_1
    //   174: invokevirtual length : ()I
    //   177: bipush #8
    //   179: iadd
    //   180: invokespecial <init> : (I)V
    //   183: astore #4
    //   185: aload #4
    //   187: ldc_w 'Sending '
    //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: pop
    //   194: aload #4
    //   196: aload_1
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: pop
    //   201: ldc 'Rpc'
    //   203: aload #4
    //   205: invokevirtual toString : ()Ljava/lang/String;
    //   208: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   211: pop
    //   212: aload #5
    //   214: ldc 'google.messenger'
    //   216: aload_0
    //   217: getfield e : Landroid/os/Messenger;
    //   220: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   223: pop
    //   224: aload_0
    //   225: getfield f : Landroid/os/Messenger;
    //   228: ifnonnull -> 238
    //   231: aload_0
    //   232: getfield g : Lcom/google/android/gms/cloudmessaging/zzd;
    //   235: ifnull -> 299
    //   238: invokestatic obtain : ()Landroid/os/Message;
    //   241: astore #4
    //   243: aload #4
    //   245: aload #5
    //   247: putfield obj : Ljava/lang/Object;
    //   250: aload_0
    //   251: getfield f : Landroid/os/Messenger;
    //   254: astore_1
    //   255: aload_1
    //   256: ifnull -> 268
    //   259: aload_1
    //   260: aload #4
    //   262: invokevirtual send : (Landroid/os/Message;)V
    //   265: goto -> 332
    //   268: aload_0
    //   269: getfield g : Lcom/google/android/gms/cloudmessaging/zzd;
    //   272: aload #4
    //   274: invokevirtual b : (Landroid/os/Message;)V
    //   277: goto -> 332
    //   280: astore_1
    //   281: ldc 'Rpc'
    //   283: iconst_3
    //   284: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   287: ifeq -> 299
    //   290: ldc 'Rpc'
    //   292: ldc_w 'Messenger failed, fallback to startService'
    //   295: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   298: pop
    //   299: aload_0
    //   300: getfield c : Lcom/google/android/gms/cloudmessaging/v;
    //   303: invokevirtual b : ()I
    //   306: iconst_2
    //   307: if_icmpne -> 322
    //   310: aload_0
    //   311: getfield b : Landroid/content/Context;
    //   314: aload #5
    //   316: invokevirtual sendBroadcast : (Landroid/content/Intent;)V
    //   319: goto -> 332
    //   322: aload_0
    //   323: getfield b : Landroid/content/Context;
    //   326: aload #5
    //   328: invokevirtual startService : (Landroid/content/Intent;)Landroid/content/ComponentName;
    //   331: pop
    //   332: aload_0
    //   333: getfield d : Ljava/util/concurrent/ScheduledExecutorService;
    //   336: new com/google/android/gms/cloudmessaging/a0
    //   339: dup
    //   340: aload_3
    //   341: invokespecial <init> : (Lz1/j;)V
    //   344: ldc2_w 30
    //   347: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   350: invokeinterface schedule : (Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    //   355: astore_1
    //   356: aload_3
    //   357: invokevirtual a : ()Lz1/i;
    //   360: getstatic com/google/android/gms/cloudmessaging/b.j : Ljava/util/concurrent/Executor;
    //   363: new com/google/android/gms/cloudmessaging/y
    //   366: dup
    //   367: aload_0
    //   368: aload_2
    //   369: aload_1
    //   370: invokespecial <init> : (Lcom/google/android/gms/cloudmessaging/b;Ljava/lang/String;Ljava/util/concurrent/ScheduledFuture;)V
    //   373: invokevirtual b : (Ljava/util/concurrent/Executor;Lz1/d;)Lz1/i;
    //   376: pop
    //   377: aload_3
    //   378: invokevirtual a : ()Lz1/i;
    //   381: areturn
    //   382: astore_1
    //   383: aload #4
    //   385: monitorexit
    //   386: aload_1
    //   387: athrow
    // Exception table:
    //   from	to	target	type
    //   21	34	382	finally
    //   250	255	280	android/os/RemoteException
    //   259	265	280	android/os/RemoteException
    //   268	277	280	android/os/RemoteException
    //   383	386	382	finally
  }
  
  public final void i(String paramString, Bundle paramBundle) {
    synchronized (this.a) {
      j j = (j)this.a.remove(paramString);
      if (j == null) {
        paramString = String.valueOf(paramString);
        if (paramString.length() != 0) {
          paramString = "Missing callback for ".concat(paramString);
        } else {
          paramString = new String("Missing callback for ");
        } 
        Log.w("Rpc", paramString);
        return;
      } 
      j.c(paramBundle);
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/cloudmessaging/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */