package com.google.android.gms.common.stats;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.util.Log;
import com.google.android.gms.common.internal.m;
import j1.o;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import l1.e;

public class b {
  public static final Object b = new Object();
  
  public static volatile b c;
  
  public ConcurrentHashMap a = new ConcurrentHashMap<Object, Object>();
  
  public static b b() {
    if (c == null)
      synchronized (b) {
        if (c == null) {
          b b2 = new b();
          this();
          c = b2;
        } 
      }  
    b b1 = c;
    m.i(b1);
    return b1;
  }
  
  public static void e(Context paramContext, ServiceConnection paramServiceConnection) {
    try {
      paramContext.unbindService(paramServiceConnection);
    } catch (IllegalArgumentException|IllegalStateException|java.util.NoSuchElementException illegalArgumentException) {}
  }
  
  public static boolean g(ServiceConnection paramServiceConnection) {
    return !(paramServiceConnection instanceof com.google.android.gms.common.internal.i1);
  }
  
  public static final boolean h(Context paramContext, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt, Executor paramExecutor) {
    return (o.m() && paramExecutor != null) ? a.a(paramContext, paramIntent, paramInt, paramExecutor, paramServiceConnection) : paramContext.bindService(paramIntent, paramServiceConnection, paramInt);
  }
  
  public boolean a(Context paramContext, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt) {
    return f(paramContext, paramContext.getClass().getName(), paramIntent, paramServiceConnection, paramInt, true, null);
  }
  
  public void c(Context paramContext, ServiceConnection paramServiceConnection) {
    if (g(paramServiceConnection) && this.a.containsKey(paramServiceConnection))
      try {
        e(paramContext, (ServiceConnection)this.a.get(paramServiceConnection));
        return;
      } finally {
        this.a.remove(paramServiceConnection);
      }  
    e(paramContext, paramServiceConnection);
  }
  
  public final boolean d(Context paramContext, String paramString, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt, Executor paramExecutor) {
    return f(paramContext, paramString, paramIntent, paramServiceConnection, paramInt, true, paramExecutor);
  }
  
  public final boolean f(Context paramContext, String paramString, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt, boolean paramBoolean, Executor paramExecutor) {
    ComponentName componentName = paramIntent.getComponent();
    if (componentName != null) {
      String str = componentName.getPackageName();
      "com.google.android.gms".equals(str);
      try {
        int i = (e.a(paramContext).c(str, 0)).flags;
        if ((i & 0x200000) != 0) {
          Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
          return false;
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    } 
    if (g(paramServiceConnection)) {
      ServiceConnection serviceConnection = this.a.putIfAbsent(paramServiceConnection, paramServiceConnection);
      if (serviceConnection != null && paramServiceConnection != serviceConnection)
        Log.w("ConnectionTracker", String.format("Duplicate binding with the same ServiceConnection: %s, %s, %s.", new Object[] { paramServiceConnection, paramString, paramIntent.getAction() })); 
      try {
        paramBoolean = h(paramContext, paramIntent, paramServiceConnection, paramInt, paramExecutor);
      } finally {
        this.a.remove(paramServiceConnection, paramServiceConnection);
      } 
    } else {
      paramBoolean = h(paramContext, paramIntent, paramServiceConnection, paramInt, paramExecutor);
    } 
    return paramBoolean;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/stats/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */