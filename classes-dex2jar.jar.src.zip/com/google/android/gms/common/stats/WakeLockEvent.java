package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import h1.b;
import java.util.List;
import javax.annotation.Nullable;

@Deprecated
public final class WakeLockEvent extends StatsEvent {
  public static final Parcelable.Creator<WakeLockEvent> CREATOR = new c();
  
  final int zza;
  
  private final long zzb;
  
  private int zzc;
  
  private final String zzd;
  
  private final String zze;
  
  private final String zzf;
  
  private final int zzg;
  
  @Nullable
  private final List zzh;
  
  private final String zzi;
  
  private final long zzj;
  
  private int zzk;
  
  private final String zzl;
  
  private final float zzm;
  
  private final long zzn;
  
  private final boolean zzo;
  
  private long zzp;
  
  public WakeLockEvent(int paramInt1, long paramLong1, int paramInt2, String paramString1, int paramInt3, List paramList, String paramString2, long paramLong2, int paramInt4, String paramString3, String paramString4, float paramFloat, long paramLong3, String paramString5, boolean paramBoolean) {
    this.zza = paramInt1;
    this.zzb = paramLong1;
    this.zzc = paramInt2;
    this.zzd = paramString1;
    this.zze = paramString3;
    this.zzf = paramString5;
    this.zzg = paramInt3;
    this.zzp = -1L;
    this.zzh = paramList;
    this.zzi = paramString2;
    this.zzj = paramLong2;
    this.zzk = paramInt4;
    this.zzl = paramString4;
    this.zzm = paramFloat;
    this.zzn = paramLong3;
    this.zzo = paramBoolean;
  }
  
  public final long R() {
    return this.zzb;
  }
  
  public final String S() {
    String str1;
    List list = this.zzh;
    String str2 = this.zzd;
    int i = this.zzg;
    String str3 = "";
    if (list == null) {
      str1 = "";
    } else {
      str1 = TextUtils.join(",", (Iterable)str1);
    } 
    int j = this.zzk;
    String str4 = this.zze;
    String str5 = str4;
    if (str4 == null)
      str5 = ""; 
    String str6 = this.zzl;
    str4 = str6;
    if (str6 == null)
      str4 = ""; 
    float f = this.zzm;
    str6 = this.zzf;
    if (str6 != null)
      str3 = str6; 
    boolean bool = this.zzo;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("\t");
    stringBuilder.append(str2);
    stringBuilder.append("\t");
    stringBuilder.append(i);
    stringBuilder.append("\t");
    stringBuilder.append(str1);
    stringBuilder.append("\t");
    stringBuilder.append(j);
    stringBuilder.append("\t");
    stringBuilder.append(str5);
    stringBuilder.append("\t");
    stringBuilder.append(str4);
    stringBuilder.append("\t");
    stringBuilder.append(f);
    stringBuilder.append("\t");
    stringBuilder.append(str3);
    stringBuilder.append("\t");
    stringBuilder.append(bool);
    return stringBuilder.toString();
  }
  
  public final int q() {
    return this.zzc;
  }
  
  public final long v() {
    return this.zzp;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zza);
    b.l(paramParcel, 2, this.zzb);
    b.o(paramParcel, 4, this.zzd, false);
    b.i(paramParcel, 5, this.zzg);
    b.q(paramParcel, 6, this.zzh, false);
    b.l(paramParcel, 8, this.zzj);
    b.o(paramParcel, 10, this.zze, false);
    b.i(paramParcel, 11, this.zzc);
    b.o(paramParcel, 12, this.zzi, false);
    b.o(paramParcel, 13, this.zzl, false);
    b.i(paramParcel, 14, this.zzk);
    b.g(paramParcel, 15, this.zzm);
    b.l(paramParcel, 16, this.zzn);
    b.o(paramParcel, 17, this.zzf, false);
    b.c(paramParcel, 18, this.zzo);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/stats/WakeLockEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */