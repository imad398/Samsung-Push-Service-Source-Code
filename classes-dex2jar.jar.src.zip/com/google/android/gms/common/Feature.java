package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class Feature extends AbstractSafeParcelable {
  public static final Parcelable.Creator<Feature> CREATOR = new s();
  
  private final String zza;
  
  @Deprecated
  private final int zzb;
  
  private final long zzc;
  
  public Feature(String paramString, int paramInt, long paramLong) {
    this.zza = paramString;
    this.zzb = paramInt;
    this.zzc = paramLong;
  }
  
  public Feature(String paramString, long paramLong) {
    this.zza = paramString;
    this.zzc = paramLong;
    this.zzb = -1;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof Feature) {
      paramObject = paramObject;
      if (((q() != null && q().equals(paramObject.q())) || (q() == null && paramObject.q() == null)) && v() == paramObject.v())
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    return k.b(new Object[] { q(), Long.valueOf(v()) });
  }
  
  public String q() {
    return this.zza;
  }
  
  public final String toString() {
    k.a a = k.c(this);
    a.a("name", q());
    a.a("version", Long.valueOf(v()));
    return a.toString();
  }
  
  public long v() {
    long l1 = this.zzc;
    long l2 = l1;
    if (l1 == -1L)
      l2 = this.zzb; 
    return l2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.o(paramParcel, 1, q(), false);
    b.i(paramParcel, 2, this.zzb);
    b.l(paramParcel, 3, v());
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/Feature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */