package com.google.android.gms.common.api;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.api.internal.a;
import com.google.android.gms.common.internal.e;
import com.google.android.gms.common.internal.m;
import g1.a0;
import g1.b;
import g1.f;
import g1.f0;
import g1.k;
import g1.n;
import g1.o;
import g1.o0;
import g1.s;
import j1.o;
import java.util.Collections;
import z1.i;
import z1.j;

public abstract class d {
  public final Context a;
  
  public final String b;
  
  public final a c;
  
  public final a.d d;
  
  public final b e;
  
  public final Looper f;
  
  public final int g;
  
  public final e h;
  
  public final n i;
  
  public final f j;
  
  public d(Context paramContext, Activity paramActivity, a parama, a.d paramd, a parama1) {
    m.j(paramContext, "Null context is not permitted.");
    m.j(parama, "Api must not be null.");
    m.j(parama1, "Settings must not be null; use Settings.DEFAULT_SETTINGS instead.");
    this.a = paramContext.getApplicationContext();
    boolean bool = o.n();
    String str1 = null;
    String str2 = str1;
    if (bool)
      try {
        str2 = (String)Context.class.getMethod("getAttributionTag", new Class[0]).invoke(paramContext, new Object[0]);
      } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
        str2 = str1;
      }  
    this.b = str2;
    this.c = parama;
    this.d = paramd;
    this.f = parama1.b;
    b b1 = b.a(parama, paramd, str2);
    this.e = b1;
    this.h = (e)new f0(this);
    f f1 = f.x(this.a);
    this.j = f1;
    this.g = f1.m();
    this.i = parama1.a;
    if (paramActivity != null && !(paramActivity instanceof GoogleApiActivity) && Looper.myLooper() == Looper.getMainLooper())
      s.u(paramActivity, f1, b1); 
    f1.b(this);
  }
  
  public d(Context paramContext, a parama, a.d paramd, a parama1) {
    this(paramContext, null, parama, paramd, parama1);
  }
  
  public e b() {
    return this.h;
  }
  
  public e.a c() {
    e.a a1 = new e.a();
    a1.d(null);
    a1.c(Collections.emptySet());
    a1.e(this.a.getClass().getName());
    a1.b(this.a.getPackageName());
    return a1;
  }
  
  public i d(o paramo) {
    return m(2, paramo);
  }
  
  public a e(a parama) {
    l(0, parama);
    return parama;
  }
  
  public final b f() {
    return this.e;
  }
  
  public String g() {
    return this.b;
  }
  
  public Looper h() {
    return this.f;
  }
  
  public final int i() {
    return this.g;
  }
  
  public final a.f j(Looper paramLooper, a0 parama0) {
    e e1 = c().a();
    a.f f1 = ((a.a)m.i(this.c.a())).a(this.a, paramLooper, e1, this.d, (e.a)parama0, (e.b)parama0);
    String str = g();
    if (str != null && f1 instanceof com.google.android.gms.common.internal.d)
      ((com.google.android.gms.common.internal.d)f1).P(str); 
    if (str == null || !(f1 instanceof k))
      return f1; 
    k k = (k)f1;
    throw null;
  }
  
  public final o0 k(Context paramContext, Handler paramHandler) {
    return new o0(paramContext, paramHandler, c().a());
  }
  
  public final a l(int paramInt, a parama) {
    parama.k();
    this.j.D(this, paramInt, parama);
    return parama;
  }
  
  public final i m(int paramInt, o paramo) {
    j j = new j();
    this.j.E(this, paramInt, paramo, j, this.i);
    return j.a();
  }
  
  public static class a {
    public static final a c = (new a()).a();
    
    public final n a;
    
    public final Looper b;
    
    public a(n param1n, Account param1Account, Looper param1Looper) {
      this.a = param1n;
      this.b = param1Looper;
    }
    
    public static class a {
      public n a;
      
      public Looper b;
      
      public d.a a() {
        if (this.a == null)
          this.a = (n)new g1.a(); 
        if (this.b == null)
          this.b = Looper.getMainLooper(); 
        return new d.a(this.a, null, this.b, null);
      }
    }
  }
  
  public static class a {
    public n a;
    
    public Looper b;
    
    public d.a a() {
      if (this.a == null)
        this.a = (n)new g1.a(); 
      if (this.b == null)
        this.b = Looper.getMainLooper(); 
      return new d.a(this.a, null, this.b, null);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */