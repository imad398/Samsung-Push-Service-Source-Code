package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class Status extends AbstractSafeParcelable implements i, ReflectedParcelable {
  public static final Parcelable.Creator<Status> CREATOR;
  
  public static final Status RESULT_CANCELED;
  
  public static final Status RESULT_DEAD_CLIENT;
  
  public static final Status RESULT_INTERNAL_ERROR;
  
  public static final Status RESULT_INTERRUPTED;
  
  public static final Status RESULT_SUCCESS;
  
  public static final Status RESULT_SUCCESS_CACHE = new Status(-1);
  
  public static final Status RESULT_TIMEOUT;
  
  public static final Status zza;
  
  final int zzb;
  
  private final int zzc;
  
  private final String zzd;
  
  private final PendingIntent zze;
  
  private final ConnectionResult zzf;
  
  static {
    RESULT_SUCCESS = new Status(0);
    RESULT_INTERRUPTED = new Status(14);
    RESULT_INTERNAL_ERROR = new Status(8);
    RESULT_TIMEOUT = new Status(15);
    RESULT_CANCELED = new Status(16);
    zza = new Status(17);
    RESULT_DEAD_CLIENT = new Status(18);
    CREATOR = new m();
  }
  
  public Status(int paramInt) {
    this(paramInt, (String)null);
  }
  
  public Status(int paramInt1, int paramInt2, String paramString, PendingIntent paramPendingIntent, ConnectionResult paramConnectionResult) {
    this.zzb = paramInt1;
    this.zzc = paramInt2;
    this.zzd = paramString;
    this.zze = paramPendingIntent;
    this.zzf = paramConnectionResult;
  }
  
  public Status(int paramInt, String paramString) {
    this(1, paramInt, paramString, null, null);
  }
  
  public Status(int paramInt, String paramString, PendingIntent paramPendingIntent) {
    this(1, paramInt, paramString, paramPendingIntent, null);
  }
  
  public Status(ConnectionResult paramConnectionResult, String paramString) {
    this(paramConnectionResult, paramString, 17);
  }
  
  public Status(ConnectionResult paramConnectionResult, String paramString, int paramInt) {
    this(1, paramInt, paramString, paramConnectionResult.R(), paramConnectionResult);
  }
  
  public String R() {
    return this.zzd;
  }
  
  public boolean S() {
    return (this.zze != null);
  }
  
  public boolean T() {
    return (this.zzc <= 0);
  }
  
  public final String U() {
    String str = this.zzd;
    return (str != null) ? str : c.a(this.zzc);
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof Status))
      return false; 
    paramObject = paramObject;
    return (this.zzb == ((Status)paramObject).zzb && this.zzc == ((Status)paramObject).zzc && k.a(this.zzd, ((Status)paramObject).zzd) && k.a(this.zze, ((Status)paramObject).zze) && k.a(this.zzf, ((Status)paramObject).zzf));
  }
  
  public int hashCode() {
    return k.b(new Object[] { Integer.valueOf(this.zzb), Integer.valueOf(this.zzc), this.zzd, this.zze, this.zzf });
  }
  
  public ConnectionResult q() {
    return this.zzf;
  }
  
  public String toString() {
    k.a a = k.c(this);
    a.a("statusCode", U());
    a.a("resolution", this.zze);
    return a.toString();
  }
  
  public int v() {
    return this.zzc;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int j = b.a(paramParcel);
    b.i(paramParcel, 1, v());
    b.o(paramParcel, 2, R(), false);
    b.n(paramParcel, 3, (Parcelable)this.zze, paramInt, false);
    b.n(paramParcel, 4, (Parcelable)q(), paramInt, false);
    b.i(paramParcel, 1000, this.zzb);
    b.b(paramParcel, j);
  }
  
  public Status x() {
    return this;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */