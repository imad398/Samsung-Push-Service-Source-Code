package com.google.android.gms.common.api;

import com.google.android.gms.common.Feature;

public final class j extends UnsupportedOperationException {
  public final Feature a;
  
  public j(Feature paramFeature) {
    this.a = paramFeature;
  }
  
  public String getMessage() {
    return "Missing ".concat(String.valueOf(this.a));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */