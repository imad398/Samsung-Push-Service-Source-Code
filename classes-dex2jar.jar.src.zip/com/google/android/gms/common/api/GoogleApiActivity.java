package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.i;
import com.google.android.gms.common.internal.m;
import g1.f;

@KeepName
public class GoogleApiActivity extends Activity implements DialogInterface.OnCancelListener {
  public int a = 0;
  
  public static Intent a(Context paramContext, PendingIntent paramPendingIntent, int paramInt, boolean paramBoolean) {
    Intent intent = new Intent(paramContext, GoogleApiActivity.class);
    intent.putExtra("pending_intent", (Parcelable)paramPendingIntent);
    intent.putExtra("failing_client_id", paramInt);
    intent.putExtra("notify_manager", paramBoolean);
    return intent;
  }
  
  public final void b() {
    Bundle bundle = getIntent().getExtras();
    if (bundle == null) {
      Log.e("GoogleApiActivity", "Activity started without extras");
      finish();
      return;
    } 
    PendingIntent pendingIntent = (PendingIntent)bundle.get("pending_intent");
    Integer integer = (Integer)bundle.get("error_code");
    if (pendingIntent != null || integer != null) {
      if (pendingIntent != null)
        try {
          startIntentSenderForResult(pendingIntent.getIntentSender(), 1, null, 0, 0, 0);
          this.a = 1;
          return;
        } catch (ActivityNotFoundException activityNotFoundException) {
          if (bundle.getBoolean("notify_manager", true)) {
            f.x((Context)this).G(new ConnectionResult(22, null), getIntent().getIntExtra("failing_client_id", -1));
          } else {
            String str2 = pendingIntent.toString();
            StringBuilder stringBuilder = new StringBuilder(str2.length() + 36);
            stringBuilder.append("Activity not found while launching ");
            stringBuilder.append(str2);
            stringBuilder.append(".");
            str2 = stringBuilder.toString();
            String str1 = str2;
            if (Build.FINGERPRINT.contains("generic"))
              str1 = str2.concat(" This may occur when resolving Google Play services connection issues on emulators with Google APIs but not Google Play Store."); 
            Log.e("GoogleApiActivity", str1, (Throwable)activityNotFoundException);
          } 
          this.a = 1;
          finish();
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          Log.e("GoogleApiActivity", "Failed to launch pendingIntent", (Throwable)sendIntentException);
          finish();
          return;
        }  
      int i = ((Integer)m.i(activityNotFoundException)).intValue();
      i.m().n(this, i, 2, this);
      this.a = 1;
      return;
    } 
    Log.e("GoogleApiActivity", "Activity started without resolution");
    finish();
  }
  
  public final void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    f f;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 1) {
      boolean bool = getIntent().getBooleanExtra("notify_manager", true);
      this.a = 0;
      setResult(paramInt2, paramIntent);
      if (bool) {
        f = f.x((Context)this);
        if (paramInt2 != -1) {
          if (paramInt2 == 0)
            f.G(new ConnectionResult(13, null), getIntent().getIntExtra("failing_client_id", -1)); 
        } else {
          f.a();
        } 
      } 
    } else if (paramInt1 == 2) {
      this.a = 0;
      setResult(paramInt2, (Intent)f);
    } 
    finish();
  }
  
  public final void onCancel(DialogInterface paramDialogInterface) {
    this.a = 0;
    setResult(0);
    finish();
  }
  
  public final void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (paramBundle != null)
      this.a = paramBundle.getInt("resolution"); 
    if (this.a != 1)
      b(); 
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    paramBundle.putInt("resolution", this.a);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/GoogleApiActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */