package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.internal.h;
import com.google.android.gms.common.internal.m;
import g1.l;
import java.util.Set;

public final class a {
  public final a a;
  
  public final g b;
  
  public final String c;
  
  public a(String paramString, a parama, g paramg) {
    m.j(parama, "Cannot construct an Api with a null ClientBuilder");
    m.j(paramg, "Cannot construct an Api with a null ClientKey");
    this.c = paramString;
    this.a = parama;
    this.b = paramg;
  }
  
  public final a a() {
    return this.a;
  }
  
  public final c b() {
    return this.b;
  }
  
  public final String c() {
    return this.c;
  }
  
  public static abstract class a extends e {
    public a.f a(Context param1Context, Looper param1Looper, com.google.android.gms.common.internal.e param1e, Object param1Object, e.a param1a, e.b param1b) {
      return b(param1Context, param1Looper, param1e, param1Object, param1a, param1b);
    }
    
    public a.f b(Context param1Context, Looper param1Looper, com.google.android.gms.common.internal.e param1e, Object param1Object, g1.e param1e1, l param1l) {
      throw new UnsupportedOperationException("buildClient must be implemented");
    }
  }
  
  public static interface b {}
  
  public static abstract class c {}
  
  public static interface d {}
  
  public static abstract class e {}
  
  public static interface f extends b {
    void a(com.google.android.gms.common.internal.d.e param1e);
    
    boolean b();
    
    Set c();
    
    void d();
    
    void e(h param1h, Set param1Set);
    
    void f(String param1String);
    
    boolean g();
    
    int i();
    
    boolean j();
    
    Feature[] k();
    
    String l();
    
    String m();
    
    void n(com.google.android.gms.common.internal.d.c param1c);
    
    boolean o();
  }
  
  public static final class g extends c {}
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */