package com.google.android.gms.common.api;

import java.util.concurrent.TimeUnit;

public abstract class f {
  public abstract void b(a parama);
  
  public abstract i c(long paramLong, TimeUnit paramTimeUnit);
  
  public static interface a {
    void a(Status param1Status);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */