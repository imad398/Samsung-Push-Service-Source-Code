package com.google.android.gms.common.api.internal;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.api.i;
import com.google.android.gms.common.internal.m;
import g1.d;

public abstract class a extends BasePendingResult implements d {
  public final com.google.android.gms.common.api.a.c n;
  
  public final com.google.android.gms.common.api.a o;
  
  public a(com.google.android.gms.common.api.a parama, e parame) {
    super((e)m.j(parame, "GoogleApiClient must not be null"));
    m.j(parama, "Api must not be null");
    this.n = parama.b();
    this.o = parama;
  }
  
  public abstract void m(com.google.android.gms.common.api.a.b paramb);
  
  public void n(i parami) {}
  
  public final void o(com.google.android.gms.common.api.a.b paramb) {
    try {
      m(paramb);
      return;
    } catch (DeadObjectException deadObjectException) {
      p((RemoteException)deadObjectException);
      throw deadObjectException;
    } catch (RemoteException remoteException) {
      p(remoteException);
      return;
    } 
  }
  
  public final void p(RemoteException paramRemoteException) {
    q(new Status(8, paramRemoteException.getLocalizedMessage(), null));
  }
  
  public final void q(Status paramStatus) {
    m.b(paramStatus.T() ^ true, "Failed result must not be success");
    i i = d(paramStatus);
    g(i);
    n(i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/internal/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */