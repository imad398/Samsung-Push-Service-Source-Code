package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.api.f;
import com.google.android.gms.common.api.g;
import com.google.android.gms.common.api.i;
import com.google.android.gms.common.internal.m;
import g1.b1;
import g1.d1;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import p1.g;

@KeepName
public abstract class BasePendingResult<R extends i> extends f {
  public static final ThreadLocal m = (ThreadLocal)new b1();
  
  public final Object a;
  
  public final a b;
  
  public final WeakReference c;
  
  public final CountDownLatch d;
  
  public final ArrayList e;
  
  public final AtomicReference f;
  
  public i g;
  
  public Status h;
  
  public volatile boolean i;
  
  public boolean j;
  
  public boolean k;
  
  public boolean l;
  
  @KeepName
  private d1 mResultGuardian;
  
  public BasePendingResult(e parame) {
    Looper looper;
    this.a = new Object();
    this.d = new CountDownLatch(1);
    this.e = new ArrayList();
    this.f = new AtomicReference();
    this.l = false;
    if (parame != null) {
      looper = parame.b();
    } else {
      looper = Looper.getMainLooper();
    } 
    this.b = new a(looper);
    this.c = new WeakReference<e>(parame);
  }
  
  public static void l(i parami) {
    if (parami instanceof g)
      try {
        ((g)parami).a();
        return;
      } catch (RuntimeException runtimeException) {
        Log.w("BasePendingResult", "Unable to release ".concat(String.valueOf(parami)), runtimeException);
      }  
  }
  
  public final void b(f.a parama) {
    boolean bool;
    if (parama != null) {
      bool = true;
    } else {
      bool = false;
    } 
    m.b(bool, "Callback cannot be null.");
    synchronized (this.a) {
      if (f()) {
        parama.a(this.h);
      } else {
        this.e.add(parama);
      } 
      return;
    } 
  }
  
  public final i c(long paramLong, TimeUnit paramTimeUnit) {
    if (paramLong > 0L)
      m.h("await must not be called on the UI thread when time is greater than zero."); 
    m.l(this.i ^ true, "Result has already been consumed.");
    m.l(true, "Cannot await if then() has been called.");
    try {
      if (!this.d.await(paramLong, paramTimeUnit))
        e(Status.RESULT_TIMEOUT); 
    } catch (InterruptedException interruptedException) {
      e(Status.RESULT_INTERRUPTED);
    } 
    m.l(f(), "Result is not ready.");
    return h();
  }
  
  public abstract i d(Status paramStatus);
  
  public final void e(Status paramStatus) {
    synchronized (this.a) {
      if (!f()) {
        g(d(paramStatus));
        this.k = true;
      } 
      return;
    } 
  }
  
  public final boolean f() {
    return (this.d.getCount() == 0L);
  }
  
  public final void g(i parami) {
    synchronized (this.a) {
      if (!this.k && !this.j) {
        f();
        m.l(f() ^ true, "Results have already been set");
        m.l(this.i ^ true, "Result has already been consumed");
        i(parami);
        return;
      } 
      l(parami);
      return;
    } 
  }
  
  public final i h() {
    synchronized (this.a) {
      m.l(this.i ^ true, "Result has already been consumed.");
      m.l(f(), "Result is not ready.");
      i i1 = this.g;
      this.g = null;
      this.i = true;
      android.support.v4.media.a.a(this.f.getAndSet(null));
      return (i)m.i(i1);
    } 
  }
  
  public final void i(i parami) {
    this.g = parami;
    this.h = parami.x();
    this.d.countDown();
    if (!this.j && this.g instanceof g)
      this.mResultGuardian = new d1(this, null); 
    ArrayList<f.a> arrayList = this.e;
    int j = arrayList.size();
    for (byte b = 0; b < j; b++)
      ((f.a)arrayList.get(b)).a(this.h); 
    this.e.clear();
  }
  
  public final void k() {
    boolean bool = this.l;
    boolean bool1 = true;
    boolean bool2 = bool1;
    if (!bool)
      if (((Boolean)m.get()).booleanValue()) {
        bool2 = bool1;
      } else {
        bool2 = false;
      }  
    this.l = bool2;
  }
  
  public static class a extends g {
    public a(Looper param1Looper) {
      super(param1Looper);
    }
    
    public final void handleMessage(Message param1Message) {
      Exception exception;
      int i = param1Message.what;
      if (i != 1) {
        if (i != 2) {
          StringBuilder stringBuilder = new StringBuilder(45);
          stringBuilder.append("Don't know how to handle message: ");
          stringBuilder.append(i);
          exception = new Exception();
          Log.wtf("BasePendingResult", stringBuilder.toString(), exception);
          return;
        } 
        ((BasePendingResult)((Message)exception).obj).e(Status.RESULT_TIMEOUT);
        return;
      } 
      Pair pair = (Pair)((Message)exception).obj;
      android.support.v4.media.a.a(pair.first);
      i i1 = (i)pair.second;
      try {
        throw null;
      } catch (RuntimeException runtimeException) {
        BasePendingResult.l(i1);
        throw runtimeException;
      } 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/internal/BasePendingResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */