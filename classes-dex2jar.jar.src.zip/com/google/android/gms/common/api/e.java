package com.google.android.gms.common.api;

import android.os.Looper;
import com.google.android.gms.common.api.internal.a;
import g1.l;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

public abstract class e {
  public static final Set a = Collections.newSetFromMap(new WeakHashMap<Object, Boolean>());
  
  public abstract a a(a parama);
  
  public abstract Looper b();
  
  public static interface a extends g1.e {}
  
  public static interface b extends l {}
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */