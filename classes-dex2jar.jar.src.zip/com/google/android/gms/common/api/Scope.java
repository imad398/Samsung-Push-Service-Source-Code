package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class Scope extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<Scope> CREATOR = new l();
  
  final int zza;
  
  private final String zzb;
  
  public Scope(int paramInt, String paramString) {
    m.f(paramString, "scopeUri must not be null or empty");
    this.zza = paramInt;
    this.zzb = paramString;
  }
  
  public Scope(String paramString) {
    this(1, paramString);
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof Scope) ? false : this.zzb.equals(((Scope)paramObject).zzb));
  }
  
  public int hashCode() {
    return this.zzb.hashCode();
  }
  
  public String q() {
    return this.zzb;
  }
  
  public String toString() {
    return this.zzb;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zza);
    b.o(paramParcel, 2, q(), false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/api/Scope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */