package com.google.android.gms.common.internal;

import android.content.Context;
import i1.d;

public abstract class p {
  public static q a(Context paramContext) {
    return b(paramContext, r.b);
  }
  
  public static q b(Context paramContext, r paramr) {
    return (q)new d(paramContext, paramr);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */