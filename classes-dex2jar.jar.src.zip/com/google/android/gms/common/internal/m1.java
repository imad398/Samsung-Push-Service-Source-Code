package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import m1.a;
import r1.a;

public final class m1 extends a implements o1 {
  public m1(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.common.internal.ICertData");
  }
  
  public final int Q() {
    Parcel parcel = v(2, N());
    int i = parcel.readInt();
    parcel.recycle();
    return i;
  }
  
  public final a a0() {
    Parcel parcel = v(1, N());
    a a1 = a.a.N(parcel.readStrongBinder());
    parcel.recycle();
    return a1;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */