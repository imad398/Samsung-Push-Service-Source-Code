package com.google.android.gms.common.internal;

import android.app.PendingIntent;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import r1.e;

public final class r0 extends e {
  public r0(d paramd, Looper paramLooper) {
    super(paramLooper);
  }
  
  public static final void a(Message paramMessage) {
    s0 s0 = (s0)paramMessage.obj;
    s0.b();
    s0.e();
  }
  
  public static final boolean b(Message paramMessage) {
    int i = paramMessage.what;
    return (i == 2 || i == 1 || i == 7);
  }
  
  public final void handleMessage(Message paramMessage) {
    StringBuilder stringBuilder;
    if (this.a.C.get() != paramMessage.arg1) {
      if (b(paramMessage))
        a(paramMessage); 
      return;
    } 
    int i = paramMessage.what;
    if ((i != 1 && i != 7 && (i != 4 || this.a.t()) && paramMessage.what != 5) || this.a.j()) {
      ConnectionResult connectionResult;
      i = paramMessage.what;
      PendingIntent pendingIntent = null;
      if (i == 4) {
        d.Z(this.a, new ConnectionResult(paramMessage.arg2));
        if (d.h0(this.a)) {
          d d2 = this.a;
          if (!d.f0(d2)) {
            d.b0(d2, 3, null);
            return;
          } 
        } 
        d d1 = this.a;
        if (d.T(d1) != null) {
          connectionResult = d.T(d1);
        } else {
          connectionResult = new ConnectionResult(8);
        } 
        this.a.p.a(connectionResult);
        this.a.L(connectionResult);
        return;
      } 
      if (i == 5) {
        d d1 = this.a;
        if (d.T(d1) != null) {
          connectionResult = d.T(d1);
        } else {
          connectionResult = new ConnectionResult(8);
        } 
        this.a.p.a(connectionResult);
        this.a.L(connectionResult);
        return;
      } 
      if (i == 3) {
        Object object = ((Message)connectionResult).obj;
        if (object instanceof PendingIntent)
          pendingIntent = (PendingIntent)object; 
        connectionResult = new ConnectionResult(((Message)connectionResult).arg2, pendingIntent);
        this.a.p.a(connectionResult);
        this.a.L(connectionResult);
        return;
      } 
      if (i == 6) {
        d.b0(this.a, 5, null);
        d d1 = this.a;
        if (d.U(d1) != null)
          d.U(d1).v(((Message)connectionResult).arg2); 
        this.a.M(((Message)connectionResult).arg2);
        d.g0(this.a, 5, 1, null);
        return;
      } 
      if (i != 2 || this.a.b()) {
        if (b((Message)connectionResult)) {
          ((s0)((Message)connectionResult).obj).c();
          return;
        } 
        i = ((Message)connectionResult).what;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Don't know how to handle message: ");
        stringBuilder.append(i);
        Exception exception = new Exception();
        Log.wtf("GmsClient", stringBuilder.toString(), exception);
        return;
      } 
      a((Message)stringBuilder);
      return;
    } 
    a((Message)stringBuilder);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */