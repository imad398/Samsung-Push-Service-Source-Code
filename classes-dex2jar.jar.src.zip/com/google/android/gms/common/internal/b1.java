package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Scope;
import h1.a;
import h1.b;

public final class b1 implements Parcelable.Creator {
  public static void a(GetServiceRequest paramGetServiceRequest, Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, paramGetServiceRequest.zzc);
    b.i(paramParcel, 2, paramGetServiceRequest.zzd);
    b.i(paramParcel, 3, paramGetServiceRequest.zze);
    b.o(paramParcel, 4, paramGetServiceRequest.zzf, false);
    b.h(paramParcel, 5, paramGetServiceRequest.zzg, false);
    b.r(paramParcel, 6, (Parcelable[])paramGetServiceRequest.zzh, paramInt, false);
    b.d(paramParcel, 7, paramGetServiceRequest.zzi, false);
    b.n(paramParcel, 8, (Parcelable)paramGetServiceRequest.zzj, paramInt, false);
    b.r(paramParcel, 10, (Parcelable[])paramGetServiceRequest.zzk, paramInt, false);
    b.r(paramParcel, 11, (Parcelable[])paramGetServiceRequest.zzl, paramInt, false);
    b.c(paramParcel, 12, paramGetServiceRequest.zzm);
    b.i(paramParcel, 13, paramGetServiceRequest.zzn);
    b.c(paramParcel, 14, paramGetServiceRequest.zzo);
    b.o(paramParcel, 15, paramGetServiceRequest.q(), false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */