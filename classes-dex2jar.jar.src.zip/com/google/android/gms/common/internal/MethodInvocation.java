package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class MethodInvocation extends AbstractSafeParcelable {
  public static final Parcelable.Creator<MethodInvocation> CREATOR = new d0();
  
  private final int zaa;
  
  private final int zab;
  
  private final int zac;
  
  private final long zad;
  
  private final long zae;
  
  private final String zaf;
  
  private final String zag;
  
  private final int zah;
  
  private final int zai;
  
  public MethodInvocation(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, String paramString1, String paramString2, int paramInt4, int paramInt5) {
    this.zaa = paramInt1;
    this.zab = paramInt2;
    this.zac = paramInt3;
    this.zad = paramLong1;
    this.zae = paramLong2;
    this.zaf = paramString1;
    this.zag = paramString2;
    this.zah = paramInt4;
    this.zai = paramInt5;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.i(paramParcel, 2, this.zab);
    b.i(paramParcel, 3, this.zac);
    b.l(paramParcel, 4, this.zad);
    b.l(paramParcel, 5, this.zae);
    b.o(paramParcel, 6, this.zaf, false);
    b.o(paramParcel, 7, this.zag, false);
    b.i(paramParcel, 8, this.zah);
    b.i(paramParcel, 9, this.zai);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/MethodInvocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */