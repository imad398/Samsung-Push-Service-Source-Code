package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class k {
  public static boolean a(Object paramObject1, Object paramObject2) {
    boolean bool1 = true;
    boolean bool2 = bool1;
    if (paramObject1 != paramObject2)
      if (paramObject1 != null) {
        if (paramObject1.equals(paramObject2)) {
          bool2 = bool1;
        } else {
          return false;
        } 
      } else {
        bool2 = false;
      }  
    return bool2;
  }
  
  public static int b(Object... paramVarArgs) {
    return Arrays.hashCode(paramVarArgs);
  }
  
  public static a c(Object paramObject) {
    return new a(paramObject, null);
  }
  
  public static final class a {
    public final List a;
    
    public final Object b;
    
    public a a(String param1String, Object param1Object) {
      List<String> list = this.a;
      m.i(param1String);
      param1Object = String.valueOf(param1Object);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append("=");
      stringBuilder.append((String)param1Object);
      list.add(stringBuilder.toString());
      return this;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(100);
      stringBuilder.append(this.b.getClass().getSimpleName());
      stringBuilder.append('{');
      int i = this.a.size();
      for (byte b = 0; b < i; b++) {
        stringBuilder.append(this.a.get(b));
        if (b < i - 1)
          stringBuilder.append(", "); 
      } 
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */