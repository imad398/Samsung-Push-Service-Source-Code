package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public final class c1 {
  public static final Uri f = (new Uri.Builder()).scheme("content").authority("com.google.android.gms.chimera").build();
  
  public final String a;
  
  public final String b;
  
  public final ComponentName c;
  
  public final int d;
  
  public final boolean e;
  
  public c1(String paramString1, String paramString2, int paramInt, boolean paramBoolean) {
    m.e(paramString1);
    this.a = paramString1;
    m.e(paramString2);
    this.b = paramString2;
    this.c = null;
    this.d = paramInt;
    this.e = paramBoolean;
  }
  
  public final int a() {
    return this.d;
  }
  
  public final ComponentName b() {
    return this.c;
  }
  
  public final Intent c(Context paramContext) {
    Intent intent;
    if (this.a != null) {
      boolean bool = this.e;
      Bundle bundle = null;
      IllegalArgumentException illegalArgumentException = null;
      if (bool) {
        Intent intent1;
        bundle = new Bundle();
        bundle.putString("serviceActionBundleKey", this.a);
        try {
          Bundle bundle1 = paramContext.getContentResolver().call(f, "serviceIntentCall", null, bundle);
        } catch (IllegalArgumentException illegalArgumentException1) {
          Log.w("ConnectionStatusConfig", "Dynamic intent resolution failed: ".concat(illegalArgumentException1.toString()));
          illegalArgumentException1 = null;
        } 
        if (illegalArgumentException1 == null) {
          illegalArgumentException1 = illegalArgumentException;
        } else {
          intent1 = (Intent)illegalArgumentException1.getParcelable("serviceResponseIntentKey");
        } 
        intent = intent1;
        if (intent1 == null) {
          Log.w("ConnectionStatusConfig", "Dynamic lookup for intent failed for action: ".concat(String.valueOf(this.a)));
          intent = intent1;
        } 
      } 
      if (intent == null)
        return (new Intent(this.a)).setPackage(this.b); 
    } else {
      intent = (new Intent()).setComponent(this.c);
    } 
    return intent;
  }
  
  public final String d() {
    return this.b;
  }
  
  public final boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof c1))
      return false; 
    paramObject = paramObject;
    return (k.a(this.a, ((c1)paramObject).a) && k.a(this.b, ((c1)paramObject).b) && k.a(this.c, ((c1)paramObject).c) && this.d == ((c1)paramObject).d && this.e == ((c1)paramObject).e);
  }
  
  public final int hashCode() {
    return k.b(new Object[] { this.a, this.b, this.c, Integer.valueOf(this.d), Boolean.valueOf(this.e) });
  }
  
  public final String toString() {
    String str1 = this.a;
    String str2 = str1;
    if (str1 == null) {
      m.i(this.c);
      str2 = this.c.flattenToString();
    } 
    return str2;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */