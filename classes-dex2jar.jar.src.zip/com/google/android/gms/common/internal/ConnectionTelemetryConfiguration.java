package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class ConnectionTelemetryConfiguration extends AbstractSafeParcelable {
  public static final Parcelable.Creator<ConnectionTelemetryConfiguration> CREATOR = new a1();
  
  private final RootTelemetryConfiguration zza;
  
  private final boolean zzb;
  
  private final boolean zzc;
  
  private final int[] zzd;
  
  private final int zze;
  
  private final int[] zzf;
  
  public ConnectionTelemetryConfiguration(RootTelemetryConfiguration paramRootTelemetryConfiguration, boolean paramBoolean1, boolean paramBoolean2, int[] paramArrayOfint1, int paramInt, int[] paramArrayOfint2) {
    this.zza = paramRootTelemetryConfiguration;
    this.zzb = paramBoolean1;
    this.zzc = paramBoolean2;
    this.zzd = paramArrayOfint1;
    this.zze = paramInt;
    this.zzf = paramArrayOfint2;
  }
  
  public int[] R() {
    return this.zzf;
  }
  
  public boolean S() {
    return this.zzb;
  }
  
  public boolean T() {
    return this.zzc;
  }
  
  public final RootTelemetryConfiguration U() {
    return this.zza;
  }
  
  public int q() {
    return this.zze;
  }
  
  public int[] v() {
    return this.zzd;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.n(paramParcel, 1, (Parcelable)this.zza, paramInt, false);
    b.c(paramParcel, 2, S());
    b.c(paramParcel, 3, T());
    b.j(paramParcel, 4, v(), false);
    b.i(paramParcel, 5, q());
    b.j(paramParcel, 6, R(), false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/ConnectionTelemetryConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */