package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.f;
import com.google.android.gms.common.api.i;
import java.util.concurrent.TimeUnit;
import z1.j;

public final class f0 implements f.a {
  public f0(f paramf, j paramj, l.a parama, g0 paramg0) {}
  
  public final void a(Status paramStatus) {
    i i;
    if (paramStatus.T()) {
      i = this.a.c(0L, TimeUnit.MILLISECONDS);
      this.b.c(this.c.a(i));
      return;
    } 
    this.b.b((Exception)b.a((Status)i));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */