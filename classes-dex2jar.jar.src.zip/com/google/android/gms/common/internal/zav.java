package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class zav extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zav> CREATOR = new i0();
  
  final int zaa;
  
  final IBinder zab;
  
  private final ConnectionResult zac;
  
  private final boolean zad;
  
  private final boolean zae;
  
  public zav(int paramInt, IBinder paramIBinder, ConnectionResult paramConnectionResult, boolean paramBoolean1, boolean paramBoolean2) {
    this.zaa = paramInt;
    this.zab = paramIBinder;
    this.zac = paramConnectionResult;
    this.zad = paramBoolean1;
    this.zae = paramBoolean2;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof zav))
      return false; 
    paramObject = paramObject;
    return (this.zac.equals(((zav)paramObject).zac) && k.a(v(), paramObject.v()));
  }
  
  public final ConnectionResult q() {
    return this.zac;
  }
  
  public final h v() {
    IBinder iBinder = this.zab;
    return (iBinder == null) ? null : h.a.N(iBinder);
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.h(paramParcel, 2, this.zab, false);
    b.n(paramParcel, 3, (Parcelable)this.zac, paramInt, false);
    b.c(paramParcel, 4, this.zad);
    b.c(paramParcel, 5, this.zae);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/zav.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */