package com.google.android.gms.common.internal;

import android.os.IInterface;

public interface j extends IInterface {
  void L3(i parami, GetServiceRequest paramGetServiceRequest);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */