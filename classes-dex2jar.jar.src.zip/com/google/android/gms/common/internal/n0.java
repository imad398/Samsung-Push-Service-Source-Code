package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import l1.d;
import l1.e;

public abstract class n0 {
  public static final Object a = new Object();
  
  public static boolean b;
  
  public static String c;
  
  public static int d;
  
  public static int a(Context paramContext) {
    c(paramContext);
    return d;
  }
  
  public static String b(Context paramContext) {
    c(paramContext);
    return c;
  }
  
  public static void c(Context paramContext) {
    synchronized (a) {
      if (b)
        return; 
      b = true;
      String str = paramContext.getPackageName();
      d d = e.a(paramContext);
      try {
        Bundle bundle = (d.c(str, 128)).metaData;
        if (bundle == null)
          return; 
        c = bundle.getString("com.google.app.id");
        d = bundle.getInt("com.google.android.gms.version");
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.wtf("MetadataValueReader", "This should never happen.", (Throwable)nameNotFoundException);
      } 
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */