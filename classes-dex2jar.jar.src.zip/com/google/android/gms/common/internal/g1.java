package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public final class g1 implements Handler.Callback {
  public final boolean handleMessage(Message paramMessage) {
    int i = paramMessage.what;
    if (i != 0) {
      if (i != 1)
        return false; 
      synchronized (h1.k(this.a)) {
        c1 c1 = (c1)paramMessage.obj;
        e1 e1 = (e1)h1.k(this.a).get(c1);
        if (e1 != null && e1.a() == 3) {
          String str = String.valueOf(c1);
          StringBuilder stringBuilder = new StringBuilder();
          this();
          stringBuilder.append("Timeout waiting for ServiceConnection callback ");
          stringBuilder.append(str);
          Exception exception = new Exception();
          this();
          Log.e("GmsClientSupervisor", stringBuilder.toString(), exception);
          ComponentName componentName2 = e1.b();
          ComponentName componentName1 = componentName2;
          if (componentName2 == null)
            componentName1 = c1.b(); 
          componentName2 = componentName1;
          if (componentName1 == null) {
            componentName2 = new ComponentName();
            String str1 = c1.d();
            m.i(str1);
            this(str1, "unknown");
          } 
          e1.onServiceDisconnected(componentName2);
        } 
        return true;
      } 
    } 
    synchronized (h1.k(this.a)) {
      c1 c1 = (c1)paramMessage.obj;
      e1 e1 = (e1)h1.k(this.a).get(c1);
      if (e1 != null && e1.i()) {
        if (e1.j())
          e1.g("GmsClientSupervisor"); 
        h1.k(this.a).remove(c1);
      } 
      return true;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */