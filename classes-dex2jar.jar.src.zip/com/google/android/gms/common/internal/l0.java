package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import r1.b;
import r1.c;

public abstract class l0 extends b implements i {
  public l0() {
    super("com.google.android.gms.common.internal.IGmsCallbacks");
  }
  
  public final boolean v(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) {
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3)
          return false; 
        paramInt1 = paramParcel1.readInt();
        IBinder iBinder = paramParcel1.readStrongBinder();
        zzj zzj = (zzj)c.a(paramParcel1, zzj.CREATOR);
        c.b(paramParcel1);
        y1(paramInt1, iBinder, zzj);
      } else {
        paramInt1 = paramParcel1.readInt();
        Bundle bundle = (Bundle)c.a(paramParcel1, Bundle.CREATOR);
        c.b(paramParcel1);
        t5(paramInt1, bundle);
      } 
    } else {
      paramInt1 = paramParcel1.readInt();
      IBinder iBinder = paramParcel1.readStrongBinder();
      Bundle bundle = (Bundle)c.a(paramParcel1, Bundle.CREATOR);
      c.b(paramParcel1);
      q8(paramInt1, iBinder, bundle);
    } 
    paramParcel2.writeNoException();
    return true;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */