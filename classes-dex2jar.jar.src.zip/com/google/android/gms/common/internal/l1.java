package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.IBinder;
import android.os.Parcel;
import r1.a;
import r1.c;

public final class l1 extends a implements h {
  public l1(IBinder paramIBinder) {
    super(paramIBinder, "com.google.android.gms.common.internal.IAccountAccessor");
  }
  
  public final Account i6() {
    Parcel parcel = v(2, N());
    Account account = (Account)c.a(parcel, Account.CREATOR);
    parcel.recycle();
    return account;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */