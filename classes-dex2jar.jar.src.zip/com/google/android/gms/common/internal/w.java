package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.l;
import com.google.android.gms.common.o;
import f.g;
import f1.b;
import j1.i;
import java.util.Locale;
import l.b;
import l1.e;

public abstract class w {
  public static final g a = new g();
  
  public static Locale b;
  
  public static String a(Context paramContext) {
    String str = paramContext.getPackageName();
    try {
      return e.a(paramContext).d(str).toString();
    } catch (android.content.pm.PackageManager.NameNotFoundException|NullPointerException nameNotFoundException) {
      String str1 = (paramContext.getApplicationInfo()).name;
      return TextUtils.isEmpty(str1) ? str : str1;
    } 
  }
  
  public static String b(Context paramContext) {
    return paramContext.getResources().getString(b.common_google_play_services_notification_channel_name);
  }
  
  public static String c(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 3) {
          paramInt = 17039370;
          return resources.getString(paramInt);
        } 
        paramInt = b.common_google_play_services_enable_button;
        return resources.getString(paramInt);
      } 
      paramInt = b.common_google_play_services_update_button;
      return resources.getString(paramInt);
    } 
    paramInt = b.common_google_play_services_install_button;
    return resources.getString(paramInt);
  }
  
  public static String d(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    String str = a(paramContext);
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 5) {
            if (paramInt != 7) {
              if (paramInt != 9) {
                if (paramInt != 20) {
                  switch (paramInt) {
                    default:
                      return resources.getString(o.common_google_play_services_unknown_issue, new Object[] { str });
                    case 18:
                      return resources.getString(b.common_google_play_services_updating_text, new Object[] { str });
                    case 17:
                      return h(paramContext, "common_google_play_services_sign_in_failed_text", str);
                    case 16:
                      break;
                  } 
                  return h(paramContext, "common_google_play_services_api_unavailable_text", str);
                } 
                return h(paramContext, "common_google_play_services_restricted_profile_text", str);
              } 
              return resources.getString(b.common_google_play_services_unsupported_text, new Object[] { str });
            } 
            return h(paramContext, "common_google_play_services_network_error_text", str);
          } 
          return h(paramContext, "common_google_play_services_invalid_account_text", str);
        } 
        return resources.getString(b.common_google_play_services_enable_text, new Object[] { str });
      } 
      return i.f(paramContext) ? resources.getString(b.common_google_play_services_wear_update_text) : resources.getString(b.common_google_play_services_update_text, new Object[] { str });
    } 
    return resources.getString(b.common_google_play_services_install_text, new Object[] { str });
  }
  
  public static String e(Context paramContext, int paramInt) {
    return (paramInt == 6 || paramInt == 19) ? h(paramContext, "common_google_play_services_resolution_required_text", a(paramContext)) : d(paramContext, paramInt);
  }
  
  public static String f(Context paramContext, int paramInt) {
    String str;
    if (paramInt == 6) {
      str = i(paramContext, "common_google_play_services_resolution_required_title");
    } else {
      str = g(paramContext, paramInt);
    } 
    return (str == null) ? paramContext.getResources().getString(b.common_google_play_services_notification_ticker) : str;
  }
  
  public static String g(Context paramContext, int paramInt) {
    StringBuilder stringBuilder;
    String str;
    Resources resources = paramContext.getResources();
    switch (paramInt) {
      default:
        stringBuilder = new StringBuilder(33);
        stringBuilder.append("Unexpected error code ");
        stringBuilder.append(paramInt);
        str = stringBuilder.toString();
        Log.e("GoogleApiAvailability", str);
        return null;
      case 20:
        Log.e("GoogleApiAvailability", "The current user profile is restricted and could not use authenticated features.");
        return i((Context)str, "common_google_play_services_restricted_profile_title");
      case 17:
        Log.e("GoogleApiAvailability", "The specified account could not be signed in.");
        return i((Context)str, "common_google_play_services_sign_in_failed_title");
      case 16:
        str = "One of the API components you attempted to connect to is not available.";
        Log.e("GoogleApiAvailability", str);
        return null;
      case 11:
        str = "The application is not licensed to the user.";
        Log.e("GoogleApiAvailability", str);
        return null;
      case 10:
        str = "Developer error occurred. Please see logs for detailed information";
        Log.e("GoogleApiAvailability", str);
        return null;
      case 9:
        str = "Google Play services is invalid. Cannot recover.";
        Log.e("GoogleApiAvailability", str);
        return null;
      case 8:
        str = "Internal error occurred. Please see logs for detailed information";
        Log.e("GoogleApiAvailability", str);
        return null;
      case 7:
        Log.e("GoogleApiAvailability", "Network error occurred. Please retry request later.");
        return i((Context)str, "common_google_play_services_network_error_title");
      case 5:
        Log.e("GoogleApiAvailability", "An invalid account was specified when connecting. Please provide a valid account.");
        return i((Context)str, "common_google_play_services_invalid_account_title");
      case 4:
      case 6:
      case 18:
        return null;
      case 3:
        return resources.getString(b.common_google_play_services_enable_title);
      case 2:
        return resources.getString(b.common_google_play_services_update_title);
      case 1:
        break;
    } 
    return resources.getString(b.common_google_play_services_install_title);
  }
  
  public static String h(Context paramContext, String paramString1, String paramString2) {
    Resources resources = paramContext.getResources();
    paramString1 = i(paramContext, paramString1);
    String str = paramString1;
    if (paramString1 == null)
      str = resources.getString(o.common_google_play_services_unknown_issue); 
    return String.format((resources.getConfiguration()).locale, str, new Object[] { paramString2 });
  }
  
  public static String i(Context paramContext, String paramString) {
    synchronized (a) {
      Locale locale = b.a(paramContext.getResources().getConfiguration()).c(0);
      if (!locale.equals(b)) {
        null.clear();
        b = locale;
      } 
      String str2 = (String)null.get(paramString);
      if (str2 != null)
        return str2; 
      Resources resources = l.d(paramContext);
      if (resources == null)
        return null; 
      int i = resources.getIdentifier(paramString, "string", "com.google.android.gms");
      if (i == 0) {
        if (paramString.length() != 0) {
          str1 = "Missing resource: ".concat(paramString);
        } else {
          str1 = new String("Missing resource: ");
        } 
        Log.w("GoogleApiAvailability", str1);
        return null;
      } 
      String str1 = str1.getString(i);
      if (TextUtils.isEmpty(str1)) {
        if (paramString.length() != 0) {
          str1 = "Got empty resource: ".concat(paramString);
        } else {
          str1 = new String("Got empty resource: ");
        } 
        Log.w("GoogleApiAvailability", str1);
        return null;
      } 
      null.put(paramString, str1);
      return str1;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */