package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;

public abstract class a extends h.a {
  public static Account O(h paramh) {
    RemoteException remoteException1;
    Account account = null;
    RemoteException remoteException2 = null;
    if (paramh != null) {
      long l = Binder.clearCallingIdentity();
      try {
        Account account1 = paramh.i6();
        Binder.restoreCallingIdentity(l);
        account = account1;
      } catch (RemoteException remoteException) {
        Log.w("AccountAccessor", "Remote account accessor probably died");
        remoteException = remoteException2;
        Binder.restoreCallingIdentity(l);
        remoteException1 = remoteException;
      } finally {}
    } 
    return (Account)remoteException1;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */