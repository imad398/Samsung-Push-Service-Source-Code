package com.google.android.gms.common.internal;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import j1.w;

public abstract class m {
  public static void a(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException();
  }
  
  public static void b(boolean paramBoolean, Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException(String.valueOf(paramObject));
  }
  
  public static void c(Handler paramHandler) {
    Looper looper = Looper.myLooper();
    if (looper != paramHandler.getLooper()) {
      String str2;
      if (looper != null) {
        str2 = looper.getThread().getName();
      } else {
        str2 = "null current looper";
      } 
      String str1 = paramHandler.getLooper().getThread().getName();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Must be called on ");
      stringBuilder.append(str1);
      stringBuilder.append(" thread, but got ");
      stringBuilder.append(str2);
      stringBuilder.append(".");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public static void d(String paramString) {
    if (w.a())
      return; 
    throw new IllegalStateException(paramString);
  }
  
  public static String e(String paramString) {
    if (!TextUtils.isEmpty(paramString))
      return paramString; 
    throw new IllegalArgumentException("Given String is empty or null");
  }
  
  public static String f(String paramString, Object paramObject) {
    if (!TextUtils.isEmpty(paramString))
      return paramString; 
    throw new IllegalArgumentException(String.valueOf(paramObject));
  }
  
  public static void g() {
    h("Must not be called on the main application thread");
  }
  
  public static void h(String paramString) {
    if (!w.a())
      return; 
    throw new IllegalStateException(paramString);
  }
  
  public static Object i(Object paramObject) {
    if (paramObject != null)
      return paramObject; 
    throw new NullPointerException("null reference");
  }
  
  public static Object j(Object paramObject1, Object paramObject2) {
    if (paramObject1 != null)
      return paramObject1; 
    throw new NullPointerException(String.valueOf(paramObject2));
  }
  
  public static void k(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException();
  }
  
  public static void l(boolean paramBoolean, Object paramObject) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(String.valueOf(paramObject));
  }
  
  public static void m(boolean paramBoolean, String paramString, Object... paramVarArgs) {
    if (paramBoolean)
      return; 
    throw new IllegalStateException(String.format(paramString, paramVarArgs));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */