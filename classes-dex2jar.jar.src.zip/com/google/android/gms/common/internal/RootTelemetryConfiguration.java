package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class RootTelemetryConfiguration extends AbstractSafeParcelable {
  public static final Parcelable.Creator<RootTelemetryConfiguration> CREATOR = new p0();
  
  private final int zza;
  
  private final boolean zzb;
  
  private final boolean zzc;
  
  private final int zzd;
  
  private final int zze;
  
  public RootTelemetryConfiguration(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3) {
    this.zza = paramInt1;
    this.zzb = paramBoolean1;
    this.zzc = paramBoolean2;
    this.zzd = paramInt2;
    this.zze = paramInt3;
  }
  
  public boolean R() {
    return this.zzb;
  }
  
  public boolean S() {
    return this.zzc;
  }
  
  public int T() {
    return this.zza;
  }
  
  public int q() {
    return this.zzd;
  }
  
  public int v() {
    return this.zze;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, T());
    b.c(paramParcel, 2, R());
    b.c(paramParcel, 3, S());
    b.i(paramParcel, 4, q());
    b.i(paramParcel, 5, v());
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/RootTelemetryConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */