package com.google.android.gms.common.internal;

import android.content.Context;
import android.util.SparseIntArray;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.j;

public final class c0 {
  public final SparseIntArray a = new SparseIntArray();
  
  public j b;
  
  public c0(j paramj) {
    m.i(paramj);
    this.b = paramj;
  }
  
  public final int a(Context paramContext, int paramInt) {
    return this.a.get(paramInt, -1);
  }
  
  public final int b(Context paramContext, a.f paramf) {
    m.i(paramContext);
    m.i(paramf);
    boolean bool = paramf.g();
    boolean bool1 = false;
    if (!bool)
      return 0; 
    int i = paramf.i();
    int k = a(paramContext, i);
    if (k == -1) {
      k = 0;
      while (true) {
        if (k < this.a.size()) {
          int m = this.a.keyAt(k);
          if (m > i && this.a.get(m) == 0) {
            k = bool1;
            break;
          } 
          k++;
          continue;
        } 
        k = -1;
        break;
      } 
      if (k == -1)
        k = this.b.h(paramContext, i); 
      this.a.put(i, k);
    } 
    return k;
  }
  
  public final void c() {
    this.a.clear();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */