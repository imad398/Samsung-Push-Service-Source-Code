package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class ClientIdentity extends AbstractSafeParcelable {
  public static final Parcelable.Creator<ClientIdentity> CREATOR = new s();
  
  public final String packageName;
  
  public final int uid;
  
  public ClientIdentity(int paramInt, String paramString) {
    this.uid = paramInt;
    this.packageName = paramString;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof ClientIdentity))
      return false; 
    paramObject = paramObject;
    return (((ClientIdentity)paramObject).uid == this.uid && k.a(((ClientIdentity)paramObject).packageName, this.packageName));
  }
  
  public final int hashCode() {
    return this.uid;
  }
  
  public final String toString() {
    int i = this.uid;
    String str = this.packageName;
    StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 12);
    stringBuilder.append(i);
    stringBuilder.append(":");
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.uid);
    b.o(paramParcel, 2, this.packageName, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/ClientIdentity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */