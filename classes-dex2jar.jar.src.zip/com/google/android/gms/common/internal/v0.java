package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;

public final class v0 extends k0 {
  public final IBinder g;
  
  public v0(d paramd, int paramInt, IBinder paramIBinder, Bundle paramBundle) {
    super(paramd, paramInt, paramBundle);
    this.g = paramIBinder;
  }
  
  public final void f(ConnectionResult paramConnectionResult) {
    if (d.V(this.h) != null)
      d.V(this.h).N(paramConnectionResult); 
    this.h.L(paramConnectionResult);
  }
  
  public final boolean g() {
    String str;
    try {
      IBinder iBinder = this.g;
      m.i(iBinder);
      String str1 = iBinder.getInterfaceDescriptor();
      if (!this.h.E().equals(str1)) {
        String str2 = this.h.E();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("service descriptor mismatch: ");
        stringBuilder.append(str2);
        stringBuilder.append(" vs. ");
        stringBuilder.append(str1);
        str1 = stringBuilder.toString();
        Log.w("GmsClient", str1);
        return false;
      } 
      IInterface iInterface = this.h.s(this.g);
      if (iInterface != null && (d.g0(this.h, 2, 4, iInterface) || d.g0(this.h, 3, 4, iInterface))) {
        d.Z(this.h, null);
        Bundle bundle = this.h.x();
        d d1 = this.h;
        if (d.U(d1) != null)
          d.U(d1).O(bundle); 
        return true;
      } 
      return false;
    } catch (RemoteException remoteException) {
      str = "service probably died";
    } 
    Log.w("GmsClient", str);
    return false;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */