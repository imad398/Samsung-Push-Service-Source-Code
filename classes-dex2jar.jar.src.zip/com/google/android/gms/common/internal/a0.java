package com.google.android.gms.common.internal;

import android.os.Bundle;
import g1.e;

public final class a0 implements d.a {
  public a0(e parame) {}
  
  public final void O(Bundle paramBundle) {
    this.a.O(paramBundle);
  }
  
  public final void v(int paramInt) {
    this.a.v(paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */