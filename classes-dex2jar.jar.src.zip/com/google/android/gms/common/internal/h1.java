package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.google.android.gms.common.stats.b;
import java.util.HashMap;
import java.util.concurrent.Executor;
import r1.e;

public final class h1 extends g {
  public final HashMap f = new HashMap<Object, Object>();
  
  public final Context g;
  
  public volatile Handler h;
  
  public final g1 i;
  
  public final b j;
  
  public final long k;
  
  public final long l;
  
  public h1(Context paramContext, Looper paramLooper) {
    g1 g11 = new g1(this, null);
    this.i = g11;
    this.g = paramContext.getApplicationContext();
    this.h = (Handler)new e(paramLooper, g11);
    this.j = b.b();
    this.k = 5000L;
    this.l = 300000L;
  }
  
  public final void d(c1 paramc1, ServiceConnection paramServiceConnection, String paramString) {
    m.j(paramServiceConnection, "ServiceConnection must not be null");
    synchronized (this.f) {
      StringBuilder stringBuilder1;
      e1 e1 = (e1)this.f.get(paramc1);
      if (e1 != null) {
        Message message;
        if (e1.h(paramServiceConnection)) {
          e1.f(paramServiceConnection, paramString);
          if (e1.i()) {
            message = this.h.obtainMessage(0, paramc1);
            this.h.sendMessageDelayed(message, this.k);
          } 
          return;
        } 
        IllegalStateException illegalStateException1 = new IllegalStateException();
        paramString = message.toString();
        stringBuilder1 = new StringBuilder();
        this();
        stringBuilder1.append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=");
        stringBuilder1.append(paramString);
        this(stringBuilder1.toString());
        throw illegalStateException1;
      } 
      IllegalStateException illegalStateException = new IllegalStateException();
      String str = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      this();
      stringBuilder2.append("Nonexistent connection status for service config: ");
      stringBuilder2.append(str);
      this(stringBuilder2.toString());
      throw illegalStateException;
    } 
  }
  
  public final boolean f(c1 paramc1, ServiceConnection paramServiceConnection, String paramString, Executor paramExecutor) {
    m.j(paramServiceConnection, "ServiceConnection must not be null");
    synchronized (this.f) {
      e1 e11;
      StringBuilder stringBuilder;
      e1 e12 = (e1)this.f.get(paramc1);
      if (e12 == null) {
        e12 = new e1();
        this(this, paramc1);
        e12.d(paramServiceConnection, paramServiceConnection, paramString);
        e12.e(paramString, paramExecutor);
        this.f.put(paramc1, e12);
        e11 = e12;
      } else {
        this.h.removeMessages(0, e11);
        if (!e12.h(paramServiceConnection)) {
          e12.d(paramServiceConnection, paramServiceConnection, paramString);
          int i = e12.a();
          if (i != 1) {
            if (i != 2) {
              e11 = e12;
            } else {
              e12.e(paramString, paramExecutor);
              e11 = e12;
            } 
          } else {
            paramServiceConnection.onServiceConnected(e12.b(), e12.c());
            e11 = e12;
          } 
          return e11.j();
        } 
        IllegalStateException illegalStateException = new IllegalStateException();
        paramString = e11.toString();
        stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("Trying to bind a GmsServiceConnection that was already connected before.  config=");
        stringBuilder.append(paramString);
        this(stringBuilder.toString());
        throw illegalStateException;
      } 
      return stringBuilder.j();
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */