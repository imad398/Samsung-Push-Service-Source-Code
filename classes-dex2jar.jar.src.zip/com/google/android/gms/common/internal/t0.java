package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

public final class t0 extends l0 {
  public d a;
  
  public final int b;
  
  public t0(d paramd, int paramInt) {
    this.a = paramd;
    this.b = paramInt;
  }
  
  public final void q8(int paramInt, IBinder paramIBinder, Bundle paramBundle) {
    m.j(this.a, "onPostInitComplete can be called only once per call to getRemoteService");
    this.a.N(paramInt, paramIBinder, paramBundle, this.b);
    this.a = null;
  }
  
  public final void t5(int paramInt, Bundle paramBundle) {
    Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
  }
  
  public final void y1(int paramInt, IBinder paramIBinder, zzj paramzzj) {
    d d1 = this.a;
    m.j(d1, "onPostInitCompleteWithConnectionInfo can be called only once per call togetRemoteService");
    m.i(paramzzj);
    d.c0(d1, paramzzj);
    q8(paramInt, paramIBinder, paramzzj.zza);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */