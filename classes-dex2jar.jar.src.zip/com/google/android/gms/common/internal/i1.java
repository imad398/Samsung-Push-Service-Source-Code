package com.google.android.gms.common.internal;

public interface i1 {}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */