package com.google.android.gms.common.internal;

public abstract class s0 {
  public Object a;
  
  public boolean b;
  
  public s0(d paramd, Object paramObject) {
    this.a = paramObject;
    this.b = false;
  }
  
  public abstract void a(Object paramObject);
  
  public abstract void b();
  
  public final void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/lang/Object;
    //   6: astore_1
    //   7: aload_0
    //   8: getfield b : Z
    //   11: ifeq -> 57
    //   14: aload_0
    //   15: invokevirtual toString : ()Ljava/lang/String;
    //   18: astore_2
    //   19: new java/lang/StringBuilder
    //   22: astore_3
    //   23: aload_3
    //   24: invokespecial <init> : ()V
    //   27: aload_3
    //   28: ldc 'Callback proxy '
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: pop
    //   34: aload_3
    //   35: aload_2
    //   36: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: pop
    //   40: aload_3
    //   41: ldc ' being reused. This is not safe.'
    //   43: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: pop
    //   47: ldc 'GmsClient'
    //   49: aload_3
    //   50: invokevirtual toString : ()Ljava/lang/String;
    //   53: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   56: pop
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: ifnull -> 68
    //   63: aload_0
    //   64: aload_1
    //   65: invokevirtual a : (Ljava/lang/Object;)V
    //   68: aload_0
    //   69: monitorenter
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield b : Z
    //   75: aload_0
    //   76: monitorexit
    //   77: aload_0
    //   78: invokevirtual e : ()V
    //   81: return
    //   82: astore_3
    //   83: aload_0
    //   84: monitorexit
    //   85: aload_3
    //   86: athrow
    //   87: astore_3
    //   88: aload_0
    //   89: monitorexit
    //   90: aload_3
    //   91: athrow
    // Exception table:
    //   from	to	target	type
    //   2	57	87	finally
    //   57	59	87	finally
    //   70	77	82	finally
    //   83	85	82	finally
    //   88	90	87	finally
  }
  
  public final void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aconst_null
    //   4: putfield a : Ljava/lang/Object;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	10	finally
    //   11	13	10	finally
  }
  
  public final void e() {
    d();
    synchronized (d.Y(this.c)) {
      d.Y(this.c).remove(this);
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */