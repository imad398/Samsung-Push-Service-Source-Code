package com.google.android.gms.common.internal;

public final class n {
  public static n b;
  
  public static final RootTelemetryConfiguration c = new RootTelemetryConfiguration(0, false, false, 0, 0);
  
  public RootTelemetryConfiguration a;
  
  public static n b() {
    // Byte code:
    //   0: ldc com/google/android/gms/common/internal/n
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/common/internal/n.b : Lcom/google/android/gms/common/internal/n;
    //   6: ifnonnull -> 21
    //   9: new com/google/android/gms/common/internal/n
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic com/google/android/gms/common/internal/n.b : Lcom/google/android/gms/common/internal/n;
    //   21: getstatic com/google/android/gms/common/internal/n.b : Lcom/google/android/gms/common/internal/n;
    //   24: astore_0
    //   25: ldc com/google/android/gms/common/internal/n
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc com/google/android/gms/common/internal/n
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  public RootTelemetryConfiguration a() {
    return this.a;
  }
  
  public final void c(RootTelemetryConfiguration paramRootTelemetryConfiguration) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 16
    //   6: aload_0
    //   7: getstatic com/google/android/gms/common/internal/n.c : Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    //   10: putfield a : Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: aload_0
    //   17: getfield a : Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    //   20: astore_2
    //   21: aload_2
    //   22: ifnull -> 48
    //   25: aload_2
    //   26: invokevirtual T : ()I
    //   29: istore_3
    //   30: aload_1
    //   31: invokevirtual T : ()I
    //   34: istore #4
    //   36: iload_3
    //   37: iload #4
    //   39: if_icmpge -> 45
    //   42: goto -> 48
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: aload_0
    //   49: aload_1
    //   50: putfield a : Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: astore_1
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   6	13	56	finally
    //   16	21	56	finally
    //   25	36	56	finally
    //   48	53	56	finally
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */