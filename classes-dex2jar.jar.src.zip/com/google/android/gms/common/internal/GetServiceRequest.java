package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class GetServiceRequest extends AbstractSafeParcelable {
  public static final Parcelable.Creator<GetServiceRequest> CREATOR = new b1();
  
  static final Scope[] zza = new Scope[0];
  
  static final Feature[] zzb = new Feature[0];
  
  final int zzc;
  
  final int zzd;
  
  int zze;
  
  String zzf;
  
  IBinder zzg;
  
  Scope[] zzh;
  
  Bundle zzi;
  
  Account zzj;
  
  Feature[] zzk;
  
  Feature[] zzl;
  
  boolean zzm;
  
  int zzn;
  
  boolean zzo;
  
  private String zzp;
  
  public GetServiceRequest(int paramInt1, int paramInt2, int paramInt3, String paramString1, IBinder paramIBinder, Scope[] paramArrayOfScope, Bundle paramBundle, Account paramAccount, Feature[] paramArrayOfFeature1, Feature[] paramArrayOfFeature2, boolean paramBoolean1, int paramInt4, boolean paramBoolean2, String paramString2) {
    Scope[] arrayOfScope = paramArrayOfScope;
    if (paramArrayOfScope == null)
      arrayOfScope = zza; 
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    Feature[] arrayOfFeature = paramArrayOfFeature1;
    if (paramArrayOfFeature1 == null)
      arrayOfFeature = zzb; 
    paramArrayOfFeature1 = paramArrayOfFeature2;
    if (paramArrayOfFeature2 == null)
      paramArrayOfFeature1 = zzb; 
    this.zzc = paramInt1;
    this.zzd = paramInt2;
    this.zze = paramInt3;
    if ("com.google.android.gms".equals(paramString1)) {
      this.zzf = "com.google.android.gms";
    } else {
      this.zzf = paramString1;
    } 
    if (paramInt1 < 2) {
      if (paramIBinder != null) {
        Account account = a.O(h.a.N(paramIBinder));
      } else {
        paramString1 = null;
      } 
      this.zzj = (Account)paramString1;
    } else {
      this.zzg = paramIBinder;
      this.zzj = paramAccount;
    } 
    this.zzh = arrayOfScope;
    this.zzi = bundle;
    this.zzk = arrayOfFeature;
    this.zzl = paramArrayOfFeature1;
    this.zzm = paramBoolean1;
    this.zzn = paramInt4;
    this.zzo = paramBoolean2;
    this.zzp = paramString2;
  }
  
  public final String q() {
    return this.zzp;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    b1.a(this, paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/GetServiceRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */