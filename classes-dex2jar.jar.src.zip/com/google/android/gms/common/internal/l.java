package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.f;
import com.google.android.gms.common.api.i;
import z1.i;
import z1.j;

public abstract class l {
  public static final g0 a = new e0();
  
  public static i a(f paramf, a parama) {
    g0 g01 = a;
    j j = new j();
    paramf.b(new f0(paramf, j, parama, g01));
    return j.a();
  }
  
  public static interface a {
    Object a(i param1i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */