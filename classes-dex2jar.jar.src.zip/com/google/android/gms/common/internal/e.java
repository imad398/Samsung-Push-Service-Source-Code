package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.view.View;
import f.b;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class e {
  public final Account a;
  
  public final Set b;
  
  public final Set c;
  
  public final Map d;
  
  public final int e;
  
  public final View f;
  
  public final String g;
  
  public final String h;
  
  public final x1.a i;
  
  public Integer j;
  
  public e(Account paramAccount, Set<?> paramSet, Map<?, ?> paramMap, int paramInt, View paramView, String paramString1, String paramString2, x1.a parama, boolean paramBoolean) {
    this.a = paramAccount;
    if (paramSet == null) {
      set = Collections.emptySet();
    } else {
      set = Collections.unmodifiableSet(paramSet);
    } 
    this.b = set;
    Map<?, ?> map = paramMap;
    if (paramMap == null)
      map = Collections.emptyMap(); 
    this.d = map;
    this.f = paramView;
    this.e = paramInt;
    this.g = paramString1;
    this.h = paramString2;
    x1.a a1 = parama;
    if (parama == null)
      a1 = x1.a.j; 
    this.i = a1;
    Set<?> set = new HashSet(set);
    Iterator iterator = map.values().iterator();
    if (!iterator.hasNext()) {
      this.c = Collections.unmodifiableSet(set);
      return;
    } 
    android.support.v4.media.a.a(iterator.next());
    throw null;
  }
  
  public Account a() {
    return this.a;
  }
  
  public Account b() {
    Account account = this.a;
    return (account != null) ? account : new Account("<<default account>>", "com.google");
  }
  
  public Set c() {
    return this.c;
  }
  
  public String d() {
    return this.g;
  }
  
  public Set e() {
    return this.b;
  }
  
  public final x1.a f() {
    return this.i;
  }
  
  public final Integer g() {
    return this.j;
  }
  
  public final String h() {
    return this.h;
  }
  
  public final void i(Integer paramInteger) {
    this.j = paramInteger;
  }
  
  public static final class a {
    public Account a;
    
    public b b;
    
    public String c;
    
    public String d;
    
    public x1.a e = x1.a.j;
    
    public e a() {
      return new e(this.a, (Set)this.b, null, 0, null, this.c, this.d, this.e, false);
    }
    
    public a b(String param1String) {
      this.c = param1String;
      return this;
    }
    
    public final a c(Collection param1Collection) {
      if (this.b == null)
        this.b = new b(); 
      this.b.addAll(param1Collection);
      return this;
    }
    
    public final a d(Account param1Account) {
      this.a = param1Account;
      return this;
    }
    
    public final a e(String param1String) {
      this.d = param1String;
      return this;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */