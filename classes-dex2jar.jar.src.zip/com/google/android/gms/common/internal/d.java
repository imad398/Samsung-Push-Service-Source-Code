package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.j;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class d {
  public static final String[] D;
  
  public static final Feature[] E = new Feature[0];
  
  public boolean A = false;
  
  public volatile zzj B = null;
  
  public AtomicInteger C = new AtomicInteger(0);
  
  public int a;
  
  public long b;
  
  public long c;
  
  public int d;
  
  public long e;
  
  public volatile String f = null;
  
  public k1 g;
  
  public final Context h;
  
  public final Looper i;
  
  public final g j;
  
  public final j k;
  
  public final Handler l;
  
  public final Object m = new Object();
  
  public final Object n = new Object();
  
  public j o;
  
  public c p;
  
  public IInterface q;
  
  public final ArrayList r = new ArrayList();
  
  public u0 s;
  
  public int t = 1;
  
  public final a u;
  
  public final b v;
  
  public final int w;
  
  public final String x;
  
  public volatile String y;
  
  public ConnectionResult z = null;
  
  static {
    D = new String[] { "service_esmobile", "service_googleme" };
  }
  
  public d(Context paramContext, Looper paramLooper, int paramInt, a parama, b paramb, String paramString) {
    this(paramContext, paramLooper, g1, j1, paramInt, parama, paramb, paramString);
  }
  
  public d(Context paramContext, Looper paramLooper, g paramg, j paramj, int paramInt, a parama, b paramb, String paramString) {
    m.j(paramContext, "Context must not be null");
    this.h = paramContext;
    m.j(paramLooper, "Looper must not be null");
    this.i = paramLooper;
    m.j(paramg, "Supervisor must not be null");
    this.j = paramg;
    m.j(paramj, "API availability must not be null");
    this.k = paramj;
    this.l = (Handler)new r0(this, paramLooper);
    this.w = paramInt;
    this.u = parama;
    this.v = paramb;
    this.x = paramString;
  }
  
  public Bundle A() {
    return new Bundle();
  }
  
  public String B() {
    return null;
  }
  
  public Set C() {
    return Collections.emptySet();
  }
  
  public final IInterface D() {
    synchronized (this.m) {
      if (this.t != 5) {
        r();
        IInterface iInterface = this.q;
        m.j(iInterface, "Client is connected but service is null");
        return iInterface;
      } 
      DeadObjectException deadObjectException = new DeadObjectException();
      this();
      throw deadObjectException;
    } 
  }
  
  public abstract String E();
  
  public abstract String F();
  
  public String G() {
    return "com.google.android.gms";
  }
  
  public ConnectionTelemetryConfiguration H() {
    zzj zzj1 = this.B;
    return (zzj1 == null) ? null : zzj1.zzd;
  }
  
  public boolean I() {
    return (i() >= 211700000);
  }
  
  public boolean J() {
    return (this.B != null);
  }
  
  public void K(IInterface paramIInterface) {
    this.c = System.currentTimeMillis();
  }
  
  public void L(ConnectionResult paramConnectionResult) {
    this.d = paramConnectionResult.q();
    this.e = System.currentTimeMillis();
  }
  
  public void M(int paramInt) {
    this.a = paramInt;
    this.b = System.currentTimeMillis();
  }
  
  public void N(int paramInt1, IBinder paramIBinder, Bundle paramBundle, int paramInt2) {
    Handler handler = this.l;
    handler.sendMessage(handler.obtainMessage(1, paramInt2, -1, new v0(this, paramInt1, paramIBinder, paramBundle)));
  }
  
  public boolean O() {
    return false;
  }
  
  public void P(String paramString) {
    this.y = paramString;
  }
  
  public void Q(int paramInt) {
    Handler handler = this.l;
    handler.sendMessage(handler.obtainMessage(6, this.C.get(), paramInt));
  }
  
  public void R(c paramc, int paramInt, PendingIntent paramPendingIntent) {
    m.j(paramc, "Connection progress callbacks cannot be null.");
    this.p = paramc;
    Handler handler = this.l;
    handler.sendMessage(handler.obtainMessage(3, this.C.get(), paramInt, paramPendingIntent));
  }
  
  public boolean S() {
    return false;
  }
  
  public final String X() {
    String str1 = this.x;
    String str2 = str1;
    if (str1 == null)
      str2 = this.h.getClass().getName(); 
    return str2;
  }
  
  public void a(e parame) {
    parame.a();
  }
  
  public boolean b() {
    synchronized (this.m) {
      boolean bool;
      if (this.t == 4) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    } 
  }
  
  public void d() {
    this.C.incrementAndGet();
    synchronized (this.r) {
      int i = this.r.size();
      for (byte b1 = 0; b1 < i; b1++)
        ((s0)this.r.get(b1)).d(); 
      this.r.clear();
      synchronized (this.n) {
        this.o = null;
        i0(1, null);
        return;
      } 
    } 
  }
  
  public void e(h paramh, Set paramSet) {
    Bundle bundle1 = A();
    int i = this.w;
    String str = this.y;
    int k = j.a;
    Scope[] arrayOfScope = GetServiceRequest.zza;
    Bundle bundle2 = new Bundle();
    Feature[] arrayOfFeature = GetServiceRequest.zzb;
    GetServiceRequest getServiceRequest = new GetServiceRequest(6, i, k, null, null, arrayOfScope, bundle2, null, arrayOfFeature, arrayOfFeature, true, 0, false, str);
    getServiceRequest.zzf = this.h.getPackageName();
    getServiceRequest.zzi = bundle1;
    if (paramSet != null)
      getServiceRequest.zzh = (Scope[])paramSet.toArray((Object[])new Scope[0]); 
    if (o()) {
      Account account2 = u();
      Account account1 = account2;
      if (account2 == null)
        account1 = new Account("<<default account>>", "com.google"); 
      getServiceRequest.zzj = account1;
      if (paramh != null)
        getServiceRequest.zzg = paramh.asBinder(); 
    } else if (O()) {
      getServiceRequest.zzj = u();
    } 
    getServiceRequest.zzk = E;
    getServiceRequest.zzl = v();
    if (S())
      getServiceRequest.zzo = true; 
    try {
      synchronized (this.n) {
        j j1 = this.o;
        if (j1 != null) {
          t0 t0 = new t0();
          this(this, this.C.get());
          j1.L3(t0, getServiceRequest);
        } else {
          Log.w("GmsClient", "mServiceBroker is null, client disconnected");
        } 
        return;
      } 
    } catch (DeadObjectException deadObjectException) {
      Log.w("GmsClient", "IGmsServiceBroker.getService failed", (Throwable)deadObjectException);
      Q(3);
      return;
    } catch (SecurityException securityException) {
      throw securityException;
    } catch (RemoteException remoteException) {
      Log.w("GmsClient", "IGmsServiceBroker.getService failed", (Throwable)remoteException);
      N(8, null, null, this.C.get());
      return;
    } catch (RuntimeException runtimeException) {
      Log.w("GmsClient", "IGmsServiceBroker.getService failed", runtimeException);
      N(8, null, null, this.C.get());
      return;
    } 
  }
  
  public final void e0(int paramInt1, Bundle paramBundle, int paramInt2) {
    Handler handler = this.l;
    handler.sendMessage(handler.obtainMessage(7, paramInt2, -1, new w0(this, paramInt1, null)));
  }
  
  public void f(String paramString) {
    this.f = paramString;
    d();
  }
  
  public boolean g() {
    return true;
  }
  
  public int i() {
    return j.a;
  }
  
  public final void i0(int paramInt, IInterface paramIInterface) {
    boolean bool1;
    boolean bool2;
    boolean bool = false;
    if (paramInt != 4) {
      bool1 = false;
    } else {
      bool1 = true;
    } 
    if (paramIInterface == null) {
      bool2 = false;
    } else {
      bool2 = true;
    } 
    if (bool1 == bool2)
      bool = true; 
    m.a(bool);
    synchronized (this.m) {
      this.t = paramInt;
      this.q = paramIInterface;
      if (paramInt != 1) {
        if (paramInt != 2 && paramInt != 3) {
          if (paramInt == 4) {
            m.i(paramIInterface);
            K(paramIInterface);
          } 
        } else {
          k1 k11;
          u0 u01 = this.s;
          if (u01 != null) {
            k1 k12 = this.g;
            if (k12 != null) {
              String str2 = k12.c();
              String str1 = k12.b();
              StringBuilder stringBuilder = new StringBuilder();
              this();
              stringBuilder.append("Calling connect() while still connected, missing disconnect() for ");
              stringBuilder.append(str2);
              stringBuilder.append(" on ");
              stringBuilder.append(str1);
              Log.e("GmsClient", stringBuilder.toString());
              g g1 = this.j;
              str2 = this.g.c();
              m.i(str2);
              g1.e(str2, this.g.b(), this.g.a(), u01, X(), this.g.d());
              this.C.incrementAndGet();
            } 
          } 
          u0 u02 = new u0();
          this(this, this.C.get());
          this.s = u02;
          if (this.t == 3 && B() != null) {
            k11 = new k1();
            this(y().getPackageName(), B(), true, g.a(), false);
          } else {
            k11 = new k1(G(), F(), false, g.a(), I());
          } 
          this.g = k11;
          if (!k11.d() || i() >= 17895000) {
            g g1 = this.j;
            String str2 = this.g.c();
            m.i(str2);
            String str3 = this.g.b();
            paramInt = this.g.a();
            String str1 = X();
            bool = this.g.d();
            Executor executor = w();
            c1 c1 = new c1();
            this(str2, str3, paramInt, bool);
            if (!g1.f(c1, u02, str1, executor)) {
              String str4 = this.g.c();
              String str5 = this.g.b();
              StringBuilder stringBuilder = new StringBuilder();
              this();
              stringBuilder.append("unable to connect to service: ");
              stringBuilder.append(str4);
              stringBuilder.append(" on ");
              stringBuilder.append(str5);
              Log.w("GmsClient", stringBuilder.toString());
              e0(16, null, this.C.get());
            } 
          } else {
            IllegalStateException illegalStateException = new IllegalStateException();
            this("Internal Error, the minimum apk version of this BaseGmsClient is too low to support dynamic lookup. Start service action: ".concat(String.valueOf(this.g.c())));
            throw illegalStateException;
          } 
        } 
      } else {
        u0 u01 = this.s;
        if (u01 != null) {
          g g1 = this.j;
          String str = this.g.c();
          m.i(str);
          g1.e(str, this.g.b(), this.g.a(), u01, X(), this.g.d());
          this.s = null;
        } 
      } 
      return;
    } 
  }
  
  public boolean j() {
    synchronized (this.m) {
      int i = this.t;
      boolean bool1 = true;
      boolean bool2 = bool1;
      if (i != 2)
        if (i == 3) {
          bool2 = bool1;
        } else {
          bool2 = false;
        }  
      return bool2;
    } 
  }
  
  public final Feature[] k() {
    zzj zzj1 = this.B;
    return (zzj1 == null) ? null : zzj1.zzb;
  }
  
  public String l() {
    if (b()) {
      k1 k11 = this.g;
      if (k11 != null)
        return k11.b(); 
    } 
    throw new RuntimeException("Failed to connect when checking package");
  }
  
  public String m() {
    return this.f;
  }
  
  public void n(c paramc) {
    m.j(paramc, "Connection progress callbacks cannot be null.");
    this.p = paramc;
    i0(2, null);
  }
  
  public boolean o() {
    return false;
  }
  
  public void q() {
    int i = this.k.h(this.h, i());
    if (i != 0) {
      i0(1, null);
      R(new d(this), i, null);
      return;
    } 
    n(new d(this));
  }
  
  public final void r() {
    if (b())
      return; 
    throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
  }
  
  public abstract IInterface s(IBinder paramIBinder);
  
  public boolean t() {
    return false;
  }
  
  public Account u() {
    return null;
  }
  
  public Feature[] v() {
    return E;
  }
  
  public Executor w() {
    return null;
  }
  
  public Bundle x() {
    return null;
  }
  
  public final Context y() {
    return this.h;
  }
  
  public int z() {
    return this.w;
  }
  
  public static interface a {
    void O(Bundle param1Bundle);
    
    void v(int param1Int);
  }
  
  public static interface b {
    void N(ConnectionResult param1ConnectionResult);
  }
  
  public static interface c {
    void a(ConnectionResult param1ConnectionResult);
  }
  
  public class d implements c {
    public d(d this$0) {}
    
    public final void a(ConnectionResult param1ConnectionResult) {
      d d1;
      if (param1ConnectionResult.T()) {
        d1 = this.a;
        d1.e(null, d1.C());
        return;
      } 
      if (d.V(this.a) != null)
        d.V(this.a).N((ConnectionResult)d1); 
    }
  }
  
  public static interface e {
    void a();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */