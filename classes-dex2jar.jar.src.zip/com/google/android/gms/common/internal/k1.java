package com.google.android.gms.common.internal;

public final class k1 {
  public final String a;
  
  public final String b;
  
  public final int c;
  
  public final boolean d;
  
  public k1(String paramString1, String paramString2, boolean paramBoolean1, int paramInt, boolean paramBoolean2) {
    this.b = paramString1;
    this.a = paramString2;
    this.c = paramInt;
    this.d = paramBoolean2;
  }
  
  public final int a() {
    return this.c;
  }
  
  public final String b() {
    return this.b;
  }
  
  public final String c() {
    return this.a;
  }
  
  public final boolean d() {
    return this.d;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */