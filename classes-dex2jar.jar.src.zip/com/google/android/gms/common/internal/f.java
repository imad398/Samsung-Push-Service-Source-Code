package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.i;
import com.google.android.gms.common.j;
import g1.e;
import g1.l;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Executor;

public abstract class f extends d implements a.f {
  public final e F;
  
  public final Set G;
  
  public final Account H;
  
  public f(Context paramContext, Looper paramLooper, int paramInt, e parame, e.a parama, e.b paramb) {
    this(paramContext, paramLooper, paramInt, parame, (e)parama, (l)paramb);
  }
  
  public f(Context paramContext, Looper paramLooper, int paramInt, e parame, e parame1, l paraml) {
    this(paramContext, paramLooper, g.b(paramContext), i.m(), paramInt, parame, (e)m.i(parame1), (l)m.i(paraml));
  }
  
  public f(Context paramContext, Looper paramLooper, g paramg, i parami, int paramInt, e parame, e parame1, l paraml) {
    super(paramContext, paramLooper, paramg, (j)parami, paramInt, a0, b0, parame.h());
    a0 a0;
    b0 b0;
    this.F = parame;
    this.H = parame.a();
    this.G = k0(parame.c());
  }
  
  public final Set C() {
    return this.G;
  }
  
  public Set c() {
    Set<?> set;
    if (o()) {
      set = this.G;
    } else {
      set = Collections.emptySet();
    } 
    return set;
  }
  
  public Set j0(Set paramSet) {
    return paramSet;
  }
  
  public final Set k0(Set paramSet) {
    Set set = j0(paramSet);
    Iterator<Scope> iterator = set.iterator();
    while (iterator.hasNext()) {
      if (paramSet.contains(iterator.next()))
        continue; 
      throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
    } 
    return set;
  }
  
  public final Account u() {
    return this.H;
  }
  
  public final Executor w() {
    return null;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */