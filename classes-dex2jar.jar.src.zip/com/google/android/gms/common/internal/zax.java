package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class zax extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zax> CREATOR = new j0();
  
  final int zaa;
  
  private final int zab;
  
  private final int zac;
  
  @Deprecated
  private final Scope[] zad;
  
  public zax(int paramInt1, int paramInt2, int paramInt3, Scope[] paramArrayOfScope) {
    this.zaa = paramInt1;
    this.zab = paramInt2;
    this.zac = paramInt3;
    this.zad = paramArrayOfScope;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.i(paramParcel, 2, this.zab);
    b.i(paramParcel, 3, this.zac);
    b.r(paramParcel, 4, (Parcelable[])this.zad, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/zax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */