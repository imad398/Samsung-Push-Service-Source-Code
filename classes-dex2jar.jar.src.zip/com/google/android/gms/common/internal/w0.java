package com.google.android.gms.common.internal;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

public final class w0 extends k0 {
  public w0(d paramd, int paramInt, Bundle paramBundle) {
    super(paramd, paramInt, null);
  }
  
  public final void f(ConnectionResult paramConnectionResult) {
    if (this.g.t() && d.h0(this.g)) {
      d.d0(this.g, 16);
      return;
    } 
    this.g.p.a(paramConnectionResult);
    this.g.L(paramConnectionResult);
  }
  
  public final boolean g() {
    this.g.p.a(ConnectionResult.RESULT_SUCCESS);
    return true;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */