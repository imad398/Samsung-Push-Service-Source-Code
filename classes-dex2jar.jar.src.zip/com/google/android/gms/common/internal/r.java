package com.google.android.gms.common.internal;

import android.os.Bundle;
import com.google.android.gms.common.api.a;

public class r implements a.d {
  public static final r b = a().a();
  
  public final String a;
  
  public static a a() {
    return new a(null);
  }
  
  public final Bundle b() {
    Bundle bundle = new Bundle();
    String str = this.a;
    if (str != null)
      bundle.putString("api", str); 
    return bundle;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof r))
      return false; 
    paramObject = paramObject;
    return k.a(this.a, ((r)paramObject).a);
  }
  
  public final int hashCode() {
    return k.b(new Object[] { this.a });
  }
  
  public static class a {
    public String a;
    
    public r a() {
      return new r(this.a, null);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */