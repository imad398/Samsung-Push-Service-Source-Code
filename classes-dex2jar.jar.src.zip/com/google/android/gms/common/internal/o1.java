package com.google.android.gms.common.internal;

import android.os.IInterface;
import m1.a;

public interface o1 extends IInterface {
  int Q();
  
  a a0();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/o1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */