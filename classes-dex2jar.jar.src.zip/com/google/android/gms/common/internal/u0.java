package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;

public final class u0 implements ServiceConnection {
  public final int a;
  
  public u0(d paramd, int paramInt) {
    this.a = paramInt;
  }
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    null = this.b;
    if (paramIBinder == null) {
      d.d0(null, 16);
      return;
    } 
    synchronized (d.W(null)) {
      d d1 = this.b;
      IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.common.internal.IGmsServiceBroker");
      if (iInterface != null && iInterface instanceof j) {
        iInterface = iInterface;
      } else {
        iInterface = new m0(paramIBinder);
      } 
      d.a0(d1, (j)iInterface);
      this.b.e0(0, null, this.a);
      return;
    } 
  }
  
  public final void onServiceDisconnected(ComponentName paramComponentName) {
    synchronized (d.W(this.b)) {
      d.a0(this.b, null);
      null = this.b.l;
      null.sendMessage(null.obtainMessage(6, this.a, 1));
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */