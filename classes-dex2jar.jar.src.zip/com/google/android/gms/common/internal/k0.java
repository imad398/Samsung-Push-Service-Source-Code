package com.google.android.gms.common.internal;

import android.app.PendingIntent;
import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

public abstract class k0 extends s0 {
  public final int d;
  
  public final Bundle e;
  
  public k0(d paramd, int paramInt, Bundle paramBundle) {
    super(paramd, Boolean.TRUE);
    this.d = paramInt;
    this.e = paramBundle;
  }
  
  public final void b() {}
  
  public abstract void f(ConnectionResult paramConnectionResult);
  
  public abstract boolean g();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */