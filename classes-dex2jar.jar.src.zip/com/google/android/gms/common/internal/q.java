package com.google.android.gms.common.internal;

import z1.i;

public interface q {
  i a(TelemetryData paramTelemetryData);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */