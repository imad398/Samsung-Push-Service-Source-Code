package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import m1.a;
import r1.b;
import r1.c;

public abstract class n1 extends b implements o1 {
  public n1() {
    super("com.google.android.gms.common.internal.ICertData");
  }
  
  public static o1 N(IBinder paramIBinder) {
    IInterface iInterface = paramIBinder.queryLocalInterface("com.google.android.gms.common.internal.ICertData");
    return (iInterface instanceof o1) ? (o1)iInterface : new m1(paramIBinder);
  }
  
  public final boolean v(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2) {
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return false; 
      paramInt1 = Q();
      paramParcel2.writeNoException();
      paramParcel2.writeInt(paramInt1);
    } else {
      a a = a0();
      paramParcel2.writeNoException();
      c.d(paramParcel2, (IInterface)a);
    } 
    return true;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */