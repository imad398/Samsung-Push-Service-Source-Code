package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.h;

public abstract class b {
  public static com.google.android.gms.common.api.b a(Status paramStatus) {
    return (com.google.android.gms.common.api.b)(paramStatus.S() ? new h(paramStatus) : new com.google.android.gms.common.api.b(paramStatus));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */