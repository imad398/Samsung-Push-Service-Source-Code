package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Message;
import android.os.StrictMode;
import j1.o;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executor;

public final class e1 implements ServiceConnection, i1 {
  public final Map a;
  
  public int b;
  
  public boolean c;
  
  public IBinder d;
  
  public final c1 e;
  
  public ComponentName f;
  
  public e1(h1 paramh1, c1 paramc1) {
    this.e = paramc1;
    this.a = new HashMap<Object, Object>();
    this.b = 2;
  }
  
  public final int a() {
    return this.b;
  }
  
  public final ComponentName b() {
    return this.f;
  }
  
  public final IBinder c() {
    return this.d;
  }
  
  public final void d(ServiceConnection paramServiceConnection1, ServiceConnection paramServiceConnection2, String paramString) {
    this.a.put(paramServiceConnection1, paramServiceConnection2);
  }
  
  public final void e(String paramString, Executor paramExecutor) {
    this.b = 3;
    StrictMode.VmPolicy vmPolicy = StrictMode.getVmPolicy();
    if (o.o())
      StrictMode.setVmPolicy(d1.a(new StrictMode.VmPolicy.Builder(vmPolicy)).build()); 
    try {
      h1 h11 = this.g;
      boolean bool = h1.j(h11).d(h1.h(h11), paramString, this.e.c(h1.h(h11)), this, this.e.a(), paramExecutor);
      this.c = bool;
      if (bool) {
        Message message = h1.i(this.g).obtainMessage(1, this.e);
        h1.i(this.g).sendMessageDelayed(message, h1.g(this.g));
      } else {
        this.b = 2;
        try {
          h1 h12 = this.g;
          h1.j(h12).c(h1.h(h12), this);
        } catch (IllegalArgumentException illegalArgumentException) {}
      } 
      return;
    } finally {
      StrictMode.setVmPolicy(vmPolicy);
    } 
  }
  
  public final void f(ServiceConnection paramServiceConnection, String paramString) {
    this.a.remove(paramServiceConnection);
  }
  
  public final void g(String paramString) {
    h1.i(this.g).removeMessages(1, this.e);
    h1 h11 = this.g;
    h1.j(h11).c(h1.h(h11), this);
    this.c = false;
    this.b = 2;
  }
  
  public final boolean h(ServiceConnection paramServiceConnection) {
    return this.a.containsKey(paramServiceConnection);
  }
  
  public final boolean i() {
    return this.a.isEmpty();
  }
  
  public final boolean j() {
    return this.c;
  }
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    synchronized (h1.k(this.g)) {
      h1.i(this.g).removeMessages(1, this.e);
      this.d = paramIBinder;
      this.f = paramComponentName;
      Iterator<ServiceConnection> iterator = this.a.values().iterator();
      while (iterator.hasNext())
        ((ServiceConnection)iterator.next()).onServiceConnected(paramComponentName, paramIBinder); 
      this.b = 1;
      return;
    } 
  }
  
  public final void onServiceDisconnected(ComponentName paramComponentName) {
    synchronized (h1.k(this.g)) {
      h1.i(this.g).removeMessages(1, this.e);
      this.d = null;
      this.f = paramComponentName;
      Iterator<ServiceConnection> iterator = this.a.values().iterator();
      while (iterator.hasNext())
        ((ServiceConnection)iterator.next()).onServiceDisconnected(paramComponentName); 
      this.b = 2;
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */