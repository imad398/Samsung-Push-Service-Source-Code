package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;

public final class m0 implements j {
  public final IBinder a;
  
  public m0(IBinder paramIBinder) {
    this.a = paramIBinder;
  }
  
  public final void L3(i parami, GetServiceRequest paramGetServiceRequest) {
    Parcel parcel1 = Parcel.obtain();
    Parcel parcel2 = Parcel.obtain();
    try {
      parcel1.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
      if (parami != null) {
        IBinder iBinder = parami.asBinder();
      } else {
        parami = null;
      } 
      parcel1.writeStrongBinder((IBinder)parami);
      if (paramGetServiceRequest != null) {
        parcel1.writeInt(1);
        b1.a(paramGetServiceRequest, parcel1, 0);
      } else {
        parcel1.writeInt(0);
      } 
      this.a.transact(46, parcel1, parcel2, 0);
      parcel2.readException();
      return;
    } finally {
      parcel2.recycle();
      parcel1.recycle();
    } 
  }
  
  public final IBinder asBinder() {
    return this.a;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */