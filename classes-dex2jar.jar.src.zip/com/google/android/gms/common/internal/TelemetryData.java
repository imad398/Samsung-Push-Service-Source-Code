package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

public class TelemetryData extends AbstractSafeParcelable {
  public static final Parcelable.Creator<TelemetryData> CREATOR = new t();
  
  private final int zaa;
  
  @Nullable
  private List<MethodInvocation> zab;
  
  public TelemetryData(int paramInt, List<MethodInvocation> paramList) {
    this.zaa = paramInt;
    this.zab = paramList;
  }
  
  public final void R(MethodInvocation paramMethodInvocation) {
    if (this.zab == null)
      this.zab = new ArrayList<MethodInvocation>(); 
    this.zab.add(paramMethodInvocation);
  }
  
  public final int q() {
    return this.zaa;
  }
  
  public final List v() {
    return this.zab;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.s(paramParcel, 2, this.zab, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/TelemetryData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */