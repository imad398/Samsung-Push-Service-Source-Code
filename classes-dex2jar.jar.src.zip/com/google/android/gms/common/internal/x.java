package com.google.android.gms.common.internal;

import android.app.Activity;
import android.content.Intent;

public final class x extends z {
  public x(Intent paramIntent, Activity paramActivity, int paramInt) {}
  
  public final void a() {
    Intent intent = this.a;
    if (intent != null)
      this.b.startActivityForResult(intent, this.c); 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */