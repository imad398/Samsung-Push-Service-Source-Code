package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;

public class o {
  public final Resources a;
  
  public final String b;
  
  public o(Context paramContext) {
    m.i(paramContext);
    Resources resources = paramContext.getResources();
    this.a = resources;
    this.b = resources.getResourcePackageName(com.google.android.gms.common.o.common_google_play_services_unknown_issue);
  }
  
  public String a(String paramString) {
    int i = this.a.getIdentifier(paramString, "string", this.b);
    return (i == 0) ? null : this.a.getString(i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */