package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.ServiceConnection;
import android.os.HandlerThread;
import android.os.Looper;
import java.util.concurrent.Executor;

public abstract class g {
  public static int a = 4225;
  
  public static final Object b = new Object();
  
  public static h1 c;
  
  public static HandlerThread d;
  
  public static boolean e = false;
  
  public static int a() {
    return a;
  }
  
  public static g b(Context paramContext) {
    synchronized (b) {
      if (c == null) {
        Looper looper;
        h1 h11 = new h1();
        Context context = paramContext.getApplicationContext();
        if (e) {
          looper = c().getLooper();
        } else {
          looper = looper.getMainLooper();
        } 
        this(context, looper);
        c = h11;
      } 
      return c;
    } 
  }
  
  public static HandlerThread c() {
    synchronized (b) {
      HandlerThread handlerThread = d;
      if (handlerThread != null)
        return handlerThread; 
      handlerThread = new HandlerThread();
      this("GoogleApiHandler", 9);
      d = handlerThread;
      handlerThread.start();
      handlerThread = d;
      return handlerThread;
    } 
  }
  
  public abstract void d(c1 paramc1, ServiceConnection paramServiceConnection, String paramString);
  
  public final void e(String paramString1, String paramString2, int paramInt, ServiceConnection paramServiceConnection, String paramString3, boolean paramBoolean) {
    d(new c1(paramString1, paramString2, paramInt, paramBoolean), paramServiceConnection, paramString3);
  }
  
  public abstract boolean f(c1 paramc1, ServiceConnection paramServiceConnection, String paramString, Executor paramExecutor);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */