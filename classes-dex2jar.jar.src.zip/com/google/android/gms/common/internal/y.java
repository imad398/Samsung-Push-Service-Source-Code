package com.google.android.gms.common.internal;

import android.content.Intent;
import g1.i;

public final class y extends z {
  public y(Intent paramIntent, i parami, int paramInt) {}
  
  public final void a() {
    Intent intent = this.a;
    if (intent != null)
      this.b.startActivityForResult(intent, 2); 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */