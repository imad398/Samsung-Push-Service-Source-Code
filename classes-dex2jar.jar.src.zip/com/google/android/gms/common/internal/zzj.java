package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class zzj extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzj> CREATOR = new z0();
  
  Bundle zza;
  
  Feature[] zzb;
  
  int zzc;
  
  ConnectionTelemetryConfiguration zzd;
  
  public zzj(Bundle paramBundle, Feature[] paramArrayOfFeature, int paramInt, ConnectionTelemetryConfiguration paramConnectionTelemetryConfiguration) {
    this.zza = paramBundle;
    this.zzb = paramArrayOfFeature;
    this.zzc = paramInt;
    this.zzd = paramConnectionTelemetryConfiguration;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.d(paramParcel, 1, this.zza, false);
    b.r(paramParcel, 2, (Parcelable[])this.zzb, paramInt, false);
    b.i(paramParcel, 3, this.zzc);
    b.n(paramParcel, 4, (Parcelable)this.zzd, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/zzj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */