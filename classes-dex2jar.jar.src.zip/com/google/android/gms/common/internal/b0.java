package com.google.android.gms.common.internal;

import com.google.android.gms.common.ConnectionResult;
import g1.l;

public final class b0 implements d.b {
  public b0(l paraml) {}
  
  public final void N(ConnectionResult paramConnectionResult) {
    this.a.N(paramConnectionResult);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/internal/b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */