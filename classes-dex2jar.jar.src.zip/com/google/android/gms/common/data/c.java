package com.google.android.gms.common.data;

import com.google.android.gms.common.internal.m;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class c implements Iterator {
  public final b a;
  
  public int b;
  
  public c(b paramb) {
    this.a = (b)m.i(paramb);
    this.b = -1;
  }
  
  public final boolean hasNext() {
    return (this.b < this.a.s() - 1);
  }
  
  public Object next() {
    if (hasNext()) {
      b b1 = this.a;
      int j = this.b + 1;
      this.b = j;
      return b1.get(j);
    } 
    int i = this.b;
    StringBuilder stringBuilder = new StringBuilder(46);
    stringBuilder.append("Cannot advance the iterator beyond ");
    stringBuilder.append(i);
    throw new NoSuchElementException(stringBuilder.toString());
  }
  
  public final void remove() {
    throw new UnsupportedOperationException("Cannot remove elements from a DataBufferIterator");
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */