package com.google.android.gms.common.data;

import com.google.android.gms.common.internal.m;
import java.util.ArrayList;

public abstract class e extends a {
  public boolean b = false;
  
  public ArrayList c;
  
  public e(DataHolder paramDataHolder) {
    super(paramDataHolder);
  }
  
  public String R() {
    return null;
  }
  
  public abstract Object S(int paramInt1, int paramInt2);
  
  public abstract String T();
  
  public final int U(int paramInt) {
    if (paramInt >= 0 && paramInt < this.c.size())
      return ((Integer)this.c.get(paramInt)).intValue(); 
    StringBuilder stringBuilder = new StringBuilder(53);
    stringBuilder.append("Position ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" is out of bounds for this buffer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public final void V() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Z
    //   6: ifne -> 236
    //   9: aload_0
    //   10: getfield a : Lcom/google/android/gms/common/data/DataHolder;
    //   13: invokestatic i : (Ljava/lang/Object;)Ljava/lang/Object;
    //   16: checkcast com/google/android/gms/common/data/DataHolder
    //   19: invokevirtual s : ()I
    //   22: istore_1
    //   23: new java/util/ArrayList
    //   26: astore_2
    //   27: aload_2
    //   28: invokespecial <init> : ()V
    //   31: aload_0
    //   32: aload_2
    //   33: putfield c : Ljava/util/ArrayList;
    //   36: iload_1
    //   37: ifle -> 231
    //   40: aload_2
    //   41: iconst_0
    //   42: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   45: invokevirtual add : (Ljava/lang/Object;)Z
    //   48: pop
    //   49: aload_0
    //   50: invokevirtual T : ()Ljava/lang/String;
    //   53: astore_3
    //   54: aload_0
    //   55: getfield a : Lcom/google/android/gms/common/data/DataHolder;
    //   58: iconst_0
    //   59: invokevirtual U : (I)I
    //   62: istore #4
    //   64: aload_0
    //   65: getfield a : Lcom/google/android/gms/common/data/DataHolder;
    //   68: aload_3
    //   69: iconst_0
    //   70: iload #4
    //   72: invokevirtual T : (Ljava/lang/String;II)Ljava/lang/String;
    //   75: astore_2
    //   76: iconst_1
    //   77: istore #4
    //   79: iload #4
    //   81: iload_1
    //   82: if_icmpge -> 231
    //   85: aload_0
    //   86: getfield a : Lcom/google/android/gms/common/data/DataHolder;
    //   89: iload #4
    //   91: invokevirtual U : (I)I
    //   94: istore #5
    //   96: aload_0
    //   97: getfield a : Lcom/google/android/gms/common/data/DataHolder;
    //   100: aload_3
    //   101: iload #4
    //   103: iload #5
    //   105: invokevirtual T : (Ljava/lang/String;II)Ljava/lang/String;
    //   108: astore #6
    //   110: aload #6
    //   112: ifnull -> 153
    //   115: aload_2
    //   116: astore #7
    //   118: aload #6
    //   120: aload_2
    //   121: invokevirtual equals : (Ljava/lang/Object;)Z
    //   124: ifne -> 144
    //   127: aload_0
    //   128: getfield c : Ljava/util/ArrayList;
    //   131: iload #4
    //   133: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   136: invokevirtual add : (Ljava/lang/Object;)Z
    //   139: pop
    //   140: aload #6
    //   142: astore #7
    //   144: iinc #4, 1
    //   147: aload #7
    //   149: astore_2
    //   150: goto -> 79
    //   153: new java/lang/NullPointerException
    //   156: astore #7
    //   158: aload_3
    //   159: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   162: invokevirtual length : ()I
    //   165: istore_1
    //   166: new java/lang/StringBuilder
    //   169: astore_2
    //   170: aload_2
    //   171: iload_1
    //   172: bipush #78
    //   174: iadd
    //   175: invokespecial <init> : (I)V
    //   178: aload_2
    //   179: ldc 'Missing value for markerColumn: '
    //   181: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: pop
    //   185: aload_2
    //   186: aload_3
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: aload_2
    //   192: ldc ', at row: '
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: aload_2
    //   199: iload #4
    //   201: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   204: pop
    //   205: aload_2
    //   206: ldc ', for window: '
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: pop
    //   212: aload_2
    //   213: iload #5
    //   215: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   218: pop
    //   219: aload #7
    //   221: aload_2
    //   222: invokevirtual toString : ()Ljava/lang/String;
    //   225: invokespecial <init> : (Ljava/lang/String;)V
    //   228: aload #7
    //   230: athrow
    //   231: aload_0
    //   232: iconst_1
    //   233: putfield b : Z
    //   236: aload_0
    //   237: monitorexit
    //   238: return
    //   239: astore_2
    //   240: aload_0
    //   241: monitorexit
    //   242: aload_2
    //   243: athrow
    // Exception table:
    //   from	to	target	type
    //   2	36	239	finally
    //   40	76	239	finally
    //   85	110	239	finally
    //   118	140	239	finally
    //   153	231	239	finally
    //   231	236	239	finally
    //   236	238	239	finally
    //   240	242	239	finally
  }
  
  public final Object get(int paramInt) {
    V();
    int i = U(paramInt);
    byte b = 0;
    int j = b;
    if (paramInt >= 0)
      if (paramInt == this.c.size()) {
        j = b;
      } else {
        if (paramInt == this.c.size() - 1) {
          j = ((DataHolder)m.i(this.a)).s();
        } else {
          j = ((Integer)this.c.get(paramInt + 1)).intValue();
        } 
        j -= ((Integer)this.c.get(paramInt)).intValue();
        if (j == 1) {
          paramInt = U(paramInt);
          j = ((DataHolder)m.i(this.a)).U(paramInt);
          String str = R();
          if (str != null && this.a.T(str, paramInt, j) == null) {
            j = b;
          } else {
            j = 1;
          } 
        } 
      }  
    return S(i, j);
  }
  
  public int s() {
    V();
    return this.c.size();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */