package com.google.android.gms.common.data;

import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.m;

public abstract class d {
  public final DataHolder a;
  
  public int b;
  
  public int c;
  
  public d(DataHolder paramDataHolder, int paramInt) {
    this.a = (DataHolder)m.i(paramDataHolder);
    d(paramInt);
  }
  
  public byte[] a(String paramString) {
    return this.a.q(paramString, this.b, this.c);
  }
  
  public int b(String paramString) {
    return this.a.v(paramString, this.b, this.c);
  }
  
  public String c(String paramString) {
    return this.a.T(paramString, this.b, this.c);
  }
  
  public final void d(int paramInt) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramInt >= 0) {
      bool2 = bool1;
      if (paramInt < this.a.s())
        bool2 = true; 
    } 
    m.k(bool2);
    this.b = paramInt;
    this.c = this.a.U(paramInt);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof d) {
      paramObject = paramObject;
      if (k.a(Integer.valueOf(((d)paramObject).b), Integer.valueOf(this.b)) && k.a(Integer.valueOf(((d)paramObject).c), Integer.valueOf(this.c)) && ((d)paramObject).a == this.a)
        return true; 
    } 
    return false;
  }
  
  public int hashCode() {
    return k.b(new Object[] { Integer.valueOf(this.b), Integer.valueOf(this.c), this.a });
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */