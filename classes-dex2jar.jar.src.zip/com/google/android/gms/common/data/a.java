package com.google.android.gms.common.data;

import java.util.Iterator;

public abstract class a implements b {
  public final DataHolder a;
  
  public a(DataHolder paramDataHolder) {
    this.a = paramDataHolder;
  }
  
  public void a() {
    DataHolder dataHolder = this.a;
    if (dataHolder != null)
      dataHolder.close(); 
  }
  
  public final void close() {
    a();
  }
  
  public Iterator iterator() {
    return new c(this);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */