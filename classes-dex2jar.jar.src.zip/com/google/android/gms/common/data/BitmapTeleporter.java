package com.google.android.gms.common.data;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class BitmapTeleporter extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<BitmapTeleporter> CREATOR = new f();
  
  final int zaa;
  
  ParcelFileDescriptor zab;
  
  final int zac;
  
  private Bitmap zad;
  
  private boolean zae;
  
  private File zaf;
  
  public BitmapTeleporter(int paramInt1, ParcelFileDescriptor paramParcelFileDescriptor, int paramInt2) {
    this.zaa = paramInt1;
    this.zab = paramParcelFileDescriptor;
    this.zac = paramInt2;
    this.zad = null;
    this.zae = false;
  }
  
  public static final void q(Closeable paramCloseable) {
    try {
      paramCloseable.close();
      return;
    } catch (IOException iOException) {
      Log.w("BitmapTeleporter", "Could not close stream", iOException);
      return;
    } 
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    if (this.zab == null) {
      Bitmap bitmap = (Bitmap)m.i(this.zad);
      ByteBuffer byteBuffer = ByteBuffer.allocate(bitmap.getRowBytes() * bitmap.getHeight());
      bitmap.copyPixelsToBuffer(byteBuffer);
      byte[] arrayOfByte = byteBuffer.array();
      File file = this.zaf;
      if (file != null) {
        try {
          file = File.createTempFile("teleporter", ".tmp", file);
          try {
            FileOutputStream fileOutputStream = new FileOutputStream();
            this(file);
            this.zab = ParcelFileDescriptor.open(file, 268435456);
            file.delete();
            DataOutputStream dataOutputStream = new DataOutputStream(new BufferedOutputStream(fileOutputStream));
            try {
              dataOutputStream.writeInt(arrayOfByte.length);
              dataOutputStream.writeInt(bitmap.getWidth());
              dataOutputStream.writeInt(bitmap.getHeight());
              dataOutputStream.writeUTF(bitmap.getConfig().toString());
              dataOutputStream.write(arrayOfByte);
              q(dataOutputStream);
            } catch (IOException null) {
              IllegalStateException illegalStateException = new IllegalStateException();
              this("Could not write into unlinked file", iOException);
              throw illegalStateException;
            } finally {}
          } catch (FileNotFoundException null) {
            throw new IllegalStateException("Temporary file is somehow already deleted");
          } 
        } catch (IOException iOException) {
          throw new IllegalStateException("Could not create temporary file", iOException);
        } 
      } else {
        throw new IllegalStateException("setTempDir() must be called before writing this object to a parcel");
      } 
    } 
    int i = b.a((Parcel)iOException);
    b.i((Parcel)iOException, 1, this.zaa);
    b.n((Parcel)iOException, 2, (Parcelable)this.zab, paramInt | 0x1, false);
    b.i((Parcel)iOException, 3, this.zac);
    b.b((Parcel)iOException, i);
    this.zab = null;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/BitmapTeleporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */