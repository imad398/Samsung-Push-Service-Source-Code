package com.google.android.gms.common.data;

public final class g extends DataHolder.a {
  public g(String[] paramArrayOfString, String paramString) {
    super(paramArrayOfString, null, null);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */