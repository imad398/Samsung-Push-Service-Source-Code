package com.google.android.gms.common.data;

import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;

@KeepName
public final class DataHolder extends AbstractSafeParcelable implements Closeable {
  public static final Parcelable.Creator<DataHolder> CREATOR = new i();
  
  private static final a zaf = new g(new String[0], null);
  
  final int zaa;
  
  Bundle zab;
  
  int[] zac;
  
  int zad;
  
  boolean zae = false;
  
  private final String[] zag;
  
  private final CursorWindow[] zah;
  
  private final int zai;
  
  private final Bundle zaj;
  
  private boolean zak = true;
  
  public DataHolder(int paramInt1, String[] paramArrayOfString, CursorWindow[] paramArrayOfCursorWindow, int paramInt2, Bundle paramBundle) {
    this.zaa = paramInt1;
    this.zag = paramArrayOfString;
    this.zah = paramArrayOfCursorWindow;
    this.zai = paramInt2;
    this.zaj = paramBundle;
  }
  
  public Bundle R() {
    return this.zaj;
  }
  
  public int S() {
    return this.zai;
  }
  
  public String T(String paramString, int paramInt1, int paramInt2) {
    X(paramString, paramInt1);
    return this.zah[paramInt2].getString(paramInt1, this.zab.getInt(paramString));
  }
  
  public int U(int paramInt) {
    boolean bool;
    int i;
    int j;
    byte b = 0;
    if (paramInt >= 0 && paramInt < this.zad) {
      bool = true;
    } else {
      bool = false;
    } 
    m.k(bool);
    while (true) {
      int[] arrayOfInt = this.zac;
      i = arrayOfInt.length;
      j = b;
      if (b < i) {
        if (paramInt < arrayOfInt[b]) {
          j = b - 1;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    paramInt = j;
    if (j == i)
      paramInt = j - 1; 
    return paramInt;
  }
  
  public boolean V() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zae : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	11	finally
    //   12	14	11	finally
  }
  
  public final void W() {
    this.zab = new Bundle();
    int i = 0;
    int j = 0;
    while (true) {
      String[] arrayOfString = this.zag;
      if (j < arrayOfString.length) {
        this.zab.putInt(arrayOfString[j], j);
        j++;
        continue;
      } 
      this.zac = new int[this.zah.length];
      int k = 0;
      j = i;
      while (true) {
        CursorWindow[] arrayOfCursorWindow = this.zah;
        if (j < arrayOfCursorWindow.length) {
          this.zac[j] = k;
          i = arrayOfCursorWindow[j].getStartPosition();
          k += this.zah[j].getNumRows() - k - i;
          j++;
          continue;
        } 
        this.zad = k;
        return;
      } 
      break;
    } 
  }
  
  public final void X(String paramString, int paramInt) {
    Bundle bundle = this.zab;
    if (bundle == null || !bundle.containsKey(paramString)) {
      paramString = String.valueOf(paramString);
      if (paramString.length() != 0) {
        paramString = "No such column: ".concat(paramString);
      } else {
        paramString = new String("No such column: ");
      } 
      throw new IllegalArgumentException(paramString);
    } 
    if (!V()) {
      if (paramInt >= 0 && paramInt < this.zad)
        return; 
      throw new CursorIndexOutOfBoundsException(paramInt, this.zad);
    } 
    throw new IllegalArgumentException("Buffer is closed.");
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zae : Z
    //   6: ifne -> 39
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield zae : Z
    //   14: iconst_0
    //   15: istore_1
    //   16: aload_0
    //   17: getfield zah : [Landroid/database/CursorWindow;
    //   20: astore_2
    //   21: iload_1
    //   22: aload_2
    //   23: arraylength
    //   24: if_icmpge -> 39
    //   27: aload_2
    //   28: iload_1
    //   29: aaload
    //   30: invokevirtual close : ()V
    //   33: iinc #1, 1
    //   36: goto -> 16
    //   39: aload_0
    //   40: monitorexit
    //   41: return
    //   42: astore_2
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_2
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	42	finally
    //   16	33	42	finally
    //   39	41	42	finally
    //   43	45	42	finally
  }
  
  public final void finalize() {
    try {
      if (this.zak && this.zah.length > 0 && !V()) {
        close();
        String str = toString();
        int i = String.valueOf(str).length();
        StringBuilder stringBuilder = new StringBuilder();
        this(i + 178);
        stringBuilder.append("Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: ");
        stringBuilder.append(str);
        stringBuilder.append(")");
        Log.e("DataBuffer", stringBuilder.toString());
      } 
      return;
    } finally {
      super.finalize();
    } 
  }
  
  public byte[] q(String paramString, int paramInt1, int paramInt2) {
    X(paramString, paramInt1);
    return this.zah[paramInt2].getBlob(paramInt1, this.zab.getInt(paramString));
  }
  
  public int s() {
    return this.zad;
  }
  
  public int v(String paramString, int paramInt1, int paramInt2) {
    X(paramString, paramInt1);
    return this.zah[paramInt2].getInt(paramInt1, this.zab.getInt(paramString));
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.p(paramParcel, 1, this.zag, false);
    b.r(paramParcel, 2, (Parcelable[])this.zah, paramInt, false);
    b.i(paramParcel, 3, S());
    b.d(paramParcel, 4, R(), false);
    b.i(paramParcel, 1000, this.zaa);
    b.b(paramParcel, i);
    if ((paramInt & 0x1) != 0)
      close(); 
  }
  
  public static abstract class a {
    public final String[] a;
    
    public final ArrayList b;
    
    public final HashMap c;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/data/DataHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */