package com.google.android.gms.common.images;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.SystemClock;
import android.support.v4.media.a;
import com.google.android.gms.common.internal.c;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public final class b implements Runnable {
  public final Uri a;
  
  public final Bitmap b;
  
  public final CountDownLatch c;
  
  public b(ImageManager paramImageManager, Uri paramUri, Bitmap paramBitmap, boolean paramBoolean, CountDownLatch paramCountDownLatch) {
    this.a = paramUri;
    this.b = paramBitmap;
    this.c = paramCountDownLatch;
  }
  
  public final void run() {
    c.a("OnBitmapLoadedRunnable must be executed in the main thread");
    Bitmap bitmap = this.b;
    null = (ImageManager.ImageReceiver)ImageManager.g(null).remove(this.a);
    if (null != null) {
      ArrayList arrayList = ImageManager.ImageReceiver.a(null);
      if (arrayList.size() > 0) {
        a.a(arrayList.get(0));
        if (this.b != null && bitmap != null) {
          ImageManager.a(null);
          throw null;
        } 
        ImageManager.f(null).put(this.a, Long.valueOf(SystemClock.elapsedRealtime()));
        ImageManager.a(null);
        ImageManager.c(null);
        throw null;
      } 
    } 
    this.c.countDown();
    synchronized (ImageManager.d()) {
      ImageManager.e().remove(this.a);
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/images/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */