package com.google.android.gms.common.images;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.util.Locale;

public final class WebImage extends AbstractSafeParcelable {
  public static final Parcelable.Creator<WebImage> CREATOR = new c();
  
  final int zaa;
  
  private final Uri zab;
  
  private final int zac;
  
  private final int zad;
  
  public WebImage(int paramInt1, Uri paramUri, int paramInt2, int paramInt3) {
    this.zaa = paramInt1;
    this.zab = paramUri;
    this.zac = paramInt2;
    this.zad = paramInt3;
  }
  
  public int R() {
    return this.zac;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null && paramObject instanceof WebImage) {
      paramObject = paramObject;
      if (k.a(this.zab, ((WebImage)paramObject).zab) && this.zac == ((WebImage)paramObject).zac && this.zad == ((WebImage)paramObject).zad)
        return true; 
    } 
    return false;
  }
  
  public int hashCode() {
    return k.b(new Object[] { this.zab, Integer.valueOf(this.zac), Integer.valueOf(this.zad) });
  }
  
  public int q() {
    return this.zad;
  }
  
  public String toString() {
    return String.format(Locale.US, "Image %dx%d %s", new Object[] { Integer.valueOf(this.zac), Integer.valueOf(this.zad), this.zab.toString() });
  }
  
  public Uri v() {
    return this.zab;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.n(paramParcel, 2, (Parcelable)v(), paramInt, false);
    b.i(paramParcel, 3, R());
    b.i(paramParcel, 4, q());
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/images/WebImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */