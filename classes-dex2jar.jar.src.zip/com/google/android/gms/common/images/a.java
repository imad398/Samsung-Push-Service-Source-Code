package com.google.android.gms.common.images;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import com.google.android.gms.common.internal.c;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public final class a implements Runnable {
  public final Uri a;
  
  public final ParcelFileDescriptor b;
  
  public a(ImageManager paramImageManager, Uri paramUri, ParcelFileDescriptor paramParcelFileDescriptor) {
    this.a = paramUri;
    this.b = paramParcelFileDescriptor;
  }
  
  public final void run() {
    c.b("LoadBitmapFromDiskRunnable can't be executed in the main thread");
    ParcelFileDescriptor parcelFileDescriptor = this.b;
    boolean bool = false;
    if (parcelFileDescriptor != null) {
      try {
        Bitmap bitmap = BitmapFactory.decodeFileDescriptor(parcelFileDescriptor.getFileDescriptor());
      } catch (OutOfMemoryError outOfMemoryError) {
        Log.e("ImageManager", "OOM while loading bitmap for uri: ".concat(String.valueOf(this.a)), outOfMemoryError);
        bool = true;
        outOfMemoryError = null;
      } 
      try {
        this.b.close();
      } catch (IOException iOException) {
        Log.e("ImageManager", "closed failed", iOException);
      } 
    } else {
      bool = false;
      parcelFileDescriptor = null;
    } 
    CountDownLatch countDownLatch = new CountDownLatch(1);
    ImageManager.b(null).post(new b(null, this.a, (Bitmap)parcelFileDescriptor, bool, countDownLatch));
    try {
      countDownLatch.await();
      return;
    } catch (InterruptedException interruptedException) {
      Log.w("ImageManager", "Latch interrupted while posting ".concat(String.valueOf(this.a)));
      return;
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/images/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */