package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseArray;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse;
import h1.b;
import java.util.ArrayList;
import java.util.HashMap;

public final class StringToIntConverter extends AbstractSafeParcelable implements FastJsonResponse.a {
  public static final Parcelable.Creator<StringToIntConverter> CREATOR = new b();
  
  final int zaa;
  
  private final HashMap<String, Integer> zab;
  
  private final SparseArray<String> zac;
  
  public StringToIntConverter(int paramInt, ArrayList<zac> paramArrayList) {
    this.zaa = paramInt;
    this.zab = new HashMap<String, Integer>();
    this.zac = new SparseArray();
    int i = paramArrayList.size();
    for (paramInt = 0; paramInt < i; paramInt++) {
      zac zac = paramArrayList.get(paramInt);
      q(zac.zab, zac.zac);
    } 
  }
  
  public StringToIntConverter q(String paramString, int paramInt) {
    this.zab.put(paramString, Integer.valueOf(paramInt));
    this.zac.put(paramInt, paramString);
    return this;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    ArrayList<zac> arrayList = new ArrayList();
    for (String str : this.zab.keySet())
      arrayList.add(new zac(str, ((Integer)this.zab.get(str)).intValue())); 
    b.s(paramParcel, 2, arrayList, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/converter/StringToIntConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */