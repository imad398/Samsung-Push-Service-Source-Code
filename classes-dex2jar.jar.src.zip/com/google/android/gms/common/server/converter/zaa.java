package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.response.FastJsonResponse;
import h1.b;

public final class zaa extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zaa> CREATOR = new a();
  
  final int zaa;
  
  private final StringToIntConverter zab;
  
  public zaa(int paramInt, StringToIntConverter paramStringToIntConverter) {
    this.zaa = paramInt;
    this.zab = paramStringToIntConverter;
  }
  
  public zaa(StringToIntConverter paramStringToIntConverter) {
    this.zaa = 1;
    this.zab = paramStringToIntConverter;
  }
  
  public static zaa q(FastJsonResponse.a parama) {
    if (parama instanceof StringToIntConverter)
      return new zaa((StringToIntConverter)parama); 
    throw new IllegalArgumentException("Unsupported safe parcelable field converter class.");
  }
  
  public final FastJsonResponse.a v() {
    StringToIntConverter stringToIntConverter = this.zab;
    if (stringToIntConverter != null)
      return stringToIntConverter; 
    throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.n(paramParcel, 2, (Parcelable)this.zab, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/converter/zaa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */