package com.google.android.gms.common.server.converter;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class zac extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zac> CREATOR = new c();
  
  final int zaa;
  
  final String zab;
  
  final int zac;
  
  public zac(int paramInt1, String paramString, int paramInt2) {
    this.zaa = paramInt1;
    this.zab = paramString;
    this.zac = paramInt2;
  }
  
  public zac(String paramString, int paramInt) {
    this.zaa = 1;
    this.zab = paramString;
    this.zac = paramInt;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.o(paramParcel, 2, this.zab, false);
    b.i(paramParcel, 3, this.zac);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/converter/zac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */