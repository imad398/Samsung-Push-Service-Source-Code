package com.google.android.gms.common.server;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class FavaDiagnosticsEntity extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<FavaDiagnosticsEntity> CREATOR = new a();
  
  final int zaa;
  
  public final String zab;
  
  public final int zac;
  
  public FavaDiagnosticsEntity(int paramInt1, String paramString, int paramInt2) {
    this.zaa = paramInt1;
    this.zab = paramString;
    this.zac = paramInt2;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.o(paramParcel, 2, this.zab, false);
    b.i(paramParcel, 3, this.zac);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/FavaDiagnosticsEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */