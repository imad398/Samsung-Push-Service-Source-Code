package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.m;
import h1.b;
import j1.c;
import j1.l;
import j1.m;
import java.util.HashMap;
import java.util.Map;

public class SafeParcelResponse extends FastSafeParcelableJsonResponse {
  public static final Parcelable.Creator<SafeParcelResponse> CREATOR = new e();
  
  private final int zaa;
  
  private final Parcel zab;
  
  private final int zac;
  
  private final zan zad;
  
  private final String zae;
  
  private int zaf;
  
  private int zag;
  
  public SafeParcelResponse(int paramInt, Parcel paramParcel, zan paramzan) {
    String str;
    this.zaa = paramInt;
    this.zab = (Parcel)m.i(paramParcel);
    this.zac = 2;
    this.zad = paramzan;
    if (paramzan == null) {
      paramParcel = null;
    } else {
      str = paramzan.q();
    } 
    this.zae = str;
    this.zaf = 2;
  }
  
  public static final void j(StringBuilder paramStringBuilder, int paramInt, Object paramObject) {
    switch (paramInt) {
      default:
        paramStringBuilder = new StringBuilder(26);
        paramStringBuilder.append("Unknown type = ");
        paramStringBuilder.append(paramInt);
        throw new IllegalArgumentException(paramStringBuilder.toString());
      case 11:
        throw new IllegalArgumentException("Method does not accept concrete type.");
      case 10:
        m.a(paramStringBuilder, (HashMap)m.i(paramObject));
        return;
      case 9:
        paramStringBuilder.append("\"");
        paramStringBuilder.append(c.b((byte[])paramObject));
        paramStringBuilder.append("\"");
        return;
      case 8:
        paramStringBuilder.append("\"");
        paramStringBuilder.append(c.a((byte[])paramObject));
        paramStringBuilder.append("\"");
        return;
      case 7:
        paramStringBuilder.append("\"");
        paramStringBuilder.append(l.a(m.i(paramObject).toString()));
        paramStringBuilder.append("\"");
        return;
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
        break;
    } 
    paramStringBuilder.append(paramObject);
  }
  
  public static final void k(StringBuilder paramStringBuilder, FastJsonResponse.Field paramField, Object paramObject) {
    if (paramField.zab) {
      paramObject = paramObject;
      paramStringBuilder.append("[");
      int i = paramObject.size();
      for (byte b = 0; b < i; b++) {
        if (b != 0)
          paramStringBuilder.append(","); 
        j(paramStringBuilder, paramField.zaa, paramObject.get(b));
      } 
      paramStringBuilder.append("]");
      return;
    } 
    j(paramStringBuilder, paramField.zaa, paramObject);
  }
  
  public final Map a() {
    zan zan1 = this.zad;
    return (zan1 == null) ? null : zan1.v((String)m.i(this.zae));
  }
  
  public final Object c(String paramString) {
    throw new UnsupportedOperationException("Converting to JSON does not require this method.");
  }
  
  public final boolean e(String paramString) {
    throw new UnsupportedOperationException("Converting to JSON does not require this method.");
  }
  
  public final Parcel h() {
    int i = this.zaf;
    if (i != 0) {
      if (i != 1)
        return this.zab; 
      b.b(this.zab, this.zag);
    } else {
      i = b.a(this.zab);
      this.zag = i;
      b.b(this.zab, i);
    } 
    this.zaf = 2;
    return this.zab;
  }
  
  public final void i(StringBuilder paramStringBuilder, Map paramMap, Parcel paramParcel) {
    // Byte code:
    //   0: new android/util/SparseArray
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #4
    //   9: aload_2
    //   10: invokeinterface entrySet : ()Ljava/util/Set;
    //   15: invokeinterface iterator : ()Ljava/util/Iterator;
    //   20: astore #5
    //   22: aload #5
    //   24: invokeinterface hasNext : ()Z
    //   29: ifeq -> 64
    //   32: aload #5
    //   34: invokeinterface next : ()Ljava/lang/Object;
    //   39: checkcast java/util/Map$Entry
    //   42: astore_2
    //   43: aload #4
    //   45: aload_2
    //   46: invokeinterface getValue : ()Ljava/lang/Object;
    //   51: checkcast com/google/android/gms/common/server/response/FastJsonResponse$Field
    //   54: invokevirtual q : ()I
    //   57: aload_2
    //   58: invokevirtual put : (ILjava/lang/Object;)V
    //   61: goto -> 22
    //   64: aload_1
    //   65: bipush #123
    //   67: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload_3
    //   72: invokestatic G : (Landroid/os/Parcel;)I
    //   75: istore #6
    //   77: iconst_0
    //   78: istore #7
    //   80: aload_3
    //   81: invokevirtual dataPosition : ()I
    //   84: iload #6
    //   86: if_icmpge -> 1187
    //   89: aload_3
    //   90: invokestatic A : (Landroid/os/Parcel;)I
    //   93: istore #8
    //   95: aload #4
    //   97: iload #8
    //   99: invokestatic v : (I)I
    //   102: invokevirtual get : (I)Ljava/lang/Object;
    //   105: checkcast java/util/Map$Entry
    //   108: astore #5
    //   110: aload #5
    //   112: ifnull -> 80
    //   115: iload #7
    //   117: ifeq -> 127
    //   120: aload_1
    //   121: ldc ','
    //   123: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: pop
    //   127: aload #5
    //   129: invokeinterface getKey : ()Ljava/lang/Object;
    //   134: checkcast java/lang/String
    //   137: astore_2
    //   138: aload #5
    //   140: invokeinterface getValue : ()Ljava/lang/Object;
    //   145: checkcast com/google/android/gms/common/server/response/FastJsonResponse$Field
    //   148: astore #5
    //   150: aload_1
    //   151: ldc '"'
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: pop
    //   157: aload_1
    //   158: aload_2
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: pop
    //   163: aload_1
    //   164: ldc '":'
    //   166: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: pop
    //   170: aload #5
    //   172: invokevirtual W : ()Z
    //   175: ifeq -> 504
    //   178: aload #5
    //   180: getfield zac : I
    //   183: istore #7
    //   185: iload #7
    //   187: tableswitch default -> 248, 0 -> 474, 1 -> 464, 2 -> 451, 3 -> 438, 4 -> 425, 5 -> 415, 6 -> 402, 7 -> 392, 8 -> 377, 9 -> 377, 10 -> 294, 11 -> 284
    //   248: new java/lang/StringBuilder
    //   251: dup
    //   252: bipush #36
    //   254: invokespecial <init> : (I)V
    //   257: astore_1
    //   258: aload_1
    //   259: ldc 'Unknown field out type = '
    //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: pop
    //   265: aload_1
    //   266: iload #7
    //   268: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   271: pop
    //   272: new java/lang/IllegalArgumentException
    //   275: dup
    //   276: aload_1
    //   277: invokevirtual toString : ()Ljava/lang/String;
    //   280: invokespecial <init> : (Ljava/lang/String;)V
    //   283: athrow
    //   284: new java/lang/IllegalArgumentException
    //   287: dup
    //   288: ldc 'Method does not accept concrete type.'
    //   290: invokespecial <init> : (Ljava/lang/String;)V
    //   293: athrow
    //   294: aload_3
    //   295: iload #8
    //   297: invokestatic f : (Landroid/os/Parcel;I)Landroid/os/Bundle;
    //   300: astore #9
    //   302: new java/util/HashMap
    //   305: dup
    //   306: invokespecial <init> : ()V
    //   309: astore #10
    //   311: aload #9
    //   313: invokevirtual keySet : ()Ljava/util/Set;
    //   316: invokeinterface iterator : ()Ljava/util/Iterator;
    //   321: astore #11
    //   323: aload #11
    //   325: invokeinterface hasNext : ()Z
    //   330: ifeq -> 366
    //   333: aload #11
    //   335: invokeinterface next : ()Ljava/lang/Object;
    //   340: checkcast java/lang/String
    //   343: astore_2
    //   344: aload #10
    //   346: aload_2
    //   347: aload #9
    //   349: aload_2
    //   350: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   353: invokestatic i : (Ljava/lang/Object;)Ljava/lang/Object;
    //   356: checkcast java/lang/String
    //   359: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   362: pop
    //   363: goto -> 323
    //   366: aload #5
    //   368: aload #10
    //   370: invokestatic f : (Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;
    //   373: astore_2
    //   374: goto -> 491
    //   377: aload #5
    //   379: aload_3
    //   380: iload #8
    //   382: invokestatic g : (Landroid/os/Parcel;I)[B
    //   385: invokestatic f : (Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;
    //   388: astore_2
    //   389: goto -> 491
    //   392: aload_3
    //   393: iload #8
    //   395: invokestatic p : (Landroid/os/Parcel;I)Ljava/lang/String;
    //   398: astore_2
    //   399: goto -> 484
    //   402: aload_3
    //   403: iload #8
    //   405: invokestatic w : (Landroid/os/Parcel;I)Z
    //   408: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   411: astore_2
    //   412: goto -> 484
    //   415: aload_3
    //   416: iload #8
    //   418: invokestatic a : (Landroid/os/Parcel;I)Ljava/math/BigDecimal;
    //   421: astore_2
    //   422: goto -> 484
    //   425: aload_3
    //   426: iload #8
    //   428: invokestatic y : (Landroid/os/Parcel;I)D
    //   431: invokestatic valueOf : (D)Ljava/lang/Double;
    //   434: astore_2
    //   435: goto -> 484
    //   438: aload_3
    //   439: iload #8
    //   441: invokestatic z : (Landroid/os/Parcel;I)F
    //   444: invokestatic valueOf : (F)Ljava/lang/Float;
    //   447: astore_2
    //   448: goto -> 484
    //   451: aload_3
    //   452: iload #8
    //   454: invokestatic D : (Landroid/os/Parcel;I)J
    //   457: invokestatic valueOf : (J)Ljava/lang/Long;
    //   460: astore_2
    //   461: goto -> 484
    //   464: aload_3
    //   465: iload #8
    //   467: invokestatic c : (Landroid/os/Parcel;I)Ljava/math/BigInteger;
    //   470: astore_2
    //   471: goto -> 484
    //   474: aload_3
    //   475: iload #8
    //   477: invokestatic C : (Landroid/os/Parcel;I)I
    //   480: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   483: astore_2
    //   484: aload #5
    //   486: aload_2
    //   487: invokestatic f : (Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;
    //   490: astore_2
    //   491: aload_1
    //   492: aload #5
    //   494: aload_2
    //   495: invokestatic k : (Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V
    //   498: iconst_1
    //   499: istore #7
    //   501: goto -> 80
    //   504: aload #5
    //   506: getfield zad : Z
    //   509: ifeq -> 784
    //   512: aload_1
    //   513: ldc '['
    //   515: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   518: pop
    //   519: aload #5
    //   521: getfield zac : I
    //   524: tableswitch default -> 588, 0 -> 762, 1 -> 749, 2 -> 736, 3 -> 723, 4 -> 710, 5 -> 697, 6 -> 684, 7 -> 671, 8 -> 660, 9 -> 660, 10 -> 660, 11 -> 599
    //   588: new java/lang/IllegalStateException
    //   591: dup
    //   592: ldc_w 'Unknown field type out.'
    //   595: invokespecial <init> : (Ljava/lang/String;)V
    //   598: athrow
    //   599: aload_3
    //   600: iload #8
    //   602: invokestatic n : (Landroid/os/Parcel;I)[Landroid/os/Parcel;
    //   605: astore_2
    //   606: aload_2
    //   607: arraylength
    //   608: istore #8
    //   610: iconst_0
    //   611: istore #7
    //   613: iload #7
    //   615: iload #8
    //   617: if_icmpge -> 772
    //   620: iload #7
    //   622: ifle -> 632
    //   625: aload_1
    //   626: ldc ','
    //   628: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   631: pop
    //   632: aload_2
    //   633: iload #7
    //   635: aaload
    //   636: iconst_0
    //   637: invokevirtual setDataPosition : (I)V
    //   640: aload_0
    //   641: aload_1
    //   642: aload #5
    //   644: invokevirtual U : ()Ljava/util/Map;
    //   647: aload_2
    //   648: iload #7
    //   650: aaload
    //   651: invokevirtual i : (Ljava/lang/StringBuilder;Ljava/util/Map;Landroid/os/Parcel;)V
    //   654: iinc #7, 1
    //   657: goto -> 613
    //   660: new java/lang/UnsupportedOperationException
    //   663: dup
    //   664: ldc_w 'List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported'
    //   667: invokespecial <init> : (Ljava/lang/String;)V
    //   670: athrow
    //   671: aload_1
    //   672: aload_3
    //   673: iload #8
    //   675: invokestatic q : (Landroid/os/Parcel;I)[Ljava/lang/String;
    //   678: invokestatic i : (Ljava/lang/StringBuilder;[Ljava/lang/String;)V
    //   681: goto -> 772
    //   684: aload_1
    //   685: aload_3
    //   686: iload #8
    //   688: invokestatic e : (Landroid/os/Parcel;I)[Z
    //   691: invokestatic h : (Ljava/lang/StringBuilder;[Z)V
    //   694: goto -> 772
    //   697: aload_1
    //   698: aload_3
    //   699: iload #8
    //   701: invokestatic b : (Landroid/os/Parcel;I)[Ljava/math/BigDecimal;
    //   704: invokestatic g : (Ljava/lang/StringBuilder;[Ljava/lang/Object;)V
    //   707: goto -> 772
    //   710: aload_1
    //   711: aload_3
    //   712: iload #8
    //   714: invokestatic h : (Landroid/os/Parcel;I)[D
    //   717: invokestatic c : (Ljava/lang/StringBuilder;[D)V
    //   720: goto -> 772
    //   723: aload_1
    //   724: aload_3
    //   725: iload #8
    //   727: invokestatic i : (Landroid/os/Parcel;I)[F
    //   730: invokestatic d : (Ljava/lang/StringBuilder;[F)V
    //   733: goto -> 772
    //   736: aload_1
    //   737: aload_3
    //   738: iload #8
    //   740: invokestatic l : (Landroid/os/Parcel;I)[J
    //   743: invokestatic f : (Ljava/lang/StringBuilder;[J)V
    //   746: goto -> 772
    //   749: aload_1
    //   750: aload_3
    //   751: iload #8
    //   753: invokestatic d : (Landroid/os/Parcel;I)[Ljava/math/BigInteger;
    //   756: invokestatic g : (Ljava/lang/StringBuilder;[Ljava/lang/Object;)V
    //   759: goto -> 772
    //   762: aload_1
    //   763: aload_3
    //   764: iload #8
    //   766: invokestatic j : (Landroid/os/Parcel;I)[I
    //   769: invokestatic e : (Ljava/lang/StringBuilder;[I)V
    //   772: ldc ']'
    //   774: astore_2
    //   775: aload_1
    //   776: aload_2
    //   777: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   780: pop
    //   781: goto -> 498
    //   784: aload #5
    //   786: getfield zac : I
    //   789: tableswitch default -> 852, 0 -> 1173, 1 -> 1157, 2 -> 1143, 3 -> 1129, 4 -> 1115, 5 -> 1105, 6 -> 1091, 7 -> 1056, 8 -> 1034, 9 -> 1012, 10 -> 889, 11 -> 863
    //   852: new java/lang/IllegalStateException
    //   855: dup
    //   856: ldc_w 'Unknown field type out'
    //   859: invokespecial <init> : (Ljava/lang/String;)V
    //   862: athrow
    //   863: aload_3
    //   864: iload #8
    //   866: invokestatic m : (Landroid/os/Parcel;I)Landroid/os/Parcel;
    //   869: astore_2
    //   870: aload_2
    //   871: iconst_0
    //   872: invokevirtual setDataPosition : (I)V
    //   875: aload_0
    //   876: aload_1
    //   877: aload #5
    //   879: invokevirtual U : ()Ljava/util/Map;
    //   882: aload_2
    //   883: invokevirtual i : (Ljava/lang/StringBuilder;Ljava/util/Map;Landroid/os/Parcel;)V
    //   886: goto -> 498
    //   889: aload_3
    //   890: iload #8
    //   892: invokestatic f : (Landroid/os/Parcel;I)Landroid/os/Bundle;
    //   895: astore_2
    //   896: aload_2
    //   897: invokevirtual keySet : ()Ljava/util/Set;
    //   900: astore #5
    //   902: aload_1
    //   903: ldc_w '{'
    //   906: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   909: pop
    //   910: aload #5
    //   912: invokeinterface iterator : ()Ljava/util/Iterator;
    //   917: astore #9
    //   919: iconst_1
    //   920: istore #7
    //   922: aload #9
    //   924: invokeinterface hasNext : ()Z
    //   929: ifeq -> 1005
    //   932: aload #9
    //   934: invokeinterface next : ()Ljava/lang/Object;
    //   939: checkcast java/lang/String
    //   942: astore #5
    //   944: iload #7
    //   946: ifne -> 956
    //   949: aload_1
    //   950: ldc ','
    //   952: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   955: pop
    //   956: aload_1
    //   957: ldc '"'
    //   959: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   962: pop
    //   963: aload_1
    //   964: aload #5
    //   966: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   969: pop
    //   970: aload_1
    //   971: ldc_w '":"'
    //   974: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   977: pop
    //   978: aload_1
    //   979: aload_2
    //   980: aload #5
    //   982: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   985: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   988: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   991: pop
    //   992: aload_1
    //   993: ldc '"'
    //   995: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   998: pop
    //   999: iconst_0
    //   1000: istore #7
    //   1002: goto -> 922
    //   1005: ldc_w '}'
    //   1008: astore_2
    //   1009: goto -> 775
    //   1012: aload_3
    //   1013: iload #8
    //   1015: invokestatic g : (Landroid/os/Parcel;I)[B
    //   1018: astore_2
    //   1019: aload_1
    //   1020: ldc '"'
    //   1022: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1025: pop
    //   1026: aload_2
    //   1027: invokestatic b : ([B)Ljava/lang/String;
    //   1030: astore_2
    //   1031: goto -> 1075
    //   1034: aload_3
    //   1035: iload #8
    //   1037: invokestatic g : (Landroid/os/Parcel;I)[B
    //   1040: astore_2
    //   1041: aload_1
    //   1042: ldc '"'
    //   1044: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1047: pop
    //   1048: aload_2
    //   1049: invokestatic a : ([B)Ljava/lang/String;
    //   1052: astore_2
    //   1053: goto -> 1075
    //   1056: aload_3
    //   1057: iload #8
    //   1059: invokestatic p : (Landroid/os/Parcel;I)Ljava/lang/String;
    //   1062: astore_2
    //   1063: aload_1
    //   1064: ldc '"'
    //   1066: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1069: pop
    //   1070: aload_2
    //   1071: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1074: astore_2
    //   1075: aload_1
    //   1076: aload_2
    //   1077: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1080: pop
    //   1081: aload_1
    //   1082: ldc '"'
    //   1084: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1087: pop
    //   1088: goto -> 498
    //   1091: aload_1
    //   1092: aload_3
    //   1093: iload #8
    //   1095: invokestatic w : (Landroid/os/Parcel;I)Z
    //   1098: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   1101: pop
    //   1102: goto -> 498
    //   1105: aload_3
    //   1106: iload #8
    //   1108: invokestatic a : (Landroid/os/Parcel;I)Ljava/math/BigDecimal;
    //   1111: astore_2
    //   1112: goto -> 1164
    //   1115: aload_1
    //   1116: aload_3
    //   1117: iload #8
    //   1119: invokestatic y : (Landroid/os/Parcel;I)D
    //   1122: invokevirtual append : (D)Ljava/lang/StringBuilder;
    //   1125: pop
    //   1126: goto -> 498
    //   1129: aload_1
    //   1130: aload_3
    //   1131: iload #8
    //   1133: invokestatic z : (Landroid/os/Parcel;I)F
    //   1136: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   1139: pop
    //   1140: goto -> 498
    //   1143: aload_1
    //   1144: aload_3
    //   1145: iload #8
    //   1147: invokestatic D : (Landroid/os/Parcel;I)J
    //   1150: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1153: pop
    //   1154: goto -> 498
    //   1157: aload_3
    //   1158: iload #8
    //   1160: invokestatic c : (Landroid/os/Parcel;I)Ljava/math/BigInteger;
    //   1163: astore_2
    //   1164: aload_1
    //   1165: aload_2
    //   1166: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1169: pop
    //   1170: goto -> 498
    //   1173: aload_1
    //   1174: aload_3
    //   1175: iload #8
    //   1177: invokestatic C : (Landroid/os/Parcel;I)I
    //   1180: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1183: pop
    //   1184: goto -> 498
    //   1187: aload_3
    //   1188: invokevirtual dataPosition : ()I
    //   1191: iload #6
    //   1193: if_icmpne -> 1204
    //   1196: aload_1
    //   1197: bipush #125
    //   1199: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   1202: pop
    //   1203: return
    //   1204: new java/lang/StringBuilder
    //   1207: dup
    //   1208: bipush #37
    //   1210: invokespecial <init> : (I)V
    //   1213: astore_1
    //   1214: aload_1
    //   1215: ldc_w 'Overread allowed size end='
    //   1218: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1221: pop
    //   1222: aload_1
    //   1223: iload #6
    //   1225: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1228: pop
    //   1229: new h1/a$a
    //   1232: dup
    //   1233: aload_1
    //   1234: invokevirtual toString : ()Ljava/lang/String;
    //   1237: aload_3
    //   1238: invokespecial <init> : (Ljava/lang/String;Landroid/os/Parcel;)V
    //   1241: athrow
  }
  
  public final String toString() {
    m.j(this.zad, "Cannot convert to JSON on client side.");
    Parcel parcel = h();
    parcel.setDataPosition(0);
    StringBuilder stringBuilder = new StringBuilder(100);
    i(stringBuilder, (Map)m.i(this.zad.v((String)m.i(this.zae))), parcel);
    return stringBuilder.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    Parcelable parcelable;
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.m(paramParcel, 2, h(), false);
    if (this.zac != 0) {
      parcelable = (Parcelable)this.zad;
    } else {
      parcelable = null;
    } 
    b.n(paramParcel, 3, parcelable, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/response/SafeParcelResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */