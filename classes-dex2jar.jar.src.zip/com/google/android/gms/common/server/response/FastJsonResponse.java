package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.server.converter.zaa;
import h1.b;
import j1.c;
import j1.l;
import j1.m;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class FastJsonResponse {
  public static final Object f(Field paramField, Object paramObject) {
    return (Field.R(paramField) != null) ? paramField.S(paramObject) : paramObject;
  }
  
  public static final void g(StringBuilder paramStringBuilder, Field paramField, Object paramObject) {
    String str;
    int i = paramField.zaa;
    if (i != 11) {
      if (i == 7) {
        str = "\"";
        paramStringBuilder.append("\"");
        paramStringBuilder.append(l.a((String)paramObject));
      } else {
        paramStringBuilder.append(paramObject);
        return;
      } 
    } else {
      Class<? extends FastJsonResponse> clazz = ((Field)str).zag;
      m.i(clazz);
      str = ((FastJsonResponse)clazz.cast(paramObject)).toString();
    } 
    paramStringBuilder.append(str);
  }
  
  public abstract Map a();
  
  public Object b(Field paramField) {
    StringBuilder stringBuilder;
    String str = paramField.zae;
    if (paramField.zag != null) {
      boolean bool;
      if (c(str) == null) {
        bool = true;
      } else {
        bool = false;
      } 
      m.m(bool, "Concrete field shouldn't be value object: %s", new Object[] { paramField.zae });
      try {
        char c = Character.toUpperCase(str.charAt(0));
        String str1 = str.substring(1);
        int i = String.valueOf(str1).length();
        stringBuilder = new StringBuilder();
        this(i + 4);
        stringBuilder.append("get");
        stringBuilder.append(c);
        stringBuilder.append(str1);
        return getClass().getMethod(stringBuilder.toString(), new Class[0]).invoke(this, new Object[0]);
      } catch (Exception exception) {
        throw new RuntimeException(exception);
      } 
    } 
    return c((String)stringBuilder);
  }
  
  public abstract Object c(String paramString);
  
  public boolean d(Field paramField) {
    if (paramField.zac == 11) {
      if (paramField.zad)
        throw new UnsupportedOperationException("Concrete type arrays not supported"); 
      throw new UnsupportedOperationException("Concrete types not supported");
    } 
    return e(paramField.zae);
  }
  
  public abstract boolean e(String paramString);
  
  public String toString() {
    String str;
    Map map = a();
    StringBuilder stringBuilder = new StringBuilder(100);
    Iterator<String> iterator = map.keySet().iterator();
    while (true) {
      if (iterator.hasNext()) {
        String str1 = iterator.next();
        Field field = (Field)map.get(str1);
        if (d(field)) {
          Object object = f(field, b(field));
          if (stringBuilder.length() == 0) {
            stringBuilder.append("{");
          } else {
            stringBuilder.append(",");
          } 
          stringBuilder.append("\"");
          stringBuilder.append(str1);
          stringBuilder.append("\":");
          if (object == null) {
            str = "null";
          } else {
            switch (((Field)str).zac) {
              default:
                if (((Field)str).zab) {
                  ArrayList arrayList = (ArrayList)object;
                  stringBuilder.append("[");
                  int i = arrayList.size();
                  for (byte b = 0; b < i; b++) {
                    if (b > 0)
                      stringBuilder.append(","); 
                    object = arrayList.get(b);
                    if (object != null)
                      g(stringBuilder, (Field)str, object); 
                  } 
                  str = "]";
                } else {
                  break;
                } 
                stringBuilder.append(str);
                continue;
              case 10:
                m.a(stringBuilder, (HashMap)object);
                continue;
              case 9:
                stringBuilder.append("\"");
                str = c.b((byte[])object);
                stringBuilder.append(str);
                stringBuilder.append("\"");
                continue;
              case 8:
                stringBuilder.append("\"");
                str = c.a((byte[])object);
                stringBuilder.append(str);
                stringBuilder.append("\"");
                continue;
            } 
            g(stringBuilder, (Field)str, object);
            continue;
          } 
        } else {
          continue;
        } 
      } else {
        break;
      } 
      stringBuilder.append(str);
    } 
    if (stringBuilder.length() > 0) {
      str = "}";
    } else {
      str = "{}";
    } 
    stringBuilder.append(str);
    return stringBuilder.toString();
  }
  
  public static class Field<I, O> extends AbstractSafeParcelable {
    public static final a CREATOR = new a();
    
    protected final int zaa;
    
    protected final boolean zab;
    
    protected final int zac;
    
    protected final boolean zad;
    
    protected final String zae;
    
    protected final int zaf;
    
    protected final Class<? extends FastJsonResponse> zag;
    
    protected final String zah;
    
    private final int zai;
    
    private zan zaj;
    
    private FastJsonResponse.a zak;
    
    public Field(int param1Int1, int param1Int2, boolean param1Boolean1, int param1Int3, boolean param1Boolean2, String param1String1, int param1Int4, String param1String2, zaa param1zaa) {
      this.zai = param1Int1;
      this.zaa = param1Int2;
      this.zab = param1Boolean1;
      this.zac = param1Int3;
      this.zad = param1Boolean2;
      this.zae = param1String1;
      this.zaf = param1Int4;
      if (param1String2 == null) {
        this.zag = null;
        this.zah = null;
      } else {
        this.zag = (Class)SafeParcelResponse.class;
        this.zah = param1String2;
      } 
      if (param1zaa == null) {
        this.zak = null;
        return;
      } 
      this.zak = param1zaa.v();
    }
    
    public final Object S(Object param1Object) {
      m.i(this.zak);
      return this.zak.c(param1Object);
    }
    
    public final String T() {
      String str1 = this.zah;
      String str2 = str1;
      if (str1 == null)
        str2 = null; 
      return str2;
    }
    
    public final Map U() {
      m.i(this.zah);
      m.i(this.zaj);
      return (Map)m.i(this.zaj.v(this.zah));
    }
    
    public final void V(zan param1zan) {
      this.zaj = param1zan;
    }
    
    public final boolean W() {
      return (this.zak != null);
    }
    
    public int q() {
      return this.zaf;
    }
    
    public final String toString() {
      k.a a1 = k.c(this).a("versionCode", Integer.valueOf(this.zai)).a("typeIn", Integer.valueOf(this.zaa)).a("typeInArray", Boolean.valueOf(this.zab)).a("typeOut", Integer.valueOf(this.zac)).a("typeOutArray", Boolean.valueOf(this.zad)).a("outputFieldName", this.zae).a("safeParcelFieldId", Integer.valueOf(this.zaf)).a("concreteTypeName", T());
      Class<? extends FastJsonResponse> clazz = this.zag;
      if (clazz != null)
        a1.a("concreteType.class", clazz.getCanonicalName()); 
      FastJsonResponse.a a2 = this.zak;
      if (a2 != null)
        a1.a("converterName", a2.getClass().getCanonicalName()); 
      return a1.toString();
    }
    
    public final zaa v() {
      FastJsonResponse.a a1 = this.zak;
      return (a1 == null) ? null : zaa.q(a1);
    }
    
    public final void writeToParcel(Parcel param1Parcel, int param1Int) {
      int i = b.a(param1Parcel);
      b.i(param1Parcel, 1, this.zai);
      b.i(param1Parcel, 2, this.zaa);
      b.c(param1Parcel, 3, this.zab);
      b.i(param1Parcel, 4, this.zac);
      b.c(param1Parcel, 5, this.zad);
      b.o(param1Parcel, 6, this.zae, false);
      b.i(param1Parcel, 7, q());
      b.o(param1Parcel, 8, T(), false);
      b.n(param1Parcel, 9, (Parcelable)v(), param1Int, false);
      b.b(param1Parcel, i);
    }
  }
  
  public static interface a {
    Object c(Object param1Object);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/response/FastJsonResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */