package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public final class zal extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zal> CREATOR = new d();
  
  final int zaa;
  
  final String zab;
  
  final ArrayList<zam> zac;
  
  public zal(int paramInt, String paramString, ArrayList<zam> paramArrayList) {
    this.zaa = paramInt;
    this.zab = paramString;
    this.zac = paramArrayList;
  }
  
  public zal(String paramString, Map paramMap) {
    String str;
    this.zaa = 1;
    this.zab = paramString;
    if (paramMap == null) {
      paramString = null;
    } else {
      ArrayList<zam> arrayList = new ArrayList();
      Iterator<String> iterator = paramMap.keySet().iterator();
      while (true) {
        ArrayList<zam> arrayList1 = arrayList;
        if (iterator.hasNext()) {
          str = iterator.next();
          arrayList.add(new zam(str, (FastJsonResponse.Field)paramMap.get(str)));
          continue;
        } 
        break;
      } 
    } 
    this.zac = (ArrayList<zam>)str;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.o(paramParcel, 2, this.zab, false);
    b.s(paramParcel, 3, this.zac, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/response/zal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */