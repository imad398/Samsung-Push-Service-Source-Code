package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class zan extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zan> CREATOR = new c();
  
  final int zaa;
  
  private final HashMap<String, Map<String, FastJsonResponse.Field<?, ?>>> zab;
  
  private final String zac;
  
  public zan(int paramInt, ArrayList<zal> paramArrayList, String paramString) {
    this.zaa = paramInt;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    int i = paramArrayList.size();
    for (paramInt = 0; paramInt < i; paramInt++) {
      zal zal = paramArrayList.get(paramInt);
      String str = zal.zab;
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
      int j = ((ArrayList)m.i(zal.zac)).size();
      for (byte b = 0; b < j; b++) {
        zam zam = zal.zac.get(b);
        hashMap1.put(zam.zab, zam.zac);
      } 
      hashMap.put(str, hashMap1);
    } 
    this.zab = (HashMap)hashMap;
    this.zac = (String)m.i(paramString);
    R();
  }
  
  public final void R() {
    for (String str : this.zab.keySet()) {
      Map map = this.zab.get(str);
      Iterator<String> iterator = map.keySet().iterator();
      while (iterator.hasNext())
        ((FastJsonResponse.Field)map.get(iterator.next())).V(this); 
    } 
  }
  
  public final String q() {
    return this.zac;
  }
  
  public final String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    for (String str : this.zab.keySet()) {
      stringBuilder.append(str);
      stringBuilder.append(":\n");
      Map map = this.zab.get(str);
      for (String str : map.keySet()) {
        stringBuilder.append("  ");
        stringBuilder.append(str);
        stringBuilder.append(": ");
        stringBuilder.append(map.get(str));
      } 
    } 
    return stringBuilder.toString();
  }
  
  public final Map v(String paramString) {
    return this.zab.get(paramString);
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    ArrayList<zal> arrayList = new ArrayList();
    for (String str : this.zab.keySet())
      arrayList.add(new zal(str, this.zab.get(str))); 
    b.s(paramParcel, 2, arrayList, false);
    b.o(paramParcel, 3, this.zac, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/response/zan.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */