package com.google.android.gms.common.server.response;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public final class zam extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zam> CREATOR = new b();
  
  final int zaa;
  
  final String zab;
  
  final FastJsonResponse.Field<?, ?> zac;
  
  public zam(int paramInt, String paramString, FastJsonResponse.Field<?, ?> paramField) {
    this.zaa = paramInt;
    this.zab = paramString;
    this.zac = paramField;
  }
  
  public zam(String paramString, FastJsonResponse.Field<?, ?> paramField) {
    this.zaa = 1;
    this.zab = paramString;
    this.zac = paramField;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.o(paramParcel, 2, this.zab, false);
    b.n(paramParcel, 3, (Parcelable)this.zac, paramInt, false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/server/response/zam.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */