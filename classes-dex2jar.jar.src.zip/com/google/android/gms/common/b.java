package com.google.android.gms.common;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import com.google.android.gms.common.internal.m;

public class b extends DialogFragment {
  public Dialog a;
  
  public DialogInterface.OnCancelListener b;
  
  public Dialog c;
  
  public static b a(Dialog paramDialog, DialogInterface.OnCancelListener paramOnCancelListener) {
    b b1 = new b();
    paramDialog = (Dialog)m.j(paramDialog, "Cannot display null dialog");
    paramDialog.setOnCancelListener(null);
    paramDialog.setOnDismissListener(null);
    b1.a = paramDialog;
    if (paramOnCancelListener != null)
      b1.b = paramOnCancelListener; 
    return b1;
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {
    DialogInterface.OnCancelListener onCancelListener = this.b;
    if (onCancelListener != null)
      onCancelListener.onCancel(paramDialogInterface); 
  }
  
  public Dialog onCreateDialog(Bundle paramBundle) {
    Dialog dialog2 = this.a;
    Dialog dialog1 = dialog2;
    if (dialog2 == null) {
      setShowsDialog(false);
      if (this.c == null)
        this.c = (Dialog)(new AlertDialog.Builder((Context)m.i(getActivity()))).create(); 
      dialog1 = this.c;
    } 
    return dialog1;
  }
  
  public void show(FragmentManager paramFragmentManager, String paramString) {
    super.show(paramFragmentManager, paramString);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/common/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */