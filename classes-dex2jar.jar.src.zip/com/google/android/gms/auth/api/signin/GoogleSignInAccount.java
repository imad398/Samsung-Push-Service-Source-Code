package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import j1.e;
import j1.h;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class GoogleSignInAccount extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new a();
  
  public static e zaa = h.d();
  
  final int zab;
  
  List<Scope> zac;
  
  private String zad;
  
  private String zae;
  
  private String zaf;
  
  private String zag;
  
  private Uri zah;
  
  private String zai;
  
  private long zaj;
  
  private String zak;
  
  private String zal;
  
  private String zam;
  
  private Set<Scope> zan = new HashSet<Scope>();
  
  public GoogleSignInAccount(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, Uri paramUri, String paramString5, long paramLong, String paramString6, List<Scope> paramList, String paramString7, String paramString8) {
    this.zab = paramInt;
    this.zad = paramString1;
    this.zae = paramString2;
    this.zaf = paramString3;
    this.zag = paramString4;
    this.zah = paramUri;
    this.zai = paramString5;
    this.zaj = paramLong;
    this.zak = paramString6;
    this.zac = paramList;
    this.zal = paramString7;
    this.zam = paramString8;
  }
  
  public static GoogleSignInAccount W(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, Uri paramUri, Long paramLong, String paramString7, Set paramSet) {
    return new GoogleSignInAccount(3, paramString1, paramString2, paramString3, paramString4, paramUri, null, paramLong.longValue(), m.e(paramString7), new ArrayList((Collection)m.i(paramSet)), paramString5, paramString6);
  }
  
  public static GoogleSignInAccount X(String paramString) {
    String str3;
    String str4;
    String str5;
    String str6;
    boolean bool = TextUtils.isEmpty(paramString);
    String str1 = null;
    if (bool)
      return null; 
    JSONObject jSONObject = new JSONObject(paramString);
    paramString = jSONObject.optString("photoUrl");
    if (!TextUtils.isEmpty(paramString)) {
      Uri uri = Uri.parse(paramString);
    } else {
      paramString = null;
    } 
    long l = Long.parseLong(jSONObject.getString("expirationTime"));
    HashSet<Scope> hashSet = new HashSet();
    JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
    int i = jSONArray.length();
    for (byte b = 0; b < i; b++)
      hashSet.add(new Scope(jSONArray.getString(b))); 
    String str2 = jSONObject.optString("id");
    if (jSONObject.has("tokenId")) {
      String str = jSONObject.optString("tokenId");
    } else {
      jSONArray = null;
    } 
    if (jSONObject.has("email")) {
      str3 = jSONObject.optString("email");
    } else {
      str3 = null;
    } 
    if (jSONObject.has("displayName")) {
      str4 = jSONObject.optString("displayName");
    } else {
      str4 = null;
    } 
    if (jSONObject.has("givenName")) {
      str5 = jSONObject.optString("givenName");
    } else {
      str5 = null;
    } 
    if (jSONObject.has("familyName")) {
      str6 = jSONObject.optString("familyName");
    } else {
      str6 = null;
    } 
    GoogleSignInAccount googleSignInAccount = W(str2, (String)jSONArray, str3, str4, str5, str6, (Uri)paramString, Long.valueOf(l), jSONObject.getString("obfuscatedIdentifier"), hashSet);
    paramString = str1;
    if (jSONObject.has("serverAuthCode"))
      paramString = jSONObject.optString("serverAuthCode"); 
    googleSignInAccount.zai = paramString;
    return googleSignInAccount;
  }
  
  public String F() {
    return this.zad;
  }
  
  public String R() {
    return this.zal;
  }
  
  public String S() {
    return this.zae;
  }
  
  public Uri T() {
    return this.zah;
  }
  
  public Set U() {
    HashSet<Scope> hashSet = new HashSet<Scope>(this.zac);
    hashSet.addAll(this.zan);
    return hashSet;
  }
  
  public String V() {
    return this.zai;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof GoogleSignInAccount))
      return false; 
    paramObject = paramObject;
    return (((GoogleSignInAccount)paramObject).zak.equals(this.zak) && paramObject.U().equals(U()));
  }
  
  public String f() {
    return this.zag;
  }
  
  public int hashCode() {
    return (this.zak.hashCode() + 527) * 31 + U().hashCode();
  }
  
  public String q() {
    return this.zaf;
  }
  
  public String v() {
    return this.zam;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zab);
    b.o(paramParcel, 2, F(), false);
    b.o(paramParcel, 3, S(), false);
    b.o(paramParcel, 4, q(), false);
    b.o(paramParcel, 5, f(), false);
    b.n(paramParcel, 6, (Parcelable)T(), paramInt, false);
    b.o(paramParcel, 7, V(), false);
    b.l(paramParcel, 8, this.zaj);
    b.o(paramParcel, 9, this.zak, false);
    b.s(paramParcel, 10, this.zac, false);
    b.o(paramParcel, 11, R(), false);
    b.o(paramParcel, 12, v(), false);
    b.b(paramParcel, i);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/auth/api/signin/GoogleSignInAccount.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */