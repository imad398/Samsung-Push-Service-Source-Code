package com.google.android.gms.auth.api.signin.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.m;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

public class b {
  public static final Lock c = new ReentrantLock();
  
  public static b d;
  
  public final Lock a = new ReentrantLock();
  
  public final SharedPreferences b;
  
  public b(Context paramContext) {
    this.b = paramContext.getSharedPreferences("com.google.android.gms.signin", 0);
  }
  
  public static b a(Context paramContext) {
    m.i(paramContext);
    Lock lock = c;
    lock.lock();
    try {
      if (d == null) {
        b b1 = new b();
        this(paramContext.getApplicationContext());
        d = b1;
      } 
      return d;
    } finally {
      c.unlock();
    } 
  }
  
  public static final String d(String paramString1, String paramString2) {
    int i = String.valueOf(paramString2).length();
    StringBuilder stringBuilder = new StringBuilder(paramString1.length() + 1 + i);
    stringBuilder.append(paramString1);
    stringBuilder.append(":");
    stringBuilder.append(paramString2);
    return stringBuilder.toString();
  }
  
  public GoogleSignInAccount b() {
    String str1 = c("defaultGoogleSignInAccount");
    boolean bool = TextUtils.isEmpty(str1);
    String str2 = null;
    if (bool) {
      str1 = str2;
    } else {
      String str = c(d("googleSignInAccount", str1));
      str1 = str2;
      if (str != null)
        try {
          GoogleSignInAccount googleSignInAccount = GoogleSignInAccount.X(str);
        } catch (JSONException jSONException) {
          str1 = str2;
        }  
    } 
    return (GoogleSignInAccount)str1;
  }
  
  public final String c(String paramString) {
    this.a.lock();
    try {
      paramString = this.b.getString(paramString, null);
      return paramString;
    } finally {
      this.a.unlock();
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/auth/api/signin/internal/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */