package com.google.android.gms.auth.api.signin.internal;

public class a {
  public static int b = 31;
  
  public int a = 1;
  
  public a a(Object paramObject) {
    int k;
    int i = b;
    int j = this.a;
    if (paramObject == null) {
      k = 0;
    } else {
      k = paramObject.hashCode();
    } 
    this.a = i * j + k;
    return this;
  }
  
  public int b() {
    return this.a;
  }
  
  public final a c(boolean paramBoolean) {
    this.a = b * this.a + paramBoolean;
    return this;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/auth/api/signin/internal/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */