package com.google.android.gms.auth.api.signin.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;

public class GoogleSignInOptionsExtensionParcelable extends AbstractSafeParcelable {
  public static final Parcelable.Creator<GoogleSignInOptionsExtensionParcelable> CREATOR = new c();
  
  final int zaa;
  
  private int zab;
  
  private Bundle zac;
  
  public GoogleSignInOptionsExtensionParcelable(int paramInt1, int paramInt2, Bundle paramBundle) {
    this.zaa = paramInt1;
    this.zab = paramInt2;
    this.zac = paramBundle;
  }
  
  public int q() {
    return this.zab;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaa);
    b.i(paramParcel, 2, q());
    b.d(paramParcel, 3, this.zac, false);
    b.b(paramParcel, paramInt);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/auth/api/signin/internal/GoogleSignInOptionsExtensionParcelable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */