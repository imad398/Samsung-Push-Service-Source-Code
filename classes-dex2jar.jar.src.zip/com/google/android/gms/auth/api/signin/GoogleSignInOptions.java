package com.google.android.gms.auth.api.signin;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.internal.GoogleSignInOptionsExtensionParcelable;
import com.google.android.gms.auth.api.signin.internal.a;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import h1.b;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class GoogleSignInOptions extends AbstractSafeParcelable implements a.d, ReflectedParcelable {
  public static final Parcelable.Creator<GoogleSignInOptions> CREATOR;
  
  public static final GoogleSignInOptions DEFAULT_GAMES_SIGN_IN;
  
  public static final GoogleSignInOptions DEFAULT_SIGN_IN;
  
  public static final Scope zaa = new Scope("profile");
  
  public static final Scope zab = new Scope("email");
  
  public static final Scope zac = new Scope("openid");
  
  public static final Scope zad;
  
  public static final Scope zae = new Scope("https://www.googleapis.com/auth/games");
  
  private static Comparator<Scope> zag;
  
  final int zaf;
  
  private final ArrayList<Scope> zah;
  
  private Account zai;
  
  private boolean zaj;
  
  private final boolean zak;
  
  private final boolean zal;
  
  private String zam;
  
  private String zan;
  
  private ArrayList<GoogleSignInOptionsExtensionParcelable> zao;
  
  private String zap;
  
  private Map<Integer, GoogleSignInOptionsExtensionParcelable> zaq;
  
  static {
    a a = new a();
    a.b();
    a.c();
    DEFAULT_SIGN_IN = a.a();
    a = new a();
    a.d(scope, new Scope[0]);
    DEFAULT_GAMES_SIGN_IN = a.a();
    CREATOR = new d();
    zag = new b();
  }
  
  public GoogleSignInOptions(int paramInt, ArrayList paramArrayList1, Account paramAccount, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString1, String paramString2, ArrayList paramArrayList2, String paramString3) {
    this(paramInt, paramArrayList1, paramAccount, paramBoolean1, paramBoolean2, paramBoolean3, paramString1, paramString2, X(paramArrayList2), paramString3);
  }
  
  public GoogleSignInOptions(int paramInt, ArrayList<Scope> paramArrayList, Account paramAccount, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString1, String paramString2, Map<Integer, GoogleSignInOptionsExtensionParcelable> paramMap, String paramString3) {
    this.zaf = paramInt;
    this.zah = paramArrayList;
    this.zai = paramAccount;
    this.zaj = paramBoolean1;
    this.zak = paramBoolean2;
    this.zal = paramBoolean3;
    this.zam = paramString1;
    this.zan = paramString2;
    this.zao = new ArrayList<GoogleSignInOptionsExtensionParcelable>(paramMap.values());
    this.zaq = paramMap;
    this.zap = paramString3;
  }
  
  public static Map X(List paramList) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramList == null)
      return hashMap; 
    for (GoogleSignInOptionsExtensionParcelable googleSignInOptionsExtensionParcelable : paramList)
      hashMap.put(Integer.valueOf(googleSignInOptionsExtensionParcelable.q()), googleSignInOptionsExtensionParcelable); 
    return hashMap;
  }
  
  public String R() {
    return this.zap;
  }
  
  public ArrayList S() {
    return new ArrayList<Scope>(this.zah);
  }
  
  public String T() {
    return this.zam;
  }
  
  public boolean U() {
    return this.zal;
  }
  
  public boolean V() {
    return this.zaj;
  }
  
  public boolean W() {
    return this.zak;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    try {
      paramObject = paramObject;
      if (this.zao.size() <= 0 && ((GoogleSignInOptions)paramObject).zao.size() <= 0 && this.zah.size() == paramObject.S().size() && this.zah.containsAll(paramObject.S())) {
        Account account = this.zai;
        if (((account == null) ? (paramObject.q() == null) : account.equals(paramObject.q())) && (TextUtils.isEmpty(this.zam) ? TextUtils.isEmpty(paramObject.T()) : this.zam.equals(paramObject.T())) && this.zal == paramObject.U() && this.zaj == paramObject.V() && this.zak == paramObject.W()) {
          boolean bool = TextUtils.equals(this.zap, paramObject.R());
          if (bool)
            return true; 
        } 
      } 
    } catch (ClassCastException classCastException) {}
    return false;
  }
  
  public int hashCode() {
    ArrayList<String> arrayList = new ArrayList();
    ArrayList<Scope> arrayList1 = this.zah;
    int i = arrayList1.size();
    for (byte b = 0; b < i; b++)
      arrayList.add(((Scope)arrayList1.get(b)).q()); 
    Collections.sort(arrayList);
    a a = new a();
    a.a(arrayList);
    a.a(this.zai);
    a.a(this.zam);
    a.c(this.zal);
    a.c(this.zaj);
    a.c(this.zak);
    a.a(this.zap);
    return a.b();
  }
  
  public Account q() {
    return this.zai;
  }
  
  public ArrayList v() {
    return this.zao;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = b.a(paramParcel);
    b.i(paramParcel, 1, this.zaf);
    b.s(paramParcel, 2, S(), false);
    b.n(paramParcel, 3, (Parcelable)q(), paramInt, false);
    b.c(paramParcel, 4, V());
    b.c(paramParcel, 5, W());
    b.c(paramParcel, 6, U());
    b.o(paramParcel, 7, T(), false);
    b.o(paramParcel, 8, this.zan, false);
    b.s(paramParcel, 9, v(), false);
    b.o(paramParcel, 10, R(), false);
    b.b(paramParcel, i);
  }
  
  static {
    Scope scope = new Scope("https://www.googleapis.com/auth/games_lite");
    zad = scope;
  }
  
  public static final class a {
    public Set a = new HashSet();
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
    
    public String e;
    
    public Account f;
    
    public String g;
    
    public Map h = new HashMap<Object, Object>();
    
    public String i;
    
    public GoogleSignInOptions a() {
      if (this.a.contains(GoogleSignInOptions.zae)) {
        Set set = this.a;
        Scope scope = GoogleSignInOptions.zad;
        if (set.contains(scope))
          this.a.remove(scope); 
      } 
      if (this.d && (this.f == null || !this.a.isEmpty()))
        b(); 
      return new GoogleSignInOptions(3, new ArrayList(this.a), this.f, this.d, this.b, this.c, this.e, this.g, this.h, this.i, null);
    }
    
    public a b() {
      this.a.add(GoogleSignInOptions.zac);
      return this;
    }
    
    public a c() {
      this.a.add(GoogleSignInOptions.zaa);
      return this;
    }
    
    public a d(Scope param1Scope, Scope... param1VarArgs) {
      this.a.add(param1Scope);
      this.a.addAll(Arrays.asList(param1VarArgs));
      return this;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/gms/auth/api/signin/GoogleSignInOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */