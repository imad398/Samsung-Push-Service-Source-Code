package com.google.android.datatransport.cct;

import androidx.annotation.Keep;
import e0.d;
import h0.d;
import h0.h;
import h0.m;

@Keep
public class CctBackendFactory implements d {
  public m create(h paramh) {
    return (m)new d(paramh.b(), paramh.e(), paramh.d());
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/datatransport/cct/CctBackendFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */