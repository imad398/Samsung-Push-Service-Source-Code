package com.google.android.datatransport.runtime.backends;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class TransportBackendDiscovery extends Service {
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/com/google/android/datatransport/runtime/backends/TransportBackendDiscovery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */