package a0;

import s0.d;

public final class b {
  public static final b b = new b(-1, -2, "mb");
  
  public static final b c = new b(320, 50, "mb");
  
  public static final b d = new b(300, 250, "as");
  
  public static final b e = new b(468, 60, "as");
  
  public static final b f = new b(728, 90, "as");
  
  public static final b g = new b(160, 600, "as");
  
  public final d a;
  
  public b(int paramInt1, int paramInt2, String paramString) {
    this(new d(paramInt1, paramInt2));
  }
  
  public b(d paramd) {
    this.a = paramd;
  }
  
  public final int a() {
    return this.a.a();
  }
  
  public final int b() {
    return this.a.c();
  }
  
  public final boolean equals(Object paramObject) {
    if (!(paramObject instanceof b))
      return false; 
    paramObject = paramObject;
    return this.a.equals(((b)paramObject).a);
  }
  
  public final int hashCode() {
    return this.a.hashCode();
  }
  
  public final String toString() {
    return this.a.toString();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a0/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */