package a0;

public enum a {
  a, b, c;
  
  static {
    a a1 = new a("UNKNOWN", 0);
    a = a1;
    a a2 = new a("MALE", 1);
    b = a2;
    a a3 = new a("FEMALE", 2);
    c = a3;
    d = new a[] { a1, a2, a3 };
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a0/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */