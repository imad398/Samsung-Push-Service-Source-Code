package b0;

import android.location.Location;
import java.util.Date;
import java.util.Set;

public class a {
  public final Date a;
  
  public final a0.a b;
  
  public final Set c;
  
  public final boolean d;
  
  public final Location e;
  
  public a(Date paramDate, a0.a parama, Set paramSet, boolean paramBoolean, Location paramLocation) {
    this.a = paramDate;
    this.b = parama;
    this.c = paramSet;
    this.d = paramBoolean;
    this.e = paramLocation;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b0/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */