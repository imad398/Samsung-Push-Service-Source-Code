package b0;

import android.os.Bundle;
import c1.a;
import com.google.ads.mediation.AbstractAdViewAdapter;

public final class h extends a {
  public h(AbstractAdViewAdapter paramAbstractAdViewAdapter) {}
  
  public final void a() {
    if (AbstractAdViewAdapter.zzb(this.a) != null && AbstractAdViewAdapter.zza(this.a) != null) {
      Bundle bundle = AbstractAdViewAdapter.zzb(this.a).a();
      AbstractAdViewAdapter.zza(this.a).w(bundle);
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b0/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */