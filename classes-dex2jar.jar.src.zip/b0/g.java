package b0;

import c1.b;
import c1.c;
import com.google.ads.mediation.AbstractAdViewAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;

public final class g implements c {
  public g(AbstractAdViewAdapter paramAbstractAdViewAdapter) {}
  
  public final void B() {
    AbstractAdViewAdapter.zza(this.a).a((MediationRewardedVideoAdAdapter)this.a);
  }
  
  public final void E() {
    AbstractAdViewAdapter.zza(this.a).h((MediationRewardedVideoAdAdapter)this.a);
    AbstractAdViewAdapter.zza(this.a, null);
  }
  
  public final void F0() {
    AbstractAdViewAdapter.zza(this.a).g((MediationRewardedVideoAdAdapter)this.a);
  }
  
  public final void G() {
    AbstractAdViewAdapter.zza(this.a).c((MediationRewardedVideoAdAdapter)this.a);
  }
  
  public final void G0(b paramb) {
    AbstractAdViewAdapter.zza(this.a).i((MediationRewardedVideoAdAdapter)this.a, paramb);
  }
  
  public final void H() {
    AbstractAdViewAdapter.zza(this.a).e((MediationRewardedVideoAdAdapter)this.a);
  }
  
  public final void k0(int paramInt) {
    AbstractAdViewAdapter.zza(this.a).b((MediationRewardedVideoAdAdapter)this.a, paramInt);
  }
  
  public final void z() {
    AbstractAdViewAdapter.zza(this.a).f((MediationRewardedVideoAdAdapter)this.a);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b0/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */