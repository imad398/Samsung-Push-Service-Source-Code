package a1;

import android.location.Location;
import java.util.Date;
import java.util.Set;

public interface a {
  boolean a();
  
  Date d();
  
  boolean e();
  
  Set f();
  
  int h();
  
  Location k();
  
  int m();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */