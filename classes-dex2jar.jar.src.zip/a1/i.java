package a1;

import java.util.Map;
import u0.b;

public interface i extends a {
  boolean b();
  
  Map c();
  
  b g();
  
  boolean i();
  
  boolean j();
  
  boolean l();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */