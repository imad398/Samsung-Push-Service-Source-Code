package a1;

import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import u0.f;

public interface e {
  void b(MediationNativeAdapter paramMediationNativeAdapter);
  
  void e(MediationNativeAdapter paramMediationNativeAdapter, f paramf);
  
  void f(MediationNativeAdapter paramMediationNativeAdapter, f paramf, String paramString);
  
  void g(MediationNativeAdapter paramMediationNativeAdapter, f paramf);
  
  void i(MediationNativeAdapter paramMediationNativeAdapter);
  
  void j(MediationNativeAdapter paramMediationNativeAdapter);
  
  void m(MediationNativeAdapter paramMediationNativeAdapter, int paramInt);
  
  void n(MediationNativeAdapter paramMediationNativeAdapter);
  
  void s(MediationNativeAdapter paramMediationNativeAdapter, k paramk);
  
  void u(MediationNativeAdapter paramMediationNativeAdapter);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */