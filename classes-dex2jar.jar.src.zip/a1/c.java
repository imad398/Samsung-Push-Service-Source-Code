package a1;

import com.google.android.gms.ads.mediation.MediationBannerAdapter;

public interface c {
  void a(MediationBannerAdapter paramMediationBannerAdapter);
  
  void h(MediationBannerAdapter paramMediationBannerAdapter);
  
  void k(MediationBannerAdapter paramMediationBannerAdapter);
  
  void l(MediationBannerAdapter paramMediationBannerAdapter);
  
  void p(MediationBannerAdapter paramMediationBannerAdapter, String paramString1, String paramString2);
  
  void q(MediationBannerAdapter paramMediationBannerAdapter);
  
  void w(MediationBannerAdapter paramMediationBannerAdapter, int paramInt);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */