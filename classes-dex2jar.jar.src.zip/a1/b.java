package a1;

import android.os.Bundle;

public interface b {
  void onDestroy();
  
  void onPause();
  
  void onResume();
  
  public static final class a {
    public int a;
    
    public final Bundle a() {
      Bundle bundle = new Bundle();
      bundle.putInt("capabilities", this.a);
      return bundle;
    }
    
    public final a b(int param1Int) {
      this.a = 1;
      return this;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */