package a1;

import java.util.List;
import u0.a;

public abstract class h extends f {
  public String h;
  
  public List i;
  
  public String j;
  
  public a.b k;
  
  public String l;
  
  public String m;
  
  public final void A(a.b paramb) {
    this.k = paramb;
  }
  
  public final String p() {
    return this.m;
  }
  
  public final String q() {
    return this.j;
  }
  
  public final String r() {
    return this.l;
  }
  
  public final String s() {
    return this.h;
  }
  
  public final List t() {
    return this.i;
  }
  
  public final a.b u() {
    return this.k;
  }
  
  public final void v(String paramString) {
    this.m = paramString;
  }
  
  public final void w(String paramString) {
    this.j = paramString;
  }
  
  public final void x(String paramString) {
    this.l = paramString;
  }
  
  public final void y(String paramString) {
    this.h = paramString;
  }
  
  public final void z(List paramList) {
    this.i = paramList;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */