package a1;

public interface j {
  void onImmersiveModeUpdated(boolean paramBoolean);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */