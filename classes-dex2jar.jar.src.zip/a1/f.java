package a1;

import android.os.Bundle;
import android.view.View;
import java.util.Map;
import s0.g;

public abstract class f {
  public boolean a;
  
  public boolean b;
  
  public Bundle c = new Bundle();
  
  public View d;
  
  public View e;
  
  public g f;
  
  public boolean g;
  
  public View a() {
    return this.d;
  }
  
  public final Bundle b() {
    return this.c;
  }
  
  public final boolean c() {
    return this.b;
  }
  
  public final boolean d() {
    return this.a;
  }
  
  public final g e() {
    return this.f;
  }
  
  public void f(View paramView) {}
  
  public boolean g() {
    return this.g;
  }
  
  public void h() {}
  
  public final void i(boolean paramBoolean) {
    this.b = paramBoolean;
  }
  
  public final void j(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public abstract void k(View paramView);
  
  public void l(View paramView, Map paramMap1, Map paramMap2) {}
  
  public void m(View paramView) {}
  
  public final void n(g paramg) {
    this.f = paramg;
  }
  
  public final View o() {
    return this.e;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */