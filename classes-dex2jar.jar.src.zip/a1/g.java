package a1;

import java.util.List;
import u0.a;

public abstract class g extends f {
  public String h;
  
  public List i;
  
  public String j;
  
  public a.b k;
  
  public String l;
  
  public double m;
  
  public String n;
  
  public String o;
  
  public final void A(a.b paramb) {
    this.k = paramb;
  }
  
  public final void B(List paramList) {
    this.i = paramList;
  }
  
  public final void C(String paramString) {
    this.o = paramString;
  }
  
  public final void D(double paramDouble) {
    this.m = paramDouble;
  }
  
  public final void E(String paramString) {
    this.n = paramString;
  }
  
  public final String p() {
    return this.j;
  }
  
  public final String q() {
    return this.l;
  }
  
  public final String r() {
    return this.h;
  }
  
  public final a.b s() {
    return this.k;
  }
  
  public final List t() {
    return this.i;
  }
  
  public final String u() {
    return this.o;
  }
  
  public final double v() {
    return this.m;
  }
  
  public final String w() {
    return this.n;
  }
  
  public final void x(String paramString) {
    this.j = paramString;
  }
  
  public final void y(String paramString) {
    this.l = paramString;
  }
  
  public final void z(String paramString) {
    this.h = paramString;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */