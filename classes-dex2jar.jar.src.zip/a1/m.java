package a1;

import com.google.android.gms.internal.ads.ax0;

public interface m {
  ax0 getVideoController();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */