package a1;

import android.os.Bundle;
import android.view.View;
import java.util.List;
import java.util.Map;
import s0.g;
import u0.a;

public abstract class k {
  public String a;
  
  public List b;
  
  public String c;
  
  public a.b d;
  
  public String e;
  
  public String f;
  
  public Double g;
  
  public String h;
  
  public String i;
  
  public g j;
  
  public boolean k;
  
  public View l;
  
  public View m;
  
  public Object n;
  
  public Bundle o = new Bundle();
  
  public boolean p;
  
  public boolean q;
  
  public final void A(Double paramDouble) {
    this.g = paramDouble;
  }
  
  public final void B(String paramString) {
    this.h = paramString;
  }
  
  public abstract void C(View paramView, Map paramMap1, Map paramMap2);
  
  public void D(View paramView) {}
  
  public final void E(g paramg) {
    this.j = paramg;
  }
  
  public final View F() {
    return this.m;
  }
  
  public final Object G() {
    return this.n;
  }
  
  public final void H(Object paramObject) {
    this.n = paramObject;
  }
  
  public View a() {
    return this.l;
  }
  
  public final String b() {
    return this.f;
  }
  
  public final String c() {
    return this.c;
  }
  
  public final String d() {
    return this.e;
  }
  
  public final Bundle e() {
    return this.o;
  }
  
  public final String f() {
    return this.a;
  }
  
  public final a.b g() {
    return this.d;
  }
  
  public final List h() {
    return this.b;
  }
  
  public final boolean i() {
    return this.q;
  }
  
  public final boolean j() {
    return this.p;
  }
  
  public final String k() {
    return this.i;
  }
  
  public final Double l() {
    return this.g;
  }
  
  public final String m() {
    return this.h;
  }
  
  public final g n() {
    return this.j;
  }
  
  public void o(View paramView) {}
  
  public boolean p() {
    return this.k;
  }
  
  public void q() {}
  
  public final void r(String paramString) {
    this.f = paramString;
  }
  
  public final void s(String paramString) {
    this.c = paramString;
  }
  
  public final void t(String paramString) {
    this.e = paramString;
  }
  
  public final void u(String paramString) {
    this.a = paramString;
  }
  
  public final void v(a.b paramb) {
    this.d = paramb;
  }
  
  public final void w(List paramList) {
    this.b = paramList;
  }
  
  public final void x(boolean paramBoolean) {
    this.q = paramBoolean;
  }
  
  public final void y(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public final void z(String paramString) {
    this.i = paramString;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a1/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */