package c1;

public interface b {
  int I0();
  
  String x();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c1/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */