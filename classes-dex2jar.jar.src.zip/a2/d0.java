package a2;

import com.google.android.gms.wearable.internal.zzag;

public final class d0 implements Runnable {
  public d0(g0 paramg0, zzag paramzzag) {}
  
  public final void run() {
    this.b.b.f((b)this.a);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */