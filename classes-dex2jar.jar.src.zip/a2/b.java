package a2;

public interface b {}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */