package a2;

import com.google.android.gms.common.api.c;

public abstract class l extends c {
  public static String a(int paramInt) {
    switch (paramInt) {
      default:
        return c.a(paramInt);
      case 4010:
        return "ACCOUNT_KEY_CREATION_FAILED";
      case 4009:
        return "UNSUPPORTED_BY_TARGET";
      case 4008:
        return "WIFI_CREDENTIAL_SYNC_NO_CREDENTIAL_FETCHED";
      case 4007:
        return "UNKNOWN_CAPABILITY";
      case 4006:
        return "DUPLICATE_CAPABILITY";
      case 4005:
        return "ASSET_UNAVAILABLE";
      case 4004:
        return "INVALID_TARGET_NODE";
      case 4003:
        return "DATA_ITEM_TOO_LARGE";
      case 4002:
        return "UNKNOWN_LISTENER";
      case 4001:
        return "DUPLICATE_LISTENER";
      case 4000:
        break;
    } 
    return "TARGET_NODE_NOT_CONNECTED";
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */