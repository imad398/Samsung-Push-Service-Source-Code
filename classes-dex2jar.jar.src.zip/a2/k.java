package a2;

import com.google.android.gms.common.api.i;
import java.util.List;

public interface k {
  public static interface a extends i {
    List Q();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */