package a2;

import java.util.List;

public final class c0 implements Runnable {
  public c0(g0 paramg0, List paramList) {}
  
  public final void run() {
    this.b.b.i(this.a);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */