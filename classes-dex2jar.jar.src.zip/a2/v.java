package a2;

import android.os.Looper;
import android.os.Message;
import com.google.android.gms.wearable.WearableListenerService;
import v1.i;

public final class v extends i {
  public boolean a;
  
  public final u b;
  
  public v(WearableListenerService paramWearableListenerService, Looper paramLooper) {
    super(paramLooper);
    this.b = new u(paramWearableListenerService, null);
  }
  
  public final void a(Message paramMessage) {
    c();
    try {
      super.a(paramMessage);
      return;
    } finally {
      if (!hasMessages(0))
        d("dispatch"); 
    } 
  }
  
  public final void b() {
    getLooper().quit();
    d("quit");
  }
  
  public final void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: ldc 'WearableLS'
    //   16: iconst_2
    //   17: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   20: ifeq -> 79
    //   23: aload_0
    //   24: getfield c : Lcom/google/android/gms/wearable/WearableListenerService;
    //   27: invokestatic s : (Lcom/google/android/gms/wearable/WearableListenerService;)Landroid/content/ComponentName;
    //   30: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   33: astore_2
    //   34: aload_2
    //   35: invokevirtual length : ()I
    //   38: istore_3
    //   39: new java/lang/StringBuilder
    //   42: astore #4
    //   44: aload #4
    //   46: iload_3
    //   47: bipush #13
    //   49: iadd
    //   50: invokespecial <init> : (I)V
    //   53: aload #4
    //   55: ldc 'bindService: '
    //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: pop
    //   61: aload #4
    //   63: aload_2
    //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: pop
    //   68: ldc 'WearableLS'
    //   70: aload #4
    //   72: invokevirtual toString : ()Ljava/lang/String;
    //   75: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   78: pop
    //   79: aload_0
    //   80: getfield c : Lcom/google/android/gms/wearable/WearableListenerService;
    //   83: astore_2
    //   84: aload_2
    //   85: aload_2
    //   86: invokestatic t : (Lcom/google/android/gms/wearable/WearableListenerService;)Landroid/content/Intent;
    //   89: aload_0
    //   90: getfield b : La2/u;
    //   93: iconst_1
    //   94: invokevirtual bindService : (Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   97: pop
    //   98: aload_0
    //   99: iconst_1
    //   100: putfield a : Z
    //   103: aload_0
    //   104: monitorexit
    //   105: return
    //   106: astore_2
    //   107: aload_0
    //   108: monitorexit
    //   109: aload_2
    //   110: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	106	finally
    //   14	79	106	finally
    //   79	103	106	finally
  }
  
  public final void d(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifne -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: ldc 'WearableLS'
    //   16: iconst_2
    //   17: invokestatic isLoggable : (Ljava/lang/String;I)Z
    //   20: ifeq -> 105
    //   23: aload_0
    //   24: getfield c : Lcom/google/android/gms/wearable/WearableListenerService;
    //   27: invokestatic s : (Lcom/google/android/gms/wearable/WearableListenerService;)Landroid/content/ComponentName;
    //   30: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   33: astore_3
    //   34: aload_1
    //   35: invokevirtual length : ()I
    //   38: istore #4
    //   40: aload_3
    //   41: invokevirtual length : ()I
    //   44: istore #5
    //   46: new java/lang/StringBuilder
    //   49: astore #6
    //   51: aload #6
    //   53: iload #4
    //   55: bipush #17
    //   57: iadd
    //   58: iload #5
    //   60: iadd
    //   61: invokespecial <init> : (I)V
    //   64: aload #6
    //   66: ldc 'unbindService: '
    //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: pop
    //   72: aload #6
    //   74: aload_1
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: pop
    //   79: aload #6
    //   81: ldc ', '
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload #6
    //   89: aload_3
    //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: pop
    //   94: ldc 'WearableLS'
    //   96: aload #6
    //   98: invokevirtual toString : ()Ljava/lang/String;
    //   101: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   104: pop
    //   105: aload_0
    //   106: getfield c : Lcom/google/android/gms/wearable/WearableListenerService;
    //   109: aload_0
    //   110: getfield b : La2/u;
    //   113: invokevirtual unbindService : (Landroid/content/ServiceConnection;)V
    //   116: goto -> 129
    //   119: astore_1
    //   120: ldc 'WearableLS'
    //   122: ldc 'Exception when unbinding from local service'
    //   124: aload_1
    //   125: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   128: pop
    //   129: aload_0
    //   130: iconst_0
    //   131: putfield a : Z
    //   134: aload_0
    //   135: monitorexit
    //   136: return
    //   137: astore_1
    //   138: aload_0
    //   139: monitorexit
    //   140: aload_1
    //   141: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	137	finally
    //   14	105	137	finally
    //   105	116	119	java/lang/RuntimeException
    //   105	116	137	finally
    //   120	129	137	finally
    //   129	134	137	finally
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */