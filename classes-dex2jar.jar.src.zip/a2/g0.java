package a2;

import android.content.Context;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.WearableListenerService;
import com.google.android.gms.wearable.g;
import com.google.android.gms.wearable.internal.i0;
import com.google.android.gms.wearable.internal.m0;
import com.google.android.gms.wearable.internal.v1;
import com.google.android.gms.wearable.internal.zzag;
import com.google.android.gms.wearable.internal.zzax;
import com.google.android.gms.wearable.internal.zzfj;
import com.google.android.gms.wearable.internal.zzfw;
import com.google.android.gms.wearable.internal.zzi;
import com.google.android.gms.wearable.internal.zzl;
import j1.t;
import java.util.List;
import z1.i;

public final class g0 extends m0 {
  public volatile int a = -1;
  
  public static final void h0(i0 parami0, boolean paramBoolean, byte[] paramArrayOfbyte) {
    try {
      parami0.R(paramBoolean, paramArrayOfbyte);
      return;
    } catch (RemoteException remoteException) {
      Log.e("WearableLS", "Failed to send a response back", (Throwable)remoteException);
      return;
    } 
  }
  
  public final void A7(zzi paramzzi) {
    R(new f0(this, paramzzi), "onEntityUpdate", paramzzi);
  }
  
  public final boolean R(Runnable paramRunnable, String paramString, Object paramObject) {
    if (Log.isLoggable("WearableLS", 3))
      Log.d("WearableLS", String.format("%s: %s %s", new Object[] { paramString, WearableListenerService.s(this.b).toString(), paramObject })); 
    int i = Binder.getCallingUid();
    if (i != this.a)
      if ((v1.a((Context)this.b).b("com.google.android.wearable.app.cn") && t.b((Context)this.b, i, "com.google.android.wearable.app.cn")) || t.a((Context)this.b, i)) {
        this.a = i;
      } else {
        null = new StringBuilder(57);
        null.append("Caller is not GooglePlayServices; caller UID: ");
        null.append(i);
        Log.e("WearableLS", null.toString());
        return false;
      }  
    synchronized (WearableListenerService.v(this.b)) {
      if (WearableListenerService.w(this.b))
        return false; 
      WearableListenerService.x(this.b).post((Runnable)null);
      return true;
    } 
  }
  
  public final void X2(zzfj paramzzfj) {
    R(new z(this, paramzzfj), "onMessageReceived", paramzzfj);
  }
  
  public final void Y7(zzfw paramzzfw) {
    R(new a0(this, paramzzfw), "onPeerConnected", paramzzfw);
  }
  
  public final void f2(zzfj paramzzfj, i0 parami0) {
    R(new w(this, paramzzfj, parami0, null), "onRequestReceived", paramzzfj);
  }
  
  public final void g6(DataHolder paramDataHolder) {
    y y = new y(this, paramDataHolder);
    try {
      String str = String.valueOf(paramDataHolder);
      int i = paramDataHolder.s();
      int j = str.length();
      StringBuilder stringBuilder = new StringBuilder();
      this(j + 18);
      stringBuilder.append(str);
      stringBuilder.append(", rows=");
      stringBuilder.append(i);
      boolean bool = R(y, "onDataItemChanged", stringBuilder.toString());
      return;
    } finally {
      paramDataHolder.close();
    } 
  }
  
  public final void h4(zzag paramzzag) {
    R(new d0(this, paramzzag), "onConnectedCapabilityChanged", paramzzag);
  }
  
  public final void k6(zzfw paramzzfw) {
    R(new b0(this, paramzzfw), "onPeerDisconnected", paramzzfw);
  }
  
  public final void m0(List paramList) {
    R(new c0(this, paramList), "onConnectedNodes", paramList);
  }
  
  public final void m6(zzax paramzzax) {
    R((Runnable)new g(this, paramzzax), "onChannelEvent", paramzzax);
  }
  
  public final void n4(zzl paramzzl) {
    R(new e0(this, paramzzl), "onNotificationReceived", paramzzl);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */