package a2;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.i;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.a;
import com.google.android.gms.common.data.e;
import com.google.android.gms.wearable.internal.m;

public class d extends e implements i {
  public final Status d;
  
  public d(DataHolder paramDataHolder) {
    super(paramDataHolder);
    this.d = new Status(paramDataHolder.S());
  }
  
  public final String T() {
    return "path";
  }
  
  public Status x() {
    return this.d;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */