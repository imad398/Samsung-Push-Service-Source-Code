package a2;

import com.google.android.gms.common.Feature;

public abstract class q {
  public static final Feature a;
  
  public static final Feature b;
  
  public static final Feature c;
  
  public static final Feature d;
  
  public static final Feature[] e;
  
  static {
    Feature feature1 = new Feature("wearable_services", 1L);
    a = feature1;
    Feature feature2 = new Feature("carrier_auth", 1L);
    b = feature2;
    Feature feature3 = new Feature("wear3_oem_companion", 1L);
    c = feature3;
    Feature feature4 = new Feature("wear_fast_pair_account_key_sync", 1L);
    d = feature4;
    e = new Feature[] { feature1, feature2, feature3, feature4 };
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */