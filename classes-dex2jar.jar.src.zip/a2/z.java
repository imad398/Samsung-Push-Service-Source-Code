package a2;

import com.google.android.gms.wearable.internal.zzfj;

public final class z implements Runnable {
  public z(g0 paramg0, zzfj paramzzfj) {}
  
  public final void run() {
    this.b.b.m((i)this.a);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */