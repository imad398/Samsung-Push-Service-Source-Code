package a2;

import com.google.android.gms.wearable.internal.zzi;

public final class f0 implements Runnable {
  public f0(g0 paramg0, zzi paramzzi) {}
  
  public final void run() {
    this.b.b.k((m)this.a);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */