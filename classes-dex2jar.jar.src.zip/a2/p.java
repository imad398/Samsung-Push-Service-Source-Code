package a2;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.wearable.ConnectionConfiguration;
import h1.a;

public final class p implements Parcelable.Creator {}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */