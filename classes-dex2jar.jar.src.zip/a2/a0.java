package a2;

import com.google.android.gms.wearable.internal.zzfw;

public final class a0 implements Runnable {
  public a0(g0 paramg0, zzfw paramzzfw) {}
  
  public final void run() {
    this.b.b.p((j)this.a);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */