package a2;

import com.google.android.gms.common.data.DataHolder;

public final class y implements Runnable {
  public y(g0 paramg0, DataHolder paramDataHolder) {}
  
  public final void run() {
    d d = new d(this.a);
    try {
      this.b.b.j(d);
      return;
    } finally {
      d.a();
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/a2/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */