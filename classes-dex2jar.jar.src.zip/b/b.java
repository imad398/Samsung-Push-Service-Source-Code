package b;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class b extends c {
  public final Object a = new Object();
  
  public final ExecutorService b = Executors.newFixedThreadPool(2, new a(this));
  
  public volatile Handler c;
  
  public void a(Runnable paramRunnable) {
    this.b.execute(paramRunnable);
  }
  
  public boolean b() {
    boolean bool;
    if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void c(Runnable paramRunnable) {
    if (this.c == null)
      synchronized (this.a) {
        if (this.c == null) {
          Handler handler = new Handler();
          this(Looper.getMainLooper());
          this.c = handler;
        } 
      }  
    this.c.post(paramRunnable);
  }
  
  public class a implements ThreadFactory {
    public final AtomicInteger a = new AtomicInteger(0);
    
    public a(b this$0) {}
    
    public Thread newThread(Runnable param1Runnable) {
      param1Runnable = new Thread(param1Runnable);
      param1Runnable.setName(String.format("arch_disk_io_%d", new Object[] { Integer.valueOf(this.a.getAndIncrement()) }));
      return (Thread)param1Runnable;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */