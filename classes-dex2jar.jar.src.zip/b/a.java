package b;

import java.util.concurrent.Executor;

public class a extends c {
  public static volatile a c;
  
  public static final Executor d = new a();
  
  public static final Executor e = new b();
  
  public c a;
  
  public c b;
  
  public a() {
    b b = new b();
    this.b = b;
    this.a = b;
  }
  
  public static Executor d() {
    return e;
  }
  
  public static a e() {
    // Byte code:
    //   0: getstatic b/a.c : Lb/a;
    //   3: ifnull -> 10
    //   6: getstatic b/a.c : Lb/a;
    //   9: areturn
    //   10: ldc b/a
    //   12: monitorenter
    //   13: getstatic b/a.c : Lb/a;
    //   16: ifnonnull -> 31
    //   19: new b/a
    //   22: astore_0
    //   23: aload_0
    //   24: invokespecial <init> : ()V
    //   27: aload_0
    //   28: putstatic b/a.c : Lb/a;
    //   31: ldc b/a
    //   33: monitorexit
    //   34: getstatic b/a.c : Lb/a;
    //   37: areturn
    //   38: astore_0
    //   39: ldc b/a
    //   41: monitorexit
    //   42: aload_0
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   13	31	38	finally
    //   31	34	38	finally
    //   39	42	38	finally
  }
  
  public void a(Runnable paramRunnable) {
    this.a.a(paramRunnable);
  }
  
  public boolean b() {
    return this.a.b();
  }
  
  public void c(Runnable paramRunnable) {
    this.a.c(paramRunnable);
  }
  
  public static final class a implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().c(param1Runnable);
    }
  }
  
  public static final class b implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().a(param1Runnable);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */