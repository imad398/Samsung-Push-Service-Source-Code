package c;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class b implements Iterable {
  public WeakHashMap a = new WeakHashMap<Object, Object>();
  
  public int b = 0;
  
  public Map.Entry a() {
    return null;
  }
  
  public c b() {
    c c = new c(this);
    this.a.put(c, Boolean.FALSE);
    return c;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof b))
      return false; 
    b b1 = (b)paramObject;
    if (size() != b1.size())
      return false; 
    paramObject = iterator();
    Iterator<b> iterator = b1.iterator();
    while (paramObject.hasNext() && iterator.hasNext()) {
      Map.Entry entry = paramObject.next();
      b1 = iterator.next();
      if ((entry == null && b1 != null) || (entry != null && !entry.equals(b1)))
        return false; 
    } 
    if (paramObject.hasNext() || iterator.hasNext())
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    Iterator<Map.Entry> iterator = iterator();
    int i;
    for (i = 0; iterator.hasNext(); i += ((Map.Entry)iterator.next()).hashCode());
    return i;
  }
  
  public Iterator iterator() {
    a a = new a(null, null);
    this.a.put(a, Boolean.FALSE);
    return a;
  }
  
  public int size() {
    return this.b;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    Iterator<Map.Entry> iterator = iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(((Map.Entry)iterator.next()).toString());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  public static class a extends d {
    public a(b.b param1b1, b.b param1b2) {
      super(param1b1, param1b2);
    }
  }
  
  public static abstract class b implements Map.Entry {}
  
  public class c implements Iterator {
    public boolean a = true;
    
    public c(b this$0) {}
    
    public Map.Entry b() {
      if (this.a) {
        this.a = false;
        this.b.getClass();
      } 
      return null;
    }
    
    public boolean hasNext() {
      if (this.a)
        this.b.getClass(); 
      return false;
    }
  }
  
  public static abstract class d implements Iterator {
    public d(b.b param1b1, b.b param1b2) {}
    
    public Map.Entry b() {
      c();
      return null;
    }
    
    public final b.b c() {
      return null;
    }
    
    public boolean hasNext() {
      return false;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */