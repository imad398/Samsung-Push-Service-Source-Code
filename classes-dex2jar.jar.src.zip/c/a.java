package c;

import java.util.HashMap;

public class a extends b {
  public HashMap c = new HashMap<Object, Object>();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */