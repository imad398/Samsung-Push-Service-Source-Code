package c4;

public enum d {
  b(-1),
  c(1),
  d(2);
  
  public final int a;
  
  d(int paramInt1) {
    this.a = paramInt1;
  }
  
  public static d c(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? b : d) : c;
  }
  
  public int b() {
    return this.a;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c4/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */