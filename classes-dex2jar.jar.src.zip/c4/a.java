package c4;

public abstract class a {
  public static int accessibility_action_clickable_span = 2131099648;
  
  public static int accessibility_custom_action_0 = 2131099649;
  
  public static int accessibility_custom_action_1 = 2131099650;
  
  public static int accessibility_custom_action_10 = 2131099651;
  
  public static int accessibility_custom_action_11 = 2131099652;
  
  public static int accessibility_custom_action_12 = 2131099653;
  
  public static int accessibility_custom_action_13 = 2131099654;
  
  public static int accessibility_custom_action_14 = 2131099655;
  
  public static int accessibility_custom_action_15 = 2131099656;
  
  public static int accessibility_custom_action_16 = 2131099657;
  
  public static int accessibility_custom_action_17 = 2131099658;
  
  public static int accessibility_custom_action_18 = 2131099659;
  
  public static int accessibility_custom_action_19 = 2131099660;
  
  public static int accessibility_custom_action_2 = 2131099661;
  
  public static int accessibility_custom_action_20 = 2131099662;
  
  public static int accessibility_custom_action_21 = 2131099663;
  
  public static int accessibility_custom_action_22 = 2131099664;
  
  public static int accessibility_custom_action_23 = 2131099665;
  
  public static int accessibility_custom_action_24 = 2131099666;
  
  public static int accessibility_custom_action_25 = 2131099667;
  
  public static int accessibility_custom_action_26 = 2131099668;
  
  public static int accessibility_custom_action_27 = 2131099669;
  
  public static int accessibility_custom_action_28 = 2131099670;
  
  public static int accessibility_custom_action_29 = 2131099671;
  
  public static int accessibility_custom_action_3 = 2131099672;
  
  public static int accessibility_custom_action_30 = 2131099673;
  
  public static int accessibility_custom_action_31 = 2131099674;
  
  public static int accessibility_custom_action_4 = 2131099675;
  
  public static int accessibility_custom_action_5 = 2131099676;
  
  public static int accessibility_custom_action_6 = 2131099677;
  
  public static int accessibility_custom_action_7 = 2131099678;
  
  public static int accessibility_custom_action_8 = 2131099679;
  
  public static int accessibility_custom_action_9 = 2131099680;
  
  public static int action0 = 2131099681;
  
  public static int action_container = 2131099682;
  
  public static int action_divider = 2131099683;
  
  public static int action_image = 2131099684;
  
  public static int action_text = 2131099685;
  
  public static int actions = 2131099686;
  
  public static int adjust_height = 2131099687;
  
  public static int adjust_width = 2131099688;
  
  public static int async = 2131099691;
  
  public static int auto = 2131099692;
  
  public static int blocking = 2131099694;
  
  public static int bottom = 2131099695;
  
  public static int browser_actions_header_text = 2131099696;
  
  public static int browser_actions_menu_item_icon = 2131099697;
  
  public static int browser_actions_menu_item_text = 2131099698;
  
  public static int browser_actions_menu_items = 2131099699;
  
  public static int browser_actions_menu_view = 2131099700;
  
  public static int btnAggregation = 2131099701;
  
  public static int btnAppUsage = 2131099702;
  
  public static int btnBasic = 2131099703;
  
  public static int btnCheckAppUsage = 2131099705;
  
  public static int btnCheckAppUsageAggr = 2131099706;
  
  public static int btnCollection = 2131099707;
  
  public static int btnConnection = 2131099708;
  
  public static int btnFolder = 2131099716;
  
  public static int btnForceCollect = 2131099717;
  
  public static int btnGenMaxDateData = 2131099719;
  
  public static int btnGenMaxSizeData = 2131099720;
  
  public static int btnInstall = 2131099722;
  
  public static int btnInstallFull = 2131099723;
  
  public static int btnLastCollectDate = 2131099725;
  
  public static int btnLocal = 2131099726;
  
  public static int btnLost = 2131099727;
  
  public static int btnNetworkUsage = 2131099728;
  
  public static int btnPolicy = 2131099729;
  
  public static int btnStartRuna = 2131099751;
  
  public static int btnStopRuna = 2131099752;
  
  public static int btnWifiPriorityTime = 2131099754;
  
  public static int cancel_action = 2131099756;
  
  public static int checkboxOnRunaDebug = 2131099760;
  
  public static int checkboxOnRunaFileDebug = 2131099761;
  
  public static int chronometer = 2131099762;
  
  public static int dark = 2131099765;
  
  public static int dataProgressBar = 2131099766;
  
  public static int dialog_button = 2131099767;
  
  public static int end = 2131099769;
  
  public static int end_padder = 2131099770;
  
  public static int forever = 2131099775;
  
  public static int historyProgressBar = 2131099776;
  
  public static int icon = 2131099777;
  
  public static int icon_group = 2131099778;
  
  public static int icon_only = 2131099779;
  
  public static int info = 2131099780;
  
  public static int italic = 2131099781;
  
  public static int itemTitle = 2131099782;
  
  public static int item_touch_helper_previous_elevation = 2131099783;
  
  public static int lastCollectEditText = 2131099784;
  
  public static int left = 2131099785;
  
  public static int light = 2131099786;
  
  public static int line1 = 2131099787;
  
  public static int line3 = 2131099788;
  
  public static int loadButton = 2131099789;
  
  public static int media_actions = 2131099791;
  
  public static int none = 2131099792;
  
  public static int normal = 2131099793;
  
  public static int notification_background = 2131099794;
  
  public static int notification_main_column = 2131099795;
  
  public static int notification_main_column_container = 2131099796;
  
  public static int resetButton = 2131099821;
  
  public static int right = 2131099823;
  
  public static int right_icon = 2131099824;
  
  public static int right_side = 2131099825;
  
  public static int runaServer = 2131099826;
  
  public static int runa_collect_list = 2131099828;
  
  public static int runa_detail_list = 2131099829;
  
  public static int saveButton = 2131099830;
  
  public static int standard = 2131099839;
  
  public static int start = 2131099840;
  
  public static int stateAggr = 2131099841;
  
  public static int stateAppUsage = 2131099842;
  
  public static int stateConn = 2131099843;
  
  public static int stateFolder = 2131099844;
  
  public static int stateInstall = 2131099845;
  
  public static int stateIpCollect = 2131099846;
  
  public static int stateNetworkUsage = 2131099847;
  
  public static int stateWifi = 2131099848;
  
  public static int status_bar_latest_event_content = 2131099849;
  
  public static int switchAggr = 2131099850;
  
  public static int switchConn = 2131099851;
  
  public static int switchFolder = 2131099852;
  
  public static int switchInstall = 2131099853;
  
  public static int switchIpCollect = 2131099854;
  
  public static int switchNetworkUsage = 2131099855;
  
  public static int switchUsage = 2131099856;
  
  public static int switchWifi = 2131099857;
  
  public static int tag_accessibility_actions = 2131099859;
  
  public static int tag_accessibility_clickable_spans = 2131099860;
  
  public static int tag_accessibility_heading = 2131099861;
  
  public static int tag_accessibility_pane_title = 2131099862;
  
  public static int tag_screen_reader_focusable = 2131099863;
  
  public static int tag_transition_group = 2131099864;
  
  public static int tag_unhandled_key_event_manager = 2131099865;
  
  public static int tag_unhandled_key_listeners = 2131099866;
  
  public static int testTextView = 2131099867;
  
  public static int text = 2131099868;
  
  public static int text2 = 2131099869;
  
  public static int textAllowList = 2131099870;
  
  public static int textAllowListWild = 2131099871;
  
  public static int textBlockList = 2131099872;
  
  public static int textBlockListWild = 2131099873;
  
  public static int textDataSync = 2131099874;
  
  public static int textPolicyNum = 2131099875;
  
  public static int textRunaVer = 2131099876;
  
  public static int textUploadPeriod = 2131099877;
  
  public static int time = 2131099878;
  
  public static int title = 2131099879;
  
  public static int top = 2131099880;
  
  public static int tvData0 = 2131099881;
  
  public static int tvData1 = 2131099882;
  
  public static int tvData2 = 2131099883;
  
  public static int tvData3 = 2131099884;
  
  public static int tvData4 = 2131099885;
  
  public static int tvDataSize = 2131099886;
  
  public static int tvDate = 2131099887;
  
  public static int tvNextUploadTime = 2131099888;
  
  public static int tvResult = 2131099889;
  
  public static int tvSize = 2131099890;
  
  public static int usageDateEditText = 2131099893;
  
  public static int wide = 2131099898;
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c4/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */