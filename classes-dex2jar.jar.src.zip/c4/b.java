package c4;

public abstract class b {
  public static int activity_runa = 2131230720;
  
  public static int activity_runa_appusage = 2131230721;
  
  public static int activity_runa_collect_info = 2131230722;
  
  public static int activity_runa_policy = 2131230723;
  
  public static int browser_actions_context_menu_page = 2131230727;
  
  public static int browser_actions_context_menu_row = 2131230728;
  
  public static int custom_dialog = 2131230729;
  
  public static int notification_action = 2131230735;
  
  public static int notification_action_tombstone = 2131230736;
  
  public static int notification_media_action = 2131230737;
  
  public static int notification_media_cancel_action = 2131230738;
  
  public static int notification_template_big_media = 2131230739;
  
  public static int notification_template_big_media_custom = 2131230740;
  
  public static int notification_template_big_media_narrow = 2131230741;
  
  public static int notification_template_big_media_narrow_custom = 2131230742;
  
  public static int notification_template_custom_big = 2131230743;
  
  public static int notification_template_icon_group = 2131230744;
  
  public static int notification_template_lines_media = 2131230745;
  
  public static int notification_template_media = 2131230746;
  
  public static int notification_template_media_custom = 2131230747;
  
  public static int notification_template_part_chronometer = 2131230748;
  
  public static int notification_template_part_time = 2131230749;
  
  public static int runa_collect_item_layout = 2131230755;
  
  public static int runa_detail_item_layout = 2131230756;
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c4/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */