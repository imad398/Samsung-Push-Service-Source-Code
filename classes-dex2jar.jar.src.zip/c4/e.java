package c4;

public enum e {
  b(-1),
  c(0),
  d(1),
  e(2),
  f(3);
  
  public final int a;
  
  e(int paramInt1) {
    this.a = paramInt1;
  }
  
  public int b() {
    return this.a;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c4/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */