package c4;

public abstract class c {
  public static String a(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? "UNKNOWN" : "UPDATE") : "REMOVE") : "INSTALL";
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/c4/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */