package b3;

import java.math.BigDecimal;

public final class f extends Number {
  public final String a;
  
  public f(String paramString) {
    this.a = paramString;
  }
  
  public double doubleValue() {
    return Double.parseDouble(this.a);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof f) {
      f f1 = (f)paramObject;
      paramObject = this.a;
      String str = f1.a;
      boolean bool1 = bool;
      if (paramObject != str)
        if (paramObject.equals(str)) {
          bool1 = bool;
        } else {
          bool1 = false;
        }  
      return bool1;
    } 
    return false;
  }
  
  public float floatValue() {
    return Float.parseFloat(this.a);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public int intValue() {
    try {
      return Integer.parseInt(this.a);
    } catch (NumberFormatException numberFormatException) {
      try {
        long l = Long.parseLong(this.a);
        return (int)l;
      } catch (NumberFormatException numberFormatException1) {
        return (new BigDecimal(this.a)).intValue();
      } 
    } 
  }
  
  public long longValue() {
    try {
      return Long.parseLong(this.a);
    } catch (NumberFormatException numberFormatException) {
      return (new BigDecimal(this.a)).longValue();
    } 
  }
  
  public String toString() {
    return this.a;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */