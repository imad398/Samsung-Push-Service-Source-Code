package b3;

public abstract class a {
  public static void a(boolean paramBoolean) {
    if (paramBoolean)
      return; 
    throw new IllegalArgumentException();
  }
  
  public static Object b(Object paramObject) {
    paramObject.getClass();
    return paramObject;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */