package b3;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public final class g extends AbstractMap implements Serializable {
  public static final Comparator h = new a();
  
  public Comparator a;
  
  public e b;
  
  public int c = 0;
  
  public int d = 0;
  
  public final e e = new e();
  
  public b f;
  
  public c g;
  
  public g() {
    this(h);
  }
  
  public g(Comparator paramComparator) {
    if (paramComparator == null)
      paramComparator = h; 
    this.a = paramComparator;
  }
  
  public final boolean a(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2)));
  }
  
  public e b(Object paramObject, boolean paramBoolean) {
    boolean bool;
    Comparator<Object> comparator = this.a;
    Object object = this.b;
    if (object != null) {
      Comparable<Object> comparable;
      if (comparator == h) {
        comparable = (Comparable)paramObject;
      } else {
        comparable = null;
      } 
      while (true) {
        Object object1 = ((e)object).f;
        if (comparable != null) {
          bool = comparable.compareTo(object1);
        } else {
          bool = comparator.compare(paramObject, object1);
        } 
        if (bool == 0)
          return (e)object; 
        if (bool < 0) {
          object1 = ((e)object).b;
        } else {
          object1 = ((e)object).c;
        } 
        if (object1 == null)
          break; 
        object = object1;
      } 
    } else {
      bool = false;
    } 
    if (!paramBoolean)
      return null; 
    e e1 = this.e;
    if (object == null) {
      if (comparator != h || paramObject instanceof Comparable) {
        paramObject = new e((e)object, paramObject, e1, e1.e);
        this.b = (e)paramObject;
        this.c++;
        this.d++;
        return (e)paramObject;
      } 
      object = new StringBuilder();
      object.append(paramObject.getClass().getName());
      object.append(" is not Comparable");
      throw new ClassCastException(object.toString());
    } 
    paramObject = new e((e)object, paramObject, e1, e1.e);
    if (bool) {
      ((e)object).b = (e)paramObject;
    } else {
      ((e)object).c = (e)paramObject;
    } 
    e((e)object, true);
    this.c++;
    this.d++;
    return (e)paramObject;
  }
  
  public e c(Map.Entry paramEntry) {
    boolean bool;
    e e1 = d(paramEntry.getKey());
    if (e1 != null && a(e1.g, paramEntry.getValue())) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramEntry = e1;
    } else {
      paramEntry = null;
    } 
    return (e)paramEntry;
  }
  
  public void clear() {
    this.b = null;
    this.c = 0;
    this.d++;
    e e1 = this.e;
    e1.e = e1;
    e1.d = e1;
  }
  
  public boolean containsKey(Object paramObject) {
    boolean bool;
    if (d(paramObject) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public e d(Object paramObject) {
    e e1 = null;
    e e2 = e1;
    if (paramObject != null)
      try {
        e2 = b(paramObject, false);
      } catch (ClassCastException classCastException) {
        e2 = e1;
      }  
    return e2;
  }
  
  public final void e(e parame, boolean paramBoolean) {
    while (parame != null) {
      int i;
      int j;
      e e1 = parame.b;
      e e2 = parame.c;
      boolean bool = false;
      byte b1 = 0;
      if (e1 != null) {
        i = e1.h;
      } else {
        i = 0;
      } 
      if (e2 != null) {
        j = e2.h;
      } else {
        j = 0;
      } 
      int k = i - j;
      if (k == -2) {
        e1 = e2.b;
        e e3 = e2.c;
        if (e3 != null) {
          i = e3.h;
        } else {
          i = 0;
        } 
        j = b1;
        if (e1 != null)
          j = e1.h; 
        i = j - i;
        if (i != -1 && (i != 0 || paramBoolean))
          j(e2); 
        i(parame);
        if (paramBoolean)
          break; 
      } else if (k == 2) {
        e e3 = e1.b;
        e2 = e1.c;
        if (e2 != null) {
          i = e2.h;
        } else {
          i = 0;
        } 
        j = bool;
        if (e3 != null)
          j = e3.h; 
        i = j - i;
        if (i != 1 && (i != 0 || paramBoolean))
          i(e1); 
        j(parame);
        if (paramBoolean)
          break; 
      } else if (k == 0) {
        parame.h = i + 1;
        if (paramBoolean)
          break; 
      } else {
        parame.h = Math.max(i, j) + 1;
        if (!paramBoolean)
          break; 
      } 
      parame = parame.a;
    } 
  }
  
  public Set entrySet() {
    b b1 = this.f;
    if (b1 == null) {
      b1 = new b(this);
      this.f = b1;
    } 
    return b1;
  }
  
  public void f(e parame, boolean paramBoolean) {
    if (paramBoolean) {
      e e4 = parame.e;
      e4.d = parame.d;
      parame.d.e = e4;
    } 
    e e1 = parame.b;
    e e2 = parame.c;
    e e3 = parame.a;
    int i = 0;
    if (e1 != null && e2 != null) {
      boolean bool;
      if (e1.h > e2.h) {
        e1 = e1.b();
      } else {
        e1 = e2.a();
      } 
      f(e1, false);
      e3 = parame.b;
      if (e3 != null) {
        bool = e3.h;
        e1.b = e3;
        e3.a = e1;
        parame.b = null;
      } else {
        bool = false;
      } 
      e3 = parame.c;
      if (e3 != null) {
        i = e3.h;
        e1.c = e3;
        e3.a = e1;
        parame.c = null;
      } 
      e1.h = Math.max(bool, i) + 1;
      h(parame, e1);
      return;
    } 
    if (e1 != null) {
      h(parame, e1);
      parame.b = null;
    } else if (e2 != null) {
      h(parame, e2);
      parame.c = null;
    } else {
      h(parame, null);
    } 
    e(e3, false);
    this.c--;
    this.d++;
  }
  
  public e g(Object paramObject) {
    paramObject = d(paramObject);
    if (paramObject != null)
      f((e)paramObject, true); 
    return (e)paramObject;
  }
  
  public Object get(Object paramObject) {
    paramObject = d(paramObject);
    if (paramObject != null) {
      paramObject = ((e)paramObject).g;
    } else {
      paramObject = null;
    } 
    return paramObject;
  }
  
  public final void h(e parame1, e parame2) {
    e e1 = parame1.a;
    parame1.a = null;
    if (parame2 != null)
      parame2.a = e1; 
    if (e1 != null) {
      if (e1.b == parame1) {
        e1.b = parame2;
      } else {
        e1.c = parame2;
      } 
    } else {
      this.b = parame2;
    } 
  }
  
  public final void i(e parame) {
    e e1 = parame.b;
    e e2 = parame.c;
    e e3 = e2.b;
    e e4 = e2.c;
    parame.c = e3;
    if (e3 != null)
      e3.a = parame; 
    h(parame, e2);
    e2.b = parame;
    parame.a = e2;
    byte b1 = 0;
    if (e1 != null) {
      i = e1.h;
    } else {
      i = 0;
    } 
    if (e3 != null) {
      j = e3.h;
    } else {
      j = 0;
    } 
    int j = Math.max(i, j) + 1;
    parame.h = j;
    int i = b1;
    if (e4 != null)
      i = e4.h; 
    e2.h = Math.max(j, i) + 1;
  }
  
  public final void j(e parame) {
    e e1 = parame.b;
    e e2 = parame.c;
    e e3 = e1.b;
    e e4 = e1.c;
    parame.b = e4;
    if (e4 != null)
      e4.a = parame; 
    h(parame, e1);
    e1.c = parame;
    parame.a = e1;
    byte b1 = 0;
    if (e2 != null) {
      i = e2.h;
    } else {
      i = 0;
    } 
    if (e4 != null) {
      j = e4.h;
    } else {
      j = 0;
    } 
    int j = Math.max(i, j) + 1;
    parame.h = j;
    int i = b1;
    if (e3 != null)
      i = e3.h; 
    e1.h = Math.max(j, i) + 1;
  }
  
  public Set keySet() {
    c c1 = this.g;
    if (c1 == null) {
      c1 = new c(this);
      this.g = c1;
    } 
    return c1;
  }
  
  public Object put(Object paramObject1, Object paramObject2) {
    if (paramObject1 != null) {
      e e1 = b(paramObject1, true);
      paramObject1 = e1.g;
      e1.g = paramObject2;
      return paramObject1;
    } 
    throw new NullPointerException("key == null");
  }
  
  public Object remove(Object paramObject) {
    paramObject = g(paramObject);
    if (paramObject != null) {
      paramObject = ((e)paramObject).g;
    } else {
      paramObject = null;
    } 
    return paramObject;
  }
  
  public int size() {
    return this.c;
  }
  
  public static final class a implements Comparator {
    public int a(Comparable<Comparable> param1Comparable1, Comparable param1Comparable2) {
      return param1Comparable1.compareTo(param1Comparable2);
    }
  }
  
  public class b extends AbstractSet {
    public b(g this$0) {}
    
    public void clear() {
      this.a.clear();
    }
    
    public boolean contains(Object param1Object) {
      boolean bool;
      if (param1Object instanceof Map.Entry && this.a.c((Map.Entry)param1Object) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public Iterator iterator() {
      return new a(this);
    }
    
    public boolean remove(Object param1Object) {
      if (!(param1Object instanceof Map.Entry))
        return false; 
      param1Object = this.a.c((Map.Entry)param1Object);
      if (param1Object == null)
        return false; 
      this.a.f((g.e)param1Object, true);
      return true;
    }
    
    public int size() {
      return this.a.c;
    }
    
    public class a extends g.d {
      public a(g.b this$0) {
        super(this$0.a);
      }
      
      public Map.Entry c() {
        return b();
      }
    }
  }
  
  public class a extends d {
    public a(g this$0) {
      super(((g.b)this$0).a);
    }
    
    public Map.Entry c() {
      return b();
    }
  }
  
  public final class c extends AbstractSet {
    public c(g this$0) {}
    
    public void clear() {
      this.a.clear();
    }
    
    public boolean contains(Object param1Object) {
      return this.a.containsKey(param1Object);
    }
    
    public Iterator iterator() {
      return new a(this);
    }
    
    public boolean remove(Object param1Object) {
      boolean bool;
      if (this.a.g(param1Object) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int size() {
      return this.a.c;
    }
    
    public class a extends g.d {
      public a(g.c this$0) {
        super(this$0.a);
      }
      
      public Object next() {
        return (b()).f;
      }
    }
  }
  
  public class a extends d {
    public a(g this$0) {
      super(((g.c)this$0).a);
    }
    
    public Object next() {
      return (b()).f;
    }
  }
  
  public abstract class d implements Iterator {
    public g.e a;
    
    public g.e b;
    
    public int c;
    
    public d(g this$0) {
      this.a = this$0.e.d;
      this.b = null;
      this.c = this$0.d;
    }
    
    public final g.e b() {
      g.e e1 = this.a;
      g g1 = this.d;
      if (e1 != g1.e) {
        if (g1.d == this.c) {
          this.a = e1.d;
          this.b = e1;
          return e1;
        } 
        throw new ConcurrentModificationException();
      } 
      throw new NoSuchElementException();
    }
    
    public final boolean hasNext() {
      boolean bool;
      if (this.a != this.d.e) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public final void remove() {
      g.e e1 = this.b;
      if (e1 != null) {
        this.d.f(e1, true);
        this.b = null;
        this.c = this.d.d;
        return;
      } 
      throw new IllegalStateException();
    }
  }
  
  public static final class e implements Map.Entry {
    public e a;
    
    public e b;
    
    public e c;
    
    public e d;
    
    public e e;
    
    public final Object f;
    
    public Object g;
    
    public int h;
    
    public e() {
      this.f = null;
      this.e = this;
      this.d = this;
    }
    
    public e(e param1e1, Object param1Object, e param1e2, e param1e3) {
      this.a = param1e1;
      this.f = param1Object;
      this.h = 1;
      this.d = param1e2;
      this.e = param1e3;
      param1e3.d = this;
      param1e2.e = this;
    }
    
    public e a() {
      e e1 = this.b;
      e e2 = this;
      while (e1 != null) {
        e e3 = e1.b;
        e2 = e1;
        e1 = e3;
      } 
      return e2;
    }
    
    public e b() {
      e e1 = this.c;
      e e2 = this;
      while (e1 != null) {
        e e3 = e1.c;
        e2 = e1;
        e1 = e3;
      } 
      return e2;
    }
    
    public boolean equals(Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: instanceof java/util/Map$Entry
      //   4: istore_2
      //   5: iconst_0
      //   6: istore_3
      //   7: iload_3
      //   8: istore #4
      //   10: iload_2
      //   11: ifeq -> 105
      //   14: aload_1
      //   15: checkcast java/util/Map$Entry
      //   18: astore_1
      //   19: aload_0
      //   20: getfield f : Ljava/lang/Object;
      //   23: astore #5
      //   25: aload #5
      //   27: ifnonnull -> 45
      //   30: iload_3
      //   31: istore #4
      //   33: aload_1
      //   34: invokeinterface getKey : ()Ljava/lang/Object;
      //   39: ifnonnull -> 105
      //   42: goto -> 62
      //   45: iload_3
      //   46: istore #4
      //   48: aload #5
      //   50: aload_1
      //   51: invokeinterface getKey : ()Ljava/lang/Object;
      //   56: invokevirtual equals : (Ljava/lang/Object;)Z
      //   59: ifeq -> 105
      //   62: aload_0
      //   63: getfield g : Ljava/lang/Object;
      //   66: astore #5
      //   68: aload_1
      //   69: invokeinterface getValue : ()Ljava/lang/Object;
      //   74: astore_1
      //   75: aload #5
      //   77: ifnonnull -> 90
      //   80: iload_3
      //   81: istore #4
      //   83: aload_1
      //   84: ifnonnull -> 105
      //   87: goto -> 102
      //   90: iload_3
      //   91: istore #4
      //   93: aload #5
      //   95: aload_1
      //   96: invokevirtual equals : (Ljava/lang/Object;)Z
      //   99: ifeq -> 105
      //   102: iconst_1
      //   103: istore #4
      //   105: iload #4
      //   107: ireturn
    }
    
    public Object getKey() {
      return this.f;
    }
    
    public Object getValue() {
      return this.g;
    }
    
    public int hashCode() {
      int j;
      Object object = this.f;
      int i = 0;
      if (object == null) {
        j = 0;
      } else {
        j = object.hashCode();
      } 
      object = this.g;
      if (object != null)
        i = object.hashCode(); 
      return j ^ i;
    }
    
    public Object setValue(Object param1Object) {
      Object object = this.g;
      this.g = param1Object;
      return object;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.f);
      stringBuilder.append("=");
      stringBuilder.append(this.g);
      return stringBuilder.toString();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */