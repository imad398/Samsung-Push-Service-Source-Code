package b3;

import c3.l;
import e3.c;
import java.io.Writer;
import z2.f;

public abstract class j {
  public static void a(f paramf, c paramc) {
    l.X.d(paramc, paramf);
  }
  
  public static Writer b(Appendable paramAppendable) {
    if (paramAppendable instanceof Writer) {
      paramAppendable = paramAppendable;
    } else {
      paramAppendable = new a(paramAppendable);
    } 
    return (Writer)paramAppendable;
  }
  
  public static final class a extends Writer {
    public final Appendable a;
    
    public final a b = new a();
    
    public a(Appendable param1Appendable) {
      this.a = param1Appendable;
    }
    
    public void close() {}
    
    public void flush() {}
    
    public void write(int param1Int) {
      this.a.append((char)param1Int);
    }
    
    public void write(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
      a a1 = this.b;
      a1.a = param1ArrayOfchar;
      this.a.append(a1, param1Int1, param1Int2 + param1Int1);
    }
    
    public static class a implements CharSequence {
      public char[] a;
      
      public char charAt(int param2Int) {
        return this.a[param2Int];
      }
      
      public int length() {
        return this.a.length;
      }
      
      public CharSequence subSequence(int param2Int1, int param2Int2) {
        return new String(this.a, param2Int1, param2Int2 - param2Int1);
      }
    }
  }
  
  public static class a implements CharSequence {
    public char[] a;
    
    public char charAt(int param1Int) {
      return this.a[param1Int];
    }
    
    public int length() {
      return this.a.length;
    }
    
    public CharSequence subSequence(int param1Int1, int param1Int2) {
      return new String(this.a, param1Int1, param1Int2 - param1Int1);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */