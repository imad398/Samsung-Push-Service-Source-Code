package b3;

import a3.e;
import com.google.gson.reflect.TypeToken;
import e3.c;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import z2.n;
import z2.o;

public final class d implements o, Cloneable {
  public static final d g = new d();
  
  public double a = -1.0D;
  
  public int b = 136;
  
  public boolean c = true;
  
  public boolean d;
  
  public List e = Collections.emptyList();
  
  public List f = Collections.emptyList();
  
  public n a(z2.d paramd, TypeToken paramTypeToken) {
    Class clazz = paramTypeToken.getRawType();
    boolean bool1 = d(clazz, true);
    boolean bool2 = d(clazz, false);
    return (!bool1 && !bool2) ? null : new a(this, bool2, bool1, paramd, paramTypeToken);
  }
  
  public d b() {
    try {
      return (d)super.clone();
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public boolean d(Class paramClass, boolean paramBoolean) {
    List list;
    if (this.a != -1.0D && !l((a3.d)paramClass.getAnnotation(a3.d.class), (e)paramClass.getAnnotation(e.class)))
      return true; 
    if (!this.c && h(paramClass))
      return true; 
    if (g(paramClass))
      return true; 
    if (paramBoolean) {
      list = this.e;
    } else {
      list = this.f;
    } 
    Iterator iterator = list.iterator();
    if (!iterator.hasNext())
      return false; 
    android.support.v4.media.a.a(iterator.next());
    throw null;
  }
  
  public boolean f(Field paramField, boolean paramBoolean) {
    List list;
    if ((this.b & paramField.getModifiers()) != 0)
      return true; 
    if (this.a != -1.0D && !l(paramField.<a3.d>getAnnotation(a3.d.class), paramField.<e>getAnnotation(e.class)))
      return true; 
    if (paramField.isSynthetic())
      return true; 
    if (this.d) {
      a3.a a = paramField.<a3.a>getAnnotation(a3.a.class);
      if (a == null || (paramBoolean ? !a.serialize() : !a.deserialize()))
        return true; 
    } 
    if (!this.c && h(paramField.getType()))
      return true; 
    if (g(paramField.getType()))
      return true; 
    if (paramBoolean) {
      list = this.e;
    } else {
      list = this.f;
    } 
    if (!list.isEmpty()) {
      new z2.a(paramField);
      Iterator iterator = list.iterator();
      if (iterator.hasNext()) {
        android.support.v4.media.a.a(iterator.next());
        throw null;
      } 
    } 
    return false;
  }
  
  public final boolean g(Class<?> paramClass) {
    boolean bool;
    if (!Enum.class.isAssignableFrom(paramClass) && (paramClass.isAnonymousClass() || paramClass.isLocalClass())) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean h(Class paramClass) {
    boolean bool;
    if (paramClass.isMemberClass() && !i(paramClass)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean i(Class paramClass) {
    boolean bool;
    if ((paramClass.getModifiers() & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean j(a3.d paramd) {
    return !(paramd != null && paramd.value() > this.a);
  }
  
  public final boolean k(e parame) {
    return !(parame != null && parame.value() <= this.a);
  }
  
  public final boolean l(a3.d paramd, e parame) {
    boolean bool;
    if (j(paramd) && k(parame)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public class a extends n {
    public n a;
    
    public a(d this$0, boolean param1Boolean1, boolean param1Boolean2, z2.d param1d, TypeToken param1TypeToken) {}
    
    public Object b(e3.a param1a) {
      if (this.b) {
        param1a.m0();
        return null;
      } 
      return e().b(param1a);
    }
    
    public void d(c param1c, Object param1Object) {
      if (this.c) {
        param1c.S();
        return;
      } 
      e().d(param1c, param1Object);
    }
    
    public final n e() {
      n n1 = this.a;
      if (n1 == null) {
        n1 = this.d.m(this.f, this.e);
        this.a = n1;
      } 
      return n1;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */