package b3;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class i {
  public static final Map a;
  
  public static final Map b;
  
  static {
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(16);
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(16);
    a(hashMap1, hashMap2, boolean.class, Boolean.class);
    a(hashMap1, hashMap2, byte.class, Byte.class);
    a(hashMap1, hashMap2, char.class, Character.class);
    a(hashMap1, hashMap2, double.class, Double.class);
    a(hashMap1, hashMap2, float.class, Float.class);
    a(hashMap1, hashMap2, int.class, Integer.class);
    a(hashMap1, hashMap2, long.class, Long.class);
    a(hashMap1, hashMap2, short.class, Short.class);
    a(hashMap1, hashMap2, void.class, Void.class);
    a = Collections.unmodifiableMap(hashMap1);
    b = Collections.unmodifiableMap(hashMap2);
  }
  
  public static void a(Map<Class<?>, Class<?>> paramMap1, Map<Class<?>, Class<?>> paramMap2, Class<?> paramClass1, Class<?> paramClass2) {
    paramMap1.put(paramClass1, paramClass2);
    paramMap2.put(paramClass2, paramClass1);
  }
  
  public static boolean b(Type paramType) {
    return a.containsKey(paramType);
  }
  
  public static Class c(Class paramClass) {
    Class clazz = (Class)a.get(a.b(paramClass));
    if (clazz != null)
      paramClass = clazz; 
    return paramClass;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */