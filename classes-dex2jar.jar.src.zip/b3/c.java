package b3;

import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public final class c {
  public final Map a;
  
  public c(Map paramMap) {
    this.a = paramMap;
  }
  
  public h a(TypeToken paramTypeToken) {
    Type type = paramTypeToken.getType();
    Class clazz = paramTypeToken.getRawType();
    android.support.v4.media.a.a(this.a.get(type));
    android.support.v4.media.a.a(this.a.get(clazz));
    h h = b(clazz);
    if (h != null)
      return h; 
    h = c(type, clazz);
    return (h != null) ? h : d(type, clazz);
  }
  
  public final h b(Class paramClass) {
    try {
      Constructor constructor = paramClass.getDeclaredConstructor(new Class[0]);
      if (!constructor.isAccessible())
        constructor.setAccessible(true); 
      return new f(this, constructor);
    } catch (NoSuchMethodException noSuchMethodException) {
      return null;
    } 
  }
  
  public final h c(Type paramType, Class<?> paramClass) {
    return (h)(Collection.class.isAssignableFrom(paramClass) ? (SortedSet.class.isAssignableFrom(paramClass) ? new g(this) : (EnumSet.class.isAssignableFrom(paramClass) ? new h(this, paramType) : (Set.class.isAssignableFrom(paramClass) ? new i(this) : (Queue.class.isAssignableFrom(paramClass) ? new j(this) : new k(this))))) : (Map.class.isAssignableFrom(paramClass) ? (ConcurrentNavigableMap.class.isAssignableFrom(paramClass) ? new l(this) : (ConcurrentMap.class.isAssignableFrom(paramClass) ? new a(this) : (SortedMap.class.isAssignableFrom(paramClass) ? new b(this) : ((paramType instanceof ParameterizedType && !String.class.isAssignableFrom(TypeToken.get(((ParameterizedType)paramType).getActualTypeArguments()[0]).getRawType())) ? new c(this) : new d(this))))) : null));
  }
  
  public final h d(Type paramType, Class paramClass) {
    return new e(this, paramClass, paramType);
  }
  
  public String toString() {
    return this.a.toString();
  }
  
  public class a implements h {
    public a(c this$0) {}
    
    public Object a() {
      return new ConcurrentHashMap<Object, Object>();
    }
  }
  
  public class b implements h {
    public b(c this$0) {}
    
    public Object a() {
      return new TreeMap<Object, Object>();
    }
  }
  
  public class c implements h {
    public c(c this$0) {}
    
    public Object a() {
      return new LinkedHashMap<Object, Object>();
    }
  }
  
  public class d implements h {
    public d(c this$0) {}
    
    public Object a() {
      return new g();
    }
  }
  
  public class e implements h {
    public final k a = k.b();
    
    public e(c this$0, Class param1Class, Type param1Type) {}
    
    public Object a() {
      try {
        return this.a.c(this.b);
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to invoke no-args constructor for ");
        stringBuilder.append(this.c);
        stringBuilder.append(". ");
        stringBuilder.append("Register an InstanceCreator with Gson for this type may fix this problem.");
        throw new RuntimeException(stringBuilder.toString(), exception);
      } 
    }
  }
  
  public class f implements h {
    public f(c this$0, Constructor param1Constructor) {}
    
    public Object a() {
      try {
        return this.a.newInstance(null);
      } catch (InstantiationException instantiationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to invoke ");
        stringBuilder.append(this.a);
        stringBuilder.append(" with no args");
        throw new RuntimeException(stringBuilder.toString(), instantiationException);
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to invoke ");
        stringBuilder.append(this.a);
        stringBuilder.append(" with no args");
        throw new RuntimeException(stringBuilder.toString(), invocationTargetException.getTargetException());
      } catch (IllegalAccessException illegalAccessException) {
        throw new AssertionError(illegalAccessException);
      } 
    }
  }
  
  public class g implements h {
    public g(c this$0) {}
    
    public Object a() {
      return new TreeSet();
    }
  }
  
  public class h implements h {
    public h(c this$0, Type param1Type) {}
    
    public Object a() {
      Type type = this.a;
      if (type instanceof ParameterizedType) {
        type = ((ParameterizedType)type).getActualTypeArguments()[0];
        if (type instanceof Class)
          return EnumSet.noneOf((Class<Enum>)type); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Invalid EnumSet type: ");
        stringBuilder1.append(this.a.toString());
        throw new z2.g(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid EnumSet type: ");
      stringBuilder.append(this.a.toString());
      throw new z2.g(stringBuilder.toString());
    }
  }
  
  public class i implements h {
    public i(c this$0) {}
    
    public Object a() {
      return new LinkedHashSet();
    }
  }
  
  public class j implements h {
    public j(c this$0) {}
    
    public Object a() {
      return new ArrayDeque();
    }
  }
  
  public class k implements h {
    public k(c this$0) {}
    
    public Object a() {
      return new ArrayList();
    }
  }
  
  public class l implements h {
    public l(c this$0) {}
    
    public Object a() {
      return new ConcurrentSkipListMap<Object, Object>();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b3/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */