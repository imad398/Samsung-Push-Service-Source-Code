package b2;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.m;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.firebase.components.ComponentDiscoveryService;
import com.google.firebase.components.ComponentRegistrar;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.provider.FirebaseInitProvider;
import e2.g;
import e2.j;
import e2.o;
import e2.x;
import f2.b0;
import g1.z0;
import j1.o;
import j1.q;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import l.o;
import n2.f;

public class e {
  public static final Object k = new Object();
  
  public static final Map l = (Map)new f.a();
  
  public final Context a;
  
  public final String b;
  
  public final l c;
  
  public final o d;
  
  public final AtomicBoolean e = new AtomicBoolean(false);
  
  public final AtomicBoolean f = new AtomicBoolean();
  
  public final x g;
  
  public final p2.b h;
  
  public final List i = new CopyOnWriteArrayList();
  
  public final List j = new CopyOnWriteArrayList();
  
  public e(Context paramContext, String paramString, l paraml) {
    this.a = (Context)m.i(paramContext);
    this.b = m.e(paramString);
    this.c = (l)m.i(paraml);
    m m = FirebaseInitProvider.b();
    y2.c.b("Firebase");
    y2.c.b("ComponentDiscovery");
    List list = g.c(paramContext, ComponentDiscoveryService.class).b();
    y2.c.a();
    y2.c.b("Runtime");
    o.b b1 = o.k((Executor)b0.a).d(list).c((ComponentRegistrar)new FirebaseCommonRegistrar()).c((ComponentRegistrar)new ExecutorsRegistrar()).b(e2.c.s(paramContext, Context.class, new Class[0])).b(e2.c.s(this, e.class, new Class[0])).b(e2.c.s(paraml, l.class, new Class[0])).g((j)new y2.b());
    if (o.a(paramContext) && FirebaseInitProvider.c())
      b1.b(e2.c.s(m, m.class, new Class[0])); 
    o o1 = b1.e();
    this.d = o1;
    y2.c.a();
    this.g = new x(new c(this, paramContext));
    this.h = o1.g(f.class);
    g(new d(this));
    y2.c.a();
  }
  
  public static e k() {
    synchronized (k) {
      e e1 = (e)l.get("[DEFAULT]");
      if (e1 != null)
        return e1; 
      IllegalStateException illegalStateException = new IllegalStateException();
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("Default FirebaseApp is not initialized in this process ");
      stringBuilder.append(q.a());
      stringBuilder.append(". Make sure to call FirebaseApp.initializeApp(Context) first.");
      this(stringBuilder.toString());
      throw illegalStateException;
    } 
  }
  
  public static e p(Context paramContext) {
    synchronized (k) {
      if (l.containsKey("[DEFAULT]")) {
        e1 = k();
        return e1;
      } 
      l l1 = l.a((Context)e1);
      if (l1 == null) {
        Log.w("FirebaseApp", "Default FirebaseApp failed to initialize because no default options were found. This usually means that com.google.gms:google-services was not applied to your gradle project.");
        return null;
      } 
      e e1 = q((Context)e1, l1);
      return e1;
    } 
  }
  
  public static e q(Context paramContext, l paraml) {
    return r(paramContext, paraml, "[DEFAULT]");
  }
  
  public static e r(Context paramContext, l paraml, String paramString) {
    b.b(paramContext);
    paramString = w(paramString);
    if (paramContext.getApplicationContext() != null)
      paramContext = paramContext.getApplicationContext(); 
    synchronized (k) {
      boolean bool;
      Map<String, e> map = l;
      if (!map.containsKey(paramString)) {
        bool = true;
      } else {
        bool = false;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("FirebaseApp name ");
      stringBuilder.append(paramString);
      stringBuilder.append(" already exists!");
      m.l(bool, stringBuilder.toString());
      m.j(paramContext, "Application context cannot be null.");
      e e1 = new e();
      this(paramContext, paramString, paraml);
      map.put(paramString, e1);
      e1.o();
      return e1;
    } 
  }
  
  public static String w(String paramString) {
    return paramString.trim();
  }
  
  public boolean equals(Object paramObject) {
    return !(paramObject instanceof e) ? false : this.b.equals(((e)paramObject).l());
  }
  
  public void g(a parama) {
    h();
    if (this.e.get() && g1.c.b().d())
      parama.a(true); 
    this.i.add(parama);
  }
  
  public final void h() {
    m.l(this.f.get() ^ true, "FirebaseApp was deleted");
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public Object i(Class paramClass) {
    h();
    return this.d.a(paramClass);
  }
  
  public Context j() {
    h();
    return this.a;
  }
  
  public String l() {
    h();
    return this.b;
  }
  
  public l m() {
    h();
    return this.c;
  }
  
  public String n() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(j1.c.c(l().getBytes(Charset.defaultCharset())));
    stringBuilder.append("+");
    stringBuilder.append(j1.c.c(m().c().getBytes(Charset.defaultCharset())));
    return stringBuilder.toString();
  }
  
  public final void o() {
    if ((o.a(this.a) ^ true) != 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Device in Direct Boot Mode: postponing initialization of Firebase APIs for app ");
      stringBuilder.append(l());
      Log.i("FirebaseApp", stringBuilder.toString());
      c.a(this.a);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Device unlocked: initializing all Firebase APIs for app ");
      stringBuilder.append(l());
      Log.i("FirebaseApp", stringBuilder.toString());
      this.d.n(t());
      ((f)this.h.get()).l();
    } 
  }
  
  public boolean s() {
    h();
    return ((u2.a)this.g.get()).b();
  }
  
  public boolean t() {
    return "[DEFAULT]".equals(l());
  }
  
  public String toString() {
    return k.c(this).a("name", this.b).a("options", this.c).toString();
  }
  
  public final void x(boolean paramBoolean) {
    Log.d("FirebaseApp", "Notifying background state change listeners.");
    Iterator<a> iterator = this.i.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).a(paramBoolean); 
  }
  
  public static interface a {
    void a(boolean param1Boolean);
  }
  
  public static class b implements g1.c.a {
    public static AtomicReference a = new AtomicReference();
    
    public static void c(Context param1Context) {
      if (o.a() && param1Context.getApplicationContext() instanceof Application) {
        Application application = (Application)param1Context.getApplicationContext();
        if (a.get() == null) {
          b b1 = new b();
          if (z0.a(a, null, b1)) {
            g1.c.c(application);
            g1.c.b().a(b1);
          } 
        } 
      } 
    }
    
    public void a(boolean param1Boolean) {
      synchronized (e.c()) {
        ArrayList arrayList = new ArrayList();
        this(e.l.values());
        for (e e : arrayList) {
          if (e.e(e).get())
            e.f(e, param1Boolean); 
        } 
        return;
      } 
    }
  }
  
  public static class c extends BroadcastReceiver {
    public static AtomicReference b = new AtomicReference();
    
    public final Context a;
    
    public c(Context param1Context) {
      this.a = param1Context;
    }
    
    public static void b(Context param1Context) {
      if (b.get() == null) {
        c c1 = new c(param1Context);
        if (z0.a(b, null, c1))
          param1Context.registerReceiver(c1, new IntentFilter("android.intent.action.USER_UNLOCKED")); 
      } 
    }
    
    public void c() {
      this.a.unregisterReceiver(this);
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      synchronized (e.c()) {
        Iterator<e> iterator = e.l.values().iterator();
        while (iterator.hasNext())
          e.d(iterator.next()); 
        c();
        return;
      } 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b2/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */