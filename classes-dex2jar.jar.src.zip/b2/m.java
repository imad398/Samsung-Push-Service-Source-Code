package b2;

import android.os.SystemClock;

public abstract class m {
  public static m a(long paramLong1, long paramLong2, long paramLong3) {
    return new a(paramLong1, paramLong2, paramLong3);
  }
  
  public static m e() {
    return a(System.currentTimeMillis(), SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
  }
  
  public abstract long b();
  
  public abstract long c();
  
  public abstract long d();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b2/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */