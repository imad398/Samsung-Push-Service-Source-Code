package b2;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.common.internal.k;
import com.google.android.gms.common.internal.m;
import com.google.android.gms.common.internal.o;
import j1.s;

public final class l {
  public final String a;
  
  public final String b;
  
  public final String c;
  
  public final String d;
  
  public final String e;
  
  public final String f;
  
  public final String g;
  
  public l(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    m.l(s.a(paramString1) ^ true, "ApplicationId must be set.");
    this.b = paramString1;
    this.a = paramString2;
    this.c = paramString3;
    this.d = paramString4;
    this.e = paramString5;
    this.f = paramString6;
    this.g = paramString7;
  }
  
  public static l a(Context paramContext) {
    o o = new o(paramContext);
    String str = o.a("google_app_id");
    return TextUtils.isEmpty(str) ? null : new l(str, o.a("google_api_key"), o.a("firebase_database_url"), o.a("ga_trackingId"), o.a("gcm_defaultSenderId"), o.a("google_storage_bucket"), o.a("project_id"));
  }
  
  public String b() {
    return this.a;
  }
  
  public String c() {
    return this.b;
  }
  
  public String d() {
    return this.e;
  }
  
  public String e() {
    return this.g;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof l;
    boolean bool1 = false;
    if (!bool)
      return false; 
    paramObject = paramObject;
    bool = bool1;
    if (k.a(this.b, ((l)paramObject).b)) {
      bool = bool1;
      if (k.a(this.a, ((l)paramObject).a)) {
        bool = bool1;
        if (k.a(this.c, ((l)paramObject).c)) {
          bool = bool1;
          if (k.a(this.d, ((l)paramObject).d)) {
            bool = bool1;
            if (k.a(this.e, ((l)paramObject).e)) {
              bool = bool1;
              if (k.a(this.f, ((l)paramObject).f)) {
                bool = bool1;
                if (k.a(this.g, ((l)paramObject).g))
                  bool = true; 
              } 
            } 
          } 
        } 
      } 
    } 
    return bool;
  }
  
  public int hashCode() {
    return k.b(new Object[] { this.b, this.a, this.c, this.d, this.e, this.f, this.g });
  }
  
  public String toString() {
    return k.c(this).a("applicationId", this.b).a("apiKey", this.a).a("databaseUrl", this.c).a("gcmSenderId", this.e).a("storageBucket", this.f).a("projectId", this.g).toString();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b2/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */