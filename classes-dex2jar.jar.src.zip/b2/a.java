package b2;

public final class a extends m {
  public final long a;
  
  public final long b;
  
  public final long c;
  
  public a(long paramLong1, long paramLong2, long paramLong3) {
    this.a = paramLong1;
    this.b = paramLong2;
    this.c = paramLong3;
  }
  
  public long b() {
    return this.b;
  }
  
  public long c() {
    return this.a;
  }
  
  public long d() {
    return this.c;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (paramObject == this)
      return true; 
    if (paramObject instanceof m) {
      paramObject = paramObject;
      if (this.a != paramObject.c() || this.b != paramObject.b() || this.c != paramObject.d())
        bool = false; 
      return bool;
    } 
    return false;
  }
  
  public int hashCode() {
    long l = this.a;
    int i = (int)(l ^ l >>> 32L);
    l = this.b;
    int j = (int)(l ^ l >>> 32L);
    l = this.c;
    return ((i ^ 0xF4243) * 1000003 ^ j) * 1000003 ^ (int)(l >>> 32L ^ l);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("StartupTime{epochMillis=");
    stringBuilder.append(this.a);
    stringBuilder.append(", elapsedRealtime=");
    stringBuilder.append(this.b);
    stringBuilder.append(", uptimeMillis=");
    stringBuilder.append(this.c);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b2/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */