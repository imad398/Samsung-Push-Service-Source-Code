package b5;

import e5.b;
import f5.c;

public final class a implements Comparable {
  public static final a e = new a(null);
  
  public static final a f = b.a();
  
  public final int a;
  
  public final int b;
  
  public final int c;
  
  public final int d;
  
  public a(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    this.d = b(paramInt1, paramInt2, paramInt3);
  }
  
  public int a(a parama) {
    b.a(parama, "other");
    return this.d - parama.d;
  }
  
  public final int b(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    bool2 = bool1;
    bool2 = bool1;
    if ((new c(0, 255)).e(paramInt1) && (new c(0, 255)).e(paramInt2) && (new c(0, 255)).e(paramInt3))
      bool2 = true; 
    if (bool2)
      return (paramInt1 << 16) + (paramInt2 << 8) + paramInt3; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Version components are out of range: ");
    stringBuilder.append(paramInt1);
    stringBuilder.append('.');
    stringBuilder.append(paramInt2);
    stringBuilder.append('.');
    stringBuilder.append(paramInt3);
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof a) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject == null)
      return false; 
    if (this.d != ((a)paramObject).d)
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return this.d;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.a);
    stringBuilder.append('.');
    stringBuilder.append(this.b);
    stringBuilder.append('.');
    stringBuilder.append(this.c);
    return stringBuilder.toString();
  }
  
  public static final class a {
    public a() {}
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b5/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */