package androidx.viewpager.widget;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.customview.view.AbsSavedState;

public class ViewPager$SavedState extends AbsSavedState {
  public static final Parcelable.Creator<ViewPager$SavedState> CREATOR = (Parcelable.Creator<ViewPager$SavedState>)new a();
  
  Parcelable adapterState;
  
  ClassLoader loader;
  
  int position;
  
  public ViewPager$SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    ClassLoader classLoader = paramClassLoader;
    if (paramClassLoader == null)
      classLoader = getClass().getClassLoader(); 
    this.position = paramParcel.readInt();
    this.adapterState = paramParcel.readParcelable(classLoader);
    this.loader = classLoader;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FragmentPager.SavedState{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" position=");
    stringBuilder.append(this.position);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.position);
    paramParcel.writeParcelable(this.adapterState, paramInt);
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator {
    public ViewPager$SavedState a(Parcel param1Parcel) {
      return new ViewPager$SavedState(param1Parcel, null);
    }
    
    public ViewPager$SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new ViewPager$SavedState(param1Parcel, param1ClassLoader);
    }
    
    public ViewPager$SavedState[] c(int param1Int) {
      return new ViewPager$SavedState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/viewpager/widget/ViewPager$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */