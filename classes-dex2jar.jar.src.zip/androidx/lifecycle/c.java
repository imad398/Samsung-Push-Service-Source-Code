package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class c {
  public static AtomicBoolean a = new AtomicBoolean(false);
  
  public static void a(Context paramContext) {
    if (a.getAndSet(true))
      return; 
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new a());
  }
  
  public static class a extends a {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      h.f(param1Activity);
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */