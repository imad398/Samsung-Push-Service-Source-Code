package androidx.lifecycle;

public abstract class b {
  public abstract b a();
  
  public enum a {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    static {
      a a1 = new a("ON_CREATE", 0);
      ON_CREATE = a1;
      a a2 = new a("ON_START", 1);
      ON_START = a2;
      a a3 = new a("ON_RESUME", 2);
      ON_RESUME = a3;
      a a4 = new a("ON_PAUSE", 3);
      ON_PAUSE = a4;
      a a5 = new a("ON_STOP", 4);
      ON_STOP = a5;
      a a6 = new a("ON_DESTROY", 5);
      ON_DESTROY = a6;
      a a7 = new a("ON_ANY", 6);
      ON_ANY = a7;
      $VALUES = new a[] { a1, a2, a3, a4, a5, a6, a7 };
    }
  }
  
  public enum b {
    a, b, c, d, e;
    
    static {
      b b1 = new b("DESTROYED", 0);
      a = b1;
      b b2 = new b("INITIALIZED", 1);
      b = b2;
      b b3 = new b("CREATED", 2);
      c = b3;
      b b4 = new b("STARTED", 3);
      d = b4;
      b b5 = new b("RESUMED", 4);
      e = b5;
      f = new b[] { b1, b2, b3, b4, b5 };
    }
    
    public boolean a(b param1b) {
      boolean bool;
      if (compareTo((E)param1b) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */