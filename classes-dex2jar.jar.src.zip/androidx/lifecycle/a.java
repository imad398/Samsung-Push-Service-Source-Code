package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public abstract class a implements Application.ActivityLifecycleCallbacks {
  public void onActivityDestroyed(Activity paramActivity) {}
  
  public void onActivityPaused(Activity paramActivity) {}
  
  public void onActivityResumed(Activity paramActivity) {}
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {}
  
  public void onActivityStarted(Activity paramActivity) {}
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */