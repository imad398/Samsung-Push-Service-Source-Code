package androidx.lifecycle;

import android.os.Handler;

public class i {
  public final e a;
  
  public final Handler b;
  
  public a c;
  
  public i(d paramd) {
    this.a = new e(paramd);
    this.b = new Handler();
  }
  
  public b a() {
    return this.a;
  }
  
  public void b() {
    f(b.a.ON_START);
  }
  
  public void c() {
    f(b.a.ON_CREATE);
  }
  
  public void d() {
    f(b.a.ON_STOP);
    f(b.a.ON_DESTROY);
  }
  
  public void e() {
    f(b.a.ON_START);
  }
  
  public final void f(b.a parama) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, parama);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public static class a implements Runnable {
    public final e a;
    
    public final b.a b;
    
    public boolean c = false;
    
    public a(e param1e, b.a param1a) {
      this.a = param1e;
      this.b = param1a;
    }
    
    public void run() {
      if (!this.c) {
        this.a.c(this.b);
        this.c = true;
      } 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */