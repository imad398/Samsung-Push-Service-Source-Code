package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;

public class h extends Fragment {
  public a a;
  
  public static h e(Activity paramActivity) {
    return (h)paramActivity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
  }
  
  public static void f(Activity paramActivity) {
    FragmentManager fragmentManager = paramActivity.getFragmentManager();
    if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
      fragmentManager.beginTransaction().add(new h(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      fragmentManager.executePendingTransactions();
    } 
  }
  
  public final void a(b.a parama) {
    Activity activity = getActivity();
    if (activity instanceof d) {
      b b = ((d)activity).e();
      if (b instanceof e)
        ((e)b).c(parama); 
    } 
  }
  
  public final void b(a parama) {
    if (parama != null)
      parama.a(); 
  }
  
  public final void c(a parama) {
    if (parama != null)
      parama.onResume(); 
  }
  
  public final void d(a parama) {
    if (parama != null)
      parama.M0(); 
  }
  
  public void g(a parama) {
    this.a = parama;
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    b(this.a);
    a(b.a.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    a(b.a.ON_DESTROY);
    this.a = null;
  }
  
  public void onPause() {
    super.onPause();
    a(b.a.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    c(this.a);
    a(b.a.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    d(this.a);
    a(b.a.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    a(b.a.ON_STOP);
  }
  
  public static interface a {
    void M0();
    
    void a();
    
    void onResume();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */