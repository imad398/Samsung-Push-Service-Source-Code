package androidx.lifecycle;

public class k {
  public final a a;
  
  public final l b;
  
  public k(l paraml, a parama) {
    this.a = parama;
    this.b = paraml;
  }
  
  public j a(Class paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public j b(String paramString, Class paramClass) {
    j j2 = this.b.b(paramString);
    if (paramClass.isInstance(j2))
      return j2; 
    j j1 = this.a.a(paramClass);
    this.b.c(paramString, j1);
    return j1;
  }
  
  public static interface a {
    j a(Class param1Class);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */