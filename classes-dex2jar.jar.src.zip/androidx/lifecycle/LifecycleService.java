package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class LifecycleService extends Service implements d {
  public final i a = new i(this);
  
  public b e() {
    return this.a.a();
  }
  
  public IBinder onBind(Intent paramIntent) {
    this.a.b();
    return null;
  }
  
  public void onCreate() {
    this.a.c();
    super.onCreate();
  }
  
  public void onDestroy() {
    this.a.d();
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    this.a.e();
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/LifecycleService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */