package androidx.lifecycle;

import java.util.HashMap;
import java.util.Iterator;

public class l {
  public final HashMap a = new HashMap<Object, Object>();
  
  public final void a() {
    Iterator<j> iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((j)iterator.next()).a(); 
    this.a.clear();
  }
  
  public final j b(String paramString) {
    return (j)this.a.get(paramString);
  }
  
  public final void c(String paramString, j paramj) {
    j j1 = this.a.put(paramString, paramj);
    if (j1 != null)
      j1.a(); 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */