package androidx.lifecycle;

public class f extends LiveData {
  public void f(Object paramObject) {
    super.f(paramObject);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */