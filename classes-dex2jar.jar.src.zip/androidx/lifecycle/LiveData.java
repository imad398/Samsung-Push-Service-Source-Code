package androidx.lifecycle;

import java.util.Map;

public abstract class LiveData {
  public static final Object j = new Object();
  
  public final Object a = new Object();
  
  public c.b b = new c.b();
  
  public int c = 0;
  
  public volatile Object d;
  
  public volatile Object e;
  
  public int f;
  
  public boolean g;
  
  public boolean h;
  
  public final Runnable i;
  
  public LiveData() {
    Object object = j;
    this.d = object;
    this.e = object;
    this.f = -1;
    this.i = new a(this);
  }
  
  public static void a(String paramString) {
    if (b.a.e().b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background");
    stringBuilder.append(" thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final void b(b paramb) {
    if (!paramb.a)
      return; 
    if (!paramb.b()) {
      paramb.a(false);
      return;
    } 
    int i = paramb.b;
    int j = this.f;
    if (i >= j)
      return; 
    paramb.b = j;
    throw null;
  }
  
  public void c(b paramb) {
    if (this.g) {
      this.h = true;
      return;
    } 
    this.g = true;
    while (true) {
      b b1;
      this.h = false;
      if (paramb != null) {
        b(paramb);
        b1 = null;
      } else {
        c.b.c<Map.Entry> c = this.b.b();
        while (true) {
          b1 = paramb;
          if (c.hasNext()) {
            b((b)((Map.Entry)c.next()).getValue());
            if (this.h) {
              b1 = paramb;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramb = b1;
      if (!this.h) {
        this.g = false;
        return;
      } 
    } 
  }
  
  public void d() {}
  
  public void e() {}
  
  public void f(Object paramObject) {
    a("setValue");
    this.f++;
    this.d = paramObject;
    c(null);
  }
  
  public class LifecycleBoundObserver extends b {
    public final d d;
    
    public boolean b() {
      return this.d.e().a().a(b.b.d);
    }
  }
  
  public class a implements Runnable {
    public a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.a.a) {
        Object object = this.a.e;
        this.a.e = LiveData.j;
        this.a.f(object);
        return;
      } 
    }
  }
  
  public abstract class b {
    public boolean a;
    
    public int b;
    
    public void a(boolean param1Boolean) {
      boolean bool;
      if (param1Boolean == this.a)
        return; 
      this.a = param1Boolean;
      LiveData liveData = this.c;
      int i = liveData.c;
      byte b1 = 1;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!param1Boolean)
        b1 = -1; 
      liveData.c = i + b1;
      if (bool && param1Boolean)
        liveData.d(); 
      liveData = this.c;
      if (liveData.c == 0 && !this.a)
        liveData.e(); 
      if (this.a)
        this.c.c(this); 
    }
    
    public abstract boolean b();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */