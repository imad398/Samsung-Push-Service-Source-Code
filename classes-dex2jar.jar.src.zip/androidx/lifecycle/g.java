package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;

public class g implements d {
  public static final g i = new g();
  
  public int a = 0;
  
  public int b = 0;
  
  public boolean c = true;
  
  public boolean d = true;
  
  public Handler e;
  
  public final e f = new e(this);
  
  public Runnable g = new a(this);
  
  public h.a h = new b(this);
  
  public static void i(Context paramContext) {
    i.f(paramContext);
  }
  
  public void a() {
    int i = this.b - 1;
    this.b = i;
    if (i == 0)
      this.e.postDelayed(this.g, 700L); 
  }
  
  public void b() {
    int i = this.b + 1;
    this.b = i;
    if (i == 1)
      if (this.c) {
        this.f.c(b.a.ON_RESUME);
        this.c = false;
      } else {
        this.e.removeCallbacks(this.g);
      }  
  }
  
  public void c() {
    int i = this.a + 1;
    this.a = i;
    if (i == 1 && this.d) {
      this.f.c(b.a.ON_START);
      this.d = false;
    } 
  }
  
  public void d() {
    this.a--;
    h();
  }
  
  public b e() {
    return this.f;
  }
  
  public void f(Context paramContext) {
    this.e = new Handler();
    this.f.c(b.a.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new c(this));
  }
  
  public void g() {
    if (this.b == 0) {
      this.c = true;
      this.f.c(b.a.ON_PAUSE);
    } 
  }
  
  public void h() {
    if (this.a == 0 && this.c) {
      this.f.c(b.a.ON_STOP);
      this.d = true;
    } 
  }
  
  public class a implements Runnable {
    public a(g this$0) {}
    
    public void run() {
      this.a.g();
      this.a.h();
    }
  }
  
  public class b implements h.a {
    public b(g this$0) {}
    
    public void M0() {
      this.a.c();
    }
    
    public void a() {}
    
    public void onResume() {
      this.a.b();
    }
  }
  
  public class c extends a {
    public c(g this$0) {}
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      h.e(param1Activity).g(this.a.h);
    }
    
    public void onActivityPaused(Activity param1Activity) {
      this.a.a();
    }
    
    public void onActivityStopped(Activity param1Activity) {
      this.a.d();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */