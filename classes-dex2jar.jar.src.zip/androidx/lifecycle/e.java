package androidx.lifecycle;

import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class e extends b {
  public c.a a = new c.a();
  
  public b.b b;
  
  public final WeakReference c;
  
  public int d = 0;
  
  public boolean e = false;
  
  public boolean f = false;
  
  public ArrayList g = new ArrayList();
  
  public e(d paramd) {
    this.c = new WeakReference<d>(paramd);
    this.b = b.b.b;
  }
  
  public static b.b b(b.a parama) {
    StringBuilder stringBuilder;
    switch (a.a[parama.ordinal()]) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected event value ");
        stringBuilder.append(parama);
        throw new IllegalArgumentException(stringBuilder.toString());
      case 6:
        return b.b.a;
      case 5:
        return b.b.e;
      case 3:
      case 4:
        return b.b.d;
      case 1:
      case 2:
        break;
    } 
    return b.b.c;
  }
  
  public b.b a() {
    return this.b;
  }
  
  public void c(b.a parama) {
    f(b(parama));
  }
  
  public final boolean d() {
    if (this.a.size() == 0)
      return true; 
    android.support.v4.media.a.a(this.a.a().getValue());
    throw null;
  }
  
  public void e(b.b paramb) {
    f(paramb);
  }
  
  public final void f(b.b paramb) {
    if (this.b == paramb)
      return; 
    this.b = paramb;
    if (this.e || this.d != 0) {
      this.f = true;
      return;
    } 
    this.e = true;
    g();
    this.e = false;
  }
  
  public final void g() {
    if ((d)this.c.get() == null) {
      Log.w("LifecycleRegistry", "LifecycleOwner is garbage collected, you shouldn't try dispatch new events from it.");
      return;
    } 
    boolean bool = d();
    this.f = false;
    if (bool)
      return; 
    android.support.v4.media.a.a(this.a.a().getValue());
    throw null;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/lifecycle/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */