package androidx.browser.customtabs;

import a.b;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import e.f;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public abstract class CustomTabsService extends Service {
  public final Map a = (Map)new f.a();
  
  public b.a b = new a(this);
  
  public boolean a(f paramf) {
    try {
      synchronized (this.a) {
        IBinder iBinder = paramf.a();
        iBinder.unlinkToDeath((IBinder.DeathRecipient)this.a.get(iBinder), 0);
        this.a.remove(iBinder);
        return true;
      } 
    } catch (NoSuchElementException noSuchElementException) {
      return false;
    } 
  }
  
  public abstract Bundle b(String paramString, Bundle paramBundle);
  
  public abstract boolean c(f paramf, Uri paramUri, Bundle paramBundle, List paramList);
  
  public abstract boolean d(f paramf);
  
  public abstract int e(f paramf, String paramString, Bundle paramBundle);
  
  public abstract boolean f(f paramf, Uri paramUri);
  
  public abstract boolean g(f paramf, Bundle paramBundle);
  
  public abstract boolean h(f paramf, int paramInt, Uri paramUri, Bundle paramBundle);
  
  public abstract boolean i(long paramLong);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.b;
  }
  
  public class a extends b.a {
    public a(CustomTabsService this$0) {}
    
    public boolean F5(a.a param1a) {
      f f = new f(param1a);
      try {
        a a1 = new a();
        this(this, f);
        synchronized (this.a.a) {
          param1a.asBinder().linkToDeath(a1, 0);
          this.a.a.put(param1a.asBinder(), a1);
          return this.a.d(f);
        } 
      } catch (RemoteException remoteException) {
        return false;
      } 
    }
    
    public boolean U1(a.a param1a, Uri param1Uri) {
      return this.a.f(new f(param1a), param1Uri);
    }
    
    public boolean V7(a.a param1a, Bundle param1Bundle) {
      return this.a.g(new f(param1a), param1Bundle);
    }
    
    public boolean f7(long param1Long) {
      return this.a.i(param1Long);
    }
    
    public boolean l8(a.a param1a, int param1Int, Uri param1Uri, Bundle param1Bundle) {
      return this.a.h(new f(param1a), param1Int, param1Uri, param1Bundle);
    }
    
    public int n5(a.a param1a, String param1String, Bundle param1Bundle) {
      return this.a.e(new f(param1a), param1String, param1Bundle);
    }
    
    public boolean q3(a.a param1a, Uri param1Uri, Bundle param1Bundle, List param1List) {
      return this.a.c(new f(param1a), param1Uri, param1Bundle, param1List);
    }
    
    public Bundle v5(String param1String, Bundle param1Bundle) {
      return this.a.b(param1String, param1Bundle);
    }
    
    public class a implements IBinder.DeathRecipient {
      public a(CustomTabsService.a this$0, f param2f) {}
      
      public void binderDied() {
        this.b.a.a(this.a);
      }
    }
  }
  
  public class a implements IBinder.DeathRecipient {
    public a(CustomTabsService this$0, f param1f) {}
    
    public void binderDied() {
      this.b.a.a(this.a);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/browser/customtabs/CustomTabsService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */