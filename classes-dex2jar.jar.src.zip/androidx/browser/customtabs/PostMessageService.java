package androidx.browser.customtabs;

import a.c;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;

public class PostMessageService extends Service {
  public c.a a = new a(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.a;
  }
  
  public class a extends c.a {
    public a(PostMessageService this$0) {}
    
    public void D4(a.a param1a, String param1String, Bundle param1Bundle) {
      param1a.I6(param1String, param1Bundle);
    }
    
    public void s2(a.a param1a, Bundle param1Bundle) {
      param1a.c7(param1Bundle);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/browser/customtabs/PostMessageService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */