package androidx.recyclerview.widget;

import android.view.View;

public abstract class k extends RecyclerView.l {
  public boolean g = true;
  
  public final void A(RecyclerView.z paramz) {
    I(paramz);
    h(paramz);
  }
  
  public final void B(RecyclerView.z paramz) {
    J(paramz);
  }
  
  public final void C(RecyclerView.z paramz, boolean paramBoolean) {
    K(paramz, paramBoolean);
    h(paramz);
  }
  
  public final void D(RecyclerView.z paramz, boolean paramBoolean) {
    L(paramz, paramBoolean);
  }
  
  public final void E(RecyclerView.z paramz) {
    M(paramz);
    h(paramz);
  }
  
  public final void F(RecyclerView.z paramz) {
    N(paramz);
  }
  
  public final void G(RecyclerView.z paramz) {
    O(paramz);
    h(paramz);
  }
  
  public final void H(RecyclerView.z paramz) {
    P(paramz);
  }
  
  public void I(RecyclerView.z paramz) {}
  
  public void J(RecyclerView.z paramz) {}
  
  public void K(RecyclerView.z paramz, boolean paramBoolean) {}
  
  public void L(RecyclerView.z paramz, boolean paramBoolean) {}
  
  public void M(RecyclerView.z paramz) {}
  
  public void N(RecyclerView.z paramz) {}
  
  public void O(RecyclerView.z paramz) {}
  
  public void P(RecyclerView.z paramz) {}
  
  public boolean a(RecyclerView.z paramz, RecyclerView.l.b paramb1, RecyclerView.l.b paramb2) {
    if (paramb1 != null) {
      int i = paramb1.a;
      int j = paramb2.a;
      if (i != j || paramb1.b != paramb2.b)
        return y(paramz, i, paramb1.b, j, paramb2.b); 
    } 
    return w(paramz);
  }
  
  public boolean b(RecyclerView.z paramz1, RecyclerView.z paramz2, RecyclerView.l.b paramb1, RecyclerView.l.b paramb2) {
    int m;
    int n;
    int i = paramb1.a;
    int j = paramb1.b;
    if (paramz2.I()) {
      m = paramb1.a;
      n = paramb1.b;
    } else {
      m = paramb2.a;
      n = paramb2.b;
    } 
    return x(paramz1, paramz2, i, j, m, n);
  }
  
  public boolean c(RecyclerView.z paramz, RecyclerView.l.b paramb1, RecyclerView.l.b paramb2) {
    int m;
    int n;
    int i = paramb1.a;
    int j = paramb1.b;
    View view = paramz.a;
    if (paramb2 == null) {
      m = view.getLeft();
    } else {
      m = paramb2.a;
    } 
    if (paramb2 == null) {
      n = view.getTop();
    } else {
      n = paramb2.b;
    } 
    if (!paramz.u() && (i != m || j != n)) {
      view.layout(m, n, view.getWidth() + m, view.getHeight() + n);
      return y(paramz, i, j, m, n);
    } 
    return z(paramz);
  }
  
  public boolean d(RecyclerView.z paramz, RecyclerView.l.b paramb1, RecyclerView.l.b paramb2) {
    int i = paramb1.a;
    int j = paramb2.a;
    if (i != j || paramb1.b != paramb2.b)
      return y(paramz, i, paramb1.b, j, paramb2.b); 
    E(paramz);
    return false;
  }
  
  public boolean f(RecyclerView.z paramz) {
    return (!this.g || paramz.s());
  }
  
  public abstract boolean w(RecyclerView.z paramz);
  
  public abstract boolean x(RecyclerView.z paramz1, RecyclerView.z paramz2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract boolean y(RecyclerView.z paramz, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract boolean z(RecyclerView.z paramz);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */