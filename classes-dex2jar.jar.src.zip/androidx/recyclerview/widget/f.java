package androidx.recyclerview.widget;

import android.view.View;

public class f {
  public boolean a = true;
  
  public int b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public int f = 0;
  
  public int g = 0;
  
  public boolean h;
  
  public boolean i;
  
  public boolean a(RecyclerView.w paramw) {
    boolean bool;
    int i = this.c;
    if (i >= 0 && i < paramw.b()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public View b(RecyclerView.t paramt) {
    View view = paramt.o(this.c);
    this.c += this.d;
    return view;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LayoutState{mAvailable=");
    stringBuilder.append(this.b);
    stringBuilder.append(", mCurrentPosition=");
    stringBuilder.append(this.c);
    stringBuilder.append(", mItemDirection=");
    stringBuilder.append(this.d);
    stringBuilder.append(", mLayoutDirection=");
    stringBuilder.append(this.e);
    stringBuilder.append(", mStartLine=");
    stringBuilder.append(this.f);
    stringBuilder.append(", mEndLine=");
    stringBuilder.append(this.g);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */