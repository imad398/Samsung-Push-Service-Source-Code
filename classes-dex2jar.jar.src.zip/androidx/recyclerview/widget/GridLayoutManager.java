package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;
import o.n;

public class GridLayoutManager extends LinearLayoutManager {
  public boolean G = false;
  
  public int H = -1;
  
  public int[] I;
  
  public View[] J;
  
  public final SparseIntArray K = new SparseIntArray();
  
  public final SparseIntArray L = new SparseIntArray();
  
  public b M = new a();
  
  public final Rect N = new Rect();
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    T2((RecyclerView.o.g0(paramContext, paramAttributeSet, paramInt1, paramInt2)).b);
  }
  
  public static int[] I2(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: aload_0
    //   3: ifnull -> 27
    //   6: aload_0
    //   7: arraylength
    //   8: iload_1
    //   9: iconst_1
    //   10: iadd
    //   11: if_icmpne -> 27
    //   14: aload_0
    //   15: astore #4
    //   17: aload_0
    //   18: aload_0
    //   19: arraylength
    //   20: iconst_1
    //   21: isub
    //   22: iaload
    //   23: iload_2
    //   24: if_icmpeq -> 34
    //   27: iload_1
    //   28: iconst_1
    //   29: iadd
    //   30: newarray int
    //   32: astore #4
    //   34: iconst_0
    //   35: istore #5
    //   37: aload #4
    //   39: iconst_0
    //   40: iconst_0
    //   41: iastore
    //   42: iload_2
    //   43: iload_1
    //   44: idiv
    //   45: istore #6
    //   47: iload_2
    //   48: iload_1
    //   49: irem
    //   50: istore #7
    //   52: iconst_0
    //   53: istore #8
    //   55: iload #5
    //   57: istore_2
    //   58: iload_3
    //   59: iload_1
    //   60: if_icmpgt -> 116
    //   63: iload_2
    //   64: iload #7
    //   66: iadd
    //   67: istore_2
    //   68: iload_2
    //   69: ifle -> 93
    //   72: iload_1
    //   73: iload_2
    //   74: isub
    //   75: iload #7
    //   77: if_icmpge -> 93
    //   80: iload #6
    //   82: iconst_1
    //   83: iadd
    //   84: istore #5
    //   86: iload_2
    //   87: iload_1
    //   88: isub
    //   89: istore_2
    //   90: goto -> 97
    //   93: iload #6
    //   95: istore #5
    //   97: iload #8
    //   99: iload #5
    //   101: iadd
    //   102: istore #8
    //   104: aload #4
    //   106: iload_3
    //   107: iload #8
    //   109: iastore
    //   110: iinc #3, 1
    //   113: goto -> 58
    //   116: aload #4
    //   118: areturn
  }
  
  public RecyclerView.LayoutParams C() {
    return (this.r == 0) ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
  }
  
  public RecyclerView.LayoutParams D(Context paramContext, AttributeSet paramAttributeSet) {
    return new LayoutParams(paramContext, paramAttributeSet);
  }
  
  public RecyclerView.LayoutParams E(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams);
  }
  
  public boolean F1() {
    boolean bool;
    if (this.C == null && !this.G) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void F2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt1, int paramInt2, boolean paramBoolean) {
    byte b1;
    int i = 0;
    if (paramBoolean) {
      paramInt2 = 1;
      b1 = paramInt1;
      paramInt1 = 0;
    } else {
      paramInt1--;
      b1 = -1;
      paramInt2 = -1;
    } 
    while (paramInt1 != b1) {
      View view = this.J[paramInt1];
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      int j = P2(paramt, paramw, f0(view));
      layoutParams.f = j;
      layoutParams.e = i;
      i += j;
      paramInt1 += paramInt2;
    } 
  }
  
  public void G1(RecyclerView.w paramw, LinearLayoutManager.c paramc, RecyclerView.o.c paramc1) {
    int i = this.H;
    for (byte b1 = 0; b1 < this.H && paramc.c(paramw) && i > 0; b1++) {
      int j = paramc.d;
      paramc1.a(j, Math.max(0, paramc.g));
      i -= this.M.d(j);
      paramc.d += paramc.e;
    } 
  }
  
  public final void G2() {
    int i = I();
    for (byte b1 = 0; b1 < i; b1++) {
      LayoutParams layoutParams = (LayoutParams)H(b1).getLayoutParams();
      int j = layoutParams.a();
      this.K.put(j, layoutParams.f());
      this.L.put(j, layoutParams.e());
    } 
  }
  
  public View H0(View paramView, int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual A : (Landroid/view/View;)Landroid/view/View;
    //   5: astore #5
    //   7: aconst_null
    //   8: astore #6
    //   10: aload #5
    //   12: ifnonnull -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload #5
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: checkcast androidx/recyclerview/widget/GridLayoutManager$LayoutParams
    //   25: astore #7
    //   27: aload #7
    //   29: getfield e : I
    //   32: istore #8
    //   34: aload #7
    //   36: getfield f : I
    //   39: iload #8
    //   41: iadd
    //   42: istore #9
    //   44: aload_0
    //   45: aload_1
    //   46: iload_2
    //   47: aload_3
    //   48: aload #4
    //   50: invokespecial H0 : (Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;)Landroid/view/View;
    //   53: ifnonnull -> 58
    //   56: aconst_null
    //   57: areturn
    //   58: aload_0
    //   59: iload_2
    //   60: invokevirtual K1 : (I)I
    //   63: iconst_1
    //   64: if_icmpne -> 73
    //   67: iconst_1
    //   68: istore #10
    //   70: goto -> 76
    //   73: iconst_0
    //   74: istore #10
    //   76: iload #10
    //   78: aload_0
    //   79: getfield w : Z
    //   82: if_icmpeq -> 90
    //   85: iconst_1
    //   86: istore_2
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_2
    //   93: ifeq -> 113
    //   96: aload_0
    //   97: invokevirtual I : ()I
    //   100: iconst_1
    //   101: isub
    //   102: istore_2
    //   103: iconst_m1
    //   104: istore #11
    //   106: iload #11
    //   108: istore #12
    //   110: goto -> 124
    //   113: aload_0
    //   114: invokevirtual I : ()I
    //   117: istore #11
    //   119: iconst_1
    //   120: istore #12
    //   122: iconst_0
    //   123: istore_2
    //   124: aload_0
    //   125: getfield r : I
    //   128: iconst_1
    //   129: if_icmpne -> 145
    //   132: aload_0
    //   133: invokevirtual j2 : ()Z
    //   136: ifeq -> 145
    //   139: iconst_1
    //   140: istore #13
    //   142: goto -> 148
    //   145: iconst_0
    //   146: istore #13
    //   148: aload_0
    //   149: aload_3
    //   150: aload #4
    //   152: iload_2
    //   153: invokevirtual N2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;I)I
    //   156: istore #14
    //   158: iconst_m1
    //   159: istore #15
    //   161: iload #15
    //   163: istore #16
    //   165: iconst_0
    //   166: istore #17
    //   168: iconst_0
    //   169: istore #18
    //   171: iload_2
    //   172: istore #19
    //   174: aconst_null
    //   175: astore_1
    //   176: iload #18
    //   178: istore_2
    //   179: iload #11
    //   181: istore #18
    //   183: iload #17
    //   185: istore #11
    //   187: iload #19
    //   189: iload #18
    //   191: if_icmpeq -> 574
    //   194: aload_0
    //   195: aload_3
    //   196: aload #4
    //   198: iload #19
    //   200: invokevirtual N2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;I)I
    //   203: istore #17
    //   205: aload_0
    //   206: iload #19
    //   208: invokevirtual H : (I)Landroid/view/View;
    //   211: astore #7
    //   213: aload #7
    //   215: aload #5
    //   217: if_acmpne -> 223
    //   220: goto -> 574
    //   223: aload #7
    //   225: invokevirtual hasFocusable : ()Z
    //   228: ifeq -> 249
    //   231: iload #17
    //   233: iload #14
    //   235: if_icmpeq -> 249
    //   238: aload #6
    //   240: ifnull -> 246
    //   243: goto -> 574
    //   246: goto -> 564
    //   249: aload #7
    //   251: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   254: checkcast androidx/recyclerview/widget/GridLayoutManager$LayoutParams
    //   257: astore #20
    //   259: aload #20
    //   261: getfield e : I
    //   264: istore #21
    //   266: aload #20
    //   268: getfield f : I
    //   271: iload #21
    //   273: iadd
    //   274: istore #22
    //   276: aload #7
    //   278: invokevirtual hasFocusable : ()Z
    //   281: ifeq -> 301
    //   284: iload #21
    //   286: iload #8
    //   288: if_icmpne -> 301
    //   291: iload #22
    //   293: iload #9
    //   295: if_icmpne -> 301
    //   298: aload #7
    //   300: areturn
    //   301: aload #7
    //   303: invokevirtual hasFocusable : ()Z
    //   306: ifeq -> 314
    //   309: aload #6
    //   311: ifnull -> 326
    //   314: aload #7
    //   316: invokevirtual hasFocusable : ()Z
    //   319: ifne -> 332
    //   322: aload_1
    //   323: ifnonnull -> 332
    //   326: iconst_1
    //   327: istore #17
    //   329: goto -> 483
    //   332: iload #21
    //   334: iload #8
    //   336: invokestatic max : (II)I
    //   339: istore #17
    //   341: iload #22
    //   343: iload #9
    //   345: invokestatic min : (II)I
    //   348: iload #17
    //   350: isub
    //   351: istore #23
    //   353: aload #7
    //   355: invokevirtual hasFocusable : ()Z
    //   358: ifeq -> 404
    //   361: iload #23
    //   363: iload #11
    //   365: if_icmple -> 371
    //   368: goto -> 326
    //   371: iload #23
    //   373: iload #11
    //   375: if_icmpne -> 480
    //   378: iload #21
    //   380: iload #15
    //   382: if_icmple -> 391
    //   385: iconst_1
    //   386: istore #17
    //   388: goto -> 394
    //   391: iconst_0
    //   392: istore #17
    //   394: iload #13
    //   396: iload #17
    //   398: if_icmpne -> 480
    //   401: goto -> 368
    //   404: aload #6
    //   406: ifnonnull -> 480
    //   409: iconst_1
    //   410: istore #24
    //   412: iconst_1
    //   413: istore #25
    //   415: aload_0
    //   416: aload #7
    //   418: iconst_0
    //   419: iconst_1
    //   420: invokevirtual w0 : (Landroid/view/View;ZZ)Z
    //   423: ifeq -> 480
    //   426: iload_2
    //   427: istore #17
    //   429: iload #23
    //   431: iload #17
    //   433: if_icmple -> 443
    //   436: iload #24
    //   438: istore #17
    //   440: goto -> 483
    //   443: iload #23
    //   445: iload #17
    //   447: if_icmpne -> 477
    //   450: iload #21
    //   452: iload #16
    //   454: if_icmple -> 464
    //   457: iload #25
    //   459: istore #17
    //   461: goto -> 467
    //   464: iconst_0
    //   465: istore #17
    //   467: iload #13
    //   469: iload #17
    //   471: if_icmpne -> 480
    //   474: goto -> 326
    //   477: goto -> 480
    //   480: iconst_0
    //   481: istore #17
    //   483: iload #17
    //   485: ifeq -> 564
    //   488: aload #7
    //   490: invokevirtual hasFocusable : ()Z
    //   493: ifeq -> 535
    //   496: aload #20
    //   498: getfield e : I
    //   501: istore #15
    //   503: iload #22
    //   505: iload #9
    //   507: invokestatic min : (II)I
    //   510: istore #11
    //   512: iload #21
    //   514: iload #8
    //   516: invokestatic max : (II)I
    //   519: istore #17
    //   521: aload #7
    //   523: astore #6
    //   525: iload #11
    //   527: iload #17
    //   529: isub
    //   530: istore #11
    //   532: goto -> 564
    //   535: aload #20
    //   537: getfield e : I
    //   540: istore #16
    //   542: iload #22
    //   544: iload #9
    //   546: invokestatic min : (II)I
    //   549: iload #21
    //   551: iload #8
    //   553: invokestatic max : (II)I
    //   556: isub
    //   557: istore_2
    //   558: aload #7
    //   560: astore_1
    //   561: goto -> 564
    //   564: iload #19
    //   566: iload #12
    //   568: iadd
    //   569: istore #19
    //   571: goto -> 187
    //   574: aload #6
    //   576: ifnull -> 582
    //   579: goto -> 585
    //   582: aload_1
    //   583: astore #6
    //   585: aload #6
    //   587: areturn
  }
  
  public final void H2(int paramInt) {
    this.I = I2(this.I, this.H, paramInt);
  }
  
  public final void J2() {
    this.K.clear();
    this.L.clear();
  }
  
  public final void K2(RecyclerView.t paramt, RecyclerView.w paramw, LinearLayoutManager.a parama, int paramInt) {
    int i;
    if (paramInt == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    paramInt = O2(paramt, paramw, parama.b);
    if (i) {
      while (paramInt > 0) {
        paramInt = parama.b;
        if (paramInt > 0) {
          parama.b = --paramInt;
          paramInt = O2(paramt, paramw, paramInt);
        } 
      } 
    } else {
      int j = paramw.b();
      i = parama.b;
      while (i < j - 1) {
        int k = i + 1;
        int m = O2(paramt, paramw, k);
        if (m > paramInt) {
          i = k;
          paramInt = m;
        } 
      } 
      parama.b = i;
    } 
  }
  
  public final void L2() {
    View[] arrayOfView = this.J;
    if (arrayOfView == null || arrayOfView.length != this.H)
      this.J = new View[this.H]; 
  }
  
  public int M(RecyclerView.t paramt, RecyclerView.w paramw) {
    return (this.r == 1) ? this.H : ((paramw.b() < 1) ? 0 : (N2(paramt, paramw, paramw.b() - 1) + 1));
  }
  
  public int M2(int paramInt1, int paramInt2) {
    if (this.r == 1 && j2()) {
      int[] arrayOfInt1 = this.I;
      int i = this.H;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.I;
    return arrayOfInt[paramInt2 + paramInt1] - arrayOfInt[paramInt1];
  }
  
  public void N0(RecyclerView.t paramt, RecyclerView.w paramw, View paramView, n paramn) {
    int j;
    boolean bool1;
    boolean bool2;
    int k;
    ViewGroup.LayoutParams layoutParams1 = paramView.getLayoutParams();
    if (!(layoutParams1 instanceof LayoutParams)) {
      M0(paramView, paramn);
      return;
    } 
    LayoutParams layoutParams = (LayoutParams)layoutParams1;
    int i = N2(paramt, paramw, layoutParams.a());
    if (this.r == 0) {
      j = layoutParams.e();
      bool1 = layoutParams.f();
      boolean bool = true;
      if (this.H > 1 && layoutParams.f() == this.H) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      k = i;
      i = j;
      j = bool;
    } else {
      bool1 = true;
      k = layoutParams.e();
      j = layoutParams.f();
      if (this.H > 1 && layoutParams.f() == this.H) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
    } 
    paramn.K(n.c.a(i, bool1, k, j, bool2, false));
  }
  
  public final int N2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt) {
    if (!paramw.e())
      return this.M.b(paramInt, this.H); 
    int i = paramt.f(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. ");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.M.b(i, this.H);
  }
  
  public final int O2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt) {
    if (!paramw.e())
      return this.M.a(paramInt, this.H); 
    int i = this.L.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = paramt.f(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.M.a(i, this.H);
  }
  
  public void P0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.M.e();
  }
  
  public final int P2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt) {
    if (!paramw.e())
      return this.M.d(paramInt); 
    int i = this.K.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = paramt.f(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 1;
    } 
    return this.M.d(i);
  }
  
  public void Q0(RecyclerView paramRecyclerView) {
    this.M.e();
  }
  
  public final void Q2(float paramFloat, int paramInt) {
    H2(Math.max(Math.round(paramFloat * this.H), paramInt));
  }
  
  public void R0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    this.M.e();
  }
  
  public final void R2(View paramView, int paramInt, boolean paramBoolean) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    Rect rect = layoutParams.b;
    int i = rect.top + rect.bottom + layoutParams.topMargin + layoutParams.bottomMargin;
    int j = rect.left + rect.right + layoutParams.leftMargin + layoutParams.rightMargin;
    int k = M2(layoutParams.e, layoutParams.f);
    if (this.r == 1) {
      j = RecyclerView.o.J(k, paramInt, j, layoutParams.width, false);
      paramInt = RecyclerView.o.J(this.t.n(), W(), i, layoutParams.height, true);
    } else {
      paramInt = RecyclerView.o.J(k, paramInt, i, layoutParams.height, false);
      j = RecyclerView.o.J(this.t.n(), n0(), j, layoutParams.width, true);
    } 
    S2(paramView, j, paramInt, paramBoolean);
  }
  
  public void S0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.M.e();
  }
  
  public final void S2(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = D1(paramView, paramInt1, paramInt2, layoutParams);
    } else {
      paramBoolean = B1(paramView, paramInt1, paramInt2, layoutParams);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public void T2(int paramInt) {
    if (paramInt == this.H)
      return; 
    this.G = true;
    if (paramInt >= 1) {
      this.H = paramInt;
      this.M.e();
      q1();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Span count should be at least 1. Provided ");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void U0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    this.M.e();
  }
  
  public final void U2() {
    int i;
    int j;
    if (i2() == 1) {
      i = m0() - d0();
      j = c0();
    } else {
      i = V() - b0();
      j = e0();
    } 
    H2(i - j);
  }
  
  public void V0(RecyclerView.t paramt, RecyclerView.w paramw) {
    if (paramw.e())
      G2(); 
    super.V0(paramt, paramw);
    J2();
  }
  
  public void W0(RecyclerView.w paramw) {
    super.W0(paramw);
    this.G = false;
  }
  
  public View a2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt1, int paramInt2, int paramInt3) {
    byte b1;
    M1();
    int i = this.t.m();
    int j = this.t.i();
    if (paramInt2 > paramInt1) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    View view1 = null;
    View view2;
    for (view2 = null; paramInt1 != paramInt2; view2 = view5) {
      View view3 = H(paramInt1);
      int k = f0(view3);
      View view4 = view1;
      View view5 = view2;
      if (k >= 0) {
        view4 = view1;
        view5 = view2;
        if (k < paramInt3)
          if (O2(paramt, paramw, k) != 0) {
            view4 = view1;
            view5 = view2;
          } else if (((RecyclerView.LayoutParams)view3.getLayoutParams()).c()) {
            view4 = view1;
            view5 = view2;
            if (view2 == null) {
              view5 = view3;
              view4 = view1;
            } 
          } else if (this.t.g(view3) >= j || this.t.d(view3) < i) {
            view4 = view1;
            view5 = view2;
            if (view1 == null) {
              view4 = view3;
              view5 = view2;
            } 
          } else {
            return view3;
          }  
      } 
      paramInt1 += b1;
      view1 = view4;
    } 
    if (view1 == null)
      view1 = view2; 
    return view1;
  }
  
  public int i0(RecyclerView.t paramt, RecyclerView.w paramw) {
    return (this.r == 0) ? this.H : ((paramw.b() < 1) ? 0 : (N2(paramt, paramw, paramw.b() - 1) + 1));
  }
  
  public void k2(RecyclerView.t paramt, RecyclerView.w paramw, LinearLayoutManager.c paramc, LinearLayoutManager.b paramb) {
    StringBuilder stringBuilder;
    int j;
    int k;
    boolean bool;
    int i = this.t.l();
    if (i != 1073741824) {
      j = 1;
    } else {
      j = 0;
    } 
    if (I() > 0) {
      k = this.I[this.H];
    } else {
      k = 0;
    } 
    if (j)
      U2(); 
    if (paramc.e == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    int m = this.H;
    if (!bool)
      m = O2(paramt, paramw, paramc.d) + P2(paramt, paramw, paramc.d); 
    int n = 0;
    byte b1 = 0;
    while (b1 < this.H && paramc.c(paramw) && m > 0) {
      int i1 = paramc.d;
      int i2 = P2(paramt, paramw, i1);
      if (i2 <= this.H) {
        m -= i2;
        if (m < 0)
          break; 
        View view = paramc.d(paramt);
        if (view == null)
          break; 
        n += i2;
        this.J[b1] = view;
        b1++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Item at position ");
      stringBuilder.append(i1);
      stringBuilder.append(" requires ");
      stringBuilder.append(i2);
      stringBuilder.append(" spans but GridLayoutManager has only ");
      stringBuilder.append(this.H);
      stringBuilder.append(" spans.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (b1 == 0) {
      paramb.b = true;
      return;
    } 
    F2((RecyclerView.t)stringBuilder, paramw, b1, n, bool);
    float f = 0.0F;
    n = 0;
    for (m = 0; n < b1; m = i2) {
      View view = this.J[n];
      if (paramc.k == null) {
        if (bool) {
          c(view);
        } else {
          d(view, 0);
        } 
      } else if (bool) {
        a(view);
      } else {
        b(view, 0);
      } 
      i(view, this.N);
      R2(view, i, false);
      int i1 = this.t.e(view);
      int i2 = m;
      if (i1 > m)
        i2 = i1; 
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      float f1 = this.t.f(view) * 1.0F / layoutParams.f;
      float f2 = f;
      if (f1 > f)
        f2 = f1; 
      n++;
      f = f2;
    } 
    n = m;
    if (j) {
      Q2(f, k);
      m = 0;
      j = 0;
      while (true) {
        n = m;
        if (j < b1) {
          View view = this.J[j];
          R2(view, 1073741824, true);
          k = this.t.e(view);
          n = m;
          if (k > m)
            n = k; 
          j++;
          m = n;
          continue;
        } 
        break;
      } 
    } 
    for (m = 0; m < b1; m++) {
      View view = this.J[m];
      if (this.t.e(view) != n) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        Rect rect = layoutParams.b;
        k = rect.top + rect.bottom + layoutParams.topMargin + layoutParams.bottomMargin;
        j = rect.left + rect.right + layoutParams.leftMargin + layoutParams.rightMargin;
        int i1 = M2(layoutParams.e, layoutParams.f);
        if (this.r == 1) {
          j = RecyclerView.o.J(i1, 1073741824, j, layoutParams.width, false);
          k = View.MeasureSpec.makeMeasureSpec(n - k, 1073741824);
        } else {
          j = View.MeasureSpec.makeMeasureSpec(n - j, 1073741824);
          k = RecyclerView.o.J(i1, 1073741824, k, layoutParams.height, false);
        } 
        S2(view, j, k, true);
      } 
    } 
    byte b2 = 0;
    paramb.a = n;
    if (this.r == 1) {
      m = paramc.f;
      j = paramc.b;
      if (m == -1) {
        boolean bool1 = false;
        k = bool1;
        i = j - n;
        m = j;
        n = bool1;
        j = i;
      } else {
        m = j + n;
        n = 0;
        k = n;
      } 
    } else {
      j = paramc.f;
      m = paramc.b;
      if (j == -1) {
        n = m - n;
        k = m;
      } else {
        k = m + n;
        n = m;
      } 
      m = 0;
      j = m;
    } 
    while (b2 < b1) {
      int i1;
      View view = this.J[b2];
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (this.r == 1) {
        if (j2()) {
          k = c0() + this.I[this.H - layoutParams.e];
          int i2 = this.t.f(view);
          n = k;
          k -= i2;
        } else {
          n = c0() + this.I[layoutParams.e];
          int i2 = this.t.f(view);
          k = n;
          n = i2 + n;
        } 
        i1 = m;
        m = j;
        j = n;
      } else {
        i1 = e0() + this.I[layoutParams.e];
        i = this.t.f(view);
        m = i1;
        j = k;
        i1 = i + i1;
        k = n;
      } 
      x0(view, k, m, j, i1);
      if (layoutParams.c() || layoutParams.b())
        paramb.c = true; 
      paramb.d |= view.hasFocusable();
      b2++;
      n = k;
      k = j;
      j = m;
      m = i1;
    } 
    Arrays.fill((Object[])this.J, (Object)null);
  }
  
  public boolean l(RecyclerView.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void m2(RecyclerView.t paramt, RecyclerView.w paramw, LinearLayoutManager.a parama, int paramInt) {
    super.m2(paramt, paramw, parama, paramInt);
    U2();
    if (paramw.b() > 0 && !paramw.e())
      K2(paramt, paramw, parama, paramInt); 
    L2();
  }
  
  public int t1(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    U2();
    L2();
    return super.t1(paramInt, paramt, paramw);
  }
  
  public int u1(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    U2();
    L2();
    return super.u1(paramInt, paramt, paramw);
  }
  
  public void w2(boolean paramBoolean) {
    if (!paramBoolean) {
      super.w2(false);
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public void y1(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.I == null)
      super.y1(paramRect, paramInt1, paramInt2); 
    int i = c0() + d0();
    int j = e0() + b0();
    if (this.r == 1) {
      paramInt2 = RecyclerView.o.m(paramInt2, paramRect.height() + j, Z());
      arrayOfInt = this.I;
      j = RecyclerView.o.m(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, a0());
      paramInt1 = paramInt2;
      paramInt2 = j;
    } else {
      paramInt1 = RecyclerView.o.m(paramInt1, arrayOfInt.width() + i, a0());
      arrayOfInt = this.I;
      j = RecyclerView.o.m(paramInt2, arrayOfInt[arrayOfInt.length - 1] + j, Z());
      paramInt2 = paramInt1;
      paramInt1 = j;
    } 
    x1(paramInt2, paramInt1);
  }
  
  public static class LayoutParams extends RecyclerView.LayoutParams {
    public int e = -1;
    
    public int f = 0;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public int e() {
      return this.e;
    }
    
    public int f() {
      return this.f;
    }
  }
  
  public static final class a extends b {
    public int c(int param1Int1, int param1Int2) {
      return param1Int1 % param1Int2;
    }
    
    public int d(int param1Int) {
      return 1;
    }
  }
  
  public static abstract class b {
    public final SparseIntArray a = new SparseIntArray();
    
    public boolean b = false;
    
    public int a(int param1Int1, int param1Int2) {
      if (!this.b)
        return c(param1Int1, param1Int2); 
      int i = this.a.get(param1Int1, -1);
      if (i != -1)
        return i; 
      param1Int2 = c(param1Int1, param1Int2);
      this.a.put(param1Int1, param1Int2);
      return param1Int2;
    }
    
    public int b(int param1Int1, int param1Int2) {
      int i = d(param1Int1);
      byte b1 = 0;
      int j = b1;
      int k;
      for (k = j; b1 < param1Int1; k = i1) {
        int i1;
        int m = d(b1);
        int n = j + m;
        if (n == param1Int2) {
          i1 = k + 1;
          j = 0;
        } else {
          j = n;
          i1 = k;
          if (n > param1Int2) {
            i1 = k + 1;
            j = m;
          } 
        } 
        b1++;
      } 
      param1Int1 = k;
      if (j + i > param1Int2)
        param1Int1 = k + 1; 
      return param1Int1;
    }
    
    public abstract int c(int param1Int1, int param1Int2);
    
    public abstract int d(int param1Int);
    
    public void e() {
      this.a.clear();
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */