package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;

public abstract class h {
  public final RecyclerView.o a;
  
  public int b = Integer.MIN_VALUE;
  
  public final Rect c = new Rect();
  
  public h(RecyclerView.o paramo) {
    this.a = paramo;
  }
  
  public static h a(RecyclerView.o paramo) {
    return new a(paramo);
  }
  
  public static h b(RecyclerView.o paramo, int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return c(paramo); 
      throw new IllegalArgumentException("invalid orientation");
    } 
    return a(paramo);
  }
  
  public static h c(RecyclerView.o paramo) {
    return new b(paramo);
  }
  
  public abstract int d(View paramView);
  
  public abstract int e(View paramView);
  
  public abstract int f(View paramView);
  
  public abstract int g(View paramView);
  
  public abstract int h();
  
  public abstract int i();
  
  public abstract int j();
  
  public abstract int k();
  
  public abstract int l();
  
  public abstract int m();
  
  public abstract int n();
  
  public int o() {
    int i;
    if (Integer.MIN_VALUE == this.b) {
      i = 0;
    } else {
      i = n() - this.b;
    } 
    return i;
  }
  
  public abstract int p(View paramView);
  
  public abstract int q(View paramView);
  
  public abstract void r(int paramInt);
  
  public void s() {
    this.b = n();
  }
  
  public static final class a extends h {
    public a(RecyclerView.o param1o) {
      super(param1o, null);
    }
    
    public int d(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.S(param1View) + layoutParams.rightMargin;
    }
    
    public int e(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.R(param1View) + layoutParams.leftMargin + layoutParams.rightMargin;
    }
    
    public int f(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.Q(param1View) + layoutParams.topMargin + layoutParams.bottomMargin;
    }
    
    public int g(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.P(param1View) - layoutParams.leftMargin;
    }
    
    public int h() {
      return this.a.m0();
    }
    
    public int i() {
      return this.a.m0() - this.a.d0();
    }
    
    public int j() {
      return this.a.d0();
    }
    
    public int k() {
      return this.a.n0();
    }
    
    public int l() {
      return this.a.W();
    }
    
    public int m() {
      return this.a.c0();
    }
    
    public int n() {
      return this.a.m0() - this.a.c0() - this.a.d0();
    }
    
    public int p(View param1View) {
      this.a.l0(param1View, true, this.c);
      return this.c.right;
    }
    
    public int q(View param1View) {
      this.a.l0(param1View, true, this.c);
      return this.c.left;
    }
    
    public void r(int param1Int) {
      this.a.A0(param1Int);
    }
  }
  
  public static final class b extends h {
    public b(RecyclerView.o param1o) {
      super(param1o, null);
    }
    
    public int d(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.N(param1View) + layoutParams.bottomMargin;
    }
    
    public int e(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.Q(param1View) + layoutParams.topMargin + layoutParams.bottomMargin;
    }
    
    public int f(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.R(param1View) + layoutParams.leftMargin + layoutParams.rightMargin;
    }
    
    public int g(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.T(param1View) - layoutParams.topMargin;
    }
    
    public int h() {
      return this.a.V();
    }
    
    public int i() {
      return this.a.V() - this.a.b0();
    }
    
    public int j() {
      return this.a.b0();
    }
    
    public int k() {
      return this.a.W();
    }
    
    public int l() {
      return this.a.n0();
    }
    
    public int m() {
      return this.a.e0();
    }
    
    public int n() {
      return this.a.V() - this.a.e0() - this.a.b0();
    }
    
    public int p(View param1View) {
      this.a.l0(param1View, true, this.c);
      return this.c.bottom;
    }
    
    public int q(View param1View) {
      this.a.l0(param1View, true, this.c);
      return this.c.top;
    }
    
    public void r(int param1Int) {
      this.a.B0(param1Int);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */