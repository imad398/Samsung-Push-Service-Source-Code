package androidx.recyclerview.widget;

import f.d;
import m.e;
import m.f;

public class m {
  public final f.a a = new f.a();
  
  public final d b = new d();
  
  public void a(RecyclerView.z paramz, RecyclerView.l.b paramb) {
    a a1 = (a)this.a.get(paramz);
    a a2 = a1;
    if (a1 == null) {
      a2 = a.b();
      this.a.put(paramz, a2);
    } 
    a2.a |= 0x2;
    a2.b = paramb;
  }
  
  public void b(RecyclerView.z paramz) {
    a a1 = (a)this.a.get(paramz);
    a a2 = a1;
    if (a1 == null) {
      a2 = a.b();
      this.a.put(paramz, a2);
    } 
    a2.a |= 0x1;
  }
  
  public void c(long paramLong, RecyclerView.z paramz) {
    this.b.i(paramLong, paramz);
  }
  
  public void d(RecyclerView.z paramz, RecyclerView.l.b paramb) {
    a a1 = (a)this.a.get(paramz);
    a a2 = a1;
    if (a1 == null) {
      a2 = a.b();
      this.a.put(paramz, a2);
    } 
    a2.c = paramb;
    a2.a |= 0x8;
  }
  
  public void e(RecyclerView.z paramz, RecyclerView.l.b paramb) {
    a a1 = (a)this.a.get(paramz);
    a a2 = a1;
    if (a1 == null) {
      a2 = a.b();
      this.a.put(paramz, a2);
    } 
    a2.b = paramb;
    a2.a |= 0x4;
  }
  
  public void f() {
    this.a.clear();
    this.b.a();
  }
  
  public RecyclerView.z g(long paramLong) {
    return (RecyclerView.z)this.b.f(paramLong);
  }
  
  public boolean h(RecyclerView.z paramz) {
    a a1 = (a)this.a.get(paramz);
    if (a1 != null) {
      int i = a1.a;
      boolean bool = true;
      if ((i & 0x1) != 0)
        return bool; 
    } 
    return false;
  }
  
  public boolean i(RecyclerView.z paramz) {
    boolean bool;
    a a1 = (a)this.a.get(paramz);
    if (a1 != null && (a1.a & 0x4) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void j() {
    a.a();
  }
  
  public void k(RecyclerView.z paramz) {
    p(paramz);
  }
  
  public final RecyclerView.l.b l(RecyclerView.z paramz, int paramInt) {
    int i = this.a.f(paramz);
    if (i < 0)
      return null; 
    a a1 = (a)this.a.l(i);
    if (a1 != null) {
      int j = a1.a;
      if ((j & paramInt) != 0) {
        RecyclerView.l.b b;
        j = paramInt & j;
        a1.a = j;
        if (paramInt == 4) {
          b = a1.b;
        } else if (paramInt == 8) {
          b = a1.c;
        } else {
          throw new IllegalArgumentException("Must provide flag PRE or POST");
        } 
        if ((j & 0xC) == 0) {
          this.a.j(i);
          a.c(a1);
        } 
        return b;
      } 
    } 
    return null;
  }
  
  public RecyclerView.l.b m(RecyclerView.z paramz) {
    return l(paramz, 8);
  }
  
  public RecyclerView.l.b n(RecyclerView.z paramz) {
    return l(paramz, 4);
  }
  
  public void o(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lf/a;
    //   4: invokevirtual size : ()I
    //   7: iconst_1
    //   8: isub
    //   9: istore_2
    //   10: iload_2
    //   11: iflt -> 209
    //   14: aload_0
    //   15: getfield a : Lf/a;
    //   18: iload_2
    //   19: invokevirtual i : (I)Ljava/lang/Object;
    //   22: checkcast androidx/recyclerview/widget/RecyclerView$z
    //   25: astore_3
    //   26: aload_0
    //   27: getfield a : Lf/a;
    //   30: iload_2
    //   31: invokevirtual j : (I)Ljava/lang/Object;
    //   34: checkcast androidx/recyclerview/widget/m$a
    //   37: astore #4
    //   39: aload #4
    //   41: getfield a : I
    //   44: istore #5
    //   46: iload #5
    //   48: iconst_3
    //   49: iand
    //   50: iconst_3
    //   51: if_icmpne -> 64
    //   54: aload_1
    //   55: aload_3
    //   56: invokeinterface a : (Landroidx/recyclerview/widget/RecyclerView$z;)V
    //   61: goto -> 198
    //   64: iload #5
    //   66: iconst_1
    //   67: iand
    //   68: ifeq -> 107
    //   71: aload #4
    //   73: getfield b : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   76: astore #6
    //   78: aload #6
    //   80: ifnonnull -> 86
    //   83: goto -> 54
    //   86: aload #4
    //   88: getfield c : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   91: astore #7
    //   93: aload_1
    //   94: aload_3
    //   95: aload #6
    //   97: aload #7
    //   99: invokeinterface c : (Landroidx/recyclerview/widget/RecyclerView$z;Landroidx/recyclerview/widget/RecyclerView$l$b;Landroidx/recyclerview/widget/RecyclerView$l$b;)V
    //   104: goto -> 198
    //   107: iload #5
    //   109: bipush #14
    //   111: iand
    //   112: bipush #14
    //   114: if_icmpne -> 137
    //   117: aload_1
    //   118: aload_3
    //   119: aload #4
    //   121: getfield b : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   124: aload #4
    //   126: getfield c : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   129: invokeinterface b : (Landroidx/recyclerview/widget/RecyclerView$z;Landroidx/recyclerview/widget/RecyclerView$l$b;Landroidx/recyclerview/widget/RecyclerView$l$b;)V
    //   134: goto -> 198
    //   137: iload #5
    //   139: bipush #12
    //   141: iand
    //   142: bipush #12
    //   144: if_icmpne -> 167
    //   147: aload_1
    //   148: aload_3
    //   149: aload #4
    //   151: getfield b : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   154: aload #4
    //   156: getfield c : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   159: invokeinterface d : (Landroidx/recyclerview/widget/RecyclerView$z;Landroidx/recyclerview/widget/RecyclerView$l$b;Landroidx/recyclerview/widget/RecyclerView$l$b;)V
    //   164: goto -> 198
    //   167: iload #5
    //   169: iconst_4
    //   170: iand
    //   171: ifeq -> 187
    //   174: aload #4
    //   176: getfield b : Landroidx/recyclerview/widget/RecyclerView$l$b;
    //   179: astore #6
    //   181: aconst_null
    //   182: astore #7
    //   184: goto -> 93
    //   187: iload #5
    //   189: bipush #8
    //   191: iand
    //   192: ifeq -> 198
    //   195: goto -> 117
    //   198: aload #4
    //   200: invokestatic c : (Landroidx/recyclerview/widget/m$a;)V
    //   203: iinc #2, -1
    //   206: goto -> 10
    //   209: return
  }
  
  public void p(RecyclerView.z paramz) {
    a a1 = (a)this.a.get(paramz);
    if (a1 == null)
      return; 
    a1.a &= 0xFFFFFFFE;
  }
  
  public void q(RecyclerView.z paramz) {
    for (int i = this.b.k() - 1; i >= 0; i--) {
      if (paramz == this.b.l(i)) {
        this.b.j(i);
        break;
      } 
    } 
    a a1 = (a)this.a.remove(paramz);
    if (a1 != null)
      a.c(a1); 
  }
  
  public static class a {
    public static e d = (e)new f(20);
    
    public int a;
    
    public RecyclerView.l.b b;
    
    public RecyclerView.l.b c;
    
    public static void a() {
      while (d.b() != null);
    }
    
    public static a b() {
      a a1 = (a)d.b();
      a a2 = a1;
      if (a1 == null)
        a2 = new a(); 
      return a2;
    }
    
    public static void c(a param1a) {
      param1a.a = 0;
      param1a.b = null;
      param1a.c = null;
      d.a(param1a);
    }
  }
  
  public static interface b {
    void a(RecyclerView.z param1z);
    
    void b(RecyclerView.z param1z, RecyclerView.l.b param1b1, RecyclerView.l.b param1b2);
    
    void c(RecyclerView.z param1z, RecyclerView.l.b param1b1, RecyclerView.l.b param1b2);
    
    void d(RecyclerView.z param1z, RecyclerView.l.b param1b1, RecyclerView.l.b param1b2);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */