package androidx.recyclerview.widget;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

public class LinearLayoutManager extends RecyclerView.o {
  public int A = Integer.MIN_VALUE;
  
  public boolean B;
  
  public SavedState C = null;
  
  public final a D = new a();
  
  public final b E = new b();
  
  public int F = 2;
  
  public int r = 1;
  
  public c s;
  
  public h t;
  
  public boolean u;
  
  public boolean v = false;
  
  public boolean w = false;
  
  public boolean x = false;
  
  public boolean y = true;
  
  public int z = -1;
  
  public LinearLayoutManager(Context paramContext, int paramInt, boolean paramBoolean) {
    u2(paramInt);
    v2(paramBoolean);
  }
  
  public LinearLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d = RecyclerView.o.g0(paramContext, paramAttributeSet, paramInt1, paramInt2);
    u2(d.a);
    v2(d.c);
    w2(d.d);
  }
  
  public final void A2(int paramInt1, int paramInt2, boolean paramBoolean, RecyclerView.w paramw) {
    this.s.l = r2();
    this.s.h = h2(paramw);
    c c1 = this.s;
    c1.f = paramInt1;
    byte b1 = -1;
    if (paramInt1 == 1) {
      c1.h += this.t.j();
      View view = f2();
      c1 = this.s;
      if (!this.w)
        b1 = 1; 
      c1.e = b1;
      paramInt1 = f0(view);
      c c2 = this.s;
      c1.d = paramInt1 + c2.e;
      c2.b = this.t.d(view);
      paramInt1 = this.t.d(view) - this.t.i();
    } else {
      View view = g2();
      c c3 = this.s;
      c3.h += this.t.m();
      c c2 = this.s;
      if (this.w)
        b1 = 1; 
      c2.e = b1;
      paramInt1 = f0(view);
      c3 = this.s;
      c2.d = paramInt1 + c3.e;
      c3.b = this.t.g(view);
      paramInt1 = -this.t.g(view) + this.t.m();
    } 
    c1 = this.s;
    c1.c = paramInt2;
    if (paramBoolean)
      c1.c = paramInt2 - paramInt1; 
    c1.g = paramInt1;
  }
  
  public View B(int paramInt) {
    int i = I();
    if (i == 0)
      return null; 
    int j = paramInt - f0(H(0));
    if (j >= 0 && j < i) {
      View view = H(j);
      if (f0(view) == paramInt)
        return view; 
    } 
    return super.B(paramInt);
  }
  
  public final void B2(int paramInt1, int paramInt2) {
    boolean bool;
    this.s.c = this.t.i() - paramInt2;
    c c1 = this.s;
    if (this.w) {
      bool = true;
    } else {
      bool = true;
    } 
    c1.e = bool;
    c1.d = paramInt1;
    c1.f = 1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public RecyclerView.LayoutParams C() {
    return new RecyclerView.LayoutParams(-2, -2);
  }
  
  public boolean C1() {
    boolean bool;
    if (W() != 1073741824 && n0() != 1073741824 && o0()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void C2(a parama) {
    B2(parama.b, parama.c);
  }
  
  public final void D2(int paramInt1, int paramInt2) {
    this.s.c = paramInt2 - this.t.m();
    c c1 = this.s;
    c1.d = paramInt1;
    if (this.w) {
      paramInt1 = 1;
    } else {
      paramInt1 = -1;
    } 
    c1.e = paramInt1;
    c1.f = -1;
    c1.b = paramInt2;
    c1.g = Integer.MIN_VALUE;
  }
  
  public final void E2(a parama) {
    D2(parama.b, parama.c);
  }
  
  public boolean F1() {
    boolean bool;
    if (this.C == null && this.u == this.x) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void G0(RecyclerView paramRecyclerView, RecyclerView.t paramt) {
    super.G0(paramRecyclerView, paramt);
    if (this.B) {
      h1(paramt);
      paramt.c();
    } 
  }
  
  public void G1(RecyclerView.w paramw, c paramc, RecyclerView.o.c paramc1) {
    int i = paramc.d;
    if (i >= 0 && i < paramw.b())
      paramc1.a(i, Math.max(0, paramc.g)); 
  }
  
  public View H0(View paramView, int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    View view1;
    View view2;
    s2();
    if (I() == 0)
      return null; 
    paramInt = K1(paramInt);
    if (paramInt == Integer.MIN_VALUE)
      return null; 
    M1();
    M1();
    A2(paramInt, (int)(this.t.n() * 0.33333334F), false, paramw);
    c c1 = this.s;
    c1.g = Integer.MIN_VALUE;
    c1.a = false;
    N1(paramt, c1, paramw, true);
    if (paramInt == -1) {
      view1 = Z1(paramt, paramw);
    } else {
      view1 = Y1(paramt, paramw);
    } 
    if (paramInt == -1) {
      view2 = g2();
    } else {
      view2 = f2();
    } 
    return view2.hasFocusable() ? ((view1 == null) ? null : view2) : view1;
  }
  
  public final int H1(RecyclerView.w paramw) {
    if (I() == 0)
      return 0; 
    M1();
    return j.a(paramw, this.t, R1(this.y ^ true, true), Q1(this.y ^ true, true), this, this.y);
  }
  
  public void I0(AccessibilityEvent paramAccessibilityEvent) {
    super.I0(paramAccessibilityEvent);
    if (I() > 0) {
      paramAccessibilityEvent.setFromIndex(S1());
      paramAccessibilityEvent.setToIndex(V1());
    } 
  }
  
  public final int I1(RecyclerView.w paramw) {
    if (I() == 0)
      return 0; 
    M1();
    return j.b(paramw, this.t, R1(this.y ^ true, true), Q1(this.y ^ true, true), this, this.y, this.w);
  }
  
  public final int J1(RecyclerView.w paramw) {
    if (I() == 0)
      return 0; 
    M1();
    return j.c(paramw, this.t, R1(this.y ^ true, true), Q1(this.y ^ true, true), this, this.y);
  }
  
  public int K1(int paramInt) {
    int i = -1;
    boolean bool1 = true;
    boolean bool2 = true;
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 17) {
          if (paramInt != 33) {
            if (paramInt != 66) {
              if (paramInt != 130)
                return Integer.MIN_VALUE; 
              if (this.r == 1) {
                paramInt = bool2;
              } else {
                paramInt = Integer.MIN_VALUE;
              } 
              return paramInt;
            } 
            if (this.r == 0) {
              paramInt = bool1;
            } else {
              paramInt = Integer.MIN_VALUE;
            } 
            return paramInt;
          } 
          if (this.r != 1)
            i = Integer.MIN_VALUE; 
          return i;
        } 
        if (this.r != 0)
          i = Integer.MIN_VALUE; 
        return i;
      } 
      return (this.r == 1) ? 1 : (j2() ? -1 : 1);
    } 
    return (this.r == 1) ? -1 : (j2() ? 1 : -1);
  }
  
  public c L1() {
    return new c();
  }
  
  public void M1() {
    if (this.s == null)
      this.s = L1(); 
  }
  
  public int N1(RecyclerView.t paramt, c paramc, RecyclerView.w paramw, boolean paramBoolean) {
    int i = paramc.c;
    int j = paramc.g;
    if (j != Integer.MIN_VALUE) {
      if (i < 0)
        paramc.g = j + i; 
      n2(paramt, paramc);
    } 
    int k = paramc.c + paramc.h;
    b b1 = this.E;
    while (true) {
      while (true)
        break; 
      if (paramBoolean) {
        k = j;
        if (b1.d)
          break; 
      } 
    } 
    return i - paramc.c;
  }
  
  public final View O1(RecyclerView.t paramt, RecyclerView.w paramw) {
    return W1(0, I());
  }
  
  public final View P1(RecyclerView.t paramt, RecyclerView.w paramw) {
    return a2(paramt, paramw, 0, I(), paramw.b());
  }
  
  public final View Q1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.w) {
      boolean bool = false;
      int j = I();
      return X1(bool, j, paramBoolean1, paramBoolean2);
    } 
    int i = I() - 1;
    byte b1 = -1;
    return X1(i, b1, paramBoolean1, paramBoolean2);
  }
  
  public final View R1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.w) {
      int j = I() - 1;
      byte b1 = -1;
      return X1(j, b1, paramBoolean1, paramBoolean2);
    } 
    boolean bool = false;
    int i = I();
    return X1(bool, i, paramBoolean1, paramBoolean2);
  }
  
  public int S1() {
    int i;
    View view = X1(0, I(), false, true);
    if (view == null) {
      i = -1;
    } else {
      i = f0(view);
    } 
    return i;
  }
  
  public final View T1(RecyclerView.t paramt, RecyclerView.w paramw) {
    return W1(I() - 1, -1);
  }
  
  public final View U1(RecyclerView.t paramt, RecyclerView.w paramw) {
    return a2(paramt, paramw, I() - 1, -1, paramw.b());
  }
  
  public void V0(RecyclerView.t paramt, RecyclerView.w paramw) {
    c c1;
    SavedState savedState = this.C;
    int i = -1;
    if ((savedState != null || this.z != -1) && paramw.b() == 0) {
      h1(paramt);
      return;
    } 
    savedState = this.C;
    if (savedState != null && savedState.a())
      this.z = this.C.mAnchorPosition; 
    M1();
    this.s.a = false;
    s2();
    View view = U();
    a a1 = this.D;
    if (!a1.e || this.z != -1 || this.C != null) {
      a1.e();
      a1 = this.D;
      a1.d = this.w ^ this.x;
      z2(paramt, paramw, a1);
      this.D.e = true;
    } else if (view != null && (this.t.g(view) >= this.t.i() || this.t.d(view) <= this.t.m())) {
      this.D.c(view, f0(view));
    } 
    int j = h2(paramw);
    if (this.s.j >= 0) {
      k = j;
      j = 0;
    } else {
      k = 0;
    } 
    int m = j + this.t.m();
    int n = k + this.t.j();
    int k = m;
    j = n;
    if (paramw.e()) {
      int i1 = this.z;
      k = m;
      j = n;
      if (i1 != -1) {
        k = m;
        j = n;
        if (this.A != Integer.MIN_VALUE) {
          View view1 = B(i1);
          k = m;
          j = n;
          if (view1 != null) {
            if (this.w) {
              j = this.t.i() - this.t.d(view1);
              k = this.A;
            } else {
              k = this.t.g(view1) - this.t.m();
              j = this.A;
            } 
            k = j - k;
            if (k > 0) {
              k = m + k;
              j = n;
            } else {
              j = n - k;
              k = m;
            } 
          } 
        } 
      } 
    } 
    a1 = this.D;
    if (a1.d ? this.w : !this.w)
      i = 1; 
    m2(paramt, paramw, a1, i);
    v(paramt);
    this.s.l = r2();
    this.s.i = paramw.e();
    a1 = this.D;
    if (a1.d) {
      E2(a1);
      c1 = this.s;
      c1.h = k;
      N1(paramt, c1, paramw, false);
      c1 = this.s;
      i = c1.b;
      n = c1.d;
      m = c1.c;
      k = j;
      if (m > 0)
        k = j + m; 
      C2(this.D);
      c1 = this.s;
      c1.h = k;
      c1.d += c1.e;
      N1(paramt, c1, paramw, false);
      c1 = this.s;
      m = c1.b;
      int i1 = c1.c;
      j = i;
      k = m;
      if (i1 > 0) {
        D2(n, i);
        c1 = this.s;
        c1.h = i1;
        N1(paramt, c1, paramw, false);
        j = this.s.b;
        k = m;
      } 
    } else {
      C2((a)c1);
      c1 = this.s;
      c1.h = j;
      N1(paramt, c1, paramw, false);
      c1 = this.s;
      i = c1.b;
      n = c1.d;
      m = c1.c;
      j = k;
      if (m > 0)
        j = k + m; 
      E2(this.D);
      c1 = this.s;
      c1.h = j;
      c1.d += c1.e;
      N1(paramt, c1, paramw, false);
      c1 = this.s;
      m = c1.b;
      int i1 = c1.c;
      j = m;
      k = i;
      if (i1 > 0) {
        B2(n, i);
        c1 = this.s;
        c1.h = i1;
        N1(paramt, c1, paramw, false);
        k = this.s.b;
        j = m;
      } 
    } 
    m = j;
    i = k;
    if (I() > 0) {
      if ((this.w ^ this.x) != 0) {
        m = d2(k, paramt, paramw, true);
        i = j + m;
        k += m;
        j = e2(i, paramt, paramw, false);
      } else {
        m = e2(j, paramt, paramw, true);
        i = j + m;
        k += m;
        j = d2(k, paramt, paramw, false);
      } 
      m = i + j;
      i = k + j;
    } 
    l2(paramt, paramw, m, i);
    if (!paramw.e()) {
      this.t.s();
    } else {
      this.D.e();
    } 
    this.u = this.x;
  }
  
  public int V1() {
    int i = I();
    int j = -1;
    View view = X1(i - 1, -1, false, true);
    if (view != null)
      j = f0(view); 
    return j;
  }
  
  public void W0(RecyclerView.w paramw) {
    super.W0(paramw);
    this.C = null;
    this.z = -1;
    this.A = Integer.MIN_VALUE;
    this.D.e();
  }
  
  public View W1(int paramInt1, int paramInt2) {
    char c1;
    char c2;
    l l;
    M1();
    if (paramInt2 > paramInt1) {
      c1 = '\001';
    } else if (paramInt2 < paramInt1) {
      c1 = '￿';
    } else {
      c1 = Character.MIN_VALUE;
    } 
    if (!c1)
      return H(paramInt1); 
    if (this.t.g(H(paramInt1)) < this.t.m()) {
      c2 = '䄄';
      c1 = '䀄';
    } else {
      c2 = '၁';
      c1 = 'ခ';
    } 
    if (this.r == 0) {
      l = this.e;
    } else {
      l = this.f;
    } 
    return l.a(paramInt1, paramInt2, c2, c1);
  }
  
  public View X1(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    char c2;
    l l;
    M1();
    char c1 = 'ŀ';
    if (paramBoolean1) {
      c2 = '怃';
    } else {
      c2 = 'ŀ';
    } 
    if (!paramBoolean2)
      c1 = Character.MIN_VALUE; 
    if (this.r == 0) {
      l = this.e;
    } else {
      l = this.f;
    } 
    return l.a(paramInt1, paramInt2, c2, c1);
  }
  
  public final View Y1(RecyclerView.t paramt, RecyclerView.w paramw) {
    View view;
    if (this.w) {
      view = O1(paramt, paramw);
    } else {
      view = T1((RecyclerView.t)view, paramw);
    } 
    return view;
  }
  
  public final View Z1(RecyclerView.t paramt, RecyclerView.w paramw) {
    View view;
    if (this.w) {
      view = T1(paramt, paramw);
    } else {
      view = O1((RecyclerView.t)view, paramw);
    } 
    return view;
  }
  
  public void a1(Parcelable paramParcelable) {
    if (paramParcelable instanceof SavedState) {
      this.C = (SavedState)paramParcelable;
      q1();
    } 
  }
  
  public View a2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt1, int paramInt2, int paramInt3) {
    View view1;
    View view2;
    byte b1;
    M1();
    int i = this.t.m();
    int j = this.t.i();
    if (paramInt2 > paramInt1) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    paramw = null;
    for (paramt = null; paramInt1 != paramInt2; paramt = t1) {
      View view4;
      View view3 = H(paramInt1);
      int k = f0(view3);
      RecyclerView.w w1 = paramw;
      RecyclerView.t t1 = paramt;
      if (k >= 0) {
        w1 = paramw;
        t1 = paramt;
        if (k < paramInt3)
          if (((RecyclerView.LayoutParams)view3.getLayoutParams()).c()) {
            w1 = paramw;
            t1 = paramt;
            if (paramt == null) {
              View view = view3;
              w1 = paramw;
            } 
          } else if (this.t.g(view3) >= j || this.t.d(view3) < i) {
            w1 = paramw;
            t1 = paramt;
            if (paramw == null) {
              view4 = view3;
              t1 = paramt;
            } 
          } else {
            return view3;
          }  
      } 
      paramInt1 += b1;
      view2 = view4;
    } 
    if (view2 != null)
      view1 = view2; 
    return view1;
  }
  
  public Parcelable b1() {
    if (this.C != null)
      return new SavedState(this.C); 
    SavedState savedState = new SavedState();
    if (I() > 0) {
      M1();
      int i = this.u ^ this.w;
      savedState.mAnchorLayoutFromEnd = i;
      if (i != 0) {
        View view = f2();
        savedState.mAnchorOffset = this.t.i() - this.t.d(view);
        savedState.mAnchorPosition = f0(view);
      } else {
        View view = g2();
        savedState.mAnchorPosition = f0(view);
        savedState.mAnchorOffset = this.t.g(view) - this.t.m();
      } 
    } else {
      savedState.b();
    } 
    return savedState;
  }
  
  public final View b2(RecyclerView.t paramt, RecyclerView.w paramw) {
    View view;
    if (this.w) {
      view = P1(paramt, paramw);
    } else {
      view = U1((RecyclerView.t)view, paramw);
    } 
    return view;
  }
  
  public final View c2(RecyclerView.t paramt, RecyclerView.w paramw) {
    View view;
    if (this.w) {
      view = U1(paramt, paramw);
    } else {
      view = P1((RecyclerView.t)view, paramw);
    } 
    return view;
  }
  
  public final int d2(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw, boolean paramBoolean) {
    int i = this.t.i() - paramInt;
    if (i > 0) {
      i = -t2(-i, paramt, paramw);
      if (paramBoolean) {
        paramInt = this.t.i() - paramInt + i;
        if (paramInt > 0) {
          this.t.r(paramInt);
          return paramInt + i;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public final int e2(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw, boolean paramBoolean) {
    int i = paramInt - this.t.m();
    if (i > 0) {
      int j = -t2(i, paramt, paramw);
      i = j;
      if (paramBoolean) {
        paramInt = paramInt + j - this.t.m();
        i = j;
        if (paramInt > 0) {
          this.t.r(-paramInt);
          i = j - paramInt;
        } 
      } 
      return i;
    } 
    return 0;
  }
  
  public void f(String paramString) {
    if (this.C == null)
      super.f(paramString); 
  }
  
  public final View f2() {
    int i;
    if (this.w) {
      i = 0;
    } else {
      i = I() - 1;
    } 
    return H(i);
  }
  
  public final View g2() {
    boolean bool;
    if (this.w) {
      bool = I() - 1;
    } else {
      bool = false;
    } 
    return H(bool);
  }
  
  public int h2(RecyclerView.w paramw) {
    return paramw.d() ? this.t.n() : 0;
  }
  
  public int i2() {
    return this.r;
  }
  
  public boolean j() {
    boolean bool;
    if (this.r == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean j2() {
    int i = X();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public boolean k() {
    int i = this.r;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public void k2(RecyclerView.t paramt, RecyclerView.w paramw, c paramc, b paramb) {
    int i;
    int j;
    int k;
    int m;
    View view = paramc.d(paramt);
    if (view == null) {
      paramb.b = true;
      return;
    } 
    RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)view.getLayoutParams();
    if (paramc.k == null) {
      boolean bool2;
      boolean bool1 = this.w;
      if (paramc.f == -1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (bool1 == bool2) {
        c(view);
      } else {
        d(view, 0);
      } 
    } else {
      boolean bool2;
      boolean bool1 = this.w;
      if (paramc.f == -1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (bool1 == bool2) {
        a(view);
      } else {
        b(view, 0);
      } 
    } 
    y0(view, 0, 0);
    paramb.a = this.t.e(view);
    if (this.r == 1) {
      if (j2()) {
        i = m0() - d0();
        j = i - this.t.f(view);
      } else {
        j = c0();
        i = this.t.f(view) + j;
      } 
      k = paramc.f;
      m = paramc.b;
      if (k == -1) {
        int n = paramb.a;
        k = m;
        int i1 = i;
        i = m - n;
        m = i1;
      } else {
        int n = paramb.a;
        int i1 = m;
        k = i;
        n += m;
        i = i1;
        m = k;
        k = n;
      } 
    } else {
      j = e0();
      k = this.t.f(view) + j;
      m = paramc.f;
      i = paramc.b;
      if (m == -1) {
        int n = paramb.a;
        m = i;
        int i1 = j;
        j = i - n;
        i = i1;
      } else {
        m = paramb.a;
        m += i;
        int n = i;
        i = j;
        j = n;
      } 
    } 
    x0(view, j, i, m, k);
    if (layoutParams.c() || layoutParams.b())
      paramb.c = true; 
    paramb.d = view.hasFocusable();
  }
  
  public final void l2(RecyclerView.t paramt, RecyclerView.w paramw, int paramInt1, int paramInt2) {
    if (paramw.g() && I() != 0 && !paramw.e() && F1()) {
      List<RecyclerView.z> list = paramt.k();
      int i = list.size();
      int j = f0(H(0));
      byte b1 = 0;
      byte b2 = b1;
      int k = b2;
      int m = b2;
      for (b2 = b1; b2 < i; b2++) {
        RecyclerView.z z = list.get(b2);
        if (!z.u()) {
          boolean bool;
          int n = z.m();
          b1 = 1;
          if (n < j) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool != this.w)
            b1 = -1; 
          n = this.t.e(z.a);
          if (b1 == -1) {
            m += n;
          } else {
            k += n;
          } 
        } 
      } 
      this.s.k = list;
      if (m > 0) {
        D2(f0(g2()), paramInt1);
        c c1 = this.s;
        c1.h = m;
        c1.c = 0;
        c1.a();
        N1(paramt, this.s, paramw, false);
      } 
      if (k > 0) {
        B2(f0(f2()), paramInt2);
        c c1 = this.s;
        c1.h = k;
        c1.c = 0;
        c1.a();
        N1(paramt, this.s, paramw, false);
      } 
      this.s.k = null;
    } 
  }
  
  public void m2(RecyclerView.t paramt, RecyclerView.w paramw, a parama, int paramInt) {}
  
  public void n(int paramInt1, int paramInt2, RecyclerView.w paramw, RecyclerView.o.c paramc) {
    if (this.r != 0)
      paramInt1 = paramInt2; 
    if (I() != 0 && paramInt1 != 0) {
      M1();
      if (paramInt1 > 0) {
        paramInt2 = 1;
      } else {
        paramInt2 = -1;
      } 
      A2(paramInt2, Math.abs(paramInt1), true, paramw);
      G1(paramw, this.s, paramc);
    } 
  }
  
  public final void n2(RecyclerView.t paramt, c paramc) {
    if (paramc.a && !paramc.l) {
      int i = paramc.f;
      int j = paramc.g;
      if (i == -1) {
        p2(paramt, j);
      } else {
        q2(paramt, j);
      } 
    } 
  }
  
  public void o(int paramInt, RecyclerView.o.c paramc) {
    boolean bool;
    int i;
    SavedState savedState = this.C;
    byte b1 = -1;
    if (savedState != null && savedState.a()) {
      savedState = this.C;
      bool = savedState.mAnchorLayoutFromEnd;
      i = savedState.mAnchorPosition;
    } else {
      s2();
      boolean bool1 = this.w;
      int j = this.z;
      i = j;
      bool = bool1;
      if (j == -1)
        if (bool1) {
          i = paramInt - 1;
          bool = bool1;
        } else {
          i = 0;
          bool = bool1;
        }  
    } 
    if (!bool)
      b1 = 1; 
    for (byte b2 = 0; b2 < this.F && i >= 0 && i < paramInt; b2++) {
      paramc.a(i, 0);
      i += b1;
    } 
  }
  
  public final void o2(RecyclerView.t paramt, int paramInt1, int paramInt2) {
    if (paramInt1 == paramInt2)
      return; 
    int i = paramInt1;
    if (paramInt2 > paramInt1) {
      while (--paramInt2 >= paramInt1) {
        k1(paramInt2, paramt);
        paramInt2--;
      } 
    } else {
      while (i > paramInt2) {
        k1(i, paramt);
        i--;
      } 
    } 
  }
  
  public int p(RecyclerView.w paramw) {
    return H1(paramw);
  }
  
  public final void p2(RecyclerView.t paramt, int paramInt) {
    int i = I();
    if (paramInt < 0)
      return; 
    int j = this.t.h() - paramInt;
    if (this.w) {
      for (paramInt = 0; paramInt < i; paramInt++) {
        View view = H(paramInt);
        if (this.t.g(view) < j || this.t.q(view) < j) {
          o2(paramt, 0, paramInt);
          return;
        } 
      } 
    } else {
      for (paramInt = --i; paramInt >= 0; paramInt--) {
        View view = H(paramInt);
        if (this.t.g(view) < j || this.t.q(view) < j) {
          o2(paramt, i, paramInt);
          break;
        } 
      } 
    } 
  }
  
  public int q(RecyclerView.w paramw) {
    return I1(paramw);
  }
  
  public boolean q0() {
    return true;
  }
  
  public final void q2(RecyclerView.t paramt, int paramInt) {
    if (paramInt < 0)
      return; 
    int i = I();
    if (this.w) {
      for (int j = --i; j >= 0; j--) {
        View view = H(j);
        if (this.t.d(view) > paramInt || this.t.p(view) > paramInt) {
          o2(paramt, i, j);
          return;
        } 
      } 
    } else {
      for (byte b1 = 0; b1 < i; b1++) {
        View view = H(b1);
        if (this.t.d(view) > paramInt || this.t.p(view) > paramInt) {
          o2(paramt, 0, b1);
          break;
        } 
      } 
    } 
  }
  
  public int r(RecyclerView.w paramw) {
    return J1(paramw);
  }
  
  public boolean r2() {
    boolean bool;
    if (this.t.k() == 0 && this.t.h() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int s(RecyclerView.w paramw) {
    return H1(paramw);
  }
  
  public final void s2() {
    int i;
    if (this.r == 1 || !j2()) {
      boolean bool = this.v;
    } else {
      i = this.v ^ true;
    } 
    this.w = i;
  }
  
  public int t(RecyclerView.w paramw) {
    return I1(paramw);
  }
  
  public int t1(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    return (this.r == 1) ? 0 : t2(paramInt, paramt, paramw);
  }
  
  public int t2(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    byte b1;
    if (I() == 0 || paramInt == 0)
      return 0; 
    this.s.a = true;
    M1();
    if (paramInt > 0) {
      b1 = 1;
    } else {
      b1 = -1;
    } 
    int i = Math.abs(paramInt);
    A2(b1, i, true, paramw);
    c c1 = this.s;
    int j = c1.g + N1(paramt, c1, paramw, false);
    if (j < 0)
      return 0; 
    if (i > j)
      paramInt = b1 * j; 
    this.t.r(-paramInt);
    this.s.j = paramInt;
    return paramInt;
  }
  
  public int u(RecyclerView.w paramw) {
    return J1(paramw);
  }
  
  public int u1(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    return (this.r == 0) ? 0 : t2(paramInt, paramt, paramw);
  }
  
  public void u2(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      f(null);
      if (paramInt != this.r || this.t == null) {
        h h1 = h.b(this, paramInt);
        this.t = h1;
        this.D.a = h1;
        this.r = paramInt;
        q1();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("invalid orientation:");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void v2(boolean paramBoolean) {
    f(null);
    if (paramBoolean == this.v)
      return; 
    this.v = paramBoolean;
    q1();
  }
  
  public void w2(boolean paramBoolean) {
    f(null);
    if (this.x == paramBoolean)
      return; 
    this.x = paramBoolean;
    q1();
  }
  
  public final boolean x2(RecyclerView.t paramt, RecyclerView.w paramw, a parama) {
    View view1;
    int i = I();
    int j = 0;
    if (i == 0)
      return false; 
    View view2 = U();
    if (view2 != null && parama.d(view2, paramw)) {
      parama.c(view2, f0(view2));
      return true;
    } 
    if (this.u != this.x)
      return false; 
    if (parama.d) {
      view1 = b2(paramt, paramw);
    } else {
      view1 = c2((RecyclerView.t)view1, paramw);
    } 
    if (view1 != null) {
      parama.b(view1, f0(view1));
      if (!paramw.e() && F1()) {
        if (this.t.g(view1) >= this.t.i() || this.t.d(view1) < this.t.m())
          j = 1; 
        if (j) {
          if (parama.d) {
            j = this.t.i();
          } else {
            j = this.t.m();
          } 
          parama.c = j;
        } 
      } 
      return true;
    } 
    return false;
  }
  
  public final boolean y2(RecyclerView.w paramw, a parama) {
    boolean bool = paramw.e();
    boolean bool1 = false;
    if (!bool) {
      int i = this.z;
      if (i != -1) {
        if (i < 0 || i >= paramw.b()) {
          this.z = -1;
          this.A = Integer.MIN_VALUE;
          return false;
        } 
        parama.b = this.z;
        SavedState savedState = this.C;
        if (savedState != null && savedState.a()) {
          bool = this.C.mAnchorLayoutFromEnd;
          parama.d = bool;
          if (bool) {
            i = this.t.i() - this.C.mAnchorOffset;
          } else {
            i = this.t.m() + this.C.mAnchorOffset;
          } 
          parama.c = i;
          return true;
        } 
        if (this.A == Integer.MIN_VALUE) {
          View view = B(this.z);
          if (view != null) {
            if (this.t.e(view) > this.t.n()) {
              parama.a();
              return true;
            } 
            if (this.t.g(view) - this.t.m() < 0) {
              parama.c = this.t.m();
              parama.d = false;
              return true;
            } 
            if (this.t.i() - this.t.d(view) < 0) {
              parama.c = this.t.i();
              parama.d = true;
              return true;
            } 
            if (parama.d) {
              i = this.t.d(view) + this.t.o();
            } else {
              i = this.t.g(view);
            } 
            parama.c = i;
          } else {
            if (I() > 0) {
              i = f0(H(0));
              if (this.z < i) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool == this.w)
                bool1 = true; 
              parama.d = bool1;
            } 
            parama.a();
          } 
          return true;
        } 
        bool = this.w;
        parama.d = bool;
        if (bool) {
          i = this.t.i() - this.A;
        } else {
          i = this.t.m() + this.A;
        } 
        parama.c = i;
        return true;
      } 
    } 
    return false;
  }
  
  public final void z2(RecyclerView.t paramt, RecyclerView.w paramw, a parama) {
    boolean bool;
    if (y2(paramw, parama))
      return; 
    if (x2(paramt, paramw, parama))
      return; 
    parama.a();
    if (this.x) {
      bool = paramw.b() - 1;
    } else {
      bool = false;
    } 
    parama.b = bool;
  }
  
  public static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new a();
    
    boolean mAnchorLayoutFromEnd;
    
    int mAnchorOffset;
    
    int mAnchorPosition;
    
    public SavedState() {}
    
    public SavedState(Parcel param1Parcel) {
      this.mAnchorPosition = param1Parcel.readInt();
      this.mAnchorOffset = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.mAnchorLayoutFromEnd = bool;
    }
    
    public SavedState(SavedState param1SavedState) {
      this.mAnchorPosition = param1SavedState.mAnchorPosition;
      this.mAnchorOffset = param1SavedState.mAnchorOffset;
      this.mAnchorLayoutFromEnd = param1SavedState.mAnchorLayoutFromEnd;
    }
    
    public boolean a() {
      boolean bool;
      if (this.mAnchorPosition >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void b() {
      this.mAnchorPosition = -1;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.mAnchorPosition);
      param1Parcel.writeInt(this.mAnchorOffset);
      param1Parcel.writeInt(this.mAnchorLayoutFromEnd);
    }
    
    public static final class a implements Parcelable.Creator {
      public LinearLayoutManager.SavedState a(Parcel param2Parcel) {
        return new LinearLayoutManager.SavedState(param2Parcel);
      }
      
      public LinearLayoutManager.SavedState[] b(int param2Int) {
        return new LinearLayoutManager.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public LinearLayoutManager.SavedState a(Parcel param1Parcel) {
      return new LinearLayoutManager.SavedState(param1Parcel);
    }
    
    public LinearLayoutManager.SavedState[] b(int param1Int) {
      return new LinearLayoutManager.SavedState[param1Int];
    }
  }
  
  public static class a {
    public h a;
    
    public int b;
    
    public int c;
    
    public boolean d;
    
    public boolean e;
    
    public a() {
      e();
    }
    
    public void a() {
      int i;
      if (this.d) {
        i = this.a.i();
      } else {
        i = this.a.m();
      } 
      this.c = i;
    }
    
    public void b(View param1View, int param1Int) {
      int i;
      if (this.d) {
        i = this.a.d(param1View) + this.a.o();
      } else {
        i = this.a.g(param1View);
      } 
      this.c = i;
      this.b = param1Int;
    }
    
    public void c(View param1View, int param1Int) {
      int i = this.a.o();
      if (i >= 0) {
        b(param1View, param1Int);
        return;
      } 
      this.b = param1Int;
      if (this.d) {
        param1Int = this.a.i() - i - this.a.d(param1View);
        this.c = this.a.i() - param1Int;
        if (param1Int > 0) {
          int j = this.a.e(param1View);
          int k = this.c;
          i = this.a.m();
          i = k - j - i + Math.min(this.a.g(param1View) - i, 0);
          if (i < 0)
            this.c += Math.min(param1Int, -i); 
        } 
      } else {
        int j = this.a.g(param1View);
        param1Int = j - this.a.m();
        this.c = j;
        if (param1Int > 0) {
          int n = this.a.e(param1View);
          int k = this.a.i();
          int m = this.a.d(param1View);
          i = this.a.i() - Math.min(0, k - i - m) - j + n;
          if (i < 0)
            this.c -= Math.min(param1Int, -i); 
        } 
      } 
    }
    
    public boolean d(View param1View, RecyclerView.w param1w) {
      boolean bool;
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      if (!layoutParams.c() && layoutParams.a() >= 0 && layoutParams.a() < param1w.b()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void e() {
      this.b = -1;
      this.c = Integer.MIN_VALUE;
      this.d = false;
      this.e = false;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AnchorInfo{mPosition=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mCoordinate=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mLayoutFromEnd=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mValid=");
      stringBuilder.append(this.e);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class b {
    public int a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
    
    public void a() {
      this.a = 0;
      this.b = false;
      this.c = false;
      this.d = false;
    }
  }
  
  public static class c {
    public boolean a = true;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int h = 0;
    
    public boolean i = false;
    
    public int j;
    
    public List k = null;
    
    public boolean l;
    
    public void a() {
      b(null);
    }
    
    public void b(View param1View) {
      int i;
      param1View = f(param1View);
      if (param1View == null) {
        i = -1;
      } else {
        i = ((RecyclerView.LayoutParams)param1View.getLayoutParams()).a();
      } 
      this.d = i;
    }
    
    public boolean c(RecyclerView.w param1w) {
      boolean bool;
      int i = this.d;
      if (i >= 0 && i < param1w.b()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public View d(RecyclerView.t param1t) {
      if (this.k != null)
        return e(); 
      View view = param1t.o(this.d);
      this.d += this.e;
      return view;
    }
    
    public final View e() {
      int i = this.k.size();
      for (byte b = 0; b < i; b++) {
        View view = ((RecyclerView.z)this.k.get(b)).a;
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)view.getLayoutParams();
        if (!layoutParams.c() && this.d == layoutParams.a()) {
          b(view);
          return view;
        } 
      } 
      return null;
    }
    
    public View f(View param1View) {
      View view2;
      int i = this.k.size();
      View view1 = null;
      int j = Integer.MAX_VALUE;
      byte b = 0;
      while (true) {
        view2 = view1;
        if (b < i) {
          View view = ((RecyclerView.z)this.k.get(b)).a;
          RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)view.getLayoutParams();
          view2 = view1;
          int k = j;
          if (view != param1View)
            if (layoutParams.c()) {
              view2 = view1;
              k = j;
            } else {
              int m = (layoutParams.a() - this.d) * this.e;
              if (m < 0) {
                view2 = view1;
                k = j;
              } else {
                view2 = view1;
                k = j;
                if (m < j) {
                  view1 = view;
                  if (m == 0) {
                    view2 = view1;
                    break;
                  } 
                  k = m;
                  view2 = view1;
                } 
              } 
            }  
          b++;
          view1 = view2;
          j = k;
          continue;
        } 
        break;
      } 
      return view2;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/LinearLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */