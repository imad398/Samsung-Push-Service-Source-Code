package androidx.recyclerview.widget;

import java.util.List;

public class g {
  public final a a;
  
  public g(a parama) {
    this.a = parama;
  }
  
  public final int a(List paramList) {
    int i = paramList.size() - 1;
    for (boolean bool = false; i >= 0; bool = bool1) {
      boolean bool1;
      if (((a.b)paramList.get(i)).a == 8) {
        bool1 = bool;
        if (bool)
          return i; 
      } else {
        bool1 = true;
      } 
      i--;
    } 
    return -1;
  }
  
  public void b(List paramList) {
    while (true) {
      int i = a(paramList);
      if (i != -1) {
        d(paramList, i, i + 1);
        continue;
      } 
      break;
    } 
  }
  
  public final void c(List<a.b> paramList, int paramInt1, a.b paramb1, int paramInt2, a.b paramb2) {
    int i = paramb1.d;
    int j = paramb2.b;
    if (i < j) {
      k = -1;
    } else {
      k = 0;
    } 
    int m = paramb1.b;
    int n = k;
    if (m < j)
      n = k + 1; 
    if (j <= m)
      paramb1.b = m + paramb2.d; 
    int k = paramb2.b;
    if (k <= i)
      paramb1.d = i + paramb2.d; 
    paramb2.b = k + n;
    paramList.set(paramInt1, paramb2);
    paramList.set(paramInt2, paramb1);
  }
  
  public final void d(List<a.b> paramList, int paramInt1, int paramInt2) {
    a.b b1 = paramList.get(paramInt1);
    a.b b2 = paramList.get(paramInt2);
    int i = b2.a;
    if (i != 1) {
      if (i != 2) {
        if (i == 4)
          f(paramList, paramInt1, b1, paramInt2, b2); 
      } else {
        e(paramList, paramInt1, b1, paramInt2, b2);
      } 
    } else {
      c(paramList, paramInt1, b1, paramInt2, b2);
    } 
  }
  
  public void e(List paramList, int paramInt1, a.b paramb1, int paramInt2, a.b paramb2) {
    // Byte code:
    //   0: aload_3
    //   1: getfield b : I
    //   4: istore #6
    //   6: aload_3
    //   7: getfield d : I
    //   10: istore #7
    //   12: iconst_0
    //   13: istore #8
    //   15: aload #5
    //   17: getfield b : I
    //   20: istore #9
    //   22: iload #6
    //   24: iload #7
    //   26: if_icmpge -> 64
    //   29: iload #9
    //   31: iload #6
    //   33: if_icmpne -> 58
    //   36: aload #5
    //   38: getfield d : I
    //   41: iload #7
    //   43: iload #6
    //   45: isub
    //   46: if_icmpne -> 58
    //   49: iconst_0
    //   50: istore #6
    //   52: iconst_1
    //   53: istore #8
    //   55: goto -> 99
    //   58: iconst_0
    //   59: istore #6
    //   61: goto -> 99
    //   64: iload #9
    //   66: iload #7
    //   68: iconst_1
    //   69: iadd
    //   70: if_icmpne -> 96
    //   73: aload #5
    //   75: getfield d : I
    //   78: iload #6
    //   80: iload #7
    //   82: isub
    //   83: if_icmpne -> 96
    //   86: iconst_1
    //   87: istore #6
    //   89: iload #6
    //   91: istore #8
    //   93: goto -> 99
    //   96: iconst_1
    //   97: istore #6
    //   99: aload #5
    //   101: getfield b : I
    //   104: istore #9
    //   106: iload #7
    //   108: iload #9
    //   110: if_icmpge -> 125
    //   113: aload #5
    //   115: iload #9
    //   117: iconst_1
    //   118: isub
    //   119: putfield b : I
    //   122: goto -> 190
    //   125: aload #5
    //   127: getfield d : I
    //   130: istore #10
    //   132: iload #7
    //   134: iload #9
    //   136: iload #10
    //   138: iadd
    //   139: if_icmpge -> 190
    //   142: aload #5
    //   144: iload #10
    //   146: iconst_1
    //   147: isub
    //   148: putfield d : I
    //   151: aload_3
    //   152: iconst_2
    //   153: putfield a : I
    //   156: aload_3
    //   157: iconst_1
    //   158: putfield d : I
    //   161: aload #5
    //   163: getfield d : I
    //   166: ifne -> 189
    //   169: aload_1
    //   170: iload #4
    //   172: invokeinterface remove : (I)Ljava/lang/Object;
    //   177: pop
    //   178: aload_0
    //   179: getfield a : Landroidx/recyclerview/widget/g$a;
    //   182: aload #5
    //   184: invokeinterface a : (Landroidx/recyclerview/widget/a$b;)V
    //   189: return
    //   190: aload_3
    //   191: getfield b : I
    //   194: istore #10
    //   196: aload #5
    //   198: getfield b : I
    //   201: istore #9
    //   203: aconst_null
    //   204: astore #11
    //   206: iload #10
    //   208: iload #9
    //   210: if_icmpgt -> 225
    //   213: aload #5
    //   215: iload #9
    //   217: iconst_1
    //   218: iadd
    //   219: putfield b : I
    //   222: goto -> 282
    //   225: aload #5
    //   227: getfield d : I
    //   230: istore #7
    //   232: iload #10
    //   234: iload #9
    //   236: iload #7
    //   238: iadd
    //   239: if_icmpge -> 282
    //   242: aload_0
    //   243: getfield a : Landroidx/recyclerview/widget/g$a;
    //   246: iconst_2
    //   247: iload #10
    //   249: iconst_1
    //   250: iadd
    //   251: iload #9
    //   253: iload #7
    //   255: iadd
    //   256: iload #10
    //   258: isub
    //   259: aconst_null
    //   260: invokeinterface b : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   265: astore #11
    //   267: aload #5
    //   269: aload_3
    //   270: getfield b : I
    //   273: aload #5
    //   275: getfield b : I
    //   278: isub
    //   279: putfield d : I
    //   282: iload #8
    //   284: ifeq -> 317
    //   287: aload_1
    //   288: iload_2
    //   289: aload #5
    //   291: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   296: pop
    //   297: aload_1
    //   298: iload #4
    //   300: invokeinterface remove : (I)Ljava/lang/Object;
    //   305: pop
    //   306: aload_0
    //   307: getfield a : Landroidx/recyclerview/widget/g$a;
    //   310: aload_3
    //   311: invokeinterface a : (Landroidx/recyclerview/widget/a$b;)V
    //   316: return
    //   317: iload #6
    //   319: ifeq -> 430
    //   322: aload #11
    //   324: ifnull -> 383
    //   327: aload_3
    //   328: getfield b : I
    //   331: istore #6
    //   333: iload #6
    //   335: aload #11
    //   337: getfield b : I
    //   340: if_icmple -> 355
    //   343: aload_3
    //   344: iload #6
    //   346: aload #11
    //   348: getfield d : I
    //   351: isub
    //   352: putfield b : I
    //   355: aload_3
    //   356: getfield d : I
    //   359: istore #6
    //   361: iload #6
    //   363: aload #11
    //   365: getfield b : I
    //   368: if_icmple -> 383
    //   371: aload_3
    //   372: iload #6
    //   374: aload #11
    //   376: getfield d : I
    //   379: isub
    //   380: putfield d : I
    //   383: aload_3
    //   384: getfield b : I
    //   387: istore #6
    //   389: iload #6
    //   391: aload #5
    //   393: getfield b : I
    //   396: if_icmple -> 411
    //   399: aload_3
    //   400: iload #6
    //   402: aload #5
    //   404: getfield d : I
    //   407: isub
    //   408: putfield b : I
    //   411: aload_3
    //   412: getfield d : I
    //   415: istore #6
    //   417: iload #6
    //   419: aload #5
    //   421: getfield b : I
    //   424: if_icmple -> 547
    //   427: goto -> 535
    //   430: aload #11
    //   432: ifnull -> 491
    //   435: aload_3
    //   436: getfield b : I
    //   439: istore #6
    //   441: iload #6
    //   443: aload #11
    //   445: getfield b : I
    //   448: if_icmplt -> 463
    //   451: aload_3
    //   452: iload #6
    //   454: aload #11
    //   456: getfield d : I
    //   459: isub
    //   460: putfield b : I
    //   463: aload_3
    //   464: getfield d : I
    //   467: istore #6
    //   469: iload #6
    //   471: aload #11
    //   473: getfield b : I
    //   476: if_icmplt -> 491
    //   479: aload_3
    //   480: iload #6
    //   482: aload #11
    //   484: getfield d : I
    //   487: isub
    //   488: putfield d : I
    //   491: aload_3
    //   492: getfield b : I
    //   495: istore #6
    //   497: iload #6
    //   499: aload #5
    //   501: getfield b : I
    //   504: if_icmplt -> 519
    //   507: aload_3
    //   508: iload #6
    //   510: aload #5
    //   512: getfield d : I
    //   515: isub
    //   516: putfield b : I
    //   519: aload_3
    //   520: getfield d : I
    //   523: istore #6
    //   525: iload #6
    //   527: aload #5
    //   529: getfield b : I
    //   532: if_icmplt -> 547
    //   535: aload_3
    //   536: iload #6
    //   538: aload #5
    //   540: getfield d : I
    //   543: isub
    //   544: putfield d : I
    //   547: aload_1
    //   548: iload_2
    //   549: aload #5
    //   551: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   556: pop
    //   557: aload_3
    //   558: getfield b : I
    //   561: aload_3
    //   562: getfield d : I
    //   565: if_icmpeq -> 581
    //   568: aload_1
    //   569: iload #4
    //   571: aload_3
    //   572: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   577: pop
    //   578: goto -> 590
    //   581: aload_1
    //   582: iload #4
    //   584: invokeinterface remove : (I)Ljava/lang/Object;
    //   589: pop
    //   590: aload #11
    //   592: ifnull -> 604
    //   595: aload_1
    //   596: iload_2
    //   597: aload #11
    //   599: invokeinterface add : (ILjava/lang/Object;)V
    //   604: return
  }
  
  public void f(List paramList, int paramInt1, a.b paramb1, int paramInt2, a.b paramb2) {
    // Byte code:
    //   0: aload_3
    //   1: getfield d : I
    //   4: istore #6
    //   6: aload #5
    //   8: getfield b : I
    //   11: istore #7
    //   13: aconst_null
    //   14: astore #8
    //   16: iload #6
    //   18: iload #7
    //   20: if_icmpge -> 35
    //   23: aload #5
    //   25: iload #7
    //   27: iconst_1
    //   28: isub
    //   29: putfield b : I
    //   32: goto -> 86
    //   35: aload #5
    //   37: getfield d : I
    //   40: istore #9
    //   42: iload #6
    //   44: iload #7
    //   46: iload #9
    //   48: iadd
    //   49: if_icmpge -> 86
    //   52: aload #5
    //   54: iload #9
    //   56: iconst_1
    //   57: isub
    //   58: putfield d : I
    //   61: aload_0
    //   62: getfield a : Landroidx/recyclerview/widget/g$a;
    //   65: iconst_4
    //   66: aload_3
    //   67: getfield b : I
    //   70: iconst_1
    //   71: aload #5
    //   73: getfield c : Ljava/lang/Object;
    //   76: invokeinterface b : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   81: astore #10
    //   83: goto -> 89
    //   86: aconst_null
    //   87: astore #10
    //   89: aload_3
    //   90: getfield b : I
    //   93: istore #7
    //   95: aload #5
    //   97: getfield b : I
    //   100: istore #9
    //   102: iload #7
    //   104: iload #9
    //   106: if_icmpgt -> 121
    //   109: aload #5
    //   111: iload #9
    //   113: iconst_1
    //   114: iadd
    //   115: putfield b : I
    //   118: goto -> 184
    //   121: aload #5
    //   123: getfield d : I
    //   126: istore #6
    //   128: iload #7
    //   130: iload #9
    //   132: iload #6
    //   134: iadd
    //   135: if_icmpge -> 184
    //   138: iload #9
    //   140: iload #6
    //   142: iadd
    //   143: iload #7
    //   145: isub
    //   146: istore #9
    //   148: aload_0
    //   149: getfield a : Landroidx/recyclerview/widget/g$a;
    //   152: iconst_4
    //   153: iload #7
    //   155: iconst_1
    //   156: iadd
    //   157: iload #9
    //   159: aload #5
    //   161: getfield c : Ljava/lang/Object;
    //   164: invokeinterface b : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   169: astore #8
    //   171: aload #5
    //   173: aload #5
    //   175: getfield d : I
    //   178: iload #9
    //   180: isub
    //   181: putfield d : I
    //   184: aload_1
    //   185: iload #4
    //   187: aload_3
    //   188: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   193: pop
    //   194: aload #5
    //   196: getfield d : I
    //   199: ifle -> 215
    //   202: aload_1
    //   203: iload_2
    //   204: aload #5
    //   206: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   211: pop
    //   212: goto -> 234
    //   215: aload_1
    //   216: iload_2
    //   217: invokeinterface remove : (I)Ljava/lang/Object;
    //   222: pop
    //   223: aload_0
    //   224: getfield a : Landroidx/recyclerview/widget/g$a;
    //   227: aload #5
    //   229: invokeinterface a : (Landroidx/recyclerview/widget/a$b;)V
    //   234: aload #10
    //   236: ifnull -> 248
    //   239: aload_1
    //   240: iload_2
    //   241: aload #10
    //   243: invokeinterface add : (ILjava/lang/Object;)V
    //   248: aload #8
    //   250: ifnull -> 262
    //   253: aload_1
    //   254: iload_2
    //   255: aload #8
    //   257: invokeinterface add : (ILjava/lang/Object;)V
    //   262: return
  }
  
  public static interface a {
    void a(a.b param1b);
    
    a.b b(int param1Int1, int param1Int2, int param1Int3, Object param1Object);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */