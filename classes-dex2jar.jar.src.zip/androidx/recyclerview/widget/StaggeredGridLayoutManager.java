package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import o.n;

public class StaggeredGridLayoutManager extends RecyclerView.o {
  public BitSet A;
  
  public int B = -1;
  
  public int C = Integer.MIN_VALUE;
  
  public LazySpanLookup D = new LazySpanLookup();
  
  public int E = 2;
  
  public boolean F;
  
  public boolean G;
  
  public SavedState H;
  
  public int I;
  
  public final Rect J = new Rect();
  
  public final b K = new b(this);
  
  public boolean L = false;
  
  public boolean M = true;
  
  public int[] N;
  
  public final Runnable O = new a(this);
  
  public int r = -1;
  
  public c[] s;
  
  public h t;
  
  public h u;
  
  public int v;
  
  public int w;
  
  public final f x;
  
  public boolean y = false;
  
  public boolean z = false;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    RecyclerView.o.d d = RecyclerView.o.g0(paramContext, paramAttributeSet, paramInt1, paramInt2);
    B2(d.a);
    D2(d.b);
    C2(d.c);
    this.x = new f();
    U1();
  }
  
  public void A0(int paramInt) {
    super.A0(paramInt);
    for (byte b1 = 0; b1 < this.r; b1++)
      this.s[b1].r(paramInt); 
  }
  
  public final void A2(int paramInt) {
    boolean bool2;
    f f1 = this.x;
    f1.e = paramInt;
    boolean bool1 = this.z;
    boolean bool = true;
    if (paramInt == -1) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool1 == bool2) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    f1.d = paramInt;
  }
  
  public void B0(int paramInt) {
    super.B0(paramInt);
    for (byte b1 = 0; b1 < this.r; b1++)
      this.s[b1].r(paramInt); 
  }
  
  public void B2(int paramInt) {
    if (paramInt == 0 || paramInt == 1) {
      f(null);
      if (paramInt == this.v)
        return; 
      this.v = paramInt;
      h h1 = this.t;
      this.t = this.u;
      this.u = h1;
      q1();
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public RecyclerView.LayoutParams C() {
    return (this.v == 0) ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
  }
  
  public void C2(boolean paramBoolean) {
    f(null);
    SavedState savedState = this.H;
    if (savedState != null && savedState.mReverseLayout != paramBoolean)
      savedState.mReverseLayout = paramBoolean; 
    this.y = paramBoolean;
    q1();
  }
  
  public RecyclerView.LayoutParams D(Context paramContext, AttributeSet paramAttributeSet) {
    return new LayoutParams(paramContext, paramAttributeSet);
  }
  
  public void D2(int paramInt) {
    f(null);
    if (paramInt != this.r) {
      m2();
      this.r = paramInt;
      this.A = new BitSet(this.r);
      this.s = new c[this.r];
      for (paramInt = 0; paramInt < this.r; paramInt++)
        this.s[paramInt] = new c(this, paramInt); 
      q1();
    } 
  }
  
  public RecyclerView.LayoutParams E(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams);
  }
  
  public final void E2(int paramInt1, int paramInt2) {
    for (byte b1 = 0; b1 < this.r; b1++) {
      if (!(this.s[b1]).a.isEmpty())
        K2(this.s[b1], paramInt1, paramInt2); 
    } 
  }
  
  public boolean F1() {
    boolean bool;
    if (this.H == null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean F2(RecyclerView.w paramw, b paramb) {
    boolean bool = this.F;
    int i = paramw.b();
    if (bool) {
      i = a2(i);
    } else {
      i = W1(i);
    } 
    paramb.a = i;
    paramb.b = Integer.MIN_VALUE;
    return true;
  }
  
  public void G0(RecyclerView paramRecyclerView, RecyclerView.t paramt) {
    super.G0(paramRecyclerView, paramt);
    l1(this.O);
    for (byte b1 = 0; b1 < this.r; b1++)
      this.s[b1].e(); 
    paramRecyclerView.requestLayout();
  }
  
  public final void G1(View paramView) {
    for (int i = this.r - 1; i >= 0; i--)
      this.s[i].a(paramView); 
  }
  
  public boolean G2(RecyclerView.w paramw, b paramb) {
    boolean bool = paramw.e();
    boolean bool1 = false;
    if (!bool) {
      int i = this.B;
      if (i == -1)
        return false; 
      if (i < 0 || i >= paramw.b()) {
        this.B = -1;
        this.C = Integer.MIN_VALUE;
        return false;
      } 
      SavedState savedState = this.H;
      if (savedState == null || savedState.mAnchorPosition == -1 || savedState.mSpanOffsetsSize < 1) {
        View view = B(this.B);
        if (view != null) {
          if (this.z) {
            i = e2();
          } else {
            i = d2();
          } 
          paramb.a = i;
          if (this.C != Integer.MIN_VALUE) {
            int j;
            if (paramb.c) {
              i = this.t.i() - this.C;
              j = this.t.d(view);
            } else {
              i = this.t.m() + this.C;
              j = this.t.g(view);
            } 
            paramb.b = i - j;
            return true;
          } 
          if (this.t.e(view) > this.t.n()) {
            if (paramb.c) {
              i = this.t.i();
            } else {
              i = this.t.m();
            } 
            paramb.b = i;
            return true;
          } 
          i = this.t.g(view) - this.t.m();
          if (i < 0) {
            paramb.b = -i;
            return true;
          } 
          i = this.t.i() - this.t.d(view);
          if (i < 0) {
            paramb.b = i;
            return true;
          } 
          paramb.b = Integer.MIN_VALUE;
        } else {
          int j = this.B;
          paramb.a = j;
          i = this.C;
          if (i == Integer.MIN_VALUE) {
            if (L1(j) == 1)
              bool1 = true; 
            paramb.c = bool1;
            paramb.a();
          } else {
            paramb.b(i);
          } 
          paramb.d = true;
        } 
        return true;
      } 
      paramb.b = Integer.MIN_VALUE;
      paramb.a = this.B;
      return true;
    } 
    return false;
  }
  
  public View H0(View paramView, int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    if (I() == 0)
      return null; 
    paramView = A(paramView);
    if (paramView == null)
      return null; 
    y2();
    int i = R1(paramInt);
    if (i == Integer.MIN_VALUE)
      return null; 
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    boolean bool1 = layoutParams.f;
    c c1 = layoutParams.e;
    if (i == 1) {
      paramInt = e2();
    } else {
      paramInt = d2();
    } 
    I2(paramInt, paramw);
    A2(i);
    f f1 = this.x;
    f1.c = f1.d + paramInt;
    f1.b = (int)(this.t.n() * 0.33333334F);
    f1 = this.x;
    f1.h = true;
    int j = 0;
    f1.a = false;
    V1(paramt, f1, paramw);
    this.F = this.z;
    if (!bool1) {
      View view = c1.m(paramInt, i);
      if (view != null && view != paramView)
        return view; 
    } 
    if (r2(i)) {
      for (int m = this.r - 1; m >= 0; m--) {
        View view = this.s[m].m(paramInt, i);
        if (view != null && view != paramView)
          return view; 
      } 
    } else {
      for (byte b1 = 0; b1 < this.r; b1++) {
        View view = this.s[b1].m(paramInt, i);
        if (view != null && view != paramView)
          return view; 
      } 
    } 
    boolean bool2 = this.y;
    if (i == -1) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if ((bool2 ^ true) == paramInt) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (!bool1) {
      int m;
      if (paramInt != 0) {
        m = c1.f();
      } else {
        m = c1.g();
      } 
      View view = B(m);
      if (view != null && view != paramView)
        return view; 
    } 
    int k = j;
    if (r2(i)) {
      for (k = this.r - 1; k >= 0; k--) {
        if (k != c1.e) {
          c[] arrayOfC = this.s;
          if (paramInt != 0) {
            j = arrayOfC[k].f();
          } else {
            j = arrayOfC[k].g();
          } 
          View view = B(j);
          if (view != null && view != paramView)
            return view; 
        } 
      } 
    } else {
      while (k < this.r) {
        c[] arrayOfC = this.s;
        if (paramInt != 0) {
          j = arrayOfC[k].f();
        } else {
          j = arrayOfC[k].g();
        } 
        View view = B(j);
        if (view != null && view != paramView)
          return view; 
        k++;
      } 
    } 
    return null;
  }
  
  public final void H1(b paramb) {
    boolean bool;
    SavedState savedState = this.H;
    int i = savedState.mSpanOffsetsSize;
    if (i > 0)
      if (i == this.r) {
        for (i = 0; i < this.r; i++) {
          this.s[i].e();
          savedState = this.H;
          int j = savedState.mSpanOffsets[i];
          int k = j;
          if (j != Integer.MIN_VALUE) {
            if (savedState.mAnchorLayoutFromEnd) {
              k = this.t.i();
            } else {
              k = this.t.m();
            } 
            k = j + k;
          } 
          this.s[i].v(k);
        } 
      } else {
        savedState.a();
        savedState = this.H;
        savedState.mAnchorPosition = savedState.mVisibleAnchorPosition;
      }  
    savedState = this.H;
    this.G = savedState.mLastLayoutRTL;
    C2(savedState.mReverseLayout);
    y2();
    savedState = this.H;
    i = savedState.mAnchorPosition;
    if (i != -1) {
      this.B = i;
      bool = savedState.mAnchorLayoutFromEnd;
    } else {
      bool = this.z;
    } 
    paramb.c = bool;
    if (savedState.mSpanLookupSize > 1) {
      LazySpanLookup lazySpanLookup = this.D;
      lazySpanLookup.a = savedState.mSpanLookup;
      lazySpanLookup.b = savedState.mFullSpanItems;
    } 
  }
  
  public void H2(RecyclerView.w paramw, b paramb) {
    if (G2(paramw, paramb))
      return; 
    if (F2(paramw, paramb))
      return; 
    paramb.a();
    paramb.a = 0;
  }
  
  public void I0(AccessibilityEvent paramAccessibilityEvent) {
    super.I0(paramAccessibilityEvent);
    if (I() > 0) {
      View view1 = Y1(false);
      View view2 = X1(false);
      if (view1 != null && view2 != null) {
        int i = f0(view1);
        int j = f0(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
        } else {
          paramAccessibilityEvent.setFromIndex(j);
          paramAccessibilityEvent.setToIndex(i);
        } 
      } 
    } 
  }
  
  public boolean I1() {
    int i = this.s[0].l(-2147483648);
    for (byte b1 = 1; b1 < this.r; b1++) {
      if (this.s[b1].l(-2147483648) != i)
        return false; 
    } 
    return true;
  }
  
  public final void I2(int paramInt, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: getfield x : Landroidx/recyclerview/widget/f;
    //   4: astore_3
    //   5: iconst_0
    //   6: istore #4
    //   8: aload_3
    //   9: iconst_0
    //   10: putfield b : I
    //   13: aload_3
    //   14: iload_1
    //   15: putfield c : I
    //   18: aload_0
    //   19: invokevirtual v0 : ()Z
    //   22: ifeq -> 93
    //   25: aload_2
    //   26: invokevirtual c : ()I
    //   29: istore #5
    //   31: iload #5
    //   33: iconst_m1
    //   34: if_icmpeq -> 93
    //   37: aload_0
    //   38: getfield z : Z
    //   41: istore #6
    //   43: iload #5
    //   45: iload_1
    //   46: if_icmpge -> 55
    //   49: iconst_1
    //   50: istore #7
    //   52: goto -> 58
    //   55: iconst_0
    //   56: istore #7
    //   58: iload #6
    //   60: iload #7
    //   62: if_icmpne -> 79
    //   65: aload_0
    //   66: getfield t : Landroidx/recyclerview/widget/h;
    //   69: invokevirtual n : ()I
    //   72: istore_1
    //   73: iconst_0
    //   74: istore #5
    //   76: goto -> 98
    //   79: aload_0
    //   80: getfield t : Landroidx/recyclerview/widget/h;
    //   83: invokevirtual n : ()I
    //   86: istore #5
    //   88: iconst_0
    //   89: istore_1
    //   90: goto -> 98
    //   93: iconst_0
    //   94: istore_1
    //   95: iload_1
    //   96: istore #5
    //   98: aload_0
    //   99: invokevirtual L : ()Z
    //   102: ifeq -> 141
    //   105: aload_0
    //   106: getfield x : Landroidx/recyclerview/widget/f;
    //   109: aload_0
    //   110: getfield t : Landroidx/recyclerview/widget/h;
    //   113: invokevirtual m : ()I
    //   116: iload #5
    //   118: isub
    //   119: putfield f : I
    //   122: aload_0
    //   123: getfield x : Landroidx/recyclerview/widget/f;
    //   126: aload_0
    //   127: getfield t : Landroidx/recyclerview/widget/h;
    //   130: invokevirtual i : ()I
    //   133: iload_1
    //   134: iadd
    //   135: putfield g : I
    //   138: goto -> 167
    //   141: aload_0
    //   142: getfield x : Landroidx/recyclerview/widget/f;
    //   145: aload_0
    //   146: getfield t : Landroidx/recyclerview/widget/h;
    //   149: invokevirtual h : ()I
    //   152: iload_1
    //   153: iadd
    //   154: putfield g : I
    //   157: aload_0
    //   158: getfield x : Landroidx/recyclerview/widget/f;
    //   161: iload #5
    //   163: ineg
    //   164: putfield f : I
    //   167: aload_0
    //   168: getfield x : Landroidx/recyclerview/widget/f;
    //   171: astore_2
    //   172: aload_2
    //   173: iconst_0
    //   174: putfield h : Z
    //   177: aload_2
    //   178: iconst_1
    //   179: putfield a : Z
    //   182: iload #4
    //   184: istore #7
    //   186: aload_0
    //   187: getfield t : Landroidx/recyclerview/widget/h;
    //   190: invokevirtual k : ()I
    //   193: ifne -> 213
    //   196: iload #4
    //   198: istore #7
    //   200: aload_0
    //   201: getfield t : Landroidx/recyclerview/widget/h;
    //   204: invokevirtual h : ()I
    //   207: ifne -> 213
    //   210: iconst_1
    //   211: istore #7
    //   213: aload_2
    //   214: iload #7
    //   216: putfield i : Z
    //   219: return
  }
  
  public boolean J1() {
    int i = this.s[0].p(-2147483648);
    for (byte b1 = 1; b1 < this.r; b1++) {
      if (this.s[b1].p(-2147483648) != i)
        return false; 
    } 
    return true;
  }
  
  public void J2(int paramInt) {
    this.w = paramInt / this.r;
    this.I = View.MeasureSpec.makeMeasureSpec(paramInt, this.u.k());
  }
  
  public final void K1(View paramView, LayoutParams paramLayoutParams, f paramf) {
    if (paramf.e == 1) {
      if (paramLayoutParams.f) {
        G1(paramView);
      } else {
        paramLayoutParams.e.a(paramView);
      } 
    } else if (paramLayoutParams.f) {
      t2(paramView);
    } else {
      paramLayoutParams.e.u(paramView);
    } 
  }
  
  public final void K2(c paramc, int paramInt1, int paramInt2) {
    int i = paramc.j();
    if ((paramInt1 == -1) ? (paramc.o() + i <= paramInt2) : (paramc.k() - i >= paramInt2))
      this.A.set(paramc.e, false); 
  }
  
  public final int L1(int paramInt) {
    boolean bool;
    int i = I();
    byte b1 = -1;
    if (i == 0) {
      if (this.z)
        b1 = 1; 
      return b1;
    } 
    if (paramInt < d2()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.z)
      b1 = 1; 
    return b1;
  }
  
  public final int L2(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  public int M(RecyclerView.t paramt, RecyclerView.w paramw) {
    return (this.v == 1) ? this.r : super.M(paramt, paramw);
  }
  
  public boolean M1() {
    int i;
    int j;
    byte b1;
    if (I() == 0 || this.E == 0 || !p0())
      return false; 
    if (this.z) {
      i = e2();
      j = d2();
    } else {
      i = d2();
      j = e2();
    } 
    if (i == 0 && l2() != null) {
      this.D.b();
      r1();
      q1();
      return true;
    } 
    if (!this.L)
      return false; 
    if (this.z) {
      b1 = -1;
    } else {
      b1 = 1;
    } 
    LazySpanLookup lazySpanLookup = this.D;
    LazySpanLookup.FullSpanItem fullSpanItem1 = lazySpanLookup.e(i, ++j, b1, true);
    if (fullSpanItem1 == null) {
      this.L = false;
      this.D.d(j);
      return false;
    } 
    LazySpanLookup.FullSpanItem fullSpanItem2 = this.D.e(i, fullSpanItem1.mPosition, b1 * -1, true);
    if (fullSpanItem2 == null) {
      this.D.d(fullSpanItem1.mPosition);
      r1();
      q1();
      return true;
    } 
    this.D.d(fullSpanItem2.mPosition + 1);
    r1();
    q1();
    return true;
  }
  
  public void N0(RecyclerView.t paramt, RecyclerView.w paramw, View paramView, n paramn) {
    boolean bool;
    int m;
    ViewGroup.LayoutParams layoutParams1 = paramView.getLayoutParams();
    if (!(layoutParams1 instanceof LayoutParams)) {
      M0(paramView, paramn);
      return;
    } 
    LayoutParams layoutParams = (LayoutParams)layoutParams1;
    int i = this.v;
    int j = 1;
    int k = 1;
    if (i == 0) {
      i = layoutParams.e();
      bool = layoutParams.f;
      j = k;
      if (bool)
        j = this.r; 
      m = -1;
      k = -1;
    } else {
      i = -1;
      byte b1 = -1;
      m = layoutParams.e();
      bool = layoutParams.f;
      if (bool)
        j = this.r; 
      k = j;
      j = b1;
    } 
    paramn.K(n.c.a(i, j, m, k, bool, false));
  }
  
  public final boolean N1(c paramc) {
    if (this.z) {
      if (paramc.k() < this.t.i()) {
        ArrayList arrayList = paramc.a;
        return (paramc.n((View)arrayList.get(arrayList.size() - 1))).f ^ true;
      } 
    } else if (paramc.o() > this.t.m()) {
      return (paramc.n((View)paramc.a.get(0))).f ^ true;
    } 
    return false;
  }
  
  public final int O1(RecyclerView.w paramw) {
    return (I() == 0) ? 0 : j.a(paramw, this.t, Y1(this.M ^ true), X1(this.M ^ true), this, this.M);
  }
  
  public void P0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    k2(paramInt1, paramInt2, 1);
  }
  
  public final int P1(RecyclerView.w paramw) {
    return (I() == 0) ? 0 : j.b(paramw, this.t, Y1(this.M ^ true), X1(this.M ^ true), this, this.M, this.z);
  }
  
  public void Q0(RecyclerView paramRecyclerView) {
    this.D.b();
    q1();
  }
  
  public final int Q1(RecyclerView.w paramw) {
    return (I() == 0) ? 0 : j.c(paramw, this.t, Y1(this.M ^ true), X1(this.M ^ true), this, this.M);
  }
  
  public void R0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    k2(paramInt1, paramInt2, 8);
  }
  
  public final int R1(int paramInt) {
    int i = -1;
    boolean bool1 = true;
    boolean bool2 = true;
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 17) {
          if (paramInt != 33) {
            if (paramInt != 66) {
              if (paramInt != 130)
                return Integer.MIN_VALUE; 
              if (this.v == 1) {
                paramInt = bool2;
              } else {
                paramInt = Integer.MIN_VALUE;
              } 
              return paramInt;
            } 
            if (this.v == 0) {
              paramInt = bool1;
            } else {
              paramInt = Integer.MIN_VALUE;
            } 
            return paramInt;
          } 
          if (this.v != 1)
            i = Integer.MIN_VALUE; 
          return i;
        } 
        if (this.v != 0)
          i = Integer.MIN_VALUE; 
        return i;
      } 
      return (this.v == 1) ? 1 : (n2() ? -1 : 1);
    } 
    return (this.v == 1) ? -1 : (n2() ? 1 : -1);
  }
  
  public void S0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    k2(paramInt1, paramInt2, 2);
  }
  
  public final LazySpanLookup.FullSpanItem S1(int paramInt) {
    LazySpanLookup.FullSpanItem fullSpanItem = new LazySpanLookup.FullSpanItem();
    fullSpanItem.mGapPerSpan = new int[this.r];
    for (byte b1 = 0; b1 < this.r; b1++)
      fullSpanItem.mGapPerSpan[b1] = paramInt - this.s[b1].l(paramInt); 
    return fullSpanItem;
  }
  
  public final LazySpanLookup.FullSpanItem T1(int paramInt) {
    LazySpanLookup.FullSpanItem fullSpanItem = new LazySpanLookup.FullSpanItem();
    fullSpanItem.mGapPerSpan = new int[this.r];
    for (byte b1 = 0; b1 < this.r; b1++)
      fullSpanItem.mGapPerSpan[b1] = this.s[b1].p(paramInt) - paramInt; 
    return fullSpanItem;
  }
  
  public void U0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    k2(paramInt1, paramInt2, 4);
  }
  
  public final void U1() {
    this.t = h.b(this, this.v);
    this.u = h.b(this, 1 - this.v);
  }
  
  public void V0(RecyclerView.t paramt, RecyclerView.w paramw) {
    q2(paramt, paramw, true);
  }
  
  public final int V1(RecyclerView.t paramt, f paramf, RecyclerView.w paramw) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A : Ljava/util/BitSet;
    //   4: astore #4
    //   6: aload_0
    //   7: getfield r : I
    //   10: istore #5
    //   12: iconst_0
    //   13: istore #6
    //   15: aload #4
    //   17: iconst_0
    //   18: iload #5
    //   20: iconst_1
    //   21: invokevirtual set : (IIZ)V
    //   24: aload_0
    //   25: getfield x : Landroidx/recyclerview/widget/f;
    //   28: getfield i : Z
    //   31: ifeq -> 57
    //   34: aload_2
    //   35: getfield e : I
    //   38: iconst_1
    //   39: if_icmpne -> 50
    //   42: ldc_w 2147483647
    //   45: istore #5
    //   47: goto -> 90
    //   50: ldc -2147483648
    //   52: istore #5
    //   54: goto -> 90
    //   57: aload_2
    //   58: getfield e : I
    //   61: iconst_1
    //   62: if_icmpne -> 79
    //   65: aload_2
    //   66: getfield g : I
    //   69: aload_2
    //   70: getfield b : I
    //   73: iadd
    //   74: istore #5
    //   76: goto -> 90
    //   79: aload_2
    //   80: getfield f : I
    //   83: aload_2
    //   84: getfield b : I
    //   87: isub
    //   88: istore #5
    //   90: aload_0
    //   91: aload_2
    //   92: getfield e : I
    //   95: iload #5
    //   97: invokevirtual E2 : (II)V
    //   100: aload_0
    //   101: getfield z : Z
    //   104: ifeq -> 119
    //   107: aload_0
    //   108: getfield t : Landroidx/recyclerview/widget/h;
    //   111: invokevirtual i : ()I
    //   114: istore #7
    //   116: goto -> 128
    //   119: aload_0
    //   120: getfield t : Landroidx/recyclerview/widget/h;
    //   123: invokevirtual m : ()I
    //   126: istore #7
    //   128: iconst_0
    //   129: istore #8
    //   131: aload_2
    //   132: aload_3
    //   133: invokevirtual a : (Landroidx/recyclerview/widget/RecyclerView$w;)Z
    //   136: ifeq -> 904
    //   139: aload_0
    //   140: getfield x : Landroidx/recyclerview/widget/f;
    //   143: getfield i : Z
    //   146: ifne -> 159
    //   149: aload_0
    //   150: getfield A : Ljava/util/BitSet;
    //   153: invokevirtual isEmpty : ()Z
    //   156: ifne -> 904
    //   159: aload_2
    //   160: aload_1
    //   161: invokevirtual b : (Landroidx/recyclerview/widget/RecyclerView$t;)Landroid/view/View;
    //   164: astore #9
    //   166: aload #9
    //   168: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   171: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams
    //   174: astore #10
    //   176: aload #10
    //   178: invokevirtual a : ()I
    //   181: istore #11
    //   183: aload_0
    //   184: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   187: iload #11
    //   189: invokevirtual g : (I)I
    //   192: istore #8
    //   194: iload #8
    //   196: iconst_m1
    //   197: if_icmpne -> 206
    //   200: iconst_1
    //   201: istore #12
    //   203: goto -> 210
    //   206: iload #6
    //   208: istore #12
    //   210: iload #12
    //   212: ifeq -> 256
    //   215: aload #10
    //   217: getfield f : Z
    //   220: ifeq -> 235
    //   223: aload_0
    //   224: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   227: iload #6
    //   229: aaload
    //   230: astore #4
    //   232: goto -> 242
    //   235: aload_0
    //   236: aload_2
    //   237: invokevirtual j2 : (Landroidx/recyclerview/widget/f;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   240: astore #4
    //   242: aload_0
    //   243: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   246: iload #11
    //   248: aload #4
    //   250: invokevirtual n : (ILandroidx/recyclerview/widget/StaggeredGridLayoutManager$c;)V
    //   253: goto -> 265
    //   256: aload_0
    //   257: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   260: iload #8
    //   262: aaload
    //   263: astore #4
    //   265: aload #10
    //   267: aload #4
    //   269: putfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   272: aload_2
    //   273: getfield e : I
    //   276: iconst_1
    //   277: if_icmpne -> 289
    //   280: aload_0
    //   281: aload #9
    //   283: invokevirtual c : (Landroid/view/View;)V
    //   286: goto -> 297
    //   289: aload_0
    //   290: aload #9
    //   292: iload #6
    //   294: invokevirtual d : (Landroid/view/View;I)V
    //   297: aload_0
    //   298: aload #9
    //   300: aload #10
    //   302: iload #6
    //   304: invokevirtual p2 : (Landroid/view/View;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams;Z)V
    //   307: aload_2
    //   308: getfield e : I
    //   311: iconst_1
    //   312: if_icmpne -> 415
    //   315: aload #10
    //   317: getfield f : Z
    //   320: ifeq -> 334
    //   323: aload_0
    //   324: iload #7
    //   326: invokevirtual f2 : (I)I
    //   329: istore #6
    //   331: goto -> 343
    //   334: aload #4
    //   336: iload #7
    //   338: invokevirtual l : (I)I
    //   341: istore #6
    //   343: aload_0
    //   344: getfield t : Landroidx/recyclerview/widget/h;
    //   347: aload #9
    //   349: invokevirtual e : (Landroid/view/View;)I
    //   352: istore #8
    //   354: iload #12
    //   356: ifeq -> 397
    //   359: aload #10
    //   361: getfield f : Z
    //   364: ifeq -> 397
    //   367: aload_0
    //   368: iload #6
    //   370: invokevirtual S1 : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;
    //   373: astore #13
    //   375: aload #13
    //   377: iconst_m1
    //   378: putfield mGapDir : I
    //   381: aload #13
    //   383: iload #11
    //   385: putfield mPosition : I
    //   388: aload_0
    //   389: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   392: aload #13
    //   394: invokevirtual a : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;)V
    //   397: iload #8
    //   399: iload #6
    //   401: iadd
    //   402: istore #14
    //   404: iload #6
    //   406: istore #8
    //   408: iload #14
    //   410: istore #6
    //   412: goto -> 500
    //   415: aload #10
    //   417: getfield f : Z
    //   420: ifeq -> 434
    //   423: aload_0
    //   424: iload #7
    //   426: invokevirtual i2 : (I)I
    //   429: istore #6
    //   431: goto -> 443
    //   434: aload #4
    //   436: iload #7
    //   438: invokevirtual p : (I)I
    //   441: istore #6
    //   443: iload #6
    //   445: aload_0
    //   446: getfield t : Landroidx/recyclerview/widget/h;
    //   449: aload #9
    //   451: invokevirtual e : (Landroid/view/View;)I
    //   454: isub
    //   455: istore #8
    //   457: iload #12
    //   459: ifeq -> 500
    //   462: aload #10
    //   464: getfield f : Z
    //   467: ifeq -> 500
    //   470: aload_0
    //   471: iload #6
    //   473: invokevirtual T1 : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;
    //   476: astore #13
    //   478: aload #13
    //   480: iconst_1
    //   481: putfield mGapDir : I
    //   484: aload #13
    //   486: iload #11
    //   488: putfield mPosition : I
    //   491: aload_0
    //   492: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   495: aload #13
    //   497: invokevirtual a : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;)V
    //   500: aload #10
    //   502: getfield f : Z
    //   505: ifeq -> 584
    //   508: aload_2
    //   509: getfield d : I
    //   512: iconst_m1
    //   513: if_icmpne -> 584
    //   516: iload #12
    //   518: ifeq -> 529
    //   521: aload_0
    //   522: iconst_1
    //   523: putfield L : Z
    //   526: goto -> 584
    //   529: aload_2
    //   530: getfield e : I
    //   533: iconst_1
    //   534: if_icmpne -> 546
    //   537: aload_0
    //   538: invokevirtual I1 : ()Z
    //   541: istore #15
    //   543: goto -> 552
    //   546: aload_0
    //   547: invokevirtual J1 : ()Z
    //   550: istore #15
    //   552: iload #15
    //   554: iconst_1
    //   555: ixor
    //   556: ifeq -> 584
    //   559: aload_0
    //   560: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   563: iload #11
    //   565: invokevirtual f : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;
    //   568: astore #13
    //   570: aload #13
    //   572: ifnull -> 521
    //   575: aload #13
    //   577: iconst_1
    //   578: putfield mHasUnwantedGapAfter : Z
    //   581: goto -> 521
    //   584: aload_0
    //   585: aload #9
    //   587: aload #10
    //   589: aload_2
    //   590: invokevirtual K1 : (Landroid/view/View;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams;Landroidx/recyclerview/widget/f;)V
    //   593: aload_0
    //   594: invokevirtual n2 : ()Z
    //   597: ifeq -> 680
    //   600: aload_0
    //   601: getfield v : I
    //   604: iconst_1
    //   605: if_icmpne -> 680
    //   608: aload #10
    //   610: getfield f : Z
    //   613: ifeq -> 628
    //   616: aload_0
    //   617: getfield u : Landroidx/recyclerview/widget/h;
    //   620: invokevirtual i : ()I
    //   623: istore #12
    //   625: goto -> 655
    //   628: aload_0
    //   629: getfield u : Landroidx/recyclerview/widget/h;
    //   632: invokevirtual i : ()I
    //   635: aload_0
    //   636: getfield r : I
    //   639: iconst_1
    //   640: isub
    //   641: aload #4
    //   643: getfield e : I
    //   646: isub
    //   647: aload_0
    //   648: getfield w : I
    //   651: imul
    //   652: isub
    //   653: istore #12
    //   655: aload_0
    //   656: getfield u : Landroidx/recyclerview/widget/h;
    //   659: aload #9
    //   661: invokevirtual e : (Landroid/view/View;)I
    //   664: istore #11
    //   666: iload #12
    //   668: istore #14
    //   670: iload #12
    //   672: iload #11
    //   674: isub
    //   675: istore #12
    //   677: goto -> 746
    //   680: aload #10
    //   682: getfield f : Z
    //   685: ifeq -> 700
    //   688: aload_0
    //   689: getfield u : Landroidx/recyclerview/widget/h;
    //   692: invokevirtual m : ()I
    //   695: istore #12
    //   697: goto -> 720
    //   700: aload #4
    //   702: getfield e : I
    //   705: aload_0
    //   706: getfield w : I
    //   709: imul
    //   710: aload_0
    //   711: getfield u : Landroidx/recyclerview/widget/h;
    //   714: invokevirtual m : ()I
    //   717: iadd
    //   718: istore #12
    //   720: aload_0
    //   721: getfield u : Landroidx/recyclerview/widget/h;
    //   724: aload #9
    //   726: invokevirtual e : (Landroid/view/View;)I
    //   729: istore #14
    //   731: iload #12
    //   733: istore #11
    //   735: iload #14
    //   737: iload #12
    //   739: iadd
    //   740: istore #14
    //   742: iload #11
    //   744: istore #12
    //   746: aload_0
    //   747: getfield v : I
    //   750: iconst_1
    //   751: if_icmpne -> 769
    //   754: iload #12
    //   756: istore #11
    //   758: iload #8
    //   760: istore #12
    //   762: iload #11
    //   764: istore #8
    //   766: goto -> 781
    //   769: iload #6
    //   771: istore #11
    //   773: iload #14
    //   775: istore #6
    //   777: iload #11
    //   779: istore #14
    //   781: aload_0
    //   782: aload #9
    //   784: iload #8
    //   786: iload #12
    //   788: iload #14
    //   790: iload #6
    //   792: invokevirtual x0 : (Landroid/view/View;IIII)V
    //   795: aload #10
    //   797: getfield f : Z
    //   800: ifeq -> 819
    //   803: aload_0
    //   804: aload_0
    //   805: getfield x : Landroidx/recyclerview/widget/f;
    //   808: getfield e : I
    //   811: iload #5
    //   813: invokevirtual E2 : (II)V
    //   816: goto -> 834
    //   819: aload_0
    //   820: aload #4
    //   822: aload_0
    //   823: getfield x : Landroidx/recyclerview/widget/f;
    //   826: getfield e : I
    //   829: iload #5
    //   831: invokevirtual K2 : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;II)V
    //   834: aload_0
    //   835: aload_1
    //   836: aload_0
    //   837: getfield x : Landroidx/recyclerview/widget/f;
    //   840: invokevirtual u2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/f;)V
    //   843: aload_0
    //   844: getfield x : Landroidx/recyclerview/widget/f;
    //   847: getfield h : Z
    //   850: ifeq -> 895
    //   853: aload #9
    //   855: invokevirtual hasFocusable : ()Z
    //   858: ifeq -> 895
    //   861: aload #10
    //   863: getfield f : Z
    //   866: ifeq -> 879
    //   869: aload_0
    //   870: getfield A : Ljava/util/BitSet;
    //   873: invokevirtual clear : ()V
    //   876: goto -> 895
    //   879: aload_0
    //   880: getfield A : Ljava/util/BitSet;
    //   883: aload #4
    //   885: getfield e : I
    //   888: iconst_0
    //   889: invokevirtual set : (IZ)V
    //   892: goto -> 895
    //   895: iconst_0
    //   896: istore #6
    //   898: iconst_1
    //   899: istore #8
    //   901: goto -> 131
    //   904: iload #8
    //   906: ifne -> 918
    //   909: aload_0
    //   910: aload_1
    //   911: aload_0
    //   912: getfield x : Landroidx/recyclerview/widget/f;
    //   915: invokevirtual u2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/f;)V
    //   918: aload_0
    //   919: getfield x : Landroidx/recyclerview/widget/f;
    //   922: getfield e : I
    //   925: iconst_m1
    //   926: if_icmpne -> 957
    //   929: aload_0
    //   930: aload_0
    //   931: getfield t : Landroidx/recyclerview/widget/h;
    //   934: invokevirtual m : ()I
    //   937: invokevirtual i2 : (I)I
    //   940: istore #5
    //   942: aload_0
    //   943: getfield t : Landroidx/recyclerview/widget/h;
    //   946: invokevirtual m : ()I
    //   949: iload #5
    //   951: isub
    //   952: istore #5
    //   954: goto -> 978
    //   957: aload_0
    //   958: aload_0
    //   959: getfield t : Landroidx/recyclerview/widget/h;
    //   962: invokevirtual i : ()I
    //   965: invokevirtual f2 : (I)I
    //   968: aload_0
    //   969: getfield t : Landroidx/recyclerview/widget/h;
    //   972: invokevirtual i : ()I
    //   975: isub
    //   976: istore #5
    //   978: iload #5
    //   980: ifle -> 997
    //   983: aload_2
    //   984: getfield b : I
    //   987: iload #5
    //   989: invokestatic min : (II)I
    //   992: istore #6
    //   994: goto -> 997
    //   997: iload #6
    //   999: ireturn
  }
  
  public void W0(RecyclerView.w paramw) {
    super.W0(paramw);
    this.B = -1;
    this.C = Integer.MIN_VALUE;
    this.H = null;
    this.K.c();
  }
  
  public final int W1(int paramInt) {
    int i = I();
    for (byte b1 = 0; b1 < i; b1++) {
      int j = f0(H(b1));
      if (j >= 0 && j < paramInt)
        return j; 
    } 
    return 0;
  }
  
  public View X1(boolean paramBoolean) {
    int i = this.t.m();
    int j = this.t.i();
    int k = I() - 1;
    View view;
    for (view = null; k >= 0; view = view2) {
      View view1 = H(k);
      int m = this.t.g(view1);
      int n = this.t.d(view1);
      View view2 = view;
      if (n > i)
        if (m >= j) {
          view2 = view;
        } else {
          if (n <= j || !paramBoolean)
            return view1; 
          view2 = view;
          if (view == null)
            view2 = view1; 
        }  
      k--;
    } 
    return view;
  }
  
  public View Y1(boolean paramBoolean) {
    int i = this.t.m();
    int j = this.t.i();
    int k = I();
    View view = null;
    byte b1 = 0;
    while (b1 < k) {
      View view1 = H(b1);
      int m = this.t.g(view1);
      View view2 = view;
      if (this.t.d(view1) > i)
        if (m >= j) {
          view2 = view;
        } else {
          if (m >= i || !paramBoolean)
            return view1; 
          view2 = view;
          if (view == null)
            view2 = view1; 
        }  
      b1++;
      view = view2;
    } 
    return view;
  }
  
  public int Z1() {
    View view;
    int i;
    if (this.z) {
      view = X1(true);
    } else {
      view = Y1(true);
    } 
    if (view == null) {
      i = -1;
    } else {
      i = f0(view);
    } 
    return i;
  }
  
  public void a1(Parcelable paramParcelable) {
    if (paramParcelable instanceof SavedState) {
      this.H = (SavedState)paramParcelable;
      q1();
    } 
  }
  
  public final int a2(int paramInt) {
    for (int i = I() - 1; i >= 0; i--) {
      int j = f0(H(i));
      if (j >= 0 && j < paramInt)
        return j; 
    } 
    return 0;
  }
  
  public Parcelable b1() {
    // Byte code:
    //   0: aload_0
    //   1: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   4: ifnull -> 19
    //   7: new androidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState
    //   10: dup
    //   11: aload_0
    //   12: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   15: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;)V
    //   18: areturn
    //   19: new androidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore_1
    //   27: aload_1
    //   28: aload_0
    //   29: getfield y : Z
    //   32: putfield mReverseLayout : Z
    //   35: aload_1
    //   36: aload_0
    //   37: getfield F : Z
    //   40: putfield mAnchorLayoutFromEnd : Z
    //   43: aload_1
    //   44: aload_0
    //   45: getfield G : Z
    //   48: putfield mLastLayoutRTL : Z
    //   51: aload_0
    //   52: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   55: astore_2
    //   56: iconst_0
    //   57: istore_3
    //   58: aload_2
    //   59: ifnull -> 97
    //   62: aload_2
    //   63: getfield a : [I
    //   66: astore #4
    //   68: aload #4
    //   70: ifnull -> 97
    //   73: aload_1
    //   74: aload #4
    //   76: putfield mSpanLookup : [I
    //   79: aload_1
    //   80: aload #4
    //   82: arraylength
    //   83: putfield mSpanLookupSize : I
    //   86: aload_1
    //   87: aload_2
    //   88: getfield b : Ljava/util/List;
    //   91: putfield mFullSpanItems : Ljava/util/List;
    //   94: goto -> 102
    //   97: aload_1
    //   98: iconst_0
    //   99: putfield mSpanLookupSize : I
    //   102: aload_0
    //   103: invokevirtual I : ()I
    //   106: ifle -> 270
    //   109: aload_0
    //   110: getfield F : Z
    //   113: ifeq -> 125
    //   116: aload_0
    //   117: invokevirtual e2 : ()I
    //   120: istore #5
    //   122: goto -> 131
    //   125: aload_0
    //   126: invokevirtual d2 : ()I
    //   129: istore #5
    //   131: aload_1
    //   132: iload #5
    //   134: putfield mAnchorPosition : I
    //   137: aload_1
    //   138: aload_0
    //   139: invokevirtual Z1 : ()I
    //   142: putfield mVisibleAnchorPosition : I
    //   145: aload_0
    //   146: getfield r : I
    //   149: istore #5
    //   151: aload_1
    //   152: iload #5
    //   154: putfield mSpanOffsetsSize : I
    //   157: aload_1
    //   158: iload #5
    //   160: newarray int
    //   162: putfield mSpanOffsets : [I
    //   165: iload_3
    //   166: aload_0
    //   167: getfield r : I
    //   170: if_icmpge -> 285
    //   173: aload_0
    //   174: getfield F : Z
    //   177: ifeq -> 216
    //   180: aload_0
    //   181: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   184: iload_3
    //   185: aaload
    //   186: ldc -2147483648
    //   188: invokevirtual l : (I)I
    //   191: istore #6
    //   193: iload #6
    //   195: istore #5
    //   197: iload #6
    //   199: ldc -2147483648
    //   201: if_icmpeq -> 256
    //   204: aload_0
    //   205: getfield t : Landroidx/recyclerview/widget/h;
    //   208: invokevirtual i : ()I
    //   211: istore #5
    //   213: goto -> 249
    //   216: aload_0
    //   217: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   220: iload_3
    //   221: aaload
    //   222: ldc -2147483648
    //   224: invokevirtual p : (I)I
    //   227: istore #6
    //   229: iload #6
    //   231: istore #5
    //   233: iload #6
    //   235: ldc -2147483648
    //   237: if_icmpeq -> 256
    //   240: aload_0
    //   241: getfield t : Landroidx/recyclerview/widget/h;
    //   244: invokevirtual m : ()I
    //   247: istore #5
    //   249: iload #6
    //   251: iload #5
    //   253: isub
    //   254: istore #5
    //   256: aload_1
    //   257: getfield mSpanOffsets : [I
    //   260: iload_3
    //   261: iload #5
    //   263: iastore
    //   264: iinc #3, 1
    //   267: goto -> 165
    //   270: aload_1
    //   271: iconst_m1
    //   272: putfield mAnchorPosition : I
    //   275: aload_1
    //   276: iconst_m1
    //   277: putfield mVisibleAnchorPosition : I
    //   280: aload_1
    //   281: iconst_0
    //   282: putfield mSpanOffsetsSize : I
    //   285: aload_1
    //   286: areturn
  }
  
  public final void b2(RecyclerView.t paramt, RecyclerView.w paramw, boolean paramBoolean) {
    int i = f2(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.t.i() - i;
    if (i > 0) {
      i -= -z2(-i, paramt, paramw);
      if (paramBoolean && i > 0)
        this.t.r(i); 
    } 
  }
  
  public void c1(int paramInt) {
    if (paramInt == 0)
      M1(); 
  }
  
  public final void c2(RecyclerView.t paramt, RecyclerView.w paramw, boolean paramBoolean) {
    int i = i2(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.t.m();
    if (i > 0) {
      i -= z2(i, paramt, paramw);
      if (paramBoolean && i > 0)
        this.t.r(-i); 
    } 
  }
  
  public int d2() {
    int i = I();
    int j = 0;
    if (i != 0)
      j = f0(H(0)); 
    return j;
  }
  
  public int e2() {
    int i = I();
    if (i == 0) {
      i = 0;
    } else {
      i = f0(H(i - 1));
    } 
    return i;
  }
  
  public void f(String paramString) {
    if (this.H == null)
      super.f(paramString); 
  }
  
  public final int f2(int paramInt) {
    int i = this.s[0].l(paramInt);
    byte b1 = 1;
    while (b1 < this.r) {
      int j = this.s[b1].l(paramInt);
      int k = i;
      if (j > i)
        k = j; 
      b1++;
      i = k;
    } 
    return i;
  }
  
  public final int g2(int paramInt) {
    int i = this.s[0].p(paramInt);
    byte b1 = 1;
    while (b1 < this.r) {
      int j = this.s[b1].p(paramInt);
      int k = i;
      if (j > i)
        k = j; 
      b1++;
      i = k;
    } 
    return i;
  }
  
  public final int h2(int paramInt) {
    int i = this.s[0].l(paramInt);
    byte b1 = 1;
    while (b1 < this.r) {
      int j = this.s[b1].l(paramInt);
      int k = i;
      if (j < i)
        k = j; 
      b1++;
      i = k;
    } 
    return i;
  }
  
  public int i0(RecyclerView.t paramt, RecyclerView.w paramw) {
    return (this.v == 0) ? this.r : super.i0(paramt, paramw);
  }
  
  public final int i2(int paramInt) {
    int i = this.s[0].p(paramInt);
    byte b1 = 1;
    while (b1 < this.r) {
      int j = this.s[b1].p(paramInt);
      int k = i;
      if (j < i)
        k = j; 
      b1++;
      i = k;
    } 
    return i;
  }
  
  public boolean j() {
    boolean bool;
    if (this.v == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final c j2(f paramf) {
    int i;
    int j;
    byte b1;
    if (r2(paramf.e)) {
      i = this.r - 1;
      j = -1;
      b1 = -1;
    } else {
      j = this.r;
      i = 0;
      b1 = 1;
    } 
    int k = paramf.e;
    c c2 = null;
    paramf = null;
    if (k == 1) {
      c c3;
      int i1 = this.t.m();
      k = Integer.MAX_VALUE;
      int i2 = i;
      while (i2 != j) {
        c2 = this.s[i2];
        int i3 = c2.l(i1);
        i = k;
        if (i3 < k) {
          c3 = c2;
          i = i3;
        } 
        i2 += b1;
        k = i;
      } 
      return c3;
    } 
    int m = this.t.i();
    k = Integer.MIN_VALUE;
    c c1 = c2;
    int n = i;
    while (n != j) {
      c2 = this.s[n];
      int i1 = c2.p(m);
      i = k;
      if (i1 > k) {
        c1 = c2;
        i = i1;
      } 
      n += b1;
      k = i;
    } 
    return c1;
  }
  
  public boolean k() {
    int i = this.v;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public final void k2(int paramInt1, int paramInt2, int paramInt3) {
    if (this.z) {
      int j = e2();
    } else {
      int j = d2();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        this.D.h(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    this.D.h(i);
  }
  
  public boolean l(RecyclerView.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public View l2() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual I : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield r : I
    //   15: invokespecial <init> : (I)V
    //   18: astore_2
    //   19: aload_2
    //   20: iconst_0
    //   21: aload_0
    //   22: getfield r : I
    //   25: iconst_1
    //   26: invokevirtual set : (IIZ)V
    //   29: aload_0
    //   30: getfield v : I
    //   33: istore_3
    //   34: iconst_m1
    //   35: istore #4
    //   37: iload_3
    //   38: iconst_1
    //   39: if_icmpne -> 54
    //   42: aload_0
    //   43: invokevirtual n2 : ()Z
    //   46: ifeq -> 54
    //   49: iconst_1
    //   50: istore_3
    //   51: goto -> 56
    //   54: iconst_m1
    //   55: istore_3
    //   56: aload_0
    //   57: getfield z : Z
    //   60: ifeq -> 69
    //   63: iconst_m1
    //   64: istore #5
    //   66: goto -> 76
    //   69: iload_1
    //   70: iconst_1
    //   71: iadd
    //   72: istore #5
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #6
    //   79: iload_1
    //   80: iload #5
    //   82: if_icmpge -> 91
    //   85: iconst_1
    //   86: istore #4
    //   88: iload_1
    //   89: istore #6
    //   91: iload #6
    //   93: iload #5
    //   95: if_icmpeq -> 350
    //   98: aload_0
    //   99: iload #6
    //   101: invokevirtual H : (I)Landroid/view/View;
    //   104: astore #7
    //   106: aload #7
    //   108: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   111: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams
    //   114: astore #8
    //   116: aload_2
    //   117: aload #8
    //   119: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   122: getfield e : I
    //   125: invokevirtual get : (I)Z
    //   128: ifeq -> 158
    //   131: aload_0
    //   132: aload #8
    //   134: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   137: invokevirtual N1 : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;)Z
    //   140: ifeq -> 146
    //   143: aload #7
    //   145: areturn
    //   146: aload_2
    //   147: aload #8
    //   149: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   152: getfield e : I
    //   155: invokevirtual clear : (I)V
    //   158: aload #8
    //   160: getfield f : Z
    //   163: ifeq -> 169
    //   166: goto -> 340
    //   169: iload #6
    //   171: iload #4
    //   173: iadd
    //   174: istore_1
    //   175: iload_1
    //   176: iload #5
    //   178: if_icmpeq -> 340
    //   181: aload_0
    //   182: iload_1
    //   183: invokevirtual H : (I)Landroid/view/View;
    //   186: astore #9
    //   188: aload_0
    //   189: getfield z : Z
    //   192: ifeq -> 234
    //   195: aload_0
    //   196: getfield t : Landroidx/recyclerview/widget/h;
    //   199: aload #7
    //   201: invokevirtual d : (Landroid/view/View;)I
    //   204: istore #10
    //   206: aload_0
    //   207: getfield t : Landroidx/recyclerview/widget/h;
    //   210: aload #9
    //   212: invokevirtual d : (Landroid/view/View;)I
    //   215: istore_1
    //   216: iload #10
    //   218: iload_1
    //   219: if_icmpge -> 225
    //   222: aload #7
    //   224: areturn
    //   225: iload #10
    //   227: iload_1
    //   228: if_icmpne -> 275
    //   231: goto -> 270
    //   234: aload_0
    //   235: getfield t : Landroidx/recyclerview/widget/h;
    //   238: aload #7
    //   240: invokevirtual g : (Landroid/view/View;)I
    //   243: istore_1
    //   244: aload_0
    //   245: getfield t : Landroidx/recyclerview/widget/h;
    //   248: aload #9
    //   250: invokevirtual g : (Landroid/view/View;)I
    //   253: istore #10
    //   255: iload_1
    //   256: iload #10
    //   258: if_icmple -> 264
    //   261: aload #7
    //   263: areturn
    //   264: iload_1
    //   265: iload #10
    //   267: if_icmpne -> 275
    //   270: iconst_1
    //   271: istore_1
    //   272: goto -> 277
    //   275: iconst_0
    //   276: istore_1
    //   277: iload_1
    //   278: ifeq -> 340
    //   281: aload #9
    //   283: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   286: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LayoutParams
    //   289: astore #9
    //   291: aload #8
    //   293: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   296: getfield e : I
    //   299: aload #9
    //   301: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   304: getfield e : I
    //   307: isub
    //   308: ifge -> 316
    //   311: iconst_1
    //   312: istore_1
    //   313: goto -> 318
    //   316: iconst_0
    //   317: istore_1
    //   318: iload_3
    //   319: ifge -> 328
    //   322: iconst_1
    //   323: istore #10
    //   325: goto -> 331
    //   328: iconst_0
    //   329: istore #10
    //   331: iload_1
    //   332: iload #10
    //   334: if_icmpeq -> 340
    //   337: aload #7
    //   339: areturn
    //   340: iload #6
    //   342: iload #4
    //   344: iadd
    //   345: istore #6
    //   347: goto -> 91
    //   350: aconst_null
    //   351: areturn
  }
  
  public void m2() {
    this.D.b();
    q1();
  }
  
  public void n(int paramInt1, int paramInt2, RecyclerView.w paramw, RecyclerView.o.c paramc) {
    if (this.v != 0)
      paramInt1 = paramInt2; 
    if (I() != 0 && paramInt1 != 0) {
      s2(paramInt1, paramw);
      int[] arrayOfInt = this.N;
      if (arrayOfInt == null || arrayOfInt.length < this.r)
        this.N = new int[this.r]; 
      boolean bool = false;
      paramInt2 = 0;
      for (paramInt1 = paramInt2; paramInt2 < this.r; paramInt1 = i) {
        f f1 = this.x;
        if (f1.d == -1) {
          i = f1.f;
          j = this.s[paramInt2].p(i);
        } else {
          i = this.s[paramInt2].l(f1.g);
          j = this.x.g;
        } 
        int j = i - j;
        int i = paramInt1;
        if (j >= 0) {
          this.N[paramInt1] = j;
          i = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.N, 0, paramInt1);
      for (paramInt2 = bool; paramInt2 < paramInt1 && this.x.a(paramw); paramInt2++) {
        paramc.a(this.x.c, this.N[paramInt2]);
        f f1 = this.x;
        f1.c += f1.d;
      } 
    } 
  }
  
  public boolean n2() {
    int i = X();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public final void o2(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    i(paramView, this.J);
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = layoutParams.leftMargin;
    Rect rect = this.J;
    paramInt1 = L2(paramInt1, i + rect.left, layoutParams.rightMargin + rect.right);
    i = layoutParams.topMargin;
    rect = this.J;
    paramInt2 = L2(paramInt2, i + rect.top, layoutParams.bottomMargin + rect.bottom);
    if (paramBoolean) {
      paramBoolean = D1(paramView, paramInt1, paramInt2, layoutParams);
    } else {
      paramBoolean = B1(paramView, paramInt1, paramInt2, layoutParams);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public int p(RecyclerView.w paramw) {
    return O1(paramw);
  }
  
  public final void p2(View paramView, LayoutParams paramLayoutParams, boolean paramBoolean) {
    if (paramLayoutParams.f) {
      if (this.v == 1) {
        i = this.I;
      } else {
        o2(paramView, RecyclerView.o.J(m0(), n0(), c0() + d0(), paramLayoutParams.width, true), this.I, paramBoolean);
        return;
      } 
    } else if (this.v == 1) {
      i = RecyclerView.o.J(this.w, n0(), 0, paramLayoutParams.width, false);
    } else {
      int m = RecyclerView.o.J(m0(), n0(), c0() + d0(), paramLayoutParams.width, true);
      i = RecyclerView.o.J(this.w, W(), 0, paramLayoutParams.height, false);
      o2(paramView, m, i, paramBoolean);
    } 
    int j = RecyclerView.o.J(V(), W(), e0() + b0(), paramLayoutParams.height, true);
    int k = i;
    int i = j;
    o2(paramView, k, i, paramBoolean);
  }
  
  public int q(RecyclerView.w paramw) {
    return P1(paramw);
  }
  
  public boolean q0() {
    boolean bool;
    if (this.E != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void q2(RecyclerView.t paramt, RecyclerView.w paramw, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield K : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   4: astore #4
    //   6: aload_0
    //   7: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield B : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual b : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual h1 : (Landroidx/recyclerview/widget/RecyclerView$t;)V
    //   33: aload #4
    //   35: invokevirtual c : ()V
    //   38: return
    //   39: aload #4
    //   41: getfield e : Z
    //   44: istore #5
    //   46: iconst_1
    //   47: istore #6
    //   49: iload #5
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield B : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #7
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #7
    //   81: iload #7
    //   83: ifeq -> 133
    //   86: aload #4
    //   88: invokevirtual c : ()V
    //   91: aload_0
    //   92: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   95: ifnull -> 107
    //   98: aload_0
    //   99: aload #4
    //   101: invokevirtual H1 : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;)V
    //   104: goto -> 120
    //   107: aload_0
    //   108: invokevirtual y2 : ()V
    //   111: aload #4
    //   113: aload_0
    //   114: getfield z : Z
    //   117: putfield c : Z
    //   120: aload_0
    //   121: aload_2
    //   122: aload #4
    //   124: invokevirtual H2 : (Landroidx/recyclerview/widget/RecyclerView$w;Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;)V
    //   127: aload #4
    //   129: iconst_1
    //   130: putfield e : Z
    //   133: aload_0
    //   134: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   137: ifnonnull -> 184
    //   140: aload_0
    //   141: getfield B : I
    //   144: iconst_m1
    //   145: if_icmpne -> 184
    //   148: aload #4
    //   150: getfield c : Z
    //   153: aload_0
    //   154: getfield F : Z
    //   157: if_icmpne -> 171
    //   160: aload_0
    //   161: invokevirtual n2 : ()Z
    //   164: aload_0
    //   165: getfield G : Z
    //   168: if_icmpeq -> 184
    //   171: aload_0
    //   172: getfield D : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup;
    //   175: invokevirtual b : ()V
    //   178: aload #4
    //   180: iconst_1
    //   181: putfield d : Z
    //   184: aload_0
    //   185: invokevirtual I : ()I
    //   188: ifle -> 386
    //   191: aload_0
    //   192: getfield H : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$SavedState;
    //   195: astore #8
    //   197: aload #8
    //   199: ifnull -> 211
    //   202: aload #8
    //   204: getfield mSpanOffsetsSize : I
    //   207: iconst_1
    //   208: if_icmpge -> 386
    //   211: aload #4
    //   213: getfield d : Z
    //   216: ifeq -> 273
    //   219: iconst_0
    //   220: istore #7
    //   222: iload #7
    //   224: aload_0
    //   225: getfield r : I
    //   228: if_icmpge -> 386
    //   231: aload_0
    //   232: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   235: iload #7
    //   237: aaload
    //   238: invokevirtual e : ()V
    //   241: aload #4
    //   243: getfield b : I
    //   246: istore #9
    //   248: iload #9
    //   250: ldc -2147483648
    //   252: if_icmpeq -> 267
    //   255: aload_0
    //   256: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   259: iload #7
    //   261: aaload
    //   262: iload #9
    //   264: invokevirtual v : (I)V
    //   267: iinc #7, 1
    //   270: goto -> 222
    //   273: iload #7
    //   275: ifne -> 338
    //   278: aload_0
    //   279: getfield K : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   282: getfield f : [I
    //   285: ifnonnull -> 291
    //   288: goto -> 338
    //   291: iconst_0
    //   292: istore #7
    //   294: iload #7
    //   296: aload_0
    //   297: getfield r : I
    //   300: if_icmpge -> 386
    //   303: aload_0
    //   304: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   307: iload #7
    //   309: aaload
    //   310: astore #8
    //   312: aload #8
    //   314: invokevirtual e : ()V
    //   317: aload #8
    //   319: aload_0
    //   320: getfield K : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   323: getfield f : [I
    //   326: iload #7
    //   328: iaload
    //   329: invokevirtual v : (I)V
    //   332: iinc #7, 1
    //   335: goto -> 294
    //   338: iconst_0
    //   339: istore #7
    //   341: iload #7
    //   343: aload_0
    //   344: getfield r : I
    //   347: if_icmpge -> 375
    //   350: aload_0
    //   351: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   354: iload #7
    //   356: aaload
    //   357: aload_0
    //   358: getfield z : Z
    //   361: aload #4
    //   363: getfield b : I
    //   366: invokevirtual b : (ZI)V
    //   369: iinc #7, 1
    //   372: goto -> 341
    //   375: aload_0
    //   376: getfield K : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   379: aload_0
    //   380: getfield s : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   383: invokevirtual d : ([Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;)V
    //   386: aload_0
    //   387: aload_1
    //   388: invokevirtual v : (Landroidx/recyclerview/widget/RecyclerView$t;)V
    //   391: aload_0
    //   392: getfield x : Landroidx/recyclerview/widget/f;
    //   395: iconst_0
    //   396: putfield a : Z
    //   399: aload_0
    //   400: iconst_0
    //   401: putfield L : Z
    //   404: aload_0
    //   405: aload_0
    //   406: getfield u : Landroidx/recyclerview/widget/h;
    //   409: invokevirtual n : ()I
    //   412: invokevirtual J2 : (I)V
    //   415: aload_0
    //   416: aload #4
    //   418: getfield a : I
    //   421: aload_2
    //   422: invokevirtual I2 : (ILandroidx/recyclerview/widget/RecyclerView$w;)V
    //   425: aload #4
    //   427: getfield c : Z
    //   430: ifeq -> 457
    //   433: aload_0
    //   434: iconst_m1
    //   435: invokevirtual A2 : (I)V
    //   438: aload_0
    //   439: aload_1
    //   440: aload_0
    //   441: getfield x : Landroidx/recyclerview/widget/f;
    //   444: aload_2
    //   445: invokevirtual V1 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   448: pop
    //   449: aload_0
    //   450: iconst_1
    //   451: invokevirtual A2 : (I)V
    //   454: goto -> 478
    //   457: aload_0
    //   458: iconst_1
    //   459: invokevirtual A2 : (I)V
    //   462: aload_0
    //   463: aload_1
    //   464: aload_0
    //   465: getfield x : Landroidx/recyclerview/widget/f;
    //   468: aload_2
    //   469: invokevirtual V1 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   472: pop
    //   473: aload_0
    //   474: iconst_m1
    //   475: invokevirtual A2 : (I)V
    //   478: aload_0
    //   479: getfield x : Landroidx/recyclerview/widget/f;
    //   482: astore #8
    //   484: aload #8
    //   486: aload #4
    //   488: getfield a : I
    //   491: aload #8
    //   493: getfield d : I
    //   496: iadd
    //   497: putfield c : I
    //   500: aload_0
    //   501: aload_1
    //   502: aload #8
    //   504: aload_2
    //   505: invokevirtual V1 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/f;Landroidx/recyclerview/widget/RecyclerView$w;)I
    //   508: pop
    //   509: aload_0
    //   510: invokevirtual x2 : ()V
    //   513: aload_0
    //   514: invokevirtual I : ()I
    //   517: ifle -> 558
    //   520: aload_0
    //   521: getfield z : Z
    //   524: ifeq -> 544
    //   527: aload_0
    //   528: aload_1
    //   529: aload_2
    //   530: iconst_1
    //   531: invokevirtual b2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   534: aload_0
    //   535: aload_1
    //   536: aload_2
    //   537: iconst_0
    //   538: invokevirtual c2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   541: goto -> 558
    //   544: aload_0
    //   545: aload_1
    //   546: aload_2
    //   547: iconst_1
    //   548: invokevirtual c2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   551: aload_0
    //   552: aload_1
    //   553: aload_2
    //   554: iconst_0
    //   555: invokevirtual b2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   558: iload_3
    //   559: ifeq -> 634
    //   562: aload_2
    //   563: invokevirtual e : ()Z
    //   566: ifne -> 634
    //   569: aload_0
    //   570: getfield E : I
    //   573: ifeq -> 603
    //   576: aload_0
    //   577: invokevirtual I : ()I
    //   580: ifle -> 603
    //   583: aload_0
    //   584: getfield L : Z
    //   587: ifne -> 597
    //   590: aload_0
    //   591: invokevirtual l2 : ()Landroid/view/View;
    //   594: ifnull -> 603
    //   597: iconst_1
    //   598: istore #7
    //   600: goto -> 606
    //   603: iconst_0
    //   604: istore #7
    //   606: iload #7
    //   608: ifeq -> 634
    //   611: aload_0
    //   612: aload_0
    //   613: getfield O : Ljava/lang/Runnable;
    //   616: invokevirtual l1 : (Ljava/lang/Runnable;)Z
    //   619: pop
    //   620: aload_0
    //   621: invokevirtual M1 : ()Z
    //   624: ifeq -> 634
    //   627: iload #6
    //   629: istore #7
    //   631: goto -> 637
    //   634: iconst_0
    //   635: istore #7
    //   637: aload_2
    //   638: invokevirtual e : ()Z
    //   641: ifeq -> 651
    //   644: aload_0
    //   645: getfield K : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   648: invokevirtual c : ()V
    //   651: aload_0
    //   652: aload #4
    //   654: getfield c : Z
    //   657: putfield F : Z
    //   660: aload_0
    //   661: aload_0
    //   662: invokevirtual n2 : ()Z
    //   665: putfield G : Z
    //   668: iload #7
    //   670: ifeq -> 687
    //   673: aload_0
    //   674: getfield K : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   677: invokevirtual c : ()V
    //   680: aload_0
    //   681: aload_1
    //   682: aload_2
    //   683: iconst_0
    //   684: invokevirtual q2 : (Landroidx/recyclerview/widget/RecyclerView$t;Landroidx/recyclerview/widget/RecyclerView$w;Z)V
    //   687: return
  }
  
  public int r(RecyclerView.w paramw) {
    return Q1(paramw);
  }
  
  public final boolean r2(int paramInt) {
    boolean bool;
    int i = this.v;
    boolean bool1 = true;
    boolean bool2 = true;
    if (i == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool != this.z) {
        bool = bool2;
      } else {
        bool = false;
      } 
      return bool;
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.z) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == n2()) {
      bool = bool1;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int s(RecyclerView.w paramw) {
    return O1(paramw);
  }
  
  public void s2(int paramInt, RecyclerView.w paramw) {
    int i;
    byte b1;
    if (paramInt > 0) {
      i = e2();
      b1 = 1;
    } else {
      i = d2();
      b1 = -1;
    } 
    this.x.a = true;
    I2(i, paramw);
    A2(b1);
    f f1 = this.x;
    f1.c = i + f1.d;
    f1.b = Math.abs(paramInt);
  }
  
  public int t(RecyclerView.w paramw) {
    return P1(paramw);
  }
  
  public int t1(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    return z2(paramInt, paramt, paramw);
  }
  
  public final void t2(View paramView) {
    for (int i = this.r - 1; i >= 0; i--)
      this.s[i].u(paramView); 
  }
  
  public int u(RecyclerView.w paramw) {
    return Q1(paramw);
  }
  
  public int u1(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    return z2(paramInt, paramt, paramw);
  }
  
  public final void u2(RecyclerView.t paramt, f paramf) {
    // Byte code:
    //   0: aload_2
    //   1: getfield a : Z
    //   4: ifeq -> 147
    //   7: aload_2
    //   8: getfield i : Z
    //   11: ifeq -> 17
    //   14: goto -> 147
    //   17: aload_2
    //   18: getfield b : I
    //   21: ifne -> 60
    //   24: aload_2
    //   25: getfield e : I
    //   28: iconst_m1
    //   29: if_icmpne -> 46
    //   32: aload_2
    //   33: getfield g : I
    //   36: istore_3
    //   37: aload_0
    //   38: aload_1
    //   39: iload_3
    //   40: invokevirtual v2 : (Landroidx/recyclerview/widget/RecyclerView$t;I)V
    //   43: goto -> 147
    //   46: aload_2
    //   47: getfield f : I
    //   50: istore_3
    //   51: aload_0
    //   52: aload_1
    //   53: iload_3
    //   54: invokevirtual w2 : (Landroidx/recyclerview/widget/RecyclerView$t;I)V
    //   57: goto -> 147
    //   60: aload_2
    //   61: getfield e : I
    //   64: iconst_m1
    //   65: if_icmpne -> 105
    //   68: aload_2
    //   69: getfield f : I
    //   72: istore_3
    //   73: iload_3
    //   74: aload_0
    //   75: iload_3
    //   76: invokevirtual g2 : (I)I
    //   79: isub
    //   80: istore_3
    //   81: iload_3
    //   82: ifge -> 88
    //   85: goto -> 32
    //   88: aload_2
    //   89: getfield g : I
    //   92: iload_3
    //   93: aload_2
    //   94: getfield b : I
    //   97: invokestatic min : (II)I
    //   100: isub
    //   101: istore_3
    //   102: goto -> 37
    //   105: aload_0
    //   106: aload_2
    //   107: getfield g : I
    //   110: invokevirtual h2 : (I)I
    //   113: aload_2
    //   114: getfield g : I
    //   117: isub
    //   118: istore_3
    //   119: iload_3
    //   120: ifge -> 126
    //   123: goto -> 46
    //   126: aload_2
    //   127: getfield f : I
    //   130: istore #4
    //   132: iload_3
    //   133: aload_2
    //   134: getfield b : I
    //   137: invokestatic min : (II)I
    //   140: iload #4
    //   142: iadd
    //   143: istore_3
    //   144: goto -> 51
    //   147: return
  }
  
  public final void v2(RecyclerView.t paramt, int paramInt) {
    int i = I() - 1;
    while (i >= 0) {
      View view = H(i);
      if (this.t.g(view) >= paramInt && this.t.q(view) >= paramInt) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.f) {
          byte b3;
          byte b1 = 0;
          byte b2 = 0;
          while (true) {
            b3 = b1;
            if (b2 < this.r) {
              if ((this.s[b2]).a.size() == 1)
                return; 
              b2++;
              continue;
            } 
            break;
          } 
          while (b3 < this.r) {
            this.s[b3].s();
            b3++;
          } 
        } else {
          if (layoutParams.e.a.size() == 1)
            return; 
          layoutParams.e.s();
        } 
        j1(view, paramt);
        i--;
      } 
    } 
  }
  
  public final void w2(RecyclerView.t paramt, int paramInt) {
    while (I() > 0) {
      byte b1 = 0;
      View view = H(0);
      if (this.t.d(view) <= paramInt && this.t.p(view) <= paramInt) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.f) {
          byte b3;
          byte b2 = 0;
          while (true) {
            b3 = b1;
            if (b2 < this.r) {
              if ((this.s[b2]).a.size() == 1)
                return; 
              b2++;
              continue;
            } 
            break;
          } 
          while (b3 < this.r) {
            this.s[b3].t();
            b3++;
          } 
        } else {
          if (layoutParams.e.a.size() == 1)
            return; 
          layoutParams.e.t();
        } 
        j1(view, paramt);
      } 
    } 
  }
  
  public final void x2() {
    if (this.u.k() == 1073741824)
      return; 
    int i = I();
    int j = 0;
    float f1 = 0.0F;
    int k;
    for (k = 0; k < i; k++) {
      View view = H(k);
      float f2 = this.u.e(view);
      if (f2 >= f1) {
        float f3 = f2;
        if (((LayoutParams)view.getLayoutParams()).f())
          f3 = f2 * 1.0F / this.r; 
        f1 = Math.max(f1, f3);
      } 
    } 
    int m = this.w;
    int n = Math.round(f1 * this.r);
    k = n;
    if (this.u.k() == Integer.MIN_VALUE)
      k = Math.min(n, this.u.n()); 
    J2(k);
    k = j;
    if (this.w == m)
      return; 
    while (k < i) {
      View view = H(k);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (!layoutParams.f)
        if (n2() && this.v == 1) {
          n = this.r;
          j = layoutParams.e.e;
          view.offsetLeftAndRight(-(n - 1 - j) * this.w - -(n - 1 - j) * m);
        } else {
          n = layoutParams.e.e;
          int i1 = this.w;
          j = this.v;
          n = i1 * n - n * m;
          if (j == 1) {
            view.offsetLeftAndRight(n);
          } else {
            view.offsetTopAndBottom(n);
          } 
        }  
      k++;
    } 
  }
  
  public void y1(Rect paramRect, int paramInt1, int paramInt2) {
    int i = c0() + d0();
    int j = e0() + b0();
    if (this.v == 1) {
      paramInt2 = RecyclerView.o.m(paramInt2, paramRect.height() + j, Z());
      paramInt1 = RecyclerView.o.m(paramInt1, this.w * this.r + i, a0());
    } else {
      paramInt1 = RecyclerView.o.m(paramInt1, paramRect.width() + i, a0());
      paramInt2 = RecyclerView.o.m(paramInt2, this.w * this.r + j, Z());
    } 
    x1(paramInt1, paramInt2);
  }
  
  public final void y2() {
    int i;
    if (this.v == 1 || !n2()) {
      boolean bool = this.y;
    } else {
      i = this.y ^ true;
    } 
    this.z = i;
  }
  
  public int z2(int paramInt, RecyclerView.t paramt, RecyclerView.w paramw) {
    if (I() == 0 || paramInt == 0)
      return 0; 
    s2(paramInt, paramw);
    int i = V1(paramt, this.x, paramw);
    if (this.x.b >= i)
      if (paramInt < 0) {
        paramInt = -i;
      } else {
        paramInt = i;
      }  
    this.t.r(-paramInt);
    this.F = this.z;
    f f1 = this.x;
    f1.b = 0;
    u2(paramt, f1);
    return paramInt;
  }
  
  public static class LayoutParams extends RecyclerView.LayoutParams {
    public StaggeredGridLayoutManager.c e;
    
    public boolean f;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public final int e() {
      StaggeredGridLayoutManager.c c1 = this.e;
      return (c1 == null) ? -1 : c1.e;
    }
    
    public boolean f() {
      return this.f;
    }
  }
  
  public static class LazySpanLookup {
    public int[] a;
    
    public List b;
    
    public void a(FullSpanItem param1FullSpanItem) {
      if (this.b == null)
        this.b = new ArrayList(); 
      int i = this.b.size();
      for (byte b = 0; b < i; b++) {
        FullSpanItem fullSpanItem = this.b.get(b);
        if (fullSpanItem.mPosition == param1FullSpanItem.mPosition)
          this.b.remove(b); 
        if (fullSpanItem.mPosition >= param1FullSpanItem.mPosition) {
          this.b.add(b, param1FullSpanItem);
          return;
        } 
      } 
      this.b.add(param1FullSpanItem);
    }
    
    public void b() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    public void c(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.a = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
      } else if (param1Int >= arrayOfInt.length) {
        int[] arrayOfInt1 = new int[o(param1Int)];
        this.a = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.a;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    public int d(int param1Int) {
      List list = this.b;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--) {
          if (((FullSpanItem)this.b.get(i)).mPosition >= param1Int)
            this.b.remove(i); 
        }  
      return h(param1Int);
    }
    
    public FullSpanItem e(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      List list = this.b;
      if (list == null)
        return null; 
      int i = list.size();
      for (byte b = 0; b < i; b++) {
        FullSpanItem fullSpanItem = this.b.get(b);
        int j = fullSpanItem.mPosition;
        if (j >= param1Int2)
          return null; 
        if (j >= param1Int1 && (param1Int3 == 0 || fullSpanItem.mGapDir == param1Int3 || (param1Boolean && fullSpanItem.mHasUnwantedGapAfter)))
          return fullSpanItem; 
      } 
      return null;
    }
    
    public FullSpanItem f(int param1Int) {
      List list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        FullSpanItem fullSpanItem = this.b.get(i);
        if (fullSpanItem.mPosition == param1Int)
          return fullSpanItem; 
      } 
      return null;
    }
    
    public int g(int param1Int) {
      int[] arrayOfInt = this.a;
      return (arrayOfInt == null || param1Int >= arrayOfInt.length) ? -1 : arrayOfInt[param1Int];
    }
    
    public int h(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null)
        return -1; 
      if (param1Int >= arrayOfInt.length)
        return -1; 
      int i = i(param1Int);
      if (i == -1) {
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, param1Int, arrayOfInt.length, -1);
        return this.a.length;
      } 
      arrayOfInt = this.a;
      Arrays.fill(arrayOfInt, param1Int, ++i, -1);
      return i;
    }
    
    public final int i(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Ljava/util/List;
      //   4: ifnonnull -> 9
      //   7: iconst_m1
      //   8: ireturn
      //   9: aload_0
      //   10: iload_1
      //   11: invokevirtual f : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem;
      //   14: astore_2
      //   15: aload_2
      //   16: ifnull -> 30
      //   19: aload_0
      //   20: getfield b : Ljava/util/List;
      //   23: aload_2
      //   24: invokeinterface remove : (Ljava/lang/Object;)Z
      //   29: pop
      //   30: aload_0
      //   31: getfield b : Ljava/util/List;
      //   34: invokeinterface size : ()I
      //   39: istore_3
      //   40: iconst_0
      //   41: istore #4
      //   43: iload #4
      //   45: iload_3
      //   46: if_icmpge -> 79
      //   49: aload_0
      //   50: getfield b : Ljava/util/List;
      //   53: iload #4
      //   55: invokeinterface get : (I)Ljava/lang/Object;
      //   60: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem
      //   63: getfield mPosition : I
      //   66: iload_1
      //   67: if_icmplt -> 73
      //   70: goto -> 82
      //   73: iinc #4, 1
      //   76: goto -> 43
      //   79: iconst_m1
      //   80: istore #4
      //   82: iload #4
      //   84: iconst_m1
      //   85: if_icmpeq -> 120
      //   88: aload_0
      //   89: getfield b : Ljava/util/List;
      //   92: iload #4
      //   94: invokeinterface get : (I)Ljava/lang/Object;
      //   99: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$LazySpanLookup$FullSpanItem
      //   102: astore_2
      //   103: aload_0
      //   104: getfield b : Ljava/util/List;
      //   107: iload #4
      //   109: invokeinterface remove : (I)Ljava/lang/Object;
      //   114: pop
      //   115: aload_2
      //   116: getfield mPosition : I
      //   119: ireturn
      //   120: iconst_m1
      //   121: ireturn
    }
    
    public void j(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null && param1Int1 < arrayOfInt.length) {
        int i = param1Int1 + param1Int2;
        c(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.a, param1Int1, i, -1);
        l(param1Int1, param1Int2);
      } 
    }
    
    public void k(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null && param1Int1 < arrayOfInt.length) {
        int i = param1Int1 + param1Int2;
        c(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, i, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        m(param1Int1, param1Int2);
      } 
    }
    
    public final void l(int param1Int1, int param1Int2) {
      List list = this.b;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        FullSpanItem fullSpanItem = this.b.get(i);
        int j = fullSpanItem.mPosition;
        if (j >= param1Int1)
          fullSpanItem.mPosition = j + param1Int2; 
      } 
    }
    
    public final void m(int param1Int1, int param1Int2) {
      List list = this.b;
      if (list == null)
        return; 
      for (int i = list.size() - 1; i >= 0; i--) {
        FullSpanItem fullSpanItem = this.b.get(i);
        int j = fullSpanItem.mPosition;
        if (j >= param1Int1)
          if (j < param1Int1 + param1Int2) {
            this.b.remove(i);
          } else {
            fullSpanItem.mPosition = j - param1Int2;
          }  
      } 
    }
    
    public void n(int param1Int, StaggeredGridLayoutManager.c param1c) {
      c(param1Int);
      this.a[param1Int] = param1c.e;
    }
    
    public int o(int param1Int) {
      int i;
      for (i = this.a.length; i <= param1Int; i *= 2);
      return i;
    }
    
    public static class FullSpanItem implements Parcelable {
      public static final Parcelable.Creator<FullSpanItem> CREATOR = new a();
      
      int mGapDir;
      
      int[] mGapPerSpan;
      
      boolean mHasUnwantedGapAfter;
      
      int mPosition;
      
      public FullSpanItem() {}
      
      public FullSpanItem(Parcel param2Parcel) {
        this.mPosition = param2Parcel.readInt();
        this.mGapDir = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.mHasUnwantedGapAfter = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.mGapPerSpan = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int a(int param2Int) {
        int[] arrayOfInt = this.mGapPerSpan;
        if (arrayOfInt == null) {
          param2Int = 0;
        } else {
          param2Int = arrayOfInt[param2Int];
        } 
        return param2Int;
      }
      
      public int describeContents() {
        return 0;
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FullSpanItem{mPosition=");
        stringBuilder.append(this.mPosition);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.mGapDir);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.mHasUnwantedGapAfter);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.mGapPerSpan));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        param2Parcel.writeInt(this.mPosition);
        param2Parcel.writeInt(this.mGapDir);
        param2Parcel.writeInt(this.mHasUnwantedGapAfter);
        int[] arrayOfInt = this.mGapPerSpan;
        if (arrayOfInt != null && arrayOfInt.length > 0) {
          param2Parcel.writeInt(arrayOfInt.length);
          param2Parcel.writeIntArray(this.mGapPerSpan);
        } else {
          param2Parcel.writeInt(0);
        } 
      }
      
      public static final class a implements Parcelable.Creator {
        public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem a(Parcel param3Parcel) {
          return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param3Parcel);
        }
        
        public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] b(int param3Int) {
          return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param3Int];
        }
      }
    }
    
    public static final class a implements Parcelable.Creator {
      public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem a(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] b(int param2Int) {
        return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param2Int];
      }
    }
  }
  
  public static class FullSpanItem implements Parcelable {
    public static final Parcelable.Creator<FullSpanItem> CREATOR = new a();
    
    int mGapDir;
    
    int[] mGapPerSpan;
    
    boolean mHasUnwantedGapAfter;
    
    int mPosition;
    
    public FullSpanItem() {}
    
    public FullSpanItem(Parcel param1Parcel) {
      this.mPosition = param1Parcel.readInt();
      this.mGapDir = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.mHasUnwantedGapAfter = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.mGapPerSpan = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int a(int param1Int) {
      int[] arrayOfInt = this.mGapPerSpan;
      if (arrayOfInt == null) {
        param1Int = 0;
      } else {
        param1Int = arrayOfInt[param1Int];
      } 
      return param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FullSpanItem{mPosition=");
      stringBuilder.append(this.mPosition);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.mGapDir);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.mHasUnwantedGapAfter);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.mGapPerSpan));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.mPosition);
      param1Parcel.writeInt(this.mGapDir);
      param1Parcel.writeInt(this.mHasUnwantedGapAfter);
      int[] arrayOfInt = this.mGapPerSpan;
      if (arrayOfInt != null && arrayOfInt.length > 0) {
        param1Parcel.writeInt(arrayOfInt.length);
        param1Parcel.writeIntArray(this.mGapPerSpan);
      } else {
        param1Parcel.writeInt(0);
      } 
    }
    
    public static final class a implements Parcelable.Creator {
      public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem a(Parcel param3Parcel) {
        return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param3Parcel);
      }
      
      public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] b(int param3Int) {
        return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param3Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem a(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[] b(int param1Int) {
      return new StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem[param1Int];
    }
  }
  
  public static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new a();
    
    boolean mAnchorLayoutFromEnd;
    
    int mAnchorPosition;
    
    List<StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem> mFullSpanItems;
    
    boolean mLastLayoutRTL;
    
    boolean mReverseLayout;
    
    int[] mSpanLookup;
    
    int mSpanLookupSize;
    
    int[] mSpanOffsets;
    
    int mSpanOffsetsSize;
    
    int mVisibleAnchorPosition;
    
    public SavedState() {}
    
    public SavedState(Parcel param1Parcel) {
      this.mAnchorPosition = param1Parcel.readInt();
      this.mVisibleAnchorPosition = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.mSpanOffsetsSize = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.mSpanOffsets = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.mSpanLookupSize = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.mSpanLookup = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool1 = false;
      if (i == 1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.mReverseLayout = bool2;
      if (param1Parcel.readInt() == 1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.mAnchorLayoutFromEnd = bool2;
      boolean bool2 = bool1;
      if (param1Parcel.readInt() == 1)
        bool2 = true; 
      this.mLastLayoutRTL = bool2;
      this.mFullSpanItems = param1Parcel.readArrayList(StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem.class.getClassLoader());
    }
    
    public SavedState(SavedState param1SavedState) {
      this.mSpanOffsetsSize = param1SavedState.mSpanOffsetsSize;
      this.mAnchorPosition = param1SavedState.mAnchorPosition;
      this.mVisibleAnchorPosition = param1SavedState.mVisibleAnchorPosition;
      this.mSpanOffsets = param1SavedState.mSpanOffsets;
      this.mSpanLookupSize = param1SavedState.mSpanLookupSize;
      this.mSpanLookup = param1SavedState.mSpanLookup;
      this.mReverseLayout = param1SavedState.mReverseLayout;
      this.mAnchorLayoutFromEnd = param1SavedState.mAnchorLayoutFromEnd;
      this.mLastLayoutRTL = param1SavedState.mLastLayoutRTL;
      this.mFullSpanItems = param1SavedState.mFullSpanItems;
    }
    
    public void a() {
      this.mSpanOffsets = null;
      this.mSpanOffsetsSize = 0;
      this.mSpanLookupSize = 0;
      this.mSpanLookup = null;
      this.mFullSpanItems = null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.mAnchorPosition);
      param1Parcel.writeInt(this.mVisibleAnchorPosition);
      param1Parcel.writeInt(this.mSpanOffsetsSize);
      if (this.mSpanOffsetsSize > 0)
        param1Parcel.writeIntArray(this.mSpanOffsets); 
      param1Parcel.writeInt(this.mSpanLookupSize);
      if (this.mSpanLookupSize > 0)
        param1Parcel.writeIntArray(this.mSpanLookup); 
      param1Parcel.writeInt(this.mReverseLayout);
      param1Parcel.writeInt(this.mAnchorLayoutFromEnd);
      param1Parcel.writeInt(this.mLastLayoutRTL);
      param1Parcel.writeList(this.mFullSpanItems);
    }
    
    public static final class a implements Parcelable.Creator {
      public StaggeredGridLayoutManager.SavedState a(Parcel param2Parcel) {
        return new StaggeredGridLayoutManager.SavedState(param2Parcel);
      }
      
      public StaggeredGridLayoutManager.SavedState[] b(int param2Int) {
        return new StaggeredGridLayoutManager.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator {
    public StaggeredGridLayoutManager.SavedState a(Parcel param1Parcel) {
      return new StaggeredGridLayoutManager.SavedState(param1Parcel);
    }
    
    public StaggeredGridLayoutManager.SavedState[] b(int param1Int) {
      return new StaggeredGridLayoutManager.SavedState[param1Int];
    }
  }
  
  public class a implements Runnable {
    public a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.a.M1();
    }
  }
  
  public class b {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public int[] f;
    
    public b(StaggeredGridLayoutManager this$0) {
      c();
    }
    
    public void a() {
      int i;
      if (this.c) {
        i = this.g.t.i();
      } else {
        i = this.g.t.m();
      } 
      this.b = i;
    }
    
    public void b(int param1Int) {
      if (this.c) {
        param1Int = this.g.t.i() - param1Int;
      } else {
        param1Int = this.g.t.m() + param1Int;
      } 
      this.b = param1Int;
    }
    
    public void c() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
    
    public void d(StaggeredGridLayoutManager.c[] param1ArrayOfc) {
      int i = param1ArrayOfc.length;
      int[] arrayOfInt = this.f;
      if (arrayOfInt == null || arrayOfInt.length < i)
        this.f = new int[this.g.s.length]; 
      for (byte b1 = 0; b1 < i; b1++)
        this.f[b1] = param1ArrayOfc[b1].p(-2147483648); 
    }
  }
  
  public class c {
    public ArrayList a = new ArrayList();
    
    public int b = Integer.MIN_VALUE;
    
    public int c = Integer.MIN_VALUE;
    
    public int d = 0;
    
    public final int e;
    
    public c(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    public void a(View param1View) {
      StaggeredGridLayoutManager.LayoutParams layoutParams = n(param1View);
      layoutParams.e = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (layoutParams.c() || layoutParams.b())
        this.d += this.f.t.e(param1View); 
    }
    
    public void b(boolean param1Boolean, int param1Int) {
      int i;
      if (param1Boolean) {
        i = l(-2147483648);
      } else {
        i = p(-2147483648);
      } 
      e();
      if (i == Integer.MIN_VALUE)
        return; 
      if ((param1Boolean && i < this.f.t.i()) || (!param1Boolean && i > this.f.t.m()))
        return; 
      int j = i;
      if (param1Int != Integer.MIN_VALUE)
        j = i + param1Int; 
      this.c = j;
      this.b = j;
    }
    
    public void c() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.LayoutParams layoutParams = n(view);
      this.c = this.f.t.d(view);
      if (layoutParams.f) {
        StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem fullSpanItem = this.f.D.f(layoutParams.a());
        if (fullSpanItem != null && fullSpanItem.mGapDir == 1)
          this.c += fullSpanItem.a(this.e); 
      } 
    }
    
    public void d() {
      View view = this.a.get(0);
      StaggeredGridLayoutManager.LayoutParams layoutParams = n(view);
      this.b = this.f.t.g(view);
      if (layoutParams.f) {
        StaggeredGridLayoutManager.LazySpanLookup.FullSpanItem fullSpanItem = this.f.D.f(layoutParams.a());
        if (fullSpanItem != null && fullSpanItem.mGapDir == -1)
          this.b -= fullSpanItem.a(this.e); 
      } 
    }
    
    public void e() {
      this.a.clear();
      q();
      this.d = 0;
    }
    
    public int f() {
      int i;
      if (this.f.y) {
        i = i(this.a.size() - 1, -1, true);
      } else {
        i = i(0, this.a.size(), true);
      } 
      return i;
    }
    
    public int g() {
      int i;
      if (this.f.y) {
        i = i(0, this.a.size(), true);
      } else {
        i = i(this.a.size() - 1, -1, true);
      } 
      return i;
    }
    
    public int h(int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      // Byte code:
      //   0: aload_0
      //   1: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   4: getfield t : Landroidx/recyclerview/widget/h;
      //   7: invokevirtual m : ()I
      //   10: istore #6
      //   12: aload_0
      //   13: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   16: getfield t : Landroidx/recyclerview/widget/h;
      //   19: invokevirtual i : ()I
      //   22: istore #7
      //   24: iload_2
      //   25: iload_1
      //   26: if_icmple -> 35
      //   29: iconst_1
      //   30: istore #8
      //   32: goto -> 38
      //   35: iconst_m1
      //   36: istore #8
      //   38: iload_1
      //   39: iload_2
      //   40: if_icmpeq -> 219
      //   43: aload_0
      //   44: getfield a : Ljava/util/ArrayList;
      //   47: iload_1
      //   48: invokevirtual get : (I)Ljava/lang/Object;
      //   51: checkcast android/view/View
      //   54: astore #9
      //   56: aload_0
      //   57: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   60: getfield t : Landroidx/recyclerview/widget/h;
      //   63: aload #9
      //   65: invokevirtual g : (Landroid/view/View;)I
      //   68: istore #10
      //   70: aload_0
      //   71: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   74: getfield t : Landroidx/recyclerview/widget/h;
      //   77: aload #9
      //   79: invokevirtual d : (Landroid/view/View;)I
      //   82: istore #11
      //   84: iconst_0
      //   85: istore #12
      //   87: iload #5
      //   89: ifeq -> 102
      //   92: iload #10
      //   94: iload #7
      //   96: if_icmpgt -> 115
      //   99: goto -> 109
      //   102: iload #10
      //   104: iload #7
      //   106: if_icmpge -> 115
      //   109: iconst_1
      //   110: istore #13
      //   112: goto -> 118
      //   115: iconst_0
      //   116: istore #13
      //   118: iload #5
      //   120: ifeq -> 133
      //   123: iload #11
      //   125: iload #6
      //   127: if_icmplt -> 143
      //   130: goto -> 140
      //   133: iload #11
      //   135: iload #6
      //   137: if_icmple -> 143
      //   140: iconst_1
      //   141: istore #12
      //   143: iload #13
      //   145: ifeq -> 211
      //   148: iload #12
      //   150: ifeq -> 211
      //   153: iload_3
      //   154: ifeq -> 186
      //   157: iload #4
      //   159: ifeq -> 186
      //   162: iload #10
      //   164: iload #6
      //   166: if_icmplt -> 211
      //   169: iload #11
      //   171: iload #7
      //   173: if_icmpgt -> 211
      //   176: aload_0
      //   177: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   180: aload #9
      //   182: invokevirtual f0 : (Landroid/view/View;)I
      //   185: ireturn
      //   186: iload #4
      //   188: ifeq -> 194
      //   191: goto -> 176
      //   194: iload #10
      //   196: iload #6
      //   198: if_icmplt -> 176
      //   201: iload #11
      //   203: iload #7
      //   205: if_icmple -> 211
      //   208: goto -> 176
      //   211: iload_1
      //   212: iload #8
      //   214: iadd
      //   215: istore_1
      //   216: goto -> 38
      //   219: iconst_m1
      //   220: ireturn
    }
    
    public int i(int param1Int1, int param1Int2, boolean param1Boolean) {
      return h(param1Int1, param1Int2, false, false, param1Boolean);
    }
    
    public int j() {
      return this.d;
    }
    
    public int k() {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      c();
      return this.c;
    }
    
    public int l(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      c();
      return this.c;
    }
    
    public View m(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_3
      //   2: aconst_null
      //   3: astore #4
      //   5: iload_2
      //   6: iconst_m1
      //   7: if_icmpne -> 120
      //   10: aload_0
      //   11: getfield a : Ljava/util/ArrayList;
      //   14: invokevirtual size : ()I
      //   17: istore #5
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore_3
      //   24: iload_2
      //   25: iload #5
      //   27: if_icmpge -> 230
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield y : Z
      //   54: ifeq -> 71
      //   57: aload #4
      //   59: astore_3
      //   60: aload #7
      //   62: aload #6
      //   64: invokevirtual f0 : (Landroid/view/View;)I
      //   67: iload_1
      //   68: if_icmple -> 230
      //   71: aload_0
      //   72: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   75: astore_3
      //   76: aload_3
      //   77: getfield y : Z
      //   80: ifne -> 99
      //   83: aload_3
      //   84: aload #6
      //   86: invokevirtual f0 : (Landroid/view/View;)I
      //   89: iload_1
      //   90: if_icmplt -> 99
      //   93: aload #4
      //   95: astore_3
      //   96: goto -> 230
      //   99: aload #4
      //   101: astore_3
      //   102: aload #6
      //   104: invokevirtual hasFocusable : ()Z
      //   107: ifeq -> 230
      //   110: iinc #2, 1
      //   113: aload #6
      //   115: astore #4
      //   117: goto -> 21
      //   120: aload_0
      //   121: getfield a : Ljava/util/ArrayList;
      //   124: invokevirtual size : ()I
      //   127: iconst_1
      //   128: isub
      //   129: istore_2
      //   130: aload_3
      //   131: astore #4
      //   133: aload #4
      //   135: astore_3
      //   136: iload_2
      //   137: iflt -> 230
      //   140: aload_0
      //   141: getfield a : Ljava/util/ArrayList;
      //   144: iload_2
      //   145: invokevirtual get : (I)Ljava/lang/Object;
      //   148: checkcast android/view/View
      //   151: astore #6
      //   153: aload_0
      //   154: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   157: astore #7
      //   159: aload #7
      //   161: getfield y : Z
      //   164: ifeq -> 181
      //   167: aload #4
      //   169: astore_3
      //   170: aload #7
      //   172: aload #6
      //   174: invokevirtual f0 : (Landroid/view/View;)I
      //   177: iload_1
      //   178: if_icmpge -> 230
      //   181: aload_0
      //   182: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   185: astore_3
      //   186: aload_3
      //   187: getfield y : Z
      //   190: ifne -> 209
      //   193: aload_3
      //   194: aload #6
      //   196: invokevirtual f0 : (Landroid/view/View;)I
      //   199: iload_1
      //   200: if_icmpgt -> 209
      //   203: aload #4
      //   205: astore_3
      //   206: goto -> 230
      //   209: aload #4
      //   211: astore_3
      //   212: aload #6
      //   214: invokevirtual hasFocusable : ()Z
      //   217: ifeq -> 230
      //   220: iinc #2, -1
      //   223: aload #6
      //   225: astore #4
      //   227: goto -> 133
      //   230: aload_3
      //   231: areturn
    }
    
    public StaggeredGridLayoutManager.LayoutParams n(View param1View) {
      return (StaggeredGridLayoutManager.LayoutParams)param1View.getLayoutParams();
    }
    
    public int o() {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      d();
      return this.b;
    }
    
    public int p(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      d();
      return this.b;
    }
    
    public void q() {
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
    }
    
    public void r(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        this.b = i + param1Int; 
      i = this.c;
      if (i != Integer.MIN_VALUE)
        this.c = i + param1Int; 
    }
    
    public void s() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.LayoutParams layoutParams = n(view);
      layoutParams.e = null;
      if (layoutParams.c() || layoutParams.b())
        this.d -= this.f.t.e(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    public void t() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.LayoutParams layoutParams = n(view);
      layoutParams.e = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (layoutParams.c() || layoutParams.b())
        this.d -= this.f.t.e(view); 
      this.b = Integer.MIN_VALUE;
    }
    
    public void u(View param1View) {
      StaggeredGridLayoutManager.LayoutParams layoutParams = n(param1View);
      layoutParams.e = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (layoutParams.c() || layoutParams.b())
        this.d += this.f.t.e(param1View); 
    }
    
    public void v(int param1Int) {
      this.b = param1Int;
      this.c = param1Int;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */