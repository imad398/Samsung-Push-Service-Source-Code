package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class c extends k {
  public static TimeInterpolator s;
  
  public ArrayList h = new ArrayList();
  
  public ArrayList i = new ArrayList();
  
  public ArrayList j = new ArrayList();
  
  public ArrayList k = new ArrayList();
  
  public ArrayList l = new ArrayList();
  
  public ArrayList m = new ArrayList();
  
  public ArrayList n = new ArrayList();
  
  public ArrayList o = new ArrayList();
  
  public ArrayList p = new ArrayList();
  
  public ArrayList q = new ArrayList();
  
  public ArrayList r = new ArrayList();
  
  public void Q(RecyclerView.z paramz) {
    View view = paramz.a;
    ViewPropertyAnimator viewPropertyAnimator = view.animate();
    this.o.add(paramz);
    viewPropertyAnimator.alpha(1.0F).setDuration(l()).setListener((Animator.AnimatorListener)new e(this, paramz, view, viewPropertyAnimator)).start();
  }
  
  public void R(i parami) {
    View view1;
    RecyclerView.z z1 = parami.a;
    View view2 = null;
    if (z1 == null) {
      z1 = null;
    } else {
      view1 = z1.a;
    } 
    RecyclerView.z z2 = parami.b;
    if (z2 != null)
      view2 = z2.a; 
    if (view1 != null) {
      ViewPropertyAnimator viewPropertyAnimator = view1.animate().setDuration(m());
      this.r.add(parami.a);
      viewPropertyAnimator.translationX((parami.e - parami.c));
      viewPropertyAnimator.translationY((parami.f - parami.d));
      viewPropertyAnimator.alpha(0.0F).setListener((Animator.AnimatorListener)new g(this, parami, viewPropertyAnimator, view1)).start();
    } 
    if (view2 != null) {
      ViewPropertyAnimator viewPropertyAnimator = view2.animate();
      this.r.add(parami.b);
      viewPropertyAnimator.translationX(0.0F).translationY(0.0F).setDuration(m()).alpha(1.0F).setListener((Animator.AnimatorListener)new h(this, parami, viewPropertyAnimator, view2)).start();
    } 
  }
  
  public void S(RecyclerView.z paramz, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = paramz.a;
    paramInt1 = paramInt3 - paramInt1;
    paramInt2 = paramInt4 - paramInt2;
    if (paramInt1 != 0)
      view.animate().translationX(0.0F); 
    if (paramInt2 != 0)
      view.animate().translationY(0.0F); 
    ViewPropertyAnimator viewPropertyAnimator = view.animate();
    this.p.add(paramz);
    viewPropertyAnimator.setDuration(n()).setListener((Animator.AnimatorListener)new f(this, paramz, paramInt1, view, paramInt2, viewPropertyAnimator)).start();
  }
  
  public final void T(RecyclerView.z paramz) {
    View view = paramz.a;
    ViewPropertyAnimator viewPropertyAnimator = view.animate();
    this.q.add(paramz);
    viewPropertyAnimator.setDuration(o()).alpha(0.0F).setListener((Animator.AnimatorListener)new d(this, paramz, viewPropertyAnimator, view)).start();
  }
  
  public void U(List paramList) {
    for (int i = paramList.size() - 1; i >= 0; i--)
      ((RecyclerView.z)paramList.get(i)).a.animate().cancel(); 
  }
  
  public void V() {
    if (!p())
      i(); 
  }
  
  public final void W(List<i> paramList, RecyclerView.z paramz) {
    for (int i = paramList.size() - 1; i >= 0; i--) {
      i i1 = paramList.get(i);
      if (Y(i1, paramz) && i1.a == null && i1.b == null)
        paramList.remove(i1); 
    } 
  }
  
  public final void X(i parami) {
    RecyclerView.z z = parami.a;
    if (z != null)
      Y(parami, z); 
    z = parami.b;
    if (z != null)
      Y(parami, z); 
  }
  
  public final boolean Y(i parami, RecyclerView.z paramz) {
    RecyclerView.z z1 = parami.b;
    boolean bool = false;
    if (z1 == paramz) {
      parami.b = null;
    } else {
      if (parami.a == paramz) {
        parami.a = null;
        bool = true;
        paramz.a.setAlpha(1.0F);
        paramz.a.setTranslationX(0.0F);
        paramz.a.setTranslationY(0.0F);
        C(paramz, bool);
        return true;
      } 
      return false;
    } 
    paramz.a.setAlpha(1.0F);
    paramz.a.setTranslationX(0.0F);
    paramz.a.setTranslationY(0.0F);
    C(paramz, bool);
    return true;
  }
  
  public final void Z(RecyclerView.z paramz) {
    if (s == null)
      s = (new ValueAnimator()).getInterpolator(); 
    paramz.a.animate().setInterpolator(s);
    j(paramz);
  }
  
  public boolean g(RecyclerView.z paramz, List paramList) {
    return (!paramList.isEmpty() || super.g(paramz, paramList));
  }
  
  public void j(RecyclerView.z paramz) {
    View view = paramz.a;
    view.animate().cancel();
    int i;
    for (i = this.j.size() - 1; i >= 0; i--) {
      if (((j)this.j.get(i)).a == paramz) {
        view.setTranslationY(0.0F);
        view.setTranslationX(0.0F);
        E(paramz);
        this.j.remove(i);
      } 
    } 
    W(this.k, paramz);
    if (this.h.remove(paramz)) {
      view.setAlpha(1.0F);
      G(paramz);
    } 
    if (this.i.remove(paramz)) {
      view.setAlpha(1.0F);
      A(paramz);
    } 
    for (i = this.n.size() - 1; i >= 0; i--) {
      ArrayList arrayList = this.n.get(i);
      W(arrayList, paramz);
      if (arrayList.isEmpty())
        this.n.remove(i); 
    } 
    for (i = this.m.size() - 1; i >= 0; i--) {
      ArrayList arrayList = this.m.get(i);
      for (int j = arrayList.size() - 1; j >= 0; j--) {
        if (((j)arrayList.get(j)).a == paramz) {
          view.setTranslationY(0.0F);
          view.setTranslationX(0.0F);
          E(paramz);
          arrayList.remove(j);
          if (arrayList.isEmpty())
            this.m.remove(i); 
          break;
        } 
      } 
    } 
    for (i = this.l.size() - 1; i >= 0; i--) {
      ArrayList arrayList = this.l.get(i);
      if (arrayList.remove(paramz)) {
        view.setAlpha(1.0F);
        A(paramz);
        if (arrayList.isEmpty())
          this.l.remove(i); 
      } 
    } 
    this.q.remove(paramz);
    this.o.remove(paramz);
    this.r.remove(paramz);
    this.p.remove(paramz);
    V();
  }
  
  public void k() {
    int i;
    for (i = this.j.size() - 1; i >= 0; i--) {
      j j = this.j.get(i);
      View view = j.a.a;
      view.setTranslationY(0.0F);
      view.setTranslationX(0.0F);
      E(j.a);
      this.j.remove(i);
    } 
    for (i = this.h.size() - 1; i >= 0; i--) {
      G(this.h.get(i));
      this.h.remove(i);
    } 
    for (i = this.i.size() - 1; i >= 0; i--) {
      RecyclerView.z z = this.i.get(i);
      z.a.setAlpha(1.0F);
      A(z);
      this.i.remove(i);
    } 
    for (i = this.k.size() - 1; i >= 0; i--)
      X(this.k.get(i)); 
    this.k.clear();
    if (!p())
      return; 
    for (i = this.m.size() - 1; i >= 0; i--) {
      ArrayList<j> arrayList = this.m.get(i);
      for (int j = arrayList.size() - 1; j >= 0; j--) {
        j j1 = arrayList.get(j);
        View view = j1.a.a;
        view.setTranslationY(0.0F);
        view.setTranslationX(0.0F);
        E(j1.a);
        arrayList.remove(j);
        if (arrayList.isEmpty())
          this.m.remove(arrayList); 
      } 
    } 
    for (i = this.l.size() - 1; i >= 0; i--) {
      ArrayList<RecyclerView.z> arrayList = this.l.get(i);
      for (int j = arrayList.size() - 1; j >= 0; j--) {
        RecyclerView.z z = arrayList.get(j);
        z.a.setAlpha(1.0F);
        A(z);
        arrayList.remove(j);
        if (arrayList.isEmpty())
          this.l.remove(arrayList); 
      } 
    } 
    for (i = this.n.size() - 1; i >= 0; i--) {
      ArrayList<i> arrayList = this.n.get(i);
      for (int j = arrayList.size() - 1; j >= 0; j--) {
        X(arrayList.get(j));
        if (arrayList.isEmpty())
          this.n.remove(arrayList); 
      } 
    } 
    U(this.q);
    U(this.p);
    U(this.o);
    U(this.r);
    i();
  }
  
  public boolean p() {
    return (!this.i.isEmpty() || !this.k.isEmpty() || !this.j.isEmpty() || !this.h.isEmpty() || !this.p.isEmpty() || !this.q.isEmpty() || !this.o.isEmpty() || !this.r.isEmpty() || !this.m.isEmpty() || !this.l.isEmpty() || !this.n.isEmpty());
  }
  
  public void u() {
    int i = this.h.isEmpty() ^ true;
    int j = this.j.isEmpty() ^ true;
    int m = this.k.isEmpty() ^ true;
    int n = this.i.isEmpty() ^ true;
    if (i == 0 && j == 0 && n == 0 && m == 0)
      return; 
    Iterator<RecyclerView.z> iterator = this.h.iterator();
    while (iterator.hasNext())
      T(iterator.next()); 
    this.h.clear();
    if (j != 0) {
      ArrayList arrayList = new ArrayList();
      arrayList.addAll(this.j);
      this.m.add(arrayList);
      this.j.clear();
      a a = new a(this, arrayList);
      if (i != 0) {
        n.j.y(((j)arrayList.get(0)).a.a, a, o());
      } else {
        a.run();
      } 
    } 
    if (m != 0) {
      ArrayList arrayList = new ArrayList();
      arrayList.addAll(this.k);
      this.n.add(arrayList);
      this.k.clear();
      b b = new b(this, arrayList);
      if (i != 0) {
        n.j.y(((i)arrayList.get(0)).a.a, b, o());
      } else {
        b.run();
      } 
    } 
    if (n != 0) {
      ArrayList arrayList = new ArrayList();
      arrayList.addAll(this.i);
      this.l.add(arrayList);
      this.i.clear();
      c c1 = new c(this, arrayList);
      if (i != 0 || j != 0 || m != 0) {
        long l2;
        long l1 = 0L;
        if (i != 0) {
          l2 = o();
        } else {
          l2 = 0L;
        } 
        if (j != 0) {
          l3 = n();
        } else {
          l3 = 0L;
        } 
        if (m != 0)
          l1 = m(); 
        long l3 = Math.max(l3, l1);
        n.j.y(((RecyclerView.z)arrayList.get(0)).a, c1, l2 + l3);
        return;
      } 
      c1.run();
    } 
  }
  
  public boolean w(RecyclerView.z paramz) {
    Z(paramz);
    paramz.a.setAlpha(0.0F);
    this.i.add(paramz);
    return true;
  }
  
  public boolean x(RecyclerView.z paramz1, RecyclerView.z paramz2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramz1 == paramz2)
      return y(paramz1, paramInt1, paramInt2, paramInt3, paramInt4); 
    float f1 = paramz1.a.getTranslationX();
    float f2 = paramz1.a.getTranslationY();
    float f3 = paramz1.a.getAlpha();
    Z(paramz1);
    int i = (int)((paramInt3 - paramInt1) - f1);
    int j = (int)((paramInt4 - paramInt2) - f2);
    paramz1.a.setTranslationX(f1);
    paramz1.a.setTranslationY(f2);
    paramz1.a.setAlpha(f3);
    if (paramz2 != null) {
      Z(paramz2);
      paramz2.a.setTranslationX(-i);
      paramz2.a.setTranslationY(-j);
      paramz2.a.setAlpha(0.0F);
    } 
    this.k.add(new i(paramz1, paramz2, paramInt1, paramInt2, paramInt3, paramInt4));
    return true;
  }
  
  public boolean y(RecyclerView.z paramz, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = paramz.a;
    paramInt1 += (int)view.getTranslationX();
    paramInt2 += (int)paramz.a.getTranslationY();
    Z(paramz);
    int i = paramInt3 - paramInt1;
    int j = paramInt4 - paramInt2;
    if (i == 0 && j == 0) {
      E(paramz);
      return false;
    } 
    if (i != 0)
      view.setTranslationX(-i); 
    if (j != 0)
      view.setTranslationY(-j); 
    this.j.add(new j(paramz, paramInt1, paramInt2, paramInt3, paramInt4));
    return true;
  }
  
  public boolean z(RecyclerView.z paramz) {
    Z(paramz);
    this.h.add(paramz);
    return true;
  }
  
  public class a implements Runnable {
    public a(c this$0, ArrayList param1ArrayList) {}
    
    public void run() {
      for (c.j j : this.a)
        this.b.S(j.a, j.b, j.c, j.d, j.e); 
      this.a.clear();
      this.b.m.remove(this.a);
    }
  }
  
  public class b implements Runnable {
    public b(c this$0, ArrayList param1ArrayList) {}
    
    public void run() {
      for (c.i i : this.a)
        this.b.R(i); 
      this.a.clear();
      this.b.n.remove(this.a);
    }
  }
  
  public class c implements Runnable {
    public c(c this$0, ArrayList param1ArrayList) {}
    
    public void run() {
      for (RecyclerView.z z : this.a)
        this.b.Q(z); 
      this.a.clear();
      this.b.l.remove(this.a);
    }
  }
  
  public class d extends AnimatorListenerAdapter {
    public d(c this$0, RecyclerView.z param1z, ViewPropertyAnimator param1ViewPropertyAnimator, View param1View) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.b.setListener(null);
      this.c.setAlpha(1.0F);
      this.d.G(this.a);
      this.d.q.remove(this.a);
      this.d.V();
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.d.H(this.a);
    }
  }
  
  public class e extends AnimatorListenerAdapter {
    public e(c this$0, RecyclerView.z param1z, View param1View, ViewPropertyAnimator param1ViewPropertyAnimator) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.b.setAlpha(1.0F);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.c.setListener(null);
      this.d.A(this.a);
      this.d.o.remove(this.a);
      this.d.V();
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.d.B(this.a);
    }
  }
  
  public class f extends AnimatorListenerAdapter {
    public f(c this$0, RecyclerView.z param1z, int param1Int1, View param1View, int param1Int2, ViewPropertyAnimator param1ViewPropertyAnimator) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      if (this.b != 0)
        this.c.setTranslationX(0.0F); 
      if (this.d != 0)
        this.c.setTranslationY(0.0F); 
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.e.setListener(null);
      this.f.E(this.a);
      this.f.p.remove(this.a);
      this.f.V();
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.f.F(this.a);
    }
  }
  
  public class g extends AnimatorListenerAdapter {
    public g(c this$0, c.i param1i, ViewPropertyAnimator param1ViewPropertyAnimator, View param1View) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.b.setListener(null);
      this.c.setAlpha(1.0F);
      this.c.setTranslationX(0.0F);
      this.c.setTranslationY(0.0F);
      this.d.C(this.a.a, true);
      this.d.r.remove(this.a.a);
      this.d.V();
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.d.D(this.a.a, true);
    }
  }
  
  public class h extends AnimatorListenerAdapter {
    public h(c this$0, c.i param1i, ViewPropertyAnimator param1ViewPropertyAnimator, View param1View) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.b.setListener(null);
      this.c.setAlpha(1.0F);
      this.c.setTranslationX(0.0F);
      this.c.setTranslationY(0.0F);
      this.d.C(this.a.b, false);
      this.d.r.remove(this.a.b);
      this.d.V();
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.d.D(this.a.b, false);
    }
  }
  
  public static class i {
    public RecyclerView.z a;
    
    public RecyclerView.z b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public i(RecyclerView.z param1z1, RecyclerView.z param1z2) {
      this.a = param1z1;
      this.b = param1z2;
    }
    
    public i(RecyclerView.z param1z1, RecyclerView.z param1z2, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this(param1z1, param1z2);
      this.c = param1Int1;
      this.d = param1Int2;
      this.e = param1Int3;
      this.f = param1Int4;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ChangeInfo{oldHolder=");
      stringBuilder.append(this.a);
      stringBuilder.append(", newHolder=");
      stringBuilder.append(this.b);
      stringBuilder.append(", fromX=");
      stringBuilder.append(this.c);
      stringBuilder.append(", fromY=");
      stringBuilder.append(this.d);
      stringBuilder.append(", toX=");
      stringBuilder.append(this.e);
      stringBuilder.append(", toY=");
      stringBuilder.append(this.f);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static class j {
    public RecyclerView.z a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public j(RecyclerView.z param1z, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a = param1z;
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = param1Int3;
      this.e = param1Int4;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */