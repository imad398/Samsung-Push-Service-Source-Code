package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;
import l.m;

public final class e implements Runnable {
  public static final ThreadLocal e = new ThreadLocal();
  
  public static Comparator f = new a();
  
  public ArrayList a = new ArrayList();
  
  public long b;
  
  public long c;
  
  public ArrayList d = new ArrayList();
  
  public static boolean e(RecyclerView paramRecyclerView, int paramInt) {
    int i = paramRecyclerView.e.j();
    for (byte b = 0; b < i; b++) {
      RecyclerView.z z = RecyclerView.d0(paramRecyclerView.e.i(b));
      if (z.c == paramInt && !z.s())
        return true; 
    } 
    return false;
  }
  
  public void a(RecyclerView paramRecyclerView) {
    this.a.add(paramRecyclerView);
  }
  
  public final void b() {
    int i = this.a.size();
    int j = 0;
    int k;
    for (k = j; j < i; k = m) {
      RecyclerView recyclerView = this.a.get(j);
      int m = k;
      if (recyclerView.getWindowVisibility() == 0) {
        recyclerView.e0.c(recyclerView, false);
        m = k + recyclerView.e0.d;
      } 
      j++;
    } 
    this.d.ensureCapacity(k);
    k = 0;
    for (j = k; k < i; j = m) {
      int m;
      RecyclerView recyclerView = this.a.get(k);
      if (recyclerView.getWindowVisibility() != 0) {
        m = j;
      } else {
        b b1 = recyclerView.e0;
        int n = Math.abs(b1.a) + Math.abs(b1.b);
        byte b = 0;
        while (true) {
          m = j;
          if (b < b1.d * 2) {
            c c;
            boolean bool;
            if (j >= this.d.size()) {
              c = new c();
              this.d.add(c);
            } else {
              c = this.d.get(j);
            } 
            int[] arrayOfInt = b1.c;
            m = arrayOfInt[b + 1];
            if (m <= n) {
              bool = true;
            } else {
              bool = false;
            } 
            c.a = bool;
            c.b = n;
            c.c = m;
            c.d = recyclerView;
            c.e = arrayOfInt[b];
            j++;
            b += 2;
            continue;
          } 
          break;
        } 
      } 
      k++;
    } 
    Collections.sort(this.d, f);
  }
  
  public final void c(c paramc, long paramLong) {
    long l;
    if (paramc.a) {
      l = Long.MAX_VALUE;
    } else {
      l = paramLong;
    } 
    RecyclerView.z z = i(paramc.d, paramc.e, l);
    if (z != null && z.b != null && z.r() && !z.s())
      h(z.b.get(), paramLong); 
  }
  
  public final void d(long paramLong) {
    for (byte b = 0; b < this.d.size(); b++) {
      c c = this.d.get(b);
      if (c.d == null)
        break; 
      c(c, paramLong);
      c.a();
    } 
  }
  
  public void f(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    if (paramRecyclerView.isAttachedToWindow() && this.b == 0L) {
      this.b = paramRecyclerView.getNanoTime();
      paramRecyclerView.post(this);
    } 
    paramRecyclerView.e0.e(paramInt1, paramInt2);
  }
  
  public void g(long paramLong) {
    b();
    d(paramLong);
  }
  
  public final void h(RecyclerView paramRecyclerView, long paramLong) {
    if (paramRecyclerView == null)
      return; 
    if (paramRecyclerView.C && paramRecyclerView.e.j() != 0)
      paramRecyclerView.R0(); 
    b b = paramRecyclerView.e0;
    b.c(paramRecyclerView, true);
    if (b.d != 0)
      try {
        m.a("RV Nested Prefetch");
        paramRecyclerView.f0.f(paramRecyclerView.l);
        for (byte b1 = 0; b1 < b.d * 2; b1 += 2)
          i(paramRecyclerView, b.c[b1], paramLong); 
      } finally {
        m.b();
      }  
  }
  
  public final RecyclerView.z i(RecyclerView paramRecyclerView, int paramInt, long paramLong) {
    if (e(paramRecyclerView, paramInt))
      return null; 
    null = paramRecyclerView.b;
    try {
      paramRecyclerView.D0();
      RecyclerView.z z = null.I(paramInt, false, paramLong);
      if (z != null)
        if (z.r() && !z.s()) {
          null.B(z.a);
        } else {
          null.a(z, false);
        }  
      return z;
    } finally {
      paramRecyclerView.F0(false);
    } 
  }
  
  public void j(RecyclerView paramRecyclerView) {
    this.a.remove(paramRecyclerView);
  }
  
  public void run() {
    try {
      m.a("RV Prefetch");
      boolean bool = this.a.isEmpty();
      if (!bool) {
        int i = this.a.size();
        byte b = 0;
        long l;
        for (l = 0L; b < i; l = l1) {
          RecyclerView recyclerView = this.a.get(b);
          long l1 = l;
          if (recyclerView.getWindowVisibility() == 0)
            l1 = Math.max(recyclerView.getDrawingTime(), l); 
          b++;
        } 
        if (l != 0L) {
          g(TimeUnit.MILLISECONDS.toNanos(l) + this.c);
          return;
        } 
      } 
      return;
    } finally {
      this.b = 0L;
      m.b();
    } 
  }
  
  public static final class a implements Comparator {
    public int a(e.c param1c1, e.c param1c2) {
      byte b2;
      RecyclerView recyclerView = param1c1.d;
      byte b = 1;
      byte b1 = 1;
      if (recyclerView == null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (param1c2.d == null) {
        b2 = 1;
      } else {
        b2 = 0;
      } 
      if (i != b2) {
        if (recyclerView == null) {
          i = b1;
        } else {
          i = -1;
        } 
        return i;
      } 
      boolean bool = param1c1.a;
      if (bool != param1c2.a) {
        i = b;
        if (bool)
          i = -1; 
        return i;
      } 
      int i = param1c2.b - param1c1.b;
      if (i != 0)
        return i; 
      i = param1c1.c - param1c2.c;
      return (i != 0) ? i : 0;
    }
  }
  
  public static class b implements RecyclerView.o.c {
    public int a;
    
    public int b;
    
    public int[] c;
    
    public int d;
    
    public void a(int param1Int1, int param1Int2) {
      if (param1Int1 >= 0) {
        if (param1Int2 >= 0) {
          int i = this.d * 2;
          int[] arrayOfInt1 = this.c;
          if (arrayOfInt1 == null) {
            int[] arrayOfInt = new int[4];
            this.c = arrayOfInt;
            Arrays.fill(arrayOfInt, -1);
          } else if (i >= arrayOfInt1.length) {
            int[] arrayOfInt = new int[i * 2];
            this.c = arrayOfInt;
            System.arraycopy(arrayOfInt1, 0, arrayOfInt, 0, arrayOfInt1.length);
          } 
          int[] arrayOfInt2 = this.c;
          arrayOfInt2[i] = param1Int1;
          arrayOfInt2[i + 1] = param1Int2;
          this.d++;
          return;
        } 
        throw new IllegalArgumentException("Pixel distance must be non-negative");
      } 
      throw new IllegalArgumentException("Layout positions must be non-negative");
    }
    
    public void b() {
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.d = 0;
    }
    
    public void c(RecyclerView param1RecyclerView, boolean param1Boolean) {
      this.d = 0;
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      RecyclerView.o o = param1RecyclerView.m;
      if (param1RecyclerView.l != null && o != null && o.s0()) {
        if (param1Boolean) {
          if (!param1RecyclerView.d.p())
            o.o(param1RecyclerView.l.c(), this); 
        } else if (!param1RecyclerView.k0()) {
          o.n(this.a, this.b, param1RecyclerView.f0, this);
        } 
        int i = this.d;
        if (i > o.l) {
          o.l = i;
          o.m = param1Boolean;
          param1RecyclerView.b.K();
        } 
      } 
    }
    
    public boolean d(int param1Int) {
      if (this.c != null) {
        int i = this.d;
        for (byte b1 = 0; b1 < i * 2; b1 += 2) {
          if (this.c[b1] == param1Int)
            return true; 
        } 
      } 
      return false;
    }
    
    public void e(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
  
  public static class c {
    public boolean a;
    
    public int b;
    
    public int c;
    
    public RecyclerView d;
    
    public int e;
    
    public void a() {
      this.a = false;
      this.b = 0;
      this.c = 0;
      this.d = null;
      this.e = 0;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */