package androidx.recyclerview.widget;

import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import n.a;
import o.n;

public class i extends a {
  public final RecyclerView d;
  
  public final a e;
  
  public i(RecyclerView paramRecyclerView) {
    this.d = paramRecyclerView;
    this.e = new a(this);
  }
  
  public void f(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    super.f(paramView, paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(RecyclerView.class.getName());
    if (paramView instanceof RecyclerView && !o()) {
      RecyclerView recyclerView = (RecyclerView)paramView;
      if (recyclerView.getLayoutManager() != null)
        recyclerView.getLayoutManager().I0(paramAccessibilityEvent); 
    } 
  }
  
  public void g(View paramView, n paramn) {
    super.g(paramView, paramn);
    paramn.I(RecyclerView.class.getName());
    if (!o() && this.d.getLayoutManager() != null)
      this.d.getLayoutManager().L0(paramn); 
  }
  
  public boolean j(View paramView, int paramInt, Bundle paramBundle) {
    return super.j(paramView, paramInt, paramBundle) ? true : ((!o() && this.d.getLayoutManager() != null) ? this.d.getLayoutManager().d1(paramInt, paramBundle) : false);
  }
  
  public a n() {
    return this.e;
  }
  
  public boolean o() {
    return this.d.k0();
  }
  
  public static class a extends a {
    public final i d;
    
    public a(i param1i) {
      this.d = param1i;
    }
    
    public void g(View param1View, n param1n) {
      super.g(param1View, param1n);
      if (!this.d.o() && this.d.d.getLayoutManager() != null)
        this.d.d.getLayoutManager().M0(param1View, param1n); 
    }
    
    public boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      return super.j(param1View, param1Int, param1Bundle) ? true : ((!this.d.o() && this.d.d.getLayoutManager() != null) ? this.d.d.getLayoutManager().f1(param1View, param1Int, param1Bundle) : false);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */