package androidx.recyclerview.widget;

import android.view.View;

public abstract class j {
  public static int a(RecyclerView.w paramw, h paramh, View paramView1, View paramView2, RecyclerView.o paramo, boolean paramBoolean) {
    if (paramo.I() == 0 || paramw.b() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    if (!paramBoolean)
      return Math.abs(paramo.f0(paramView1) - paramo.f0(paramView2)) + 1; 
    int i = paramh.d(paramView2);
    int k = paramh.g(paramView1);
    return Math.min(paramh.n(), i - k);
  }
  
  public static int b(RecyclerView.w paramw, h paramh, View paramView1, View paramView2, RecyclerView.o paramo, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramo.I() == 0 || paramw.b() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    int i = Math.min(paramo.f0(paramView1), paramo.f0(paramView2));
    int k = Math.max(paramo.f0(paramView1), paramo.f0(paramView2));
    if (paramBoolean2) {
      k = Math.max(0, paramw.b() - k - 1);
    } else {
      k = Math.max(0, i);
    } 
    if (!paramBoolean1)
      return k; 
    i = Math.abs(paramh.d(paramView2) - paramh.g(paramView1));
    int m = Math.abs(paramo.f0(paramView1) - paramo.f0(paramView2));
    float f = i / (m + 1);
    return Math.round(k * f + (paramh.m() - paramh.g(paramView1)));
  }
  
  public static int c(RecyclerView.w paramw, h paramh, View paramView1, View paramView2, RecyclerView.o paramo, boolean paramBoolean) {
    if (paramo.I() == 0 || paramw.b() == 0 || paramView1 == null || paramView2 == null)
      return 0; 
    if (!paramBoolean)
      return paramw.b(); 
    int i = paramh.d(paramView2);
    int k = paramh.g(paramView1);
    int m = Math.abs(paramo.f0(paramView1) - paramo.f0(paramView2));
    return (int)((i - k) / (m + 1) * paramw.b());
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */