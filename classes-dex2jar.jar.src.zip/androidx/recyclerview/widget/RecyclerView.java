package androidx.recyclerview.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.customview.view.AbsSavedState;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecyclerView extends ViewGroup {
  public static final boolean A0;
  
  public static final boolean B0;
  
  public static final boolean C0;
  
  public static final boolean D0;
  
  public static final Class[] E0;
  
  public static final Interpolator F0;
  
  public static final int[] w0 = new int[] { 16843830 };
  
  public static final int[] x0 = new int[] { 16842987 };
  
  public static final boolean y0 = false;
  
  public static final boolean z0 = true;
  
  public final AccessibilityManager A;
  
  public List B;
  
  public boolean C;
  
  public boolean D;
  
  public int E;
  
  public int F;
  
  public k G;
  
  public EdgeEffect H;
  
  public EdgeEffect I;
  
  public EdgeEffect J;
  
  public EdgeEffect K;
  
  public l L;
  
  public int M;
  
  public int N;
  
  public VelocityTracker O;
  
  public int P;
  
  public int Q;
  
  public int R;
  
  public int S;
  
  public int T;
  
  public final int U;
  
  public final int V;
  
  public float W;
  
  public final v a;
  
  public float a0;
  
  public final t b;
  
  public boolean b0;
  
  public SavedState c;
  
  public final y c0;
  
  public a d;
  
  public e d0;
  
  public b e;
  
  public e.b e0;
  
  public final m f;
  
  public final w f0;
  
  public boolean g;
  
  public r g0;
  
  public final Runnable h;
  
  public List h0;
  
  public final Rect i;
  
  public boolean i0;
  
  public final Rect j;
  
  public boolean j0;
  
  public final RectF k;
  
  public l.a k0;
  
  public g l;
  
  public boolean l0;
  
  public o m;
  
  public i m0;
  
  public final ArrayList n;
  
  public final int[] n0;
  
  public final ArrayList o;
  
  public n.e o0;
  
  public q p;
  
  public final int[] p0;
  
  public boolean q;
  
  public final int[] q0;
  
  public boolean r;
  
  public final int[] r0;
  
  public boolean s;
  
  public final int[] s0;
  
  public boolean t;
  
  public final List t0;
  
  public int u;
  
  public Runnable u0;
  
  public boolean v;
  
  public final m.b v0;
  
  public boolean w;
  
  public boolean x;
  
  public int y;
  
  public boolean z;
  
  static {
    A0 = true;
    B0 = true;
    C0 = false;
    D0 = false;
    Class<int> clazz = int.class;
    E0 = new Class[] { Context.class, AttributeSet.class, clazz, clazz };
    F0 = new c();
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    e.b b1;
    boolean bool1;
    this.a = new v(this);
    this.b = new t(this);
    this.f = new m();
    this.h = new a(this);
    this.i = new Rect();
    this.j = new Rect();
    this.k = new RectF();
    this.n = new ArrayList();
    this.o = new ArrayList();
    this.u = 0;
    this.C = false;
    this.D = false;
    this.E = 0;
    this.F = 0;
    this.G = new k();
    this.L = new c();
    this.M = 0;
    this.N = -1;
    this.W = Float.MIN_VALUE;
    this.a0 = Float.MIN_VALUE;
    boolean bool = true;
    this.b0 = true;
    this.c0 = new y(this);
    if (B0) {
      b1 = new e.b();
    } else {
      b1 = null;
    } 
    this.e0 = b1;
    this.f0 = new w();
    this.i0 = false;
    this.j0 = false;
    this.k0 = new m(this);
    this.l0 = false;
    this.n0 = new int[2];
    this.p0 = new int[2];
    this.q0 = new int[2];
    this.r0 = new int[2];
    this.s0 = new int[2];
    this.t0 = new ArrayList();
    this.u0 = new b(this);
    this.v0 = new d(this);
    if (paramAttributeSet != null) {
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, x0, paramInt, 0);
      this.g = typedArray.getBoolean(0, true);
      typedArray.recycle();
    } else {
      this.g = true;
    } 
    setScrollContainer(true);
    setFocusableInTouchMode(true);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.T = viewConfiguration.getScaledTouchSlop();
    this.W = n.o.b(viewConfiguration, paramContext);
    this.a0 = n.o.c(viewConfiguration, paramContext);
    this.U = viewConfiguration.getScaledMinimumFlingVelocity();
    this.V = viewConfiguration.getScaledMaximumFlingVelocity();
    if (getOverScrollMode() == 2) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    this.L.v(this.k0);
    m0();
    o0();
    n0();
    if (n.j.i((View)this) == 0)
      n.j.B((View)this, 1); 
    this.A = (AccessibilityManager)getContext().getSystemService("accessibility");
    setAccessibilityDelegateCompat(new i(this));
    if (paramAttributeSet != null) {
      TypedArray typedArray2 = paramContext.obtainStyledAttributes(paramAttributeSet, t.b.RecyclerView, paramInt, 0);
      String str = typedArray2.getString(t.b.RecyclerView_layoutManager);
      if (typedArray2.getInt(t.b.RecyclerView_android_descendantFocusability, -1) == -1)
        setDescendantFocusability(262144); 
      bool1 = typedArray2.getBoolean(t.b.RecyclerView_fastScrollEnabled, false);
      this.s = bool1;
      if (bool1)
        p0((StateListDrawable)typedArray2.getDrawable(t.b.RecyclerView_fastScrollVerticalThumbDrawable), typedArray2.getDrawable(t.b.RecyclerView_fastScrollVerticalTrackDrawable), (StateListDrawable)typedArray2.getDrawable(t.b.RecyclerView_fastScrollHorizontalThumbDrawable), typedArray2.getDrawable(t.b.RecyclerView_fastScrollHorizontalTrackDrawable)); 
      typedArray2.recycle();
      u(paramContext, str, paramAttributeSet, paramInt, 0);
      TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, w0, paramInt, 0);
      bool1 = typedArray1.getBoolean(0, true);
      typedArray1.recycle();
    } else {
      setDescendantFocusability(262144);
      bool1 = bool;
    } 
    setNestedScrollingEnabled(bool1);
  }
  
  public static RecyclerView U(View paramView) {
    if (!(paramView instanceof ViewGroup))
      return null; 
    if (paramView instanceof RecyclerView)
      return (RecyclerView)paramView; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int j = viewGroup.getChildCount();
    for (byte b1 = 0; b1 < j; b1++) {
      RecyclerView recyclerView = U(viewGroup.getChildAt(b1));
      if (recyclerView != null)
        return recyclerView; 
    } 
    return null;
  }
  
  public static z d0(View paramView) {
    return (paramView == null) ? null : ((LayoutParams)paramView.getLayoutParams()).a;
  }
  
  public static void e0(View paramView, Rect paramRect) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    Rect rect = layoutParams.b;
    paramRect.set(paramView.getLeft() - rect.left - layoutParams.leftMargin, paramView.getTop() - rect.top - layoutParams.topMargin, paramView.getRight() + rect.right + layoutParams.rightMargin, paramView.getBottom() + rect.bottom + layoutParams.bottomMargin);
  }
  
  private n.e getScrollingChildHelper() {
    if (this.o0 == null)
      this.o0 = new n.e((View)this); 
    return this.o0;
  }
  
  public static void q(z paramz) {
    WeakReference<WeakReference> weakReference = paramz.b;
    if (weakReference != null) {
      weakReference = weakReference.get();
      label17: while (true) {
        View view = (View)weakReference;
        while (view != null) {
          if (view == paramz.a)
            return; 
          ViewParent viewParent = view.getParent();
          if (viewParent instanceof View)
            continue label17; 
          viewParent = null;
        } 
        paramz.b = null;
        break;
      } 
    } 
  }
  
  public void A() {
    // Byte code:
    //   0: aload_0
    //   1: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
    //   4: ifnonnull -> 20
    //   7: ldc_w 'No adapter attached; skipping layout'
    //   10: astore_1
    //   11: ldc_w 'RecyclerView'
    //   14: aload_1
    //   15: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: return
    //   20: aload_0
    //   21: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   24: ifnonnull -> 34
    //   27: ldc_w 'No layout manager attached; skipping layout'
    //   30: astore_1
    //   31: goto -> 11
    //   34: aload_0
    //   35: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
    //   38: astore_1
    //   39: aload_1
    //   40: iconst_0
    //   41: putfield j : Z
    //   44: aload_1
    //   45: getfield e : I
    //   48: iconst_1
    //   49: if_icmpne -> 71
    //   52: aload_0
    //   53: invokevirtual B : ()V
    //   56: aload_0
    //   57: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   60: aload_0
    //   61: invokevirtual v1 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   64: aload_0
    //   65: invokevirtual C : ()V
    //   68: goto -> 120
    //   71: aload_0
    //   72: getfield d : Landroidx/recyclerview/widget/a;
    //   75: invokevirtual q : ()Z
    //   78: ifne -> 56
    //   81: aload_0
    //   82: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   85: invokevirtual m0 : ()I
    //   88: aload_0
    //   89: invokevirtual getWidth : ()I
    //   92: if_icmpne -> 56
    //   95: aload_0
    //   96: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   99: invokevirtual V : ()I
    //   102: aload_0
    //   103: invokevirtual getHeight : ()I
    //   106: if_icmpeq -> 112
    //   109: goto -> 56
    //   112: aload_0
    //   113: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   116: aload_0
    //   117: invokevirtual v1 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   120: aload_0
    //   121: invokevirtual D : ()V
    //   124: return
  }
  
  public void A0(int paramInt1, int paramInt2, boolean paramBoolean) {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.i(b1));
      if (z != null && !z.I()) {
        int n = z.c;
        if (n >= paramInt1 + paramInt2) {
          z.z(-paramInt2, paramBoolean);
        } else if (n >= paramInt1) {
          z.i(paramInt1 - 1, -paramInt2, paramBoolean);
        } else {
          continue;
        } 
        this.f0.g = true;
      } 
      continue;
    } 
    this.b.w(paramInt1, paramInt2, paramBoolean);
    requestLayout();
  }
  
  public final void B() {
    w w1 = this.f0;
    boolean bool = true;
    w1.a(1);
    Q(this.f0);
    this.f0.j = false;
    j1();
    this.f.f();
    D0();
    L0();
    a1();
    w1 = this.f0;
    if (!w1.k || !this.j0)
      bool = false; 
    w1.i = bool;
    this.j0 = false;
    this.i0 = false;
    w1.h = w1.l;
    w1.f = this.l.c();
    T(this.n0);
    if (this.f0.k) {
      int j = this.e.g();
      for (byte b1 = 0; b1 < j; b1++) {
        z z = d0(this.e.f(b1));
        if (!z.I() && (!z.s() || this.l.f())) {
          l.b b2 = this.L.t(this.f0, z, l.e(z), z.o());
          this.f.e(z, b2);
          if (this.f0.i && z.x() && !z.u() && !z.I() && !z.s()) {
            long l1 = b0(z);
            this.f.c(l1, z);
          } 
        } 
      } 
    } 
    if (this.f0.l) {
      b1();
      w1 = this.f0;
      bool = w1.g;
      w1.g = false;
      this.m.V0(this.b, w1);
      this.f0.g = bool;
      for (byte b1 = 0; b1 < this.e.g(); b1++) {
        z z = d0(this.e.f(b1));
        if (!z.I() && !this.f.i(z)) {
          int n = l.e(z);
          bool = z.p(8192);
          int j = n;
          if (!bool)
            j = n | 0x1000; 
          l.b b2 = this.L.t(this.f0, z, j, z.o());
          if (bool) {
            O0(z, b2);
          } else {
            this.f.a(z, b2);
          } 
        } 
      } 
    } 
    r();
    E0();
    l1(false);
    this.f0.e = 2;
  }
  
  public void B0(View paramView) {}
  
  public final void C() {
    boolean bool;
    j1();
    D0();
    this.f0.a(6);
    this.d.j();
    this.f0.f = this.l.c();
    w w1 = this.f0;
    w1.d = 0;
    w1.h = false;
    this.m.V0(this.b, w1);
    w1 = this.f0;
    w1.g = false;
    this.c = null;
    if (w1.k && this.L != null) {
      bool = true;
    } else {
      bool = false;
    } 
    w1.k = bool;
    w1.e = 4;
    E0();
    l1(false);
  }
  
  public void C0(View paramView) {}
  
  public final void D() {
    this.f0.a(4);
    j1();
    D0();
    w w1 = this.f0;
    w1.e = 1;
    if (w1.k) {
      for (int j = this.e.g() - 1; j >= 0; j--) {
        z z2 = d0(this.e.f(j));
        if (z2.I())
          continue; 
        long l1 = b0(z2);
        l.b b1 = this.L.s(this.f0, z2);
        z z1 = this.f.g(l1);
        if (z1 != null && !z1.I()) {
          boolean bool1 = this.f.h(z1);
          boolean bool2 = this.f.h(z2);
          if (!bool1 || z1 != z2) {
            l.b b2 = this.f.n(z1);
            this.f.d(z2, b1);
            b1 = this.f.m(z2);
            if (b2 == null) {
              i0(l1, z2, z1);
            } else {
              l(z1, z2, b2, b1, bool1, bool2);
            } 
            continue;
          } 
        } 
        this.f.d(z2, b1);
        continue;
      } 
      this.f.o(this.v0);
    } 
    this.m.i1(this.b);
    w1 = this.f0;
    w1.c = w1.f;
    this.C = false;
    this.D = false;
    w1.k = false;
    w1.l = false;
    this.m.g = false;
    ArrayList arrayList = this.b.b;
    if (arrayList != null)
      arrayList.clear(); 
    o o1 = this.m;
    if (o1.m) {
      o1.l = 0;
      o1.m = false;
      this.b.K();
    } 
    this.m.W0(this.f0);
    E0();
    l1(false);
    this.f.f();
    int[] arrayOfInt = this.n0;
    if (w(arrayOfInt[0], arrayOfInt[1]))
      J(0, 0); 
    P0();
    Y0();
  }
  
  public void D0() {
    this.E++;
  }
  
  public boolean E(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return getScrollingChildHelper().d(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public void E0() {
    F0(true);
  }
  
  public boolean F(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5) {
    return getScrollingChildHelper().f(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5);
  }
  
  public void F0(boolean paramBoolean) {
    int j = this.E - 1;
    this.E = j;
    if (j < 1) {
      this.E = 0;
      if (paramBoolean) {
        z();
        K();
      } 
    } 
  }
  
  public final boolean G(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getAction();
    q q1 = this.p;
    if (q1 != null)
      if (j == 0) {
        this.p = null;
      } else {
        q1.b(this, paramMotionEvent);
        if (j == 3 || j == 1)
          this.p = null; 
        return true;
      }  
    if (j != 0) {
      int n = this.o.size();
      for (j = 0; j < n; j++) {
        q1 = this.o.get(j);
        if (q1.a(this, paramMotionEvent)) {
          this.p = q1;
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public final void G0(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(j) == this.N) {
      if (j == 0) {
        j = 1;
      } else {
        j = 0;
      } 
      this.N = paramMotionEvent.getPointerId(j);
      int n = (int)(paramMotionEvent.getX(j) + 0.5F);
      this.R = n;
      this.P = n;
      j = (int)(paramMotionEvent.getY(j) + 0.5F);
      this.S = j;
      this.Q = j;
    } 
  }
  
  public final boolean H(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getAction();
    if (j == 3 || j == 0)
      this.p = null; 
    int n = this.o.size();
    for (byte b1 = 0; b1 < n; b1++) {
      q q1 = this.o.get(b1);
      if (q1.a(this, paramMotionEvent) && j != 3) {
        this.p = q1;
        return true;
      } 
    } 
    return false;
  }
  
  public void H0(int paramInt) {}
  
  public void I(int paramInt) {
    o o1 = this.m;
    if (o1 != null)
      o1.c1(paramInt); 
    H0(paramInt);
    r r1 = this.g0;
    if (r1 != null)
      r1.a(this, paramInt); 
    List list = this.h0;
    if (list != null)
      for (int j = list.size() - 1; j >= 0; j--)
        ((r)this.h0.get(j)).a(this, paramInt);  
  }
  
  public void I0(int paramInt1, int paramInt2) {}
  
  public void J(int paramInt1, int paramInt2) {
    this.F++;
    int j = getScrollX();
    int n = getScrollY();
    onScrollChanged(j, n, j, n);
    I0(paramInt1, paramInt2);
    r r1 = this.g0;
    if (r1 != null)
      r1.b(this, paramInt1, paramInt2); 
    List list = this.h0;
    if (list != null)
      for (j = list.size() - 1; j >= 0; j--)
        ((r)this.h0.get(j)).b(this, paramInt1, paramInt2);  
    this.F--;
  }
  
  public void J0() {
    if (!this.l0 && this.q) {
      n.j.x((View)this, this.u0);
      this.l0 = true;
    } 
  }
  
  public void K() {
    for (int j = this.t0.size() - 1; j >= 0; j--) {
      z z = this.t0.get(j);
      if (z.a.getParent() == this && !z.I()) {
        int n = z.q;
        if (n != -1) {
          n.j.B(z.a, n);
          z.q = -1;
        } 
      } 
    } 
    this.t0.clear();
  }
  
  public final boolean K0() {
    boolean bool;
    if (this.L != null && this.m.F1()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void L() {
    int j;
    int n;
    if (this.K != null)
      return; 
    EdgeEffect edgeEffect = this.G.a(this, 3);
    this.K = edgeEffect;
    if (this.g) {
      j = getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
      n = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
    } else {
      j = getMeasuredWidth();
      n = getMeasuredHeight();
    } 
    edgeEffect.setSize(j, n);
  }
  
  public final void L0() {
    // Byte code:
    //   0: aload_0
    //   1: getfield C : Z
    //   4: ifeq -> 29
    //   7: aload_0
    //   8: getfield d : Landroidx/recyclerview/widget/a;
    //   11: invokevirtual u : ()V
    //   14: aload_0
    //   15: getfield D : Z
    //   18: ifeq -> 29
    //   21: aload_0
    //   22: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   25: aload_0
    //   26: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   29: aload_0
    //   30: invokevirtual K0 : ()Z
    //   33: ifeq -> 46
    //   36: aload_0
    //   37: getfield d : Landroidx/recyclerview/widget/a;
    //   40: invokevirtual s : ()V
    //   43: goto -> 53
    //   46: aload_0
    //   47: getfield d : Landroidx/recyclerview/widget/a;
    //   50: invokevirtual j : ()V
    //   53: aload_0
    //   54: getfield i0 : Z
    //   57: istore_1
    //   58: iconst_0
    //   59: istore_2
    //   60: iload_1
    //   61: ifne -> 79
    //   64: aload_0
    //   65: getfield j0 : Z
    //   68: ifeq -> 74
    //   71: goto -> 79
    //   74: iconst_0
    //   75: istore_3
    //   76: goto -> 81
    //   79: iconst_1
    //   80: istore_3
    //   81: aload_0
    //   82: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
    //   85: astore #4
    //   87: aload_0
    //   88: getfield t : Z
    //   91: ifeq -> 143
    //   94: aload_0
    //   95: getfield L : Landroidx/recyclerview/widget/RecyclerView$l;
    //   98: ifnull -> 143
    //   101: aload_0
    //   102: getfield C : Z
    //   105: istore_1
    //   106: iload_1
    //   107: ifne -> 124
    //   110: iload_3
    //   111: ifne -> 124
    //   114: aload_0
    //   115: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   118: getfield g : Z
    //   121: ifeq -> 143
    //   124: iload_1
    //   125: ifeq -> 138
    //   128: aload_0
    //   129: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
    //   132: invokevirtual f : ()Z
    //   135: ifeq -> 143
    //   138: iconst_1
    //   139: istore_1
    //   140: goto -> 145
    //   143: iconst_0
    //   144: istore_1
    //   145: aload #4
    //   147: iload_1
    //   148: putfield k : Z
    //   151: aload_0
    //   152: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
    //   155: astore #4
    //   157: iload_2
    //   158: istore_1
    //   159: aload #4
    //   161: getfield k : Z
    //   164: ifeq -> 193
    //   167: iload_2
    //   168: istore_1
    //   169: iload_3
    //   170: ifeq -> 193
    //   173: iload_2
    //   174: istore_1
    //   175: aload_0
    //   176: getfield C : Z
    //   179: ifne -> 193
    //   182: iload_2
    //   183: istore_1
    //   184: aload_0
    //   185: invokevirtual K0 : ()Z
    //   188: ifeq -> 193
    //   191: iconst_1
    //   192: istore_1
    //   193: aload #4
    //   195: iload_1
    //   196: putfield l : Z
    //   199: return
  }
  
  public void M() {
    int j;
    int n;
    if (this.H != null)
      return; 
    EdgeEffect edgeEffect = this.G.a(this, 0);
    this.H = edgeEffect;
    if (this.g) {
      j = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
      n = getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
    } else {
      j = getMeasuredHeight();
      n = getMeasuredWidth();
    } 
    edgeEffect.setSize(j, n);
  }
  
  public void M0(boolean paramBoolean) {
    this.D = paramBoolean | this.D;
    this.C = true;
    v0();
  }
  
  public void N() {
    int j;
    int n;
    if (this.J != null)
      return; 
    EdgeEffect edgeEffect = this.G.a(this, 2);
    this.J = edgeEffect;
    if (this.g) {
      j = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
      n = getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
    } else {
      j = getMeasuredHeight();
      n = getMeasuredWidth();
    } 
    edgeEffect.setSize(j, n);
  }
  
  public final void N0(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #5
    //   3: fload_2
    //   4: fconst_0
    //   5: fcmpg
    //   6: ifge -> 57
    //   9: aload_0
    //   10: invokevirtual M : ()V
    //   13: aload_0
    //   14: getfield H : Landroid/widget/EdgeEffect;
    //   17: astore #6
    //   19: fload_2
    //   20: fneg
    //   21: aload_0
    //   22: invokevirtual getWidth : ()I
    //   25: i2f
    //   26: fdiv
    //   27: fstore #7
    //   29: fconst_1
    //   30: fload_3
    //   31: aload_0
    //   32: invokevirtual getHeight : ()I
    //   35: i2f
    //   36: fdiv
    //   37: fsub
    //   38: fstore #8
    //   40: fload #7
    //   42: fstore_3
    //   43: aload #6
    //   45: fload_3
    //   46: fload #8
    //   48: invokestatic a : (Landroid/widget/EdgeEffect;FF)V
    //   51: iconst_1
    //   52: istore #9
    //   54: goto -> 100
    //   57: fload_2
    //   58: fconst_0
    //   59: fcmpl
    //   60: ifle -> 97
    //   63: aload_0
    //   64: invokevirtual N : ()V
    //   67: aload_0
    //   68: getfield J : Landroid/widget/EdgeEffect;
    //   71: astore #6
    //   73: fload_2
    //   74: aload_0
    //   75: invokevirtual getWidth : ()I
    //   78: i2f
    //   79: fdiv
    //   80: fstore #7
    //   82: fload_3
    //   83: aload_0
    //   84: invokevirtual getHeight : ()I
    //   87: i2f
    //   88: fdiv
    //   89: fstore #8
    //   91: fload #7
    //   93: fstore_3
    //   94: goto -> 43
    //   97: iconst_0
    //   98: istore #9
    //   100: fload #4
    //   102: fconst_0
    //   103: fcmpg
    //   104: ifge -> 141
    //   107: aload_0
    //   108: invokevirtual O : ()V
    //   111: aload_0
    //   112: getfield I : Landroid/widget/EdgeEffect;
    //   115: fload #4
    //   117: fneg
    //   118: aload_0
    //   119: invokevirtual getHeight : ()I
    //   122: i2f
    //   123: fdiv
    //   124: fload_1
    //   125: aload_0
    //   126: invokevirtual getWidth : ()I
    //   129: i2f
    //   130: fdiv
    //   131: invokestatic a : (Landroid/widget/EdgeEffect;FF)V
    //   134: iload #5
    //   136: istore #9
    //   138: goto -> 183
    //   141: fload #4
    //   143: fconst_0
    //   144: fcmpl
    //   145: ifle -> 183
    //   148: aload_0
    //   149: invokevirtual L : ()V
    //   152: aload_0
    //   153: getfield K : Landroid/widget/EdgeEffect;
    //   156: fload #4
    //   158: aload_0
    //   159: invokevirtual getHeight : ()I
    //   162: i2f
    //   163: fdiv
    //   164: fconst_1
    //   165: fload_1
    //   166: aload_0
    //   167: invokevirtual getWidth : ()I
    //   170: i2f
    //   171: fdiv
    //   172: fsub
    //   173: invokestatic a : (Landroid/widget/EdgeEffect;FF)V
    //   176: iload #5
    //   178: istore #9
    //   180: goto -> 183
    //   183: iload #9
    //   185: ifne -> 201
    //   188: fload_2
    //   189: fconst_0
    //   190: fcmpl
    //   191: ifne -> 201
    //   194: fload #4
    //   196: fconst_0
    //   197: fcmpl
    //   198: ifeq -> 205
    //   201: aload_0
    //   202: invokestatic w : (Landroid/view/View;)V
    //   205: return
  }
  
  public void O() {
    int j;
    int n;
    if (this.I != null)
      return; 
    EdgeEffect edgeEffect = this.G.a(this, 1);
    this.I = edgeEffect;
    if (this.g) {
      j = getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
      n = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
    } else {
      j = getMeasuredWidth();
      n = getMeasuredHeight();
    } 
    edgeEffect.setSize(j, n);
  }
  
  public void O0(z paramz, l.b paramb) {
    paramz.E(0, 8192);
    if (this.f0.i && paramz.x() && !paramz.u() && !paramz.I()) {
      long l1 = b0(paramz);
      this.f.c(l1, paramz);
    } 
    this.f.e(paramz, paramb);
  }
  
  public String P() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" ");
    stringBuilder.append(toString());
    stringBuilder.append(", adapter:");
    stringBuilder.append(this.l);
    stringBuilder.append(", layout:");
    stringBuilder.append(this.m);
    stringBuilder.append(", context:");
    stringBuilder.append(getContext());
    return stringBuilder.toString();
  }
  
  public final void P0() {
    if (this.b0 && this.l != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
      View view1;
      if (!isFocused()) {
        view1 = getFocusedChild();
        if (D0 && (view1.getParent() == null || !view1.hasFocus())) {
          if (this.e.g() == 0) {
            requestFocus();
            return;
          } 
        } else if (!this.e.n(view1)) {
          return;
        } 
      } 
      long l1 = this.f0.n;
      View view2 = null;
      if (l1 != -1L && this.l.f()) {
        view1 = (View)X(this.f0.n);
      } else {
        view1 = null;
      } 
      if (view1 == null || this.e.n(((z)view1).a) || !((z)view1).a.hasFocusable()) {
        view1 = view2;
        if (this.e.g() > 0)
          view1 = V(); 
      } else {
        view1 = ((z)view1).a;
      } 
      if (view1 != null) {
        int j = this.f0.o;
        view2 = view1;
        if (j != -1L) {
          View view = view1.findViewById(j);
          view2 = view1;
          if (view != null) {
            view2 = view1;
            if (view.isFocusable())
              view2 = view; 
          } 
        } 
        view2.requestFocus();
      } 
    } 
  }
  
  public final void Q(w paramw) {
    if (getScrollState() == 2) {
      OverScroller overScroller = this.c0.c;
      paramw.p = overScroller.getFinalX() - overScroller.getCurrX();
      paramw.q = overScroller.getFinalY() - overScroller.getCurrY();
    } else {
      paramw.p = 0;
      paramw.q = 0;
    } 
  }
  
  public final void Q0() {
    EdgeEffect edgeEffect = this.H;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = this.H.isFinished();
    } else {
      bool1 = false;
    } 
    edgeEffect = this.I;
    boolean bool2 = bool1;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = bool1 | this.I.isFinished();
    } 
    edgeEffect = this.J;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.J.isFinished();
    } 
    edgeEffect = this.K;
    bool2 = bool1;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = bool1 | this.K.isFinished();
    } 
    if (bool2)
      n.j.w((View)this); 
  }
  
  public View R(View paramView) {
    ViewParent viewParent;
    while (true) {
      viewParent = paramView.getParent();
      if (viewParent != null && viewParent != this && viewParent instanceof View) {
        paramView = (View)viewParent;
        continue;
      } 
      break;
    } 
    if (viewParent != this)
      paramView = null; 
    return paramView;
  }
  
  public void R0() {
    l l1 = this.L;
    if (l1 != null)
      l1.k(); 
    o o1 = this.m;
    if (o1 != null) {
      o1.h1(this.b);
      this.m.i1(this.b);
    } 
    this.b.c();
  }
  
  public z S(View paramView) {
    z z;
    paramView = R(paramView);
    if (paramView == null) {
      paramView = null;
    } else {
      z = c0(paramView);
    } 
    return z;
  }
  
  public boolean S0(View paramView) {
    j1();
    boolean bool = this.e.r(paramView);
    if (bool) {
      z z = d0(paramView);
      this.b.J(z);
      this.b.C(z);
    } 
    l1(bool ^ true);
    return bool;
  }
  
  public final void T(int[] paramArrayOfint) {
    int j = this.e.g();
    if (j == 0) {
      paramArrayOfint[0] = -1;
      paramArrayOfint[1] = -1;
      return;
    } 
    int n = Integer.MAX_VALUE;
    int i1 = Integer.MIN_VALUE;
    byte b1 = 0;
    while (b1 < j) {
      int i2;
      z z = d0(this.e.f(b1));
      if (z.I()) {
        i2 = i1;
      } else {
        int i3 = z.m();
        int i4 = n;
        if (i3 < n)
          i4 = i3; 
        n = i4;
        i2 = i1;
        if (i3 > i1) {
          i2 = i3;
          n = i4;
        } 
      } 
      b1++;
      i1 = i2;
    } 
    paramArrayOfint[0] = n;
    paramArrayOfint[1] = i1;
  }
  
  public void T0(n paramn) {
    o o1 = this.m;
    if (o1 != null)
      o1.f("Cannot remove item decoration during a scroll  or layout"); 
    this.n.remove(paramn);
    if (this.n.isEmpty()) {
      boolean bool;
      if (getOverScrollMode() == 2) {
        bool = true;
      } else {
        bool = false;
      } 
      setWillNotDraw(bool);
    } 
    u0();
    requestLayout();
  }
  
  public void U0(q paramq) {
    this.o.remove(paramq);
    if (this.p == paramq)
      this.p = null; 
  }
  
  public final View V() {
    w w1 = this.f0;
    int j = w1.m;
    if (j == -1)
      j = 0; 
    int n = w1.b();
    for (int i1 = j; i1 < n; i1++) {
      z z = W(i1);
      if (z == null)
        break; 
      if (z.a.hasFocusable())
        return z.a; 
    } 
    for (j = Math.min(n, j) - 1; j >= 0; j--) {
      z z = W(j);
      if (z == null)
        return null; 
      if (z.a.hasFocusable())
        return z.a; 
    } 
    return null;
  }
  
  public void V0(r paramr) {
    List list = this.h0;
    if (list != null)
      list.remove(paramr); 
  }
  
  public z W(int paramInt) {
    boolean bool = this.C;
    z z = null;
    if (bool)
      return null; 
    int j = this.e.j();
    byte b1 = 0;
    while (b1 < j) {
      z z1 = d0(this.e.i(b1));
      z z2 = z;
      if (z1 != null) {
        z2 = z;
        if (!z1.u()) {
          z2 = z;
          if (a0(z1) == paramInt)
            if (this.e.n(z1.a)) {
              z2 = z1;
            } else {
              return z1;
            }  
        } 
      } 
      b1++;
      z = z2;
    } 
    return z;
  }
  
  public void W0() {
    int j = this.e.g();
    for (byte b1 = 0; b1 < j; b1++) {
      View view = this.e.f(b1);
      z z = c0(view);
      if (z != null) {
        z = z.i;
        if (z != null) {
          View view1 = z.a;
          int n = view.getLeft();
          int i1 = view.getTop();
          if (n != view1.getLeft() || i1 != view1.getTop())
            view1.layout(n, i1, view1.getWidth() + n, view1.getHeight() + i1); 
        } 
      } 
    } 
  }
  
  public z X(long paramLong) {
    g g1 = this.l;
    z z1 = null;
    z z2 = null;
    z z3 = z1;
    if (g1 != null)
      if (!g1.f()) {
        z3 = z1;
      } else {
        int j = this.e.j();
        byte b1 = 0;
        while (true) {
          z3 = z2;
          if (b1 < j) {
            z1 = d0(this.e.i(b1));
            z3 = z2;
            if (z1 != null) {
              z3 = z2;
              if (!z1.u()) {
                z3 = z2;
                if (z1.k() == paramLong)
                  if (this.e.n(z1.a)) {
                    z3 = z1;
                  } else {
                    return z1;
                  }  
              } 
            } 
            b1++;
            z2 = z3;
            continue;
          } 
          break;
        } 
      }  
    return z3;
  }
  
  public final void X0(View paramView1, View paramView2) {
    View view;
    boolean bool1;
    if (paramView2 != null) {
      view = paramView2;
    } else {
      view = paramView1;
    } 
    this.i.set(0, 0, view.getWidth(), view.getHeight());
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (layoutParams instanceof LayoutParams) {
      LayoutParams layoutParams1 = (LayoutParams)layoutParams;
      if (!layoutParams1.c) {
        Rect rect2 = layoutParams1.b;
        Rect rect1 = this.i;
        rect1.left -= rect2.left;
        rect1.right += rect2.right;
        rect1.top -= rect2.top;
        rect1.bottom += rect2.bottom;
      } 
    } 
    if (paramView2 != null) {
      offsetDescendantRectToMyCoords(paramView2, this.i);
      offsetRectIntoDescendantCoords(paramView1, this.i);
    } 
    o o1 = this.m;
    Rect rect = this.i;
    boolean bool = this.t;
    if (paramView2 == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    o1.p1(this, paramView1, rect, bool ^ true, bool1);
  }
  
  public z Y(int paramInt, boolean paramBoolean) {
    int j = this.e.j();
    Object object = null;
    byte b1 = 0;
    while (b1 < j) {
      z z = d0(this.e.i(b1));
      Object object1 = object;
      if (z != null) {
        object1 = object;
        if (!z.u()) {
          if (paramBoolean) {
            if (z.c != paramInt) {
              object1 = object;
              continue;
            } 
          } else if (z.m() != paramInt) {
            object1 = object;
            continue;
          } 
          if (this.e.n(z.a)) {
            object1 = z;
          } else {
            return z;
          } 
        } 
      } 
      continue;
      b1++;
      object = SYNTHETIC_LOCAL_VARIABLE_7;
    } 
    return (z)object;
  }
  
  public final void Y0() {
    w w1 = this.f0;
    w1.n = -1L;
    w1.m = -1;
    w1.o = -1;
  }
  
  public boolean Z(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 21
    //   9: ldc_w 'RecyclerView'
    //   12: ldc_w 'Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.'
    //   15: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: iconst_0
    //   20: ireturn
    //   21: aload_0
    //   22: getfield w : Z
    //   25: ifeq -> 30
    //   28: iconst_0
    //   29: ireturn
    //   30: aload_3
    //   31: invokevirtual j : ()Z
    //   34: istore #4
    //   36: aload_0
    //   37: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   40: invokevirtual k : ()Z
    //   43: istore #5
    //   45: iload #4
    //   47: ifeq -> 64
    //   50: iload_1
    //   51: istore #6
    //   53: iload_1
    //   54: invokestatic abs : (I)I
    //   57: aload_0
    //   58: getfield U : I
    //   61: if_icmpge -> 67
    //   64: iconst_0
    //   65: istore #6
    //   67: iload #5
    //   69: ifeq -> 85
    //   72: iload_2
    //   73: istore_1
    //   74: iload_2
    //   75: invokestatic abs : (I)I
    //   78: aload_0
    //   79: getfield U : I
    //   82: if_icmpge -> 87
    //   85: iconst_0
    //   86: istore_1
    //   87: iload #6
    //   89: ifne -> 98
    //   92: iload_1
    //   93: ifne -> 98
    //   96: iconst_0
    //   97: ireturn
    //   98: iload #6
    //   100: i2f
    //   101: fstore #7
    //   103: iload_1
    //   104: i2f
    //   105: fstore #8
    //   107: aload_0
    //   108: fload #7
    //   110: fload #8
    //   112: invokevirtual dispatchNestedPreFling : (FF)Z
    //   115: ifne -> 223
    //   118: iload #4
    //   120: ifne -> 137
    //   123: iload #5
    //   125: ifeq -> 131
    //   128: goto -> 137
    //   131: iconst_0
    //   132: istore #9
    //   134: goto -> 140
    //   137: iconst_1
    //   138: istore #9
    //   140: aload_0
    //   141: fload #7
    //   143: fload #8
    //   145: iload #9
    //   147: invokevirtual dispatchNestedFling : (FFZ)Z
    //   150: pop
    //   151: iload #9
    //   153: ifeq -> 223
    //   156: iload #4
    //   158: istore_2
    //   159: iload #5
    //   161: ifeq -> 169
    //   164: iload #4
    //   166: iconst_2
    //   167: ior
    //   168: istore_2
    //   169: aload_0
    //   170: iload_2
    //   171: iconst_1
    //   172: invokevirtual k1 : (II)Z
    //   175: pop
    //   176: aload_0
    //   177: getfield V : I
    //   180: istore_2
    //   181: iload_2
    //   182: ineg
    //   183: iload #6
    //   185: iload_2
    //   186: invokestatic min : (II)I
    //   189: invokestatic max : (II)I
    //   192: istore_2
    //   193: aload_0
    //   194: getfield V : I
    //   197: istore #6
    //   199: iload #6
    //   201: ineg
    //   202: iload_1
    //   203: iload #6
    //   205: invokestatic min : (II)I
    //   208: invokestatic max : (II)I
    //   211: istore_1
    //   212: aload_0
    //   213: getfield c0 : Landroidx/recyclerview/widget/RecyclerView$y;
    //   216: iload_2
    //   217: iload_1
    //   218: invokevirtual e : (II)V
    //   221: iconst_1
    //   222: ireturn
    //   223: iconst_0
    //   224: ireturn
  }
  
  public final void Z0() {
    VelocityTracker velocityTracker = this.O;
    if (velocityTracker != null)
      velocityTracker.clear(); 
    m1(0);
    Q0();
  }
  
  public void a(int paramInt1, int paramInt2) {
    if (paramInt1 < 0) {
      M();
      this.H.onAbsorb(-paramInt1);
    } else if (paramInt1 > 0) {
      N();
      this.J.onAbsorb(paramInt1);
    } 
    if (paramInt2 < 0) {
      O();
      this.I.onAbsorb(-paramInt2);
    } else if (paramInt2 > 0) {
      L();
      this.K.onAbsorb(paramInt2);
    } 
    if (paramInt1 != 0 || paramInt2 != 0)
      n.j.w((View)this); 
  }
  
  public int a0(z paramz) {
    return (paramz.p(524) || !paramz.r()) ? -1 : this.d.e(paramz.c);
  }
  
  public final void a1() {
    z z2;
    boolean bool = this.b0;
    z z1 = null;
    if (bool && hasFocus() && this.l != null) {
      z2 = (z)getFocusedChild();
    } else {
      z2 = null;
    } 
    if (z2 == null) {
      z2 = z1;
    } else {
      z2 = S((View)z2);
    } 
    if (z2 == null) {
      Y0();
    } else {
      long l1;
      int j;
      w w1 = this.f0;
      if (this.l.f()) {
        l1 = z2.k();
      } else {
        l1 = -1L;
      } 
      w1.n = l1;
      w1 = this.f0;
      if (this.C) {
        j = -1;
      } else if (z2.u()) {
        j = z2.d;
      } else {
        j = z2.j();
      } 
      w1.m = j;
      this.f0.o = f0(z2.a);
    } 
  }
  
  public void addFocusables(ArrayList paramArrayList, int paramInt1, int paramInt2) {
    o o1 = this.m;
    if (o1 == null || !o1.D0(this, paramArrayList, paramInt1, paramInt2))
      super.addFocusables(paramArrayList, paramInt1, paramInt2); 
  }
  
  public long b0(z paramz) {
    long l1;
    if (this.l.f()) {
      l1 = paramz.k();
    } else {
      l1 = paramz.c;
    } 
    return l1;
  }
  
  public void b1() {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.i(b1));
      if (!z.I())
        z.D(); 
    } 
  }
  
  public z c0(View paramView) {
    ViewParent viewParent = paramView.getParent();
    if (viewParent == null || viewParent == this)
      return d0(paramView); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a direct child of ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean c1(int paramInt1, int paramInt2, MotionEvent paramMotionEvent) {
    int[] arrayOfInt;
    int j;
    int n;
    int i1;
    int i2;
    t();
    g g1 = this.l;
    boolean bool1 = true;
    if (g1 != null) {
      d1(paramInt1, paramInt2, this.s0);
      int[] arrayOfInt1 = this.s0;
      j = arrayOfInt1[0];
      n = arrayOfInt1[1];
      i1 = n;
      i2 = j;
      j = paramInt1 - j;
      n = paramInt2 - n;
    } else {
      n = 0;
      i1 = n;
      i2 = i1;
      j = i2;
    } 
    if (!this.n.isEmpty())
      invalidate(); 
    if (F(i2, i1, j, n, this.p0, 0)) {
      paramInt2 = this.R;
      int[] arrayOfInt1 = this.p0;
      paramInt1 = arrayOfInt1[0];
      this.R = paramInt2 - paramInt1;
      paramInt2 = this.S;
      n = arrayOfInt1[1];
      this.S = paramInt2 - n;
      if (paramMotionEvent != null)
        paramMotionEvent.offsetLocation(paramInt1, n); 
      arrayOfInt = this.r0;
      paramInt1 = arrayOfInt[0];
      arrayOfInt1 = this.p0;
      arrayOfInt[0] = paramInt1 + arrayOfInt1[0];
      arrayOfInt[1] = arrayOfInt[1] + arrayOfInt1[1];
    } else if (getOverScrollMode() != 2) {
      if (arrayOfInt != null && !n.d.a((MotionEvent)arrayOfInt, 8194))
        N0(arrayOfInt.getX(), j, arrayOfInt.getY(), n); 
      s(paramInt1, paramInt2);
    } 
    if (i2 != 0 || i1 != 0)
      J(i2, i1); 
    if (!awakenScrollBars())
      invalidate(); 
    boolean bool2 = bool1;
    if (i2 == 0)
      if (i1 != 0) {
        bool2 = bool1;
      } else {
        bool2 = false;
      }  
    return bool2;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams instanceof LayoutParams && this.m.l((LayoutParams)paramLayoutParams)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int computeHorizontalScrollExtent() {
    o o1 = this.m;
    int j = 0;
    if (o1 == null)
      return 0; 
    if (o1.j())
      j = this.m.p(this.f0); 
    return j;
  }
  
  public int computeHorizontalScrollOffset() {
    o o1 = this.m;
    int j = 0;
    if (o1 == null)
      return 0; 
    if (o1.j())
      j = this.m.q(this.f0); 
    return j;
  }
  
  public int computeHorizontalScrollRange() {
    o o1 = this.m;
    int j = 0;
    if (o1 == null)
      return 0; 
    if (o1.j())
      j = this.m.r(this.f0); 
    return j;
  }
  
  public int computeVerticalScrollExtent() {
    o o1 = this.m;
    int j = 0;
    if (o1 == null)
      return 0; 
    if (o1.k())
      j = this.m.s(this.f0); 
    return j;
  }
  
  public int computeVerticalScrollOffset() {
    o o1 = this.m;
    int j = 0;
    if (o1 == null)
      return 0; 
    if (o1.k())
      j = this.m.t(this.f0); 
    return j;
  }
  
  public int computeVerticalScrollRange() {
    o o1 = this.m;
    int j = 0;
    if (o1 == null)
      return 0; 
    if (o1.k())
      j = this.m.u(this.f0); 
    return j;
  }
  
  public void d1(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    j1();
    D0();
    l.m.a("RV Scroll");
    Q(this.f0);
    if (paramInt1 != 0) {
      paramInt1 = this.m.t1(paramInt1, this.b, this.f0);
    } else {
      paramInt1 = 0;
    } 
    if (paramInt2 != 0) {
      paramInt2 = this.m.u1(paramInt2, this.b, this.f0);
    } else {
      paramInt2 = 0;
    } 
    l.m.b();
    W0();
    E0();
    l1(false);
    if (paramArrayOfint != null) {
      paramArrayOfint[0] = paramInt1;
      paramArrayOfint[1] = paramInt2;
    } 
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return getScrollingChildHelper().a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return getScrollingChildHelper().b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return getScrollingChildHelper().c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return getScrollingChildHelper().e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void dispatchRestoreInstanceState(SparseArray paramSparseArray) {
    dispatchThawSelfOnly(paramSparseArray);
  }
  
  public void dispatchSaveInstanceState(SparseArray paramSparseArray) {
    dispatchFreezeSelfOnly(paramSparseArray);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int j = this.n.size();
    boolean bool1 = false;
    int n;
    for (n = 0; n < j; n++)
      ((n)this.n.get(n)).h(paramCanvas, this, this.f0); 
    EdgeEffect edgeEffect = this.H;
    boolean bool2 = true;
    if (edgeEffect != null && !edgeEffect.isFinished()) {
      int i1 = paramCanvas.save();
      if (this.g) {
        n = getPaddingBottom();
      } else {
        n = 0;
      } 
      paramCanvas.rotate(270.0F);
      paramCanvas.translate((-getHeight() + n), 0.0F);
      edgeEffect = this.H;
      if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
        j = 1;
      } else {
        j = 0;
      } 
      paramCanvas.restoreToCount(i1);
    } else {
      j = 0;
    } 
    edgeEffect = this.I;
    n = j;
    if (edgeEffect != null) {
      n = j;
      if (!edgeEffect.isFinished()) {
        int i1 = paramCanvas.save();
        if (this.g)
          paramCanvas.translate(getPaddingLeft(), getPaddingTop()); 
        edgeEffect = this.I;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          n = 1;
        } else {
          n = 0;
        } 
        n = j | n;
        paramCanvas.restoreToCount(i1);
      } 
    } 
    edgeEffect = this.J;
    j = n;
    if (edgeEffect != null) {
      j = n;
      if (!edgeEffect.isFinished()) {
        int i1 = paramCanvas.save();
        int i2 = getWidth();
        if (this.g) {
          j = getPaddingTop();
        } else {
          j = 0;
        } 
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-j, -i2);
        edgeEffect = this.J;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          j = 1;
        } else {
          j = 0;
        } 
        j = n | j;
        paramCanvas.restoreToCount(i1);
      } 
    } 
    edgeEffect = this.K;
    n = j;
    if (edgeEffect != null) {
      n = j;
      if (!edgeEffect.isFinished()) {
        float f;
        int i1 = paramCanvas.save();
        paramCanvas.rotate(180.0F);
        if (this.g) {
          f = (-getWidth() + getPaddingRight());
          n = -getHeight() + getPaddingBottom();
        } else {
          f = -getWidth();
          n = -getHeight();
        } 
        paramCanvas.translate(f, n);
        edgeEffect = this.K;
        n = bool1;
        if (edgeEffect != null) {
          n = bool1;
          if (edgeEffect.draw(paramCanvas))
            n = 1; 
        } 
        n = j | n;
        paramCanvas.restoreToCount(i1);
      } 
    } 
    if (n == 0 && this.L != null && this.n.size() > 0 && this.L.p())
      n = bool2; 
    if (n != 0)
      n.j.w((View)this); 
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public final void e1(g paramg, boolean paramBoolean1, boolean paramBoolean2) {
    g g1 = this.l;
    if (g1 != null) {
      g1.r(this.a);
      this.l.l(this);
    } 
    if (!paramBoolean1 || paramBoolean2)
      R0(); 
    this.d.u();
    g1 = this.l;
    this.l = paramg;
    if (paramg != null) {
      paramg.q(this.a);
      paramg.h(this);
    } 
    o o1 = this.m;
    if (o1 != null)
      o1.C0(g1, this.l); 
    this.b.x(g1, this.l, paramBoolean1);
    this.f0.g = true;
  }
  
  public final void f(z paramz) {
    boolean bool;
    View view = paramz.a;
    if (view.getParent() == this) {
      bool = true;
    } else {
      bool = false;
    } 
    this.b.J(c0(view));
    if (paramz.w()) {
      this.e.c(view, -1, view.getLayoutParams(), true);
    } else {
      b b1 = this.e;
      if (!bool) {
        b1.b(view, true);
      } else {
        b1.k(view);
      } 
    } 
  }
  
  public final int f0(View paramView) {
    int j;
    label11: while (true) {
      j = paramView.getId();
      View view = paramView;
      while (!view.isFocused() && view instanceof ViewGroup && view.hasFocus()) {
        paramView = ((ViewGroup)view).getFocusedChild();
        view = paramView;
        if (paramView.getId() != -1)
          continue label11; 
      } 
      break;
    } 
    return j;
  }
  
  public boolean f1(z paramz, int paramInt) {
    if (s0()) {
      paramz.q = paramInt;
      this.t0.add(paramz);
      return false;
    } 
    n.j.B(paramz.a, paramInt);
    return true;
  }
  
  public View focusSearch(View paramView, int paramInt) {
    View view1;
    int j;
    View view2 = this.m.O0(paramView, paramInt);
    if (view2 != null)
      return view2; 
    g g1 = this.l;
    boolean bool = true;
    if (g1 != null && this.m != null && !s0() && !this.w) {
      j = 1;
    } else {
      j = 0;
    } 
    FocusFinder focusFinder = FocusFinder.getInstance();
    if (j && (paramInt == 2 || paramInt == 1)) {
      if (this.m.k()) {
        byte b1;
        byte b2;
        if (paramInt == 2) {
          b1 = 130;
        } else {
          b1 = 33;
        } 
        if (focusFinder.findNextFocus(this, paramView, b1) == null) {
          b2 = 1;
        } else {
          b2 = 0;
        } 
        j = b2;
        if (C0) {
          paramInt = b1;
          j = b2;
        } 
      } else {
        j = 0;
      } 
      int i1 = j;
      int n = paramInt;
      if (!j) {
        i1 = j;
        n = paramInt;
        if (this.m.j()) {
          if (this.m.X() == 1) {
            j = 1;
          } else {
            j = 0;
          } 
          if (paramInt == 2) {
            n = 1;
          } else {
            n = 0;
          } 
          if ((j ^ n) != 0) {
            j = 66;
          } else {
            j = 17;
          } 
          if (focusFinder.findNextFocus(this, paramView, j) == null) {
            n = bool;
          } else {
            n = 0;
          } 
          if (C0)
            paramInt = j; 
          i1 = n;
          n = paramInt;
        } 
      } 
      if (i1 != 0) {
        t();
        if (R(paramView) == null)
          return null; 
        j1();
        this.m.H0(paramView, n, this.b, this.f0);
        l1(false);
      } 
      view1 = focusFinder.findNextFocus(this, paramView, n);
      paramInt = n;
    } else {
      view1 = view1.findNextFocus(this, paramView, paramInt);
      if (view1 == null && j != 0) {
        t();
        if (R(paramView) == null)
          return null; 
        j1();
        view1 = this.m.H0(paramView, paramInt, this.b, this.f0);
        l1(false);
      } 
    } 
    if (view1 != null && !view1.hasFocusable()) {
      if (getFocusedChild() == null)
        return super.focusSearch(paramView, paramInt); 
      X0(view1, null);
      return paramView;
    } 
    if (!t0(paramView, view1, paramInt))
      view1 = super.focusSearch(paramView, paramInt); 
    return view1;
  }
  
  public void g(n paramn) {
    h(paramn, -1);
  }
  
  public final String g0(Context paramContext, String paramString) {
    if (paramString.charAt(0) == '.') {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramContext.getPackageName());
      stringBuilder1.append(paramString);
      return stringBuilder1.toString();
    } 
    if (paramString.contains("."))
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(RecyclerView.class.getPackage().getName());
    stringBuilder.append('.');
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  public boolean g1(AccessibilityEvent paramAccessibilityEvent) {
    boolean bool = s0();
    boolean bool1 = false;
    if (bool) {
      boolean bool2;
      if (paramAccessibilityEvent != null) {
        bool2 = o.b.a(paramAccessibilityEvent);
      } else {
        bool2 = false;
      } 
      if (!bool2)
        bool2 = bool1; 
      this.y |= bool2;
      return true;
    } 
    return false;
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    o o1 = this.m;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.C(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(P());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    o o1 = this.m;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.D(getContext(), paramAttributeSet); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(P());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    o o1 = this.m;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.E(paramLayoutParams); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(P());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public g getAdapter() {
    return this.l;
  }
  
  public int getBaseline() {
    o o1 = this.m;
    return (o1 != null) ? o1.F() : super.getBaseline();
  }
  
  public int getChildDrawingOrder(int paramInt1, int paramInt2) {
    return super.getChildDrawingOrder(paramInt1, paramInt2);
  }
  
  public boolean getClipToPadding() {
    return this.g;
  }
  
  public i getCompatAccessibilityDelegate() {
    return this.m0;
  }
  
  public k getEdgeEffectFactory() {
    return this.G;
  }
  
  public l getItemAnimator() {
    return this.L;
  }
  
  public int getItemDecorationCount() {
    return this.n.size();
  }
  
  public o getLayoutManager() {
    return this.m;
  }
  
  public int getMaxFlingVelocity() {
    return this.V;
  }
  
  public int getMinFlingVelocity() {
    return this.U;
  }
  
  public long getNanoTime() {
    return B0 ? System.nanoTime() : 0L;
  }
  
  public p getOnFlingListener() {
    return null;
  }
  
  public boolean getPreserveFocusAfterLayout() {
    return this.b0;
  }
  
  public s getRecycledViewPool() {
    return this.b.i();
  }
  
  public int getScrollState() {
    return this.M;
  }
  
  public void h(n paramn, int paramInt) {
    o o1 = this.m;
    if (o1 != null)
      o1.f("Cannot add item decoration during a scroll  or layout"); 
    if (this.n.isEmpty())
      setWillNotDraw(false); 
    if (paramInt < 0) {
      this.n.add(paramn);
    } else {
      this.n.add(paramInt, paramn);
    } 
    u0();
    requestLayout();
  }
  
  public Rect h0(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (!layoutParams.c)
      return layoutParams.b; 
    if (this.f0.e() && (layoutParams.b() || layoutParams.d()))
      return layoutParams.b; 
    Rect rect = layoutParams.b;
    rect.set(0, 0, 0, 0);
    int j = this.n.size();
    for (byte b1 = 0; b1 < j; b1++) {
      this.i.set(0, 0, 0, 0);
      ((n)this.n.get(b1)).e(this.i, paramView, this, this.f0);
      int n = rect.left;
      Rect rect1 = this.i;
      rect.left = n + rect1.left;
      rect.top += rect1.top;
      rect.right += rect1.right;
      rect.bottom += rect1.bottom;
    } 
    layoutParams.c = false;
    return rect;
  }
  
  public void h1(int paramInt1, int paramInt2) {
    i1(paramInt1, paramInt2, null);
  }
  
  public boolean hasNestedScrollingParent() {
    return getScrollingChildHelper().j();
  }
  
  public void i(q paramq) {
    this.o.add(paramq);
  }
  
  public final void i0(long paramLong, z paramz1, z paramz2) {
    StringBuilder stringBuilder1;
    int j = this.e.g();
    for (byte b1 = 0; b1 < j; b1++) {
      z z1 = d0(this.e.f(b1));
      if (z1 != paramz1 && b0(z1) == paramLong) {
        g g1 = this.l;
        if (g1 != null && g1.f()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
          stringBuilder.append(z1);
          stringBuilder.append(" \n View Holder 2:");
          stringBuilder.append(paramz1);
          stringBuilder.append(P());
          throw new IllegalStateException(stringBuilder.toString());
        } 
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
        stringBuilder1.append(z1);
        stringBuilder1.append(" \n View Holder 2:");
        stringBuilder1.append(paramz1);
        stringBuilder1.append(P());
        throw new IllegalStateException(stringBuilder1.toString());
      } 
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Problem while matching changed view holders with the newones. The pre-layout information for the change holder ");
    stringBuilder2.append(stringBuilder1);
    stringBuilder2.append(" cannot be found but it is necessary for ");
    stringBuilder2.append(paramz1);
    stringBuilder2.append(P());
    Log.e("RecyclerView", stringBuilder2.toString());
  }
  
  public void i1(int paramInt1, int paramInt2, Interpolator paramInterpolator) {
    o o1 = this.m;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    if (this.w)
      return; 
    if (!o1.j())
      paramInt1 = 0; 
    if (!this.m.k())
      paramInt2 = 0; 
    if (paramInt1 != 0 || paramInt2 != 0)
      this.c0.h(paramInt1, paramInt2, paramInterpolator); 
  }
  
  public boolean isAttachedToWindow() {
    return this.q;
  }
  
  public boolean isNestedScrollingEnabled() {
    return getScrollingChildHelper().l();
  }
  
  public void j(r paramr) {
    if (this.h0 == null)
      this.h0 = new ArrayList(); 
    this.h0.add(paramr);
  }
  
  public boolean j0(int paramInt) {
    return getScrollingChildHelper().k(paramInt);
  }
  
  public void j1() {
    int j = this.u + 1;
    this.u = j;
    if (j == 1 && !this.w)
      this.v = false; 
  }
  
  public void k(z paramz, l.b paramb1, l.b paramb2) {
    paramz.F(false);
    if (this.L.a(paramz, paramb1, paramb2))
      J0(); 
  }
  
  public boolean k0() {
    return (!this.t || this.C || this.d.p());
  }
  
  public boolean k1(int paramInt1, int paramInt2) {
    return getScrollingChildHelper().p(paramInt1, paramInt2);
  }
  
  public final void l(z paramz1, z paramz2, l.b paramb1, l.b paramb2, boolean paramBoolean1, boolean paramBoolean2) {
    paramz1.F(false);
    if (paramBoolean1)
      f(paramz1); 
    if (paramz1 != paramz2) {
      if (paramBoolean2)
        f(paramz2); 
      paramz1.h = paramz2;
      f(paramz1);
      this.b.J(paramz1);
      paramz2.F(false);
      paramz2.i = paramz1;
    } 
    if (this.L.b(paramz1, paramz2, paramb1, paramb2))
      J0(); 
  }
  
  public final boolean l0() {
    int j = this.e.g();
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.f(b1));
      if (z != null && !z.I() && z.x())
        return true; 
    } 
    return false;
  }
  
  public void l1(boolean paramBoolean) {
    if (this.u < 1)
      this.u = 1; 
    if (!paramBoolean && !this.w)
      this.v = false; 
    if (this.u == 1) {
      if (paramBoolean && this.v && !this.w && this.m != null && this.l != null)
        A(); 
      if (!this.w)
        this.v = false; 
    } 
    this.u--;
  }
  
  public void m(z paramz, l.b paramb1, l.b paramb2) {
    f(paramz);
    paramz.F(false);
    if (this.L.c(paramz, paramb1, paramb2))
      J0(); 
  }
  
  public void m0() {
    this.d = new a(new f(this));
  }
  
  public void m1(int paramInt) {
    getScrollingChildHelper().r(paramInt);
  }
  
  public void n(String paramString) {
    if (s0()) {
      StringBuilder stringBuilder;
      if (paramString == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot call this method while RecyclerView is computing a layout or scrolling");
        stringBuilder.append(P());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      throw new IllegalStateException(stringBuilder);
    } 
    if (this.F > 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(P());
      Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(stringBuilder.toString()));
    } 
  }
  
  public final void n0() {
    if (n.j.j((View)this) == 0)
      n.j.C((View)this, 8); 
  }
  
  public void n1() {
    setScrollState(0);
    o1();
  }
  
  public boolean o(z paramz) {
    l l1 = this.L;
    return (l1 == null || l1.g(paramz, paramz.o()));
  }
  
  public final void o0() {
    this.e = new b(new e(this));
  }
  
  public final void o1() {
    this.c0.i();
    o o1 = this.m;
    if (o1 != null)
      o1.E1(); 
  }
  
  public void onAttachedToWindow() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial onAttachedToWindow : ()V
    //   4: aload_0
    //   5: iconst_0
    //   6: putfield E : I
    //   9: iconst_1
    //   10: istore_1
    //   11: aload_0
    //   12: iconst_1
    //   13: putfield q : Z
    //   16: aload_0
    //   17: getfield t : Z
    //   20: ifeq -> 33
    //   23: aload_0
    //   24: invokevirtual isLayoutRequested : ()Z
    //   27: ifne -> 33
    //   30: goto -> 35
    //   33: iconst_0
    //   34: istore_1
    //   35: aload_0
    //   36: iload_1
    //   37: putfield t : Z
    //   40: aload_0
    //   41: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   44: astore_2
    //   45: aload_2
    //   46: ifnull -> 54
    //   49: aload_2
    //   50: aload_0
    //   51: invokevirtual y : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   54: aload_0
    //   55: iconst_0
    //   56: putfield l0 : Z
    //   59: getstatic androidx/recyclerview/widget/RecyclerView.B0 : Z
    //   62: ifeq -> 165
    //   65: getstatic androidx/recyclerview/widget/e.e : Ljava/lang/ThreadLocal;
    //   68: astore_2
    //   69: aload_2
    //   70: invokevirtual get : ()Ljava/lang/Object;
    //   73: checkcast androidx/recyclerview/widget/e
    //   76: astore_3
    //   77: aload_0
    //   78: aload_3
    //   79: putfield d0 : Landroidx/recyclerview/widget/e;
    //   82: aload_3
    //   83: ifnonnull -> 157
    //   86: aload_0
    //   87: new androidx/recyclerview/widget/e
    //   90: dup
    //   91: invokespecial <init> : ()V
    //   94: putfield d0 : Landroidx/recyclerview/widget/e;
    //   97: aload_0
    //   98: invokestatic h : (Landroid/view/View;)Landroid/view/Display;
    //   101: astore_3
    //   102: aload_0
    //   103: invokevirtual isInEditMode : ()Z
    //   106: ifne -> 131
    //   109: aload_3
    //   110: ifnull -> 131
    //   113: aload_3
    //   114: invokevirtual getRefreshRate : ()F
    //   117: fstore #4
    //   119: fload #4
    //   121: ldc_w 30.0
    //   124: fcmpl
    //   125: iflt -> 131
    //   128: goto -> 136
    //   131: ldc_w 60.0
    //   134: fstore #4
    //   136: aload_0
    //   137: getfield d0 : Landroidx/recyclerview/widget/e;
    //   140: astore_3
    //   141: aload_3
    //   142: ldc_w 1.0E9
    //   145: fload #4
    //   147: fdiv
    //   148: f2l
    //   149: putfield c : J
    //   152: aload_2
    //   153: aload_3
    //   154: invokevirtual set : (Ljava/lang/Object;)V
    //   157: aload_0
    //   158: getfield d0 : Landroidx/recyclerview/widget/e;
    //   161: aload_0
    //   162: invokevirtual a : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   165: return
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    l l1 = this.L;
    if (l1 != null)
      l1.k(); 
    n1();
    this.q = false;
    o o1 = this.m;
    if (o1 != null)
      o1.z(this, this.b); 
    this.t0.clear();
    removeCallbacks(this.u0);
    this.f.j();
    if (B0) {
      e e1 = this.d0;
      if (e1 != null) {
        e1.j(this);
        this.d0 = null;
      } 
    } 
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    int j = this.n.size();
    for (byte b1 = 0; b1 < j; b1++)
      ((n)this.n.get(b1)).g(paramCanvas, this, this.f0); 
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   4: ifnonnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_0
    //   10: getfield w : Z
    //   13: ifeq -> 18
    //   16: iconst_0
    //   17: ireturn
    //   18: aload_1
    //   19: invokevirtual getAction : ()I
    //   22: bipush #8
    //   24: if_icmpne -> 177
    //   27: aload_1
    //   28: invokevirtual getSource : ()I
    //   31: iconst_2
    //   32: iand
    //   33: ifeq -> 92
    //   36: aload_0
    //   37: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   40: invokevirtual k : ()Z
    //   43: ifeq -> 57
    //   46: aload_1
    //   47: bipush #9
    //   49: invokevirtual getAxisValue : (I)F
    //   52: fneg
    //   53: fstore_2
    //   54: goto -> 59
    //   57: fconst_0
    //   58: fstore_2
    //   59: fload_2
    //   60: fstore_3
    //   61: aload_0
    //   62: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   65: invokevirtual j : ()Z
    //   68: ifeq -> 81
    //   71: aload_1
    //   72: bipush #10
    //   74: invokevirtual getAxisValue : (I)F
    //   77: fstore_3
    //   78: goto -> 145
    //   81: fconst_0
    //   82: fstore #4
    //   84: fload_3
    //   85: fstore_2
    //   86: fload #4
    //   88: fstore_3
    //   89: goto -> 145
    //   92: aload_1
    //   93: invokevirtual getSource : ()I
    //   96: ldc_w 4194304
    //   99: iand
    //   100: ifeq -> 141
    //   103: aload_1
    //   104: bipush #26
    //   106: invokevirtual getAxisValue : (I)F
    //   109: fstore_3
    //   110: aload_0
    //   111: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   114: invokevirtual k : ()Z
    //   117: ifeq -> 126
    //   120: fload_3
    //   121: fneg
    //   122: fstore_3
    //   123: goto -> 81
    //   126: aload_0
    //   127: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   130: invokevirtual j : ()Z
    //   133: ifeq -> 141
    //   136: fconst_0
    //   137: fstore_2
    //   138: goto -> 145
    //   141: fconst_0
    //   142: fstore_2
    //   143: fload_2
    //   144: fstore_3
    //   145: fload_2
    //   146: fconst_0
    //   147: fcmpl
    //   148: ifne -> 157
    //   151: fload_3
    //   152: fconst_0
    //   153: fcmpl
    //   154: ifeq -> 177
    //   157: aload_0
    //   158: fload_3
    //   159: aload_0
    //   160: getfield W : F
    //   163: fmul
    //   164: f2i
    //   165: fload_2
    //   166: aload_0
    //   167: getfield a0 : F
    //   170: fmul
    //   171: f2i
    //   172: aload_1
    //   173: invokevirtual c1 : (IILandroid/view/MotionEvent;)Z
    //   176: pop
    //   177: iconst_0
    //   178: ireturn
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    StringBuilder stringBuilder;
    int j;
    boolean bool1 = this.w;
    boolean bool = false;
    if (bool1)
      return false; 
    if (H(paramMotionEvent)) {
      p();
      return true;
    } 
    o o1 = this.m;
    if (o1 == null)
      return false; 
    boolean bool2 = o1.j();
    bool1 = this.m.k();
    if (this.O == null)
      this.O = VelocityTracker.obtain(); 
    this.O.addMovement(paramMotionEvent);
    int n = paramMotionEvent.getActionMasked();
    int i1 = paramMotionEvent.getActionIndex();
    if (n != 0) {
      if (n != 1) {
        if (n != 2) {
          if (n != 3) {
            if (n != 5) {
              if (n == 6)
                G0(paramMotionEvent); 
            } else {
              this.N = paramMotionEvent.getPointerId(i1);
              j = (int)(paramMotionEvent.getX(i1) + 0.5F);
              this.R = j;
              this.P = j;
              i1 = (int)(paramMotionEvent.getY(i1) + 0.5F);
              this.S = i1;
              this.Q = i1;
            } 
          } else {
            p();
          } 
        } else {
          n = paramMotionEvent.findPointerIndex(this.N);
          if (n < 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Error processing scroll; pointer index for id ");
            stringBuilder.append(this.N);
            stringBuilder.append(" not found. Did any MotionEvents get skipped?");
            Log.e("RecyclerView", stringBuilder.toString());
            return false;
          } 
          i1 = (int)(stringBuilder.getX(n) + 0.5F);
          int i2 = (int)(stringBuilder.getY(n) + 0.5F);
          if (this.M != 1) {
            int i3 = this.P;
            n = this.Q;
            if (j != 0 && Math.abs(i1 - i3) > this.T) {
              this.R = i1;
              i1 = 1;
            } else {
              i1 = 0;
            } 
            j = i1;
            if (bool1) {
              j = i1;
              if (Math.abs(i2 - n) > this.T) {
                this.S = i2;
                j = 1;
              } 
            } 
            if (j != 0)
              setScrollState(1); 
          } 
        } 
      } else {
        this.O.clear();
        m1(0);
      } 
    } else {
      if (this.x)
        this.x = false; 
      this.N = stringBuilder.getPointerId(0);
      i1 = (int)(stringBuilder.getX() + 0.5F);
      this.R = i1;
      this.P = i1;
      i1 = (int)(stringBuilder.getY() + 0.5F);
      this.S = i1;
      this.Q = i1;
      if (this.M == 2) {
        getParent().requestDisallowInterceptTouchEvent(true);
        setScrollState(1);
      } 
      int[] arrayOfInt = this.r0;
      arrayOfInt[1] = 0;
      arrayOfInt[0] = 0;
      i1 = j;
      if (bool1)
        i1 = j | 0x2; 
      k1(i1, 0);
    } 
    if (this.M == 1)
      bool = true; 
    return bool;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    l.m.a("RV OnLayout");
    A();
    l.m.b();
    this.t = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    o o1 = this.m;
    if (o1 == null) {
      v(paramInt1, paramInt2);
      return;
    } 
    boolean bool = o1.q0();
    boolean bool1 = false;
    if (bool) {
      int j = View.MeasureSpec.getMode(paramInt1);
      int n = View.MeasureSpec.getMode(paramInt2);
      this.m.X0(this.b, this.f0, paramInt1, paramInt2);
      boolean bool2 = bool1;
      if (j == 1073741824) {
        bool2 = bool1;
        if (n == 1073741824)
          bool2 = true; 
      } 
      if (bool2 || this.l == null)
        return; 
      if (this.f0.e == 1)
        B(); 
      this.m.w1(paramInt1, paramInt2);
      this.f0.j = true;
      C();
      this.m.z1(paramInt1, paramInt2);
      if (this.m.C1()) {
        this.m.w1(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
        this.f0.j = true;
        C();
        this.m.z1(paramInt1, paramInt2);
      } 
    } else {
      if (this.r) {
        this.m.X0(this.b, this.f0, paramInt1, paramInt2);
        return;
      } 
      if (this.z) {
        j1();
        D0();
        L0();
        E0();
        w w1 = this.f0;
        if (w1.l) {
          w1.h = true;
        } else {
          this.d.j();
          this.f0.h = false;
        } 
        this.z = false;
        l1(false);
      } else if (this.f0.l) {
        setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
        return;
      } 
      g g1 = this.l;
      if (g1 != null) {
        this.f0.f = g1.c();
      } else {
        this.f0.f = 0;
      } 
      j1();
      this.m.X0(this.b, this.f0, paramInt1, paramInt2);
      l1(false);
      this.f0.h = false;
    } 
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    return s0() ? false : super.onRequestFocusInDescendants(paramInt, paramRect);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    this.c = savedState;
    super.onRestoreInstanceState(savedState.a());
    o o1 = this.m;
    if (o1 != null) {
      Parcelable parcelable = this.c.mLayoutState;
      if (parcelable != null)
        o1.a1(parcelable); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState1 = new SavedState(super.onSaveInstanceState());
    SavedState savedState2 = this.c;
    if (savedState2 != null) {
      savedState1.b(savedState2);
    } else {
      o o1 = this.m;
      if (o1 != null) {
        Parcelable parcelable = o1.b1();
      } else {
        o1 = null;
      } 
      savedState1.mLayoutState = (Parcelable)o1;
    } 
    return (Parcelable)savedState1;
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3 || paramInt2 != paramInt4)
      q0(); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield w : Z
    //   4: istore_2
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_2
    //   8: ifne -> 982
    //   11: aload_0
    //   12: getfield x : Z
    //   15: ifeq -> 21
    //   18: goto -> 982
    //   21: aload_0
    //   22: aload_1
    //   23: invokevirtual G : (Landroid/view/MotionEvent;)Z
    //   26: ifeq -> 35
    //   29: aload_0
    //   30: invokevirtual p : ()V
    //   33: iconst_1
    //   34: ireturn
    //   35: aload_0
    //   36: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   39: astore #4
    //   41: aload #4
    //   43: ifnonnull -> 48
    //   46: iconst_0
    //   47: ireturn
    //   48: aload #4
    //   50: invokevirtual j : ()Z
    //   53: istore #5
    //   55: aload_0
    //   56: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
    //   59: invokevirtual k : ()Z
    //   62: istore_2
    //   63: aload_0
    //   64: getfield O : Landroid/view/VelocityTracker;
    //   67: ifnonnull -> 77
    //   70: aload_0
    //   71: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   74: putfield O : Landroid/view/VelocityTracker;
    //   77: aload_1
    //   78: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
    //   81: astore #4
    //   83: aload_1
    //   84: invokevirtual getActionMasked : ()I
    //   87: istore #6
    //   89: aload_1
    //   90: invokevirtual getActionIndex : ()I
    //   93: istore #7
    //   95: iload #6
    //   97: ifne -> 116
    //   100: aload_0
    //   101: getfield r0 : [I
    //   104: astore #8
    //   106: aload #8
    //   108: iconst_1
    //   109: iconst_0
    //   110: iastore
    //   111: aload #8
    //   113: iconst_0
    //   114: iconst_0
    //   115: iastore
    //   116: aload_0
    //   117: getfield r0 : [I
    //   120: astore #8
    //   122: aload #4
    //   124: aload #8
    //   126: iconst_0
    //   127: iaload
    //   128: i2f
    //   129: aload #8
    //   131: iconst_1
    //   132: iaload
    //   133: i2f
    //   134: invokevirtual offsetLocation : (FF)V
    //   137: iload #6
    //   139: ifeq -> 881
    //   142: iload #6
    //   144: iconst_1
    //   145: if_icmpeq -> 766
    //   148: iload #6
    //   150: iconst_2
    //   151: if_icmpeq -> 266
    //   154: iload #6
    //   156: iconst_3
    //   157: if_icmpeq -> 256
    //   160: iload #6
    //   162: iconst_5
    //   163: if_icmpeq -> 190
    //   166: iload #6
    //   168: bipush #6
    //   170: if_icmpeq -> 179
    //   173: iload_3
    //   174: istore #7
    //   176: goto -> 961
    //   179: aload_0
    //   180: aload_1
    //   181: invokevirtual G0 : (Landroid/view/MotionEvent;)V
    //   184: iload_3
    //   185: istore #7
    //   187: goto -> 961
    //   190: aload_0
    //   191: aload_1
    //   192: iload #7
    //   194: invokevirtual getPointerId : (I)I
    //   197: putfield N : I
    //   200: aload_1
    //   201: iload #7
    //   203: invokevirtual getX : (I)F
    //   206: ldc_w 0.5
    //   209: fadd
    //   210: f2i
    //   211: istore #6
    //   213: aload_0
    //   214: iload #6
    //   216: putfield R : I
    //   219: aload_0
    //   220: iload #6
    //   222: putfield P : I
    //   225: aload_1
    //   226: iload #7
    //   228: invokevirtual getY : (I)F
    //   231: ldc_w 0.5
    //   234: fadd
    //   235: f2i
    //   236: istore #7
    //   238: aload_0
    //   239: iload #7
    //   241: putfield S : I
    //   244: aload_0
    //   245: iload #7
    //   247: putfield Q : I
    //   250: iload_3
    //   251: istore #7
    //   253: goto -> 961
    //   256: aload_0
    //   257: invokevirtual p : ()V
    //   260: iload_3
    //   261: istore #7
    //   263: goto -> 961
    //   266: aload_1
    //   267: aload_0
    //   268: getfield N : I
    //   271: invokevirtual findPointerIndex : (I)I
    //   274: istore #7
    //   276: iload #7
    //   278: ifge -> 327
    //   281: new java/lang/StringBuilder
    //   284: dup
    //   285: invokespecial <init> : ()V
    //   288: astore_1
    //   289: aload_1
    //   290: ldc_w 'Error processing scroll; pointer index for id '
    //   293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   296: pop
    //   297: aload_1
    //   298: aload_0
    //   299: getfield N : I
    //   302: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   305: pop
    //   306: aload_1
    //   307: ldc_w ' not found. Did any MotionEvents get skipped?'
    //   310: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   313: pop
    //   314: ldc_w 'RecyclerView'
    //   317: aload_1
    //   318: invokevirtual toString : ()Ljava/lang/String;
    //   321: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   324: pop
    //   325: iconst_0
    //   326: ireturn
    //   327: aload_1
    //   328: iload #7
    //   330: invokevirtual getX : (I)F
    //   333: ldc_w 0.5
    //   336: fadd
    //   337: f2i
    //   338: istore #9
    //   340: aload_1
    //   341: iload #7
    //   343: invokevirtual getY : (I)F
    //   346: ldc_w 0.5
    //   349: fadd
    //   350: f2i
    //   351: istore #10
    //   353: aload_0
    //   354: getfield R : I
    //   357: iload #9
    //   359: isub
    //   360: istore #11
    //   362: aload_0
    //   363: getfield S : I
    //   366: iload #10
    //   368: isub
    //   369: istore #12
    //   371: iload #11
    //   373: istore #6
    //   375: iload #12
    //   377: istore #7
    //   379: aload_0
    //   380: iload #11
    //   382: iload #12
    //   384: aload_0
    //   385: getfield q0 : [I
    //   388: aload_0
    //   389: getfield p0 : [I
    //   392: iconst_0
    //   393: invokevirtual E : (II[I[II)Z
    //   396: ifeq -> 475
    //   399: aload_0
    //   400: getfield q0 : [I
    //   403: astore_1
    //   404: iload #11
    //   406: aload_1
    //   407: iconst_0
    //   408: iaload
    //   409: isub
    //   410: istore #6
    //   412: iload #12
    //   414: aload_1
    //   415: iconst_1
    //   416: iaload
    //   417: isub
    //   418: istore #7
    //   420: aload_0
    //   421: getfield p0 : [I
    //   424: astore_1
    //   425: aload #4
    //   427: aload_1
    //   428: iconst_0
    //   429: iaload
    //   430: i2f
    //   431: aload_1
    //   432: iconst_1
    //   433: iaload
    //   434: i2f
    //   435: invokevirtual offsetLocation : (FF)V
    //   438: aload_0
    //   439: getfield r0 : [I
    //   442: astore_1
    //   443: aload_1
    //   444: iconst_0
    //   445: iaload
    //   446: istore #12
    //   448: aload_0
    //   449: getfield p0 : [I
    //   452: astore #8
    //   454: aload_1
    //   455: iconst_0
    //   456: iload #12
    //   458: aload #8
    //   460: iconst_0
    //   461: iaload
    //   462: iadd
    //   463: iastore
    //   464: aload_1
    //   465: iconst_1
    //   466: aload_1
    //   467: iconst_1
    //   468: iaload
    //   469: aload #8
    //   471: iconst_1
    //   472: iaload
    //   473: iadd
    //   474: iastore
    //   475: iload #6
    //   477: istore #12
    //   479: iload #7
    //   481: istore #11
    //   483: aload_0
    //   484: getfield M : I
    //   487: iconst_1
    //   488: if_icmpeq -> 638
    //   491: iload #5
    //   493: ifeq -> 544
    //   496: iload #6
    //   498: invokestatic abs : (I)I
    //   501: istore #11
    //   503: aload_0
    //   504: getfield T : I
    //   507: istore #12
    //   509: iload #11
    //   511: iload #12
    //   513: if_icmple -> 544
    //   516: iload #6
    //   518: ifle -> 531
    //   521: iload #6
    //   523: iload #12
    //   525: isub
    //   526: istore #6
    //   528: goto -> 538
    //   531: iload #6
    //   533: iload #12
    //   535: iadd
    //   536: istore #6
    //   538: iconst_1
    //   539: istore #12
    //   541: goto -> 547
    //   544: iconst_0
    //   545: istore #12
    //   547: iload #12
    //   549: istore #13
    //   551: iload #7
    //   553: istore #14
    //   555: iload_2
    //   556: ifeq -> 612
    //   559: iload #7
    //   561: invokestatic abs : (I)I
    //   564: istore #11
    //   566: aload_0
    //   567: getfield T : I
    //   570: istore #15
    //   572: iload #12
    //   574: istore #13
    //   576: iload #7
    //   578: istore #14
    //   580: iload #11
    //   582: iload #15
    //   584: if_icmple -> 612
    //   587: iload #7
    //   589: ifle -> 602
    //   592: iload #7
    //   594: iload #15
    //   596: isub
    //   597: istore #14
    //   599: goto -> 609
    //   602: iload #7
    //   604: iload #15
    //   606: iadd
    //   607: istore #14
    //   609: iconst_1
    //   610: istore #13
    //   612: iload #6
    //   614: istore #12
    //   616: iload #14
    //   618: istore #11
    //   620: iload #13
    //   622: ifeq -> 638
    //   625: aload_0
    //   626: iconst_1
    //   627: invokevirtual setScrollState : (I)V
    //   630: iload #14
    //   632: istore #11
    //   634: iload #6
    //   636: istore #12
    //   638: iload_3
    //   639: istore #7
    //   641: aload_0
    //   642: getfield M : I
    //   645: iconst_1
    //   646: if_icmpne -> 961
    //   649: aload_0
    //   650: getfield p0 : [I
    //   653: astore_1
    //   654: aload_0
    //   655: iload #9
    //   657: aload_1
    //   658: iconst_0
    //   659: iaload
    //   660: isub
    //   661: putfield R : I
    //   664: aload_0
    //   665: iload #10
    //   667: aload_1
    //   668: iconst_1
    //   669: iaload
    //   670: isub
    //   671: putfield S : I
    //   674: iload #5
    //   676: ifeq -> 686
    //   679: iload #12
    //   681: istore #7
    //   683: goto -> 689
    //   686: iconst_0
    //   687: istore #7
    //   689: iload_2
    //   690: ifeq -> 700
    //   693: iload #11
    //   695: istore #6
    //   697: goto -> 703
    //   700: iconst_0
    //   701: istore #6
    //   703: aload_0
    //   704: iload #7
    //   706: iload #6
    //   708: aload #4
    //   710: invokevirtual c1 : (IILandroid/view/MotionEvent;)Z
    //   713: ifeq -> 726
    //   716: aload_0
    //   717: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   720: iconst_1
    //   721: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   726: aload_0
    //   727: getfield d0 : Landroidx/recyclerview/widget/e;
    //   730: astore_1
    //   731: iload_3
    //   732: istore #7
    //   734: aload_1
    //   735: ifnull -> 961
    //   738: iload #12
    //   740: ifne -> 751
    //   743: iload_3
    //   744: istore #7
    //   746: iload #11
    //   748: ifeq -> 961
    //   751: aload_1
    //   752: aload_0
    //   753: iload #12
    //   755: iload #11
    //   757: invokevirtual f : (Landroidx/recyclerview/widget/RecyclerView;II)V
    //   760: iload_3
    //   761: istore #7
    //   763: goto -> 961
    //   766: aload_0
    //   767: getfield O : Landroid/view/VelocityTracker;
    //   770: aload #4
    //   772: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   775: aload_0
    //   776: getfield O : Landroid/view/VelocityTracker;
    //   779: sipush #1000
    //   782: aload_0
    //   783: getfield V : I
    //   786: i2f
    //   787: invokevirtual computeCurrentVelocity : (IF)V
    //   790: iload #5
    //   792: ifeq -> 812
    //   795: aload_0
    //   796: getfield O : Landroid/view/VelocityTracker;
    //   799: aload_0
    //   800: getfield N : I
    //   803: invokevirtual getXVelocity : (I)F
    //   806: fneg
    //   807: fstore #16
    //   809: goto -> 815
    //   812: fconst_0
    //   813: fstore #16
    //   815: iload_2
    //   816: ifeq -> 836
    //   819: aload_0
    //   820: getfield O : Landroid/view/VelocityTracker;
    //   823: aload_0
    //   824: getfield N : I
    //   827: invokevirtual getYVelocity : (I)F
    //   830: fneg
    //   831: fstore #17
    //   833: goto -> 839
    //   836: fconst_0
    //   837: fstore #17
    //   839: fload #16
    //   841: fconst_0
    //   842: fcmpl
    //   843: ifne -> 853
    //   846: fload #17
    //   848: fconst_0
    //   849: fcmpl
    //   850: ifeq -> 866
    //   853: aload_0
    //   854: fload #16
    //   856: f2i
    //   857: fload #17
    //   859: f2i
    //   860: invokevirtual Z : (II)Z
    //   863: ifne -> 871
    //   866: aload_0
    //   867: iconst_0
    //   868: invokevirtual setScrollState : (I)V
    //   871: aload_0
    //   872: invokevirtual Z0 : ()V
    //   875: iconst_1
    //   876: istore #7
    //   878: goto -> 961
    //   881: aload_0
    //   882: aload_1
    //   883: iconst_0
    //   884: invokevirtual getPointerId : (I)I
    //   887: putfield N : I
    //   890: aload_1
    //   891: invokevirtual getX : ()F
    //   894: ldc_w 0.5
    //   897: fadd
    //   898: f2i
    //   899: istore #7
    //   901: aload_0
    //   902: iload #7
    //   904: putfield R : I
    //   907: aload_0
    //   908: iload #7
    //   910: putfield P : I
    //   913: aload_1
    //   914: invokevirtual getY : ()F
    //   917: ldc_w 0.5
    //   920: fadd
    //   921: f2i
    //   922: istore #7
    //   924: aload_0
    //   925: iload #7
    //   927: putfield S : I
    //   930: aload_0
    //   931: iload #7
    //   933: putfield Q : I
    //   936: iload #5
    //   938: istore #7
    //   940: iload_2
    //   941: ifeq -> 950
    //   944: iload #5
    //   946: iconst_2
    //   947: ior
    //   948: istore #7
    //   950: aload_0
    //   951: iload #7
    //   953: iconst_0
    //   954: invokevirtual k1 : (II)Z
    //   957: pop
    //   958: iload_3
    //   959: istore #7
    //   961: iload #7
    //   963: ifne -> 975
    //   966: aload_0
    //   967: getfield O : Landroid/view/VelocityTracker;
    //   970: aload #4
    //   972: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   975: aload #4
    //   977: invokevirtual recycle : ()V
    //   980: iconst_1
    //   981: ireturn
    //   982: iconst_0
    //   983: ireturn
  }
  
  public final void p() {
    Z0();
    setScrollState(0);
  }
  
  public void p0(StateListDrawable paramStateListDrawable1, Drawable paramDrawable1, StateListDrawable paramStateListDrawable2, Drawable paramDrawable2) {
    if (paramStateListDrawable1 != null && paramDrawable1 != null && paramStateListDrawable2 != null && paramDrawable2 != null) {
      Resources resources = getContext().getResources();
      new d(this, paramStateListDrawable1, paramDrawable1, paramStateListDrawable2, paramDrawable2, resources.getDimensionPixelSize(t.a.fastscroll_default_thickness), resources.getDimensionPixelSize(t.a.fastscroll_minimum_range), resources.getDimensionPixelOffset(t.a.fastscroll_margin));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set fast scroller without both required drawables.");
    stringBuilder.append(P());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void p1(int paramInt1, int paramInt2, Object paramObject) {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++) {
      View view = this.e.i(b1);
      z z = d0(view);
      if (z != null && !z.I()) {
        int n = z.c;
        if (n >= paramInt1 && n < paramInt1 + paramInt2) {
          z.b(2);
          z.a(paramObject);
          ((LayoutParams)view.getLayoutParams()).c = true;
        } 
      } 
    } 
    this.b.M(paramInt1, paramInt2);
  }
  
  public void q0() {
    this.K = null;
    this.I = null;
    this.J = null;
    this.H = null;
  }
  
  public void r() {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.i(b1));
      if (!z.I())
        z.c(); 
    } 
    this.b.d();
  }
  
  public boolean r0() {
    boolean bool;
    AccessibilityManager accessibilityManager = this.A;
    if (accessibilityManager != null && accessibilityManager.isEnabled()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void removeDetachedView(View paramView, boolean paramBoolean) {
    StringBuilder stringBuilder;
    z z = d0(paramView);
    if (z != null)
      if (z.w()) {
        z.f();
      } else if (!z.I()) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
        stringBuilder.append(z);
        stringBuilder.append(P());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    stringBuilder.clearAnimation();
    y((View)stringBuilder);
    super.removeDetachedView((View)stringBuilder, paramBoolean);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.m.Z0(this, this.f0, paramView1, paramView2) && paramView2 != null)
      X0(paramView1, paramView2); 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    return this.m.o1(this, paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    int j = this.o.size();
    for (byte b1 = 0; b1 < j; b1++)
      ((q)this.o.get(b1)).c(paramBoolean); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    if (this.u == 0 && !this.w) {
      super.requestLayout();
    } else {
      this.v = true;
    } 
  }
  
  public void s(int paramInt1, int paramInt2) {
    EdgeEffect edgeEffect = this.H;
    if (edgeEffect != null && !edgeEffect.isFinished() && paramInt1 > 0) {
      this.H.onRelease();
      bool1 = this.H.isFinished();
    } else {
      bool1 = false;
    } 
    edgeEffect = this.J;
    boolean bool2 = bool1;
    if (edgeEffect != null) {
      bool2 = bool1;
      if (!edgeEffect.isFinished()) {
        bool2 = bool1;
        if (paramInt1 < 0) {
          this.J.onRelease();
          bool2 = bool1 | this.J.isFinished();
        } 
      } 
    } 
    edgeEffect = this.I;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt2 > 0) {
          this.I.onRelease();
          bool1 = bool2 | this.I.isFinished();
        } 
      } 
    } 
    edgeEffect = this.K;
    bool2 = bool1;
    if (edgeEffect != null) {
      bool2 = bool1;
      if (!edgeEffect.isFinished()) {
        bool2 = bool1;
        if (paramInt2 < 0) {
          this.K.onRelease();
          bool2 = bool1 | this.K.isFinished();
        } 
      } 
    } 
    if (bool2)
      n.j.w((View)this); 
  }
  
  public boolean s0() {
    boolean bool;
    if (this.E > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void scrollBy(int paramInt1, int paramInt2) {
    o o1 = this.m;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    if (this.w)
      return; 
    boolean bool1 = o1.j();
    boolean bool2 = this.m.k();
    if (bool1 || bool2) {
      if (!bool1)
        paramInt1 = 0; 
      if (!bool2)
        paramInt2 = 0; 
      c1(paramInt1, paramInt2, null);
    } 
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
  }
  
  public void sendAccessibilityEventUnchecked(AccessibilityEvent paramAccessibilityEvent) {
    if (g1(paramAccessibilityEvent))
      return; 
    super.sendAccessibilityEventUnchecked(paramAccessibilityEvent);
  }
  
  public void setAccessibilityDelegateCompat(i parami) {
    this.m0 = parami;
    n.j.A((View)this, parami);
  }
  
  public void setAdapter(g paramg) {
    setLayoutFrozen(false);
    e1(paramg, false, true);
    M0(false);
    requestLayout();
  }
  
  public void setChildDrawingOrderCallback(j paramj) {
    if (paramj == null)
      return; 
    setChildrenDrawingOrderEnabled(false);
  }
  
  public void setClipToPadding(boolean paramBoolean) {
    if (paramBoolean != this.g)
      q0(); 
    this.g = paramBoolean;
    super.setClipToPadding(paramBoolean);
    if (this.t)
      requestLayout(); 
  }
  
  public void setEdgeEffectFactory(k paramk) {
    m.g.a(paramk);
    this.G = paramk;
    q0();
  }
  
  public void setHasFixedSize(boolean paramBoolean) {
    this.r = paramBoolean;
  }
  
  public void setItemAnimator(l paraml) {
    l l1 = this.L;
    if (l1 != null) {
      l1.k();
      this.L.v(null);
    } 
    this.L = paraml;
    if (paraml != null)
      paraml.v(this.k0); 
  }
  
  public void setItemViewCacheSize(int paramInt) {
    this.b.G(paramInt);
  }
  
  public void setLayoutFrozen(boolean paramBoolean) {
    if (paramBoolean != this.w) {
      n("Do not setLayoutFrozen in layout or scroll");
      if (!paramBoolean) {
        this.w = false;
        if (this.v && this.m != null && this.l != null)
          requestLayout(); 
        this.v = false;
      } else {
        long l1 = SystemClock.uptimeMillis();
        onTouchEvent(MotionEvent.obtain(l1, l1, 3, 0.0F, 0.0F, 0));
        this.w = true;
        this.x = true;
        n1();
      } 
    } 
  }
  
  public void setLayoutManager(o paramo) {
    if (paramo == this.m)
      return; 
    n1();
    if (this.m != null) {
      l l1 = this.L;
      if (l1 != null)
        l1.k(); 
      this.m.h1(this.b);
      this.m.i1(this.b);
      this.b.c();
      if (this.q)
        this.m.z(this, this.b); 
      this.m.A1(null);
      this.m = null;
    } else {
      this.b.c();
    } 
    this.e.o();
    this.m = paramo;
    if (paramo != null)
      if (paramo.b == null) {
        paramo.A1(this);
        if (this.q)
          this.m.y(this); 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LayoutManager ");
        stringBuilder.append(paramo);
        stringBuilder.append(" is already attached to a RecyclerView:");
        stringBuilder.append(paramo.b.P());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    this.b.K();
    requestLayout();
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    getScrollingChildHelper().m(paramBoolean);
  }
  
  public void setOnFlingListener(p paramp) {}
  
  @Deprecated
  public void setOnScrollListener(r paramr) {
    this.g0 = paramr;
  }
  
  public void setPreserveFocusAfterLayout(boolean paramBoolean) {
    this.b0 = paramBoolean;
  }
  
  public void setRecycledViewPool(s params) {
    this.b.E(params);
  }
  
  public void setRecyclerListener(u paramu) {}
  
  public void setScrollState(int paramInt) {
    if (paramInt == this.M)
      return; 
    this.M = paramInt;
    if (paramInt != 2)
      o1(); 
    I(paramInt);
  }
  
  public void setScrollingTouchSlop(int paramInt) {
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    if (paramInt != 0)
      if (paramInt != 1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("setScrollingTouchSlop(): bad argument constant ");
        stringBuilder.append(paramInt);
        stringBuilder.append("; using default value");
        Log.w("RecyclerView", stringBuilder.toString());
      } else {
        paramInt = viewConfiguration.getScaledPagingTouchSlop();
        this.T = paramInt;
      }  
    paramInt = viewConfiguration.getScaledTouchSlop();
    this.T = paramInt;
  }
  
  public void setViewCacheExtension(x paramx) {
    this.b.F(paramx);
  }
  
  public boolean startNestedScroll(int paramInt) {
    return getScrollingChildHelper().o(paramInt);
  }
  
  public void stopNestedScroll() {
    getScrollingChildHelper().q();
  }
  
  public void t() {
    if (!this.t || this.C) {
      l.m.a("RV FullInvalidate");
      A();
      l.m.b();
      return;
    } 
    if (!this.d.p())
      return; 
    if (this.d.o(4) && !this.d.o(11)) {
      l.m.a("RV PartialInvalidate");
      j1();
      D0();
      this.d.s();
      if (!this.v)
        if (l0()) {
          A();
        } else {
          this.d.i();
        }  
      l1(true);
      E0();
    } else if (this.d.p()) {
      l.m.a("RV FullInvalidate");
      A();
    } else {
      return;
    } 
    l.m.b();
  }
  
  public final boolean t0(View paramView1, View paramView2, int paramInt) {
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = bool5;
    if (paramView2 != null)
      if (paramView2 == this) {
        bool7 = bool5;
      } else {
        byte b2;
        if (R(paramView2) == null)
          return false; 
        if (paramView1 == null)
          return true; 
        if (R(paramView1) == null)
          return true; 
        this.i.set(0, 0, paramView1.getWidth(), paramView1.getHeight());
        this.j.set(0, 0, paramView2.getWidth(), paramView2.getHeight());
        offsetDescendantRectToMyCoords(paramView1, this.i);
        offsetDescendantRectToMyCoords(paramView2, this.j);
        int j = this.m.X();
        byte b1 = -1;
        if (j == 1) {
          b2 = -1;
        } else {
          b2 = 1;
        } 
        Rect rect1 = this.i;
        int n = rect1.left;
        Rect rect2 = this.j;
        int i1 = rect2.left;
        if ((n < i1 || rect1.right <= i1) && rect1.right < rect2.right) {
          j = 1;
        } else {
          j = rect1.right;
          int i3 = rect2.right;
          if ((j > i3 || n >= i3) && n > i1) {
            j = -1;
          } else {
            j = 0;
          } 
        } 
        i1 = rect1.top;
        int i2 = rect2.top;
        if ((i1 < i2 || rect1.bottom <= i2) && rect1.bottom < rect2.bottom) {
          b1 = 1;
        } else {
          n = rect1.bottom;
          int i3 = rect2.bottom;
          if ((n <= i3 && i1 < i3) || i1 <= i2)
            b1 = 0; 
        } 
        if (paramInt != 1) {
          if (paramInt != 2) {
            if (paramInt != 17) {
              if (paramInt != 33) {
                if (paramInt != 66) {
                  if (paramInt == 130) {
                    bool7 = bool6;
                    if (b1 > 0)
                      bool7 = true; 
                    return bool7;
                  } 
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Invalid direction: ");
                  stringBuilder.append(paramInt);
                  stringBuilder.append(P());
                  throw new IllegalArgumentException(stringBuilder.toString());
                } 
                bool7 = bool1;
                if (j > 0)
                  bool7 = true; 
                return bool7;
              } 
              bool7 = bool2;
              if (b1 < 0)
                bool7 = true; 
              return bool7;
            } 
            bool7 = bool3;
            if (j < 0)
              bool7 = true; 
            return bool7;
          } 
          if (b1 <= 0) {
            bool7 = bool4;
            if (b1 == 0) {
              bool7 = bool4;
              if (j * b2 >= 0)
                bool7 = true; 
            } 
            return bool7;
          } 
        } else {
          if (b1 >= 0) {
            bool7 = bool5;
            if (b1 == 0) {
              bool7 = bool5;
              if (j * b2 <= 0)
                bool7 = true; 
            } 
            return bool7;
          } 
          bool7 = true;
        } 
        bool7 = true;
      }  
    return bool7;
  }
  
  public final void u(Context paramContext, String paramString, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (paramString != null) {
      paramString = paramString.trim();
      if (!paramString.isEmpty()) {
        String str = g0(paramContext, paramString);
        try {
          ClassLoader classLoader;
          StringBuilder stringBuilder;
          if (isInEditMode()) {
            classLoader = getClass().getClassLoader();
          } else {
            classLoader = paramContext.getClassLoader();
          } 
          Class<? extends o> clazz = classLoader.loadClass(str).asSubclass(o.class);
          try {
            Constructor<? extends o> constructor = clazz.getConstructor(E0);
            Object[] arrayOfObject2 = new Object[4];
            arrayOfObject2[0] = paramContext;
            arrayOfObject2[1] = paramAttributeSet;
            arrayOfObject2[2] = Integer.valueOf(paramInt1);
            arrayOfObject2[3] = Integer.valueOf(paramInt2);
            Object[] arrayOfObject1 = arrayOfObject2;
          } catch (NoSuchMethodException noSuchMethodException1) {
            try {
              Constructor<? extends o> constructor = clazz.getConstructor(new Class[0]);
              paramContext = null;
              constructor.setAccessible(true);
              setLayoutManager(constructor.newInstance((Object[])paramContext));
            } catch (NoSuchMethodException noSuchMethodException) {
              noSuchMethodException.initCause(noSuchMethodException1);
              IllegalStateException illegalStateException = new IllegalStateException();
              stringBuilder = new StringBuilder();
              this();
              stringBuilder.append(paramAttributeSet.getPositionDescription());
              stringBuilder.append(": Error creating LayoutManager ");
              stringBuilder.append(str);
              this(stringBuilder.toString(), noSuchMethodException);
              throw illegalStateException;
            } 
          } 
          stringBuilder.setAccessible(true);
          setLayoutManager(stringBuilder.newInstance((Object[])noSuchMethodException));
        } catch (ClassNotFoundException classNotFoundException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Unable to find LayoutManager ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), classNotFoundException);
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Could not instantiate the LayoutManager: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), invocationTargetException);
        } catch (InstantiationException instantiationException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Could not instantiate the LayoutManager: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), instantiationException);
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Cannot access non-public constructor ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), illegalAccessException);
        } catch (ClassCastException classCastException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Class is not a LayoutManager ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), classCastException);
        } 
      } 
    } 
  }
  
  public void u0() {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++)
      ((LayoutParams)this.e.i(b1).getLayoutParams()).c = true; 
    this.b.s();
  }
  
  public void v(int paramInt1, int paramInt2) {
    setMeasuredDimension(o.m(paramInt1, getPaddingLeft() + getPaddingRight(), n.j.m((View)this)), o.m(paramInt2, getPaddingTop() + getPaddingBottom(), n.j.l((View)this)));
  }
  
  public void v0() {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.i(b1));
      if (z != null && !z.I())
        z.b(6); 
    } 
    u0();
    this.b.t();
  }
  
  public final boolean w(int paramInt1, int paramInt2) {
    T(this.n0);
    int[] arrayOfInt = this.n0;
    boolean bool = false;
    if (arrayOfInt[0] != paramInt1 || arrayOfInt[1] != paramInt2)
      bool = true; 
    return bool;
  }
  
  public void w0(int paramInt) {
    int j = this.e.g();
    for (byte b1 = 0; b1 < j; b1++)
      this.e.f(b1).offsetLeftAndRight(paramInt); 
  }
  
  public void x(View paramView) {
    z z = d0(paramView);
    B0(paramView);
    g g1 = this.l;
    if (g1 != null && z != null)
      g1.n(z); 
    List list = this.B;
    if (list != null) {
      int j = list.size() - 1;
      if (j >= 0) {
        android.support.v4.media.a.a(this.B.get(j));
        throw null;
      } 
    } 
  }
  
  public void x0(int paramInt) {
    int j = this.e.g();
    for (byte b1 = 0; b1 < j; b1++)
      this.e.f(b1).offsetTopAndBottom(paramInt); 
  }
  
  public void y(View paramView) {
    z z = d0(paramView);
    C0(paramView);
    g g1 = this.l;
    if (g1 != null && z != null)
      g1.o(z); 
    List list = this.B;
    if (list != null) {
      int j = list.size() - 1;
      if (j >= 0) {
        android.support.v4.media.a.a(this.B.get(j));
        throw null;
      } 
    } 
  }
  
  public void y0(int paramInt1, int paramInt2) {
    int j = this.e.j();
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.i(b1));
      if (z != null && !z.I() && z.c >= paramInt1) {
        z.z(paramInt2, false);
        this.f0.g = true;
      } 
    } 
    this.b.u(paramInt1, paramInt2);
    requestLayout();
  }
  
  public final void z() {
    int j = this.y;
    this.y = 0;
    if (j != 0 && r0()) {
      AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain();
      accessibilityEvent.setEventType(2048);
      o.b.b(accessibilityEvent, j);
      sendAccessibilityEventUnchecked(accessibilityEvent);
    } 
  }
  
  public void z0(int paramInt1, int paramInt2) {
    boolean bool;
    int n;
    int i1;
    int j = this.e.j();
    if (paramInt1 < paramInt2) {
      bool = true;
      n = paramInt1;
      i1 = paramInt2;
    } else {
      i1 = paramInt1;
      n = paramInt2;
      bool = true;
    } 
    for (byte b1 = 0; b1 < j; b1++) {
      z z = d0(this.e.i(b1));
      if (z != null) {
        int i2 = z.c;
        if (i2 >= n && i2 <= i1) {
          if (i2 == paramInt1) {
            z.z(paramInt2 - paramInt1, false);
          } else {
            z.z(bool, false);
          } 
          this.f0.g = true;
        } 
      } 
    } 
    this.b.v(paramInt1, paramInt2);
    requestLayout();
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public RecyclerView.z a;
    
    public final Rect b = new Rect();
    
    public boolean c = true;
    
    public boolean d = false;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super((ViewGroup.LayoutParams)param1LayoutParams);
    }
    
    public int a() {
      return this.a.m();
    }
    
    public boolean b() {
      return this.a.x();
    }
    
    public boolean c() {
      return this.a.u();
    }
    
    public boolean d() {
      return this.a.s();
    }
  }
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    Parcelable mLayoutState;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      if (param1ClassLoader == null)
        param1ClassLoader = RecyclerView.o.class.getClassLoader(); 
      this.mLayoutState = param1Parcel.readParcelable(param1ClassLoader);
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void b(SavedState param1SavedState) {
      this.mLayoutState = param1SavedState.mLayoutState;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeParcelable(this.mLayoutState, 0);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator {
      public RecyclerView.SavedState a(Parcel param2Parcel) {
        return new RecyclerView.SavedState(param2Parcel, null);
      }
      
      public RecyclerView.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new RecyclerView.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public RecyclerView.SavedState[] c(int param2Int) {
        return new RecyclerView.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator {
    public RecyclerView.SavedState a(Parcel param1Parcel) {
      return new RecyclerView.SavedState(param1Parcel, null);
    }
    
    public RecyclerView.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new RecyclerView.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public RecyclerView.SavedState[] c(int param1Int) {
      return new RecyclerView.SavedState[param1Int];
    }
  }
  
  public class a implements Runnable {
    public a(RecyclerView this$0) {}
    
    public void run() {
      RecyclerView recyclerView = this.a;
      if (recyclerView.t && !recyclerView.isLayoutRequested()) {
        recyclerView = this.a;
        if (!recyclerView.q) {
          recyclerView.requestLayout();
          return;
        } 
        if (recyclerView.w) {
          recyclerView.v = true;
          return;
        } 
        recyclerView.t();
      } 
    }
  }
  
  public class b implements Runnable {
    public b(RecyclerView this$0) {}
    
    public void run() {
      RecyclerView.l l = this.a.L;
      if (l != null)
        l.u(); 
      this.a.l0 = false;
    }
  }
  
  public static final class c implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  public class d implements m.b {
    public d(RecyclerView this$0) {}
    
    public void a(RecyclerView.z param1z) {
      RecyclerView recyclerView = this.a;
      recyclerView.m.j1(param1z.a, recyclerView.b);
    }
    
    public void b(RecyclerView.z param1z, RecyclerView.l.b param1b1, RecyclerView.l.b param1b2) {
      this.a.k(param1z, param1b1, param1b2);
    }
    
    public void c(RecyclerView.z param1z, RecyclerView.l.b param1b1, RecyclerView.l.b param1b2) {
      this.a.b.J(param1z);
      this.a.m(param1z, param1b1, param1b2);
    }
    
    public void d(RecyclerView.z param1z, RecyclerView.l.b param1b1, RecyclerView.l.b param1b2) {
      param1z.F(false);
      RecyclerView recyclerView = this.a;
      boolean bool = recyclerView.C;
      RecyclerView.l l = recyclerView.L;
      if (bool ? l.b(param1z, param1z, param1b1, param1b2) : l.d(param1z, param1b1, param1b2))
        this.a.J0(); 
    }
  }
  
  public class e implements b.b {
    public e(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.getChildAt(param1Int);
    }
    
    public void b(View param1View) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z != null)
        z.A(this.a); 
    }
    
    public RecyclerView.z c(View param1View) {
      return RecyclerView.d0(param1View);
    }
    
    public void d(int param1Int) {
      View view = a(param1Int);
      if (view != null) {
        RecyclerView.z z = RecyclerView.d0(view);
        if (z != null)
          if (!z.w() || z.I()) {
            z.b(256);
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("called detach on an already detached child ");
            stringBuilder.append(z);
            stringBuilder.append(this.a.P());
            throw new IllegalArgumentException(stringBuilder.toString());
          }  
      } 
      RecyclerView.c(this.a, param1Int);
    }
    
    public void e(View param1View) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z != null)
        z.B(this.a); 
    }
    
    public void f(View param1View, int param1Int) {
      this.a.addView(param1View, param1Int);
      this.a.x(param1View);
    }
    
    public int g() {
      return this.a.getChildCount();
    }
    
    public void h(int param1Int) {
      View view = this.a.getChildAt(param1Int);
      if (view != null) {
        this.a.y(view);
        view.clearAnimation();
      } 
      this.a.removeViewAt(param1Int);
    }
    
    public void i() {
      int i = g();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = a(b1);
        this.a.y(view);
        view.clearAnimation();
      } 
      this.a.removeAllViews();
    }
    
    public void j(View param1View, int param1Int, ViewGroup.LayoutParams param1LayoutParams) {
      StringBuilder stringBuilder;
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z != null)
        if (z.w() || z.I()) {
          z.f();
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Called attach on a child which is not detached: ");
          stringBuilder.append(z);
          stringBuilder.append(this.a.P());
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
      RecyclerView.b(this.a, (View)stringBuilder, param1Int, param1LayoutParams);
    }
    
    public int k(View param1View) {
      return this.a.indexOfChild(param1View);
    }
  }
  
  public class f implements a.a {
    public f(RecyclerView this$0) {}
    
    public void a(int param1Int1, int param1Int2) {
      this.a.z0(param1Int1, param1Int2);
      this.a.i0 = true;
    }
    
    public void b(a.b param1b) {
      i(param1b);
    }
    
    public RecyclerView.z c(int param1Int) {
      RecyclerView.z z = this.a.Y(param1Int, true);
      return (z == null) ? null : (this.a.e.n(z.a) ? null : z);
    }
    
    public void d(int param1Int1, int param1Int2) {
      this.a.A0(param1Int1, param1Int2, false);
      this.a.i0 = true;
    }
    
    public void e(int param1Int1, int param1Int2) {
      this.a.y0(param1Int1, param1Int2);
      this.a.i0 = true;
    }
    
    public void f(int param1Int1, int param1Int2) {
      this.a.A0(param1Int1, param1Int2, true);
      RecyclerView recyclerView = this.a;
      recyclerView.i0 = true;
      RecyclerView.w w = recyclerView.f0;
      w.d += param1Int2;
    }
    
    public void g(a.b param1b) {
      i(param1b);
    }
    
    public void h(int param1Int1, int param1Int2, Object param1Object) {
      this.a.p1(param1Int1, param1Int2, param1Object);
      this.a.j0 = true;
    }
    
    public void i(a.b param1b) {
      int i = param1b.a;
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            if (i == 8) {
              RecyclerView recyclerView = this.a;
              recyclerView.m.R0(recyclerView, param1b.b, param1b.d, 1);
            } 
          } else {
            RecyclerView recyclerView = this.a;
            recyclerView.m.U0(recyclerView, param1b.b, param1b.d, param1b.c);
          } 
        } else {
          RecyclerView recyclerView = this.a;
          recyclerView.m.S0(recyclerView, param1b.b, param1b.d);
        } 
      } else {
        RecyclerView recyclerView = this.a;
        recyclerView.m.P0(recyclerView, param1b.b, param1b.d);
      } 
    }
  }
  
  public static abstract class g {
    public final RecyclerView.h a = new RecyclerView.h();
    
    public boolean b = false;
    
    public final void a(RecyclerView.z param1z, int param1Int) {
      param1z.c = param1Int;
      if (f())
        param1z.e = d(param1Int); 
      param1z.E(1, 519);
      l.m.a("RV OnBindView");
      j(param1z, param1Int, param1z.o());
      param1z.d();
      ViewGroup.LayoutParams layoutParams = param1z.a.getLayoutParams();
      if (layoutParams instanceof RecyclerView.LayoutParams)
        ((RecyclerView.LayoutParams)layoutParams).c = true; 
      l.m.b();
    }
    
    public final RecyclerView.z b(ViewGroup param1ViewGroup, int param1Int) {
      try {
        l.m.a("RV CreateView");
        RecyclerView.z z = k(param1ViewGroup, param1Int);
        if (z.a.getParent() == null) {
          z.f = param1Int;
          return z;
        } 
        IllegalStateException illegalStateException = new IllegalStateException();
        this("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
        throw illegalStateException;
      } finally {
        l.m.b();
      } 
    }
    
    public abstract int c();
    
    public long d(int param1Int) {
      return -1L;
    }
    
    public int e(int param1Int) {
      return 0;
    }
    
    public final boolean f() {
      return this.b;
    }
    
    public final void g() {
      this.a.a();
    }
    
    public void h(RecyclerView param1RecyclerView) {}
    
    public abstract void i(RecyclerView.z param1z, int param1Int);
    
    public void j(RecyclerView.z param1z, int param1Int, List param1List) {
      i(param1z, param1Int);
    }
    
    public abstract RecyclerView.z k(ViewGroup param1ViewGroup, int param1Int);
    
    public void l(RecyclerView param1RecyclerView) {}
    
    public boolean m(RecyclerView.z param1z) {
      return false;
    }
    
    public void n(RecyclerView.z param1z) {}
    
    public void o(RecyclerView.z param1z) {}
    
    public void p(RecyclerView.z param1z) {}
    
    public void q(RecyclerView.i param1i) {
      this.a.registerObserver(param1i);
    }
    
    public void r(RecyclerView.i param1i) {
      this.a.unregisterObserver(param1i);
    }
  }
  
  public static class h extends Observable {
    public void a() {
      for (int i = this.mObservers.size() - 1; i >= 0; i--)
        ((RecyclerView.i)this.mObservers.get(i)).a(); 
    }
  }
  
  public static abstract class i {
    public abstract void a();
  }
  
  public static interface j {}
  
  public static class k {
    public EdgeEffect a(RecyclerView param1RecyclerView, int param1Int) {
      return new EdgeEffect(param1RecyclerView.getContext());
    }
  }
  
  public static abstract class l {
    public a a = null;
    
    public ArrayList b = new ArrayList();
    
    public long c = 120L;
    
    public long d = 120L;
    
    public long e = 250L;
    
    public long f = 250L;
    
    public static int e(RecyclerView.z param1z) {
      int i = param1z.j & 0xE;
      if (param1z.s())
        return 4; 
      int j = i;
      if ((i & 0x4) == 0) {
        int k = param1z.n();
        int m = param1z.j();
        j = i;
        if (k != -1) {
          j = i;
          if (m != -1) {
            j = i;
            if (k != m)
              j = i | 0x800; 
          } 
        } 
      } 
      return j;
    }
    
    public abstract boolean a(RecyclerView.z param1z, b param1b1, b param1b2);
    
    public abstract boolean b(RecyclerView.z param1z1, RecyclerView.z param1z2, b param1b1, b param1b2);
    
    public abstract boolean c(RecyclerView.z param1z, b param1b1, b param1b2);
    
    public abstract boolean d(RecyclerView.z param1z, b param1b1, b param1b2);
    
    public abstract boolean f(RecyclerView.z param1z);
    
    public boolean g(RecyclerView.z param1z, List param1List) {
      return f(param1z);
    }
    
    public final void h(RecyclerView.z param1z) {
      r(param1z);
      a a1 = this.a;
      if (a1 != null)
        a1.a(param1z); 
    }
    
    public final void i() {
      if (this.b.size() <= 0) {
        this.b.clear();
        return;
      } 
      android.support.v4.media.a.a(this.b.get(0));
      throw null;
    }
    
    public abstract void j(RecyclerView.z param1z);
    
    public abstract void k();
    
    public long l() {
      return this.c;
    }
    
    public long m() {
      return this.f;
    }
    
    public long n() {
      return this.e;
    }
    
    public long o() {
      return this.d;
    }
    
    public abstract boolean p();
    
    public b q() {
      return new b();
    }
    
    public void r(RecyclerView.z param1z) {}
    
    public b s(RecyclerView.w param1w, RecyclerView.z param1z) {
      return q().a(param1z);
    }
    
    public b t(RecyclerView.w param1w, RecyclerView.z param1z, int param1Int, List param1List) {
      return q().a(param1z);
    }
    
    public abstract void u();
    
    public void v(a param1a) {
      this.a = param1a;
    }
    
    public static interface a {
      void a(RecyclerView.z param2z);
    }
    
    public static class b {
      public int a;
      
      public int b;
      
      public int c;
      
      public int d;
      
      public b a(RecyclerView.z param2z) {
        return b(param2z, 0);
      }
      
      public b b(RecyclerView.z param2z, int param2Int) {
        View view = param2z.a;
        this.a = view.getLeft();
        this.b = view.getTop();
        this.c = view.getRight();
        this.d = view.getBottom();
        return this;
      }
    }
  }
  
  public static interface a {
    void a(RecyclerView.z param1z);
  }
  
  public static class b {
    public int a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public b a(RecyclerView.z param1z) {
      return b(param1z, 0);
    }
    
    public b b(RecyclerView.z param1z, int param1Int) {
      View view = param1z.a;
      this.a = view.getLeft();
      this.b = view.getTop();
      this.c = view.getRight();
      this.d = view.getBottom();
      return this;
    }
  }
  
  public class m implements l.a {
    public m(RecyclerView this$0) {}
    
    public void a(RecyclerView.z param1z) {
      param1z.F(true);
      if (param1z.h != null && param1z.i == null)
        param1z.h = null; 
      param1z.i = null;
      if (!param1z.H() && !this.a.S0(param1z.a) && param1z.w())
        this.a.removeDetachedView(param1z.a, false); 
    }
  }
  
  public static abstract class n {
    public void d(Rect param1Rect, int param1Int, RecyclerView param1RecyclerView) {
      param1Rect.set(0, 0, 0, 0);
    }
    
    public void e(Rect param1Rect, View param1View, RecyclerView param1RecyclerView, RecyclerView.w param1w) {
      d(param1Rect, ((RecyclerView.LayoutParams)param1View.getLayoutParams()).a(), param1RecyclerView);
    }
    
    public void f(Canvas param1Canvas, RecyclerView param1RecyclerView) {}
    
    public void g(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.w param1w) {
      f(param1Canvas, param1RecyclerView);
    }
    
    public abstract void h(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.w param1w);
  }
  
  public static abstract class o {
    public b a;
    
    public RecyclerView b;
    
    public final l.b c;
    
    public final l.b d;
    
    public l e;
    
    public l f;
    
    public boolean g;
    
    public boolean h;
    
    public boolean i;
    
    public boolean j;
    
    public boolean k;
    
    public int l;
    
    public boolean m;
    
    public int n;
    
    public int o;
    
    public int p;
    
    public int q;
    
    public o() {
      a a = new a(this);
      this.c = a;
      b b1 = new b(this);
      this.d = b1;
      this.e = new l(a);
      this.f = new l(b1);
      this.g = false;
      this.h = false;
      this.i = false;
      this.j = true;
      this.k = true;
    }
    
    public static int J(int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {
      param1Int1 = Math.max(0, param1Int1 - param1Int3);
      if (param1Boolean) {
        if (param1Int4 >= 0) {
          param1Int2 = 1073741824;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        if (param1Int4 != -1 || (param1Int2 != Integer.MIN_VALUE && (param1Int2 == 0 || param1Int2 != 1073741824))) {
          param1Int2 = 0;
          param1Int4 = param1Int2;
        } 
      } else {
        if (param1Int4 >= 0) {
          param1Int2 = 1073741824;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        if (param1Int4 == -1) {
          param1Int4 = param1Int1;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        if (param1Int4 == -2) {
          if (param1Int2 == Integer.MIN_VALUE || param1Int2 == 1073741824) {
            param1Int2 = Integer.MIN_VALUE;
            param1Int4 = param1Int1;
            return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
          } 
          param1Int2 = 0;
          param1Int4 = param1Int1;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        param1Int2 = 0;
        param1Int4 = param1Int2;
      } 
      param1Int4 = param1Int1;
      return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
    }
    
    public static d g0(Context param1Context, AttributeSet param1AttributeSet, int param1Int1, int param1Int2) {
      d d = new d();
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, t.b.RecyclerView, param1Int1, param1Int2);
      d.a = typedArray.getInt(t.b.RecyclerView_android_orientation, 1);
      d.b = typedArray.getInt(t.b.RecyclerView_spanCount, 1);
      d.c = typedArray.getBoolean(t.b.RecyclerView_reverseLayout, false);
      d.d = typedArray.getBoolean(t.b.RecyclerView_stackFromEnd, false);
      typedArray.recycle();
      return d;
    }
    
    public static int m(int param1Int1, int param1Int2, int param1Int3) {
      int i = View.MeasureSpec.getMode(param1Int1);
      param1Int1 = View.MeasureSpec.getSize(param1Int1);
      if (i != Integer.MIN_VALUE) {
        if (i != 1073741824)
          param1Int1 = Math.max(param1Int2, param1Int3); 
        return param1Int1;
      } 
      return Math.min(param1Int1, Math.max(param1Int2, param1Int3));
    }
    
    public static boolean u0(int param1Int1, int param1Int2, int param1Int3) {
      int i = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      boolean bool1 = false;
      boolean bool2 = false;
      if (param1Int3 > 0 && param1Int1 != param1Int3)
        return false; 
      if (i != Integer.MIN_VALUE) {
        if (i != 0) {
          if (i != 1073741824)
            return false; 
          if (param1Int2 == param1Int1)
            bool2 = true; 
          return bool2;
        } 
        return true;
      } 
      bool2 = bool1;
      if (param1Int2 >= param1Int1)
        bool2 = true; 
      return bool2;
    }
    
    public View A(View param1View) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return null; 
      param1View = recyclerView.R(param1View);
      return (param1View == null) ? null : (this.a.n(param1View) ? null : param1View);
    }
    
    public void A0(int param1Int) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.w0(param1Int); 
    }
    
    public void A1(RecyclerView param1RecyclerView) {
      int i;
      if (param1RecyclerView == null) {
        this.b = null;
        this.a = null;
        i = 0;
        this.p = 0;
      } else {
        this.b = param1RecyclerView;
        this.a = param1RecyclerView.e;
        this.p = param1RecyclerView.getWidth();
        i = param1RecyclerView.getHeight();
      } 
      this.q = i;
      this.n = 1073741824;
      this.o = 1073741824;
    }
    
    public View B(int param1Int) {
      int i = I();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = H(b1);
        RecyclerView.z z = RecyclerView.d0(view);
        if (z != null && z.m() == param1Int && !z.I() && (this.b.f0.e() || !z.u()))
          return view; 
      } 
      return null;
    }
    
    public void B0(int param1Int) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.x0(param1Int); 
    }
    
    public boolean B1(View param1View, int param1Int1, int param1Int2, RecyclerView.LayoutParams param1LayoutParams) {
      return (param1View.isLayoutRequested() || !this.j || !u0(param1View.getWidth(), param1Int1, param1LayoutParams.width) || !u0(param1View.getHeight(), param1Int2, param1LayoutParams.height));
    }
    
    public abstract RecyclerView.LayoutParams C();
    
    public void C0(RecyclerView.g param1g1, RecyclerView.g param1g2) {}
    
    public boolean C1() {
      return false;
    }
    
    public RecyclerView.LayoutParams D(Context param1Context, AttributeSet param1AttributeSet) {
      return new RecyclerView.LayoutParams(param1Context, param1AttributeSet);
    }
    
    public boolean D0(RecyclerView param1RecyclerView, ArrayList param1ArrayList, int param1Int1, int param1Int2) {
      return false;
    }
    
    public boolean D1(View param1View, int param1Int1, int param1Int2, RecyclerView.LayoutParams param1LayoutParams) {
      return (!this.j || !u0(param1View.getMeasuredWidth(), param1Int1, param1LayoutParams.width) || !u0(param1View.getMeasuredHeight(), param1Int2, param1LayoutParams.height));
    }
    
    public RecyclerView.LayoutParams E(ViewGroup.LayoutParams param1LayoutParams) {
      return (param1LayoutParams instanceof RecyclerView.LayoutParams) ? new RecyclerView.LayoutParams((RecyclerView.LayoutParams)param1LayoutParams) : ((param1LayoutParams instanceof ViewGroup.MarginLayoutParams) ? new RecyclerView.LayoutParams((ViewGroup.MarginLayoutParams)param1LayoutParams) : new RecyclerView.LayoutParams(param1LayoutParams));
    }
    
    public void E0(RecyclerView param1RecyclerView) {}
    
    public void E1() {}
    
    public int F() {
      return -1;
    }
    
    public void F0(RecyclerView param1RecyclerView) {}
    
    public abstract boolean F1();
    
    public int G(View param1View) {
      return ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b.bottom;
    }
    
    public void G0(RecyclerView param1RecyclerView, RecyclerView.t param1t) {
      F0(param1RecyclerView);
    }
    
    public View H(int param1Int) {
      b b1 = this.a;
      if (b1 != null) {
        View view = b1.f(param1Int);
      } else {
        b1 = null;
      } 
      return (View)b1;
    }
    
    public abstract View H0(View param1View, int param1Int, RecyclerView.t param1t, RecyclerView.w param1w);
    
    public int I() {
      boolean bool;
      b b1 = this.a;
      if (b1 != null) {
        bool = b1.g();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void I0(AccessibilityEvent param1AccessibilityEvent) {
      RecyclerView recyclerView = this.b;
      J0(recyclerView.b, recyclerView.f0, param1AccessibilityEvent);
    }
    
    public void J0(RecyclerView.t param1t, RecyclerView.w param1w, AccessibilityEvent param1AccessibilityEvent) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null && param1AccessibilityEvent != null) {
        boolean bool1 = true;
        boolean bool2 = bool1;
        if (!recyclerView.canScrollVertically(1)) {
          bool2 = bool1;
          if (!this.b.canScrollVertically(-1)) {
            bool2 = bool1;
            if (!this.b.canScrollHorizontally(-1))
              if (this.b.canScrollHorizontally(1)) {
                bool2 = bool1;
              } else {
                bool2 = false;
              }  
          } 
        } 
        param1AccessibilityEvent.setScrollable(bool2);
        RecyclerView.g g = this.b.l;
        if (g != null)
          param1AccessibilityEvent.setItemCount(g.c()); 
      } 
    }
    
    public final int[] K(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean) {
      int i = c0();
      int j = e0();
      int k = m0();
      int m = d0();
      int n = V();
      int i1 = b0();
      int i2 = param1View.getLeft() + param1Rect.left - param1View.getScrollX();
      int i3 = param1View.getTop() + param1Rect.top - param1View.getScrollY();
      int i4 = param1Rect.width();
      int i5 = param1Rect.height();
      int i6 = i2 - i;
      i = Math.min(0, i6);
      int i7 = i3 - j;
      j = Math.min(0, i7);
      m = i4 + i2 - k - m;
      i2 = Math.max(0, m);
      i3 = Math.max(0, i5 + i3 - n - i1);
      if (X() == 1) {
        if (i2 != 0) {
          i = i2;
        } else {
          i = Math.max(i, m);
        } 
      } else if (i == 0) {
        i = Math.min(i6, i2);
      } 
      if (j == 0)
        j = Math.min(i7, i3); 
      return new int[] { i, j };
    }
    
    public void K0(RecyclerView.t param1t, RecyclerView.w param1w, o.n param1n) {
      if (this.b.canScrollVertically(-1) || this.b.canScrollHorizontally(-1)) {
        param1n.a(8192);
        param1n.O(true);
      } 
      if (this.b.canScrollVertically(1) || this.b.canScrollHorizontally(1)) {
        param1n.a(4096);
        param1n.O(true);
      } 
      param1n.J(o.n.b.a(i0(param1t, param1w), M(param1t, param1w), t0(param1t, param1w), j0(param1t, param1w)));
    }
    
    public boolean L() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null && recyclerView.g) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void L0(o.n param1n) {
      RecyclerView recyclerView = this.b;
      K0(recyclerView.b, recyclerView.f0, param1n);
    }
    
    public int M(RecyclerView.t param1t, RecyclerView.w param1w) {
      RecyclerView recyclerView = this.b;
      byte b1 = 1;
      int i = b1;
      if (recyclerView != null)
        if (recyclerView.l == null) {
          i = b1;
        } else {
          i = b1;
          if (j())
            i = this.b.l.c(); 
        }  
      return i;
    }
    
    public void M0(View param1View, o.n param1n) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z != null && !z.u() && !this.a.n(z.a)) {
        RecyclerView recyclerView = this.b;
        N0(recyclerView.b, recyclerView.f0, param1View, param1n);
      } 
    }
    
    public int N(View param1View) {
      return param1View.getBottom() + G(param1View);
    }
    
    public void N0(RecyclerView.t param1t, RecyclerView.w param1w, View param1View, o.n param1n) {
      boolean bool1;
      boolean bool = k();
      int i = 0;
      if (bool) {
        bool1 = f0(param1View);
      } else {
        bool1 = false;
      } 
      if (j())
        i = f0(param1View); 
      param1n.K(o.n.c.a(bool1, 1, i, 1, false, false));
    }
    
    public void O(View param1View, Rect param1Rect) {
      RecyclerView.e0(param1View, param1Rect);
    }
    
    public View O0(View param1View, int param1Int) {
      return null;
    }
    
    public int P(View param1View) {
      return param1View.getLeft() - Y(param1View);
    }
    
    public void P0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public int Q(View param1View) {
      Rect rect = ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b;
      return param1View.getMeasuredHeight() + rect.top + rect.bottom;
    }
    
    public void Q0(RecyclerView param1RecyclerView) {}
    
    public int R(View param1View) {
      Rect rect = ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b;
      return param1View.getMeasuredWidth() + rect.left + rect.right;
    }
    
    public void R0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public int S(View param1View) {
      return param1View.getRight() + h0(param1View);
    }
    
    public void S0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public int T(View param1View) {
      return param1View.getTop() - k0(param1View);
    }
    
    public void T0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public View U() {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return null; 
      View view = recyclerView.getFocusedChild();
      return (view == null || this.a.n(view)) ? null : view;
    }
    
    public void U0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2, Object param1Object) {
      T0(param1RecyclerView, param1Int1, param1Int2);
    }
    
    public int V() {
      return this.q;
    }
    
    public abstract void V0(RecyclerView.t param1t, RecyclerView.w param1w);
    
    public int W() {
      return this.o;
    }
    
    public void W0(RecyclerView.w param1w) {}
    
    public int X() {
      return n.j.k((View)this.b);
    }
    
    public void X0(RecyclerView.t param1t, RecyclerView.w param1w, int param1Int1, int param1Int2) {
      this.b.v(param1Int1, param1Int2);
    }
    
    public int Y(View param1View) {
      return ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b.left;
    }
    
    public boolean Y0(RecyclerView param1RecyclerView, View param1View1, View param1View2) {
      return (v0() || param1RecyclerView.s0());
    }
    
    public int Z() {
      return n.j.l((View)this.b);
    }
    
    public boolean Z0(RecyclerView param1RecyclerView, RecyclerView.w param1w, View param1View1, View param1View2) {
      return Y0(param1RecyclerView, param1View1, param1View2);
    }
    
    public void a(View param1View) {
      b(param1View, -1);
    }
    
    public int a0() {
      return n.j.m((View)this.b);
    }
    
    public abstract void a1(Parcelable param1Parcelable);
    
    public void b(View param1View, int param1Int) {
      e(param1View, param1Int, true);
    }
    
    public int b0() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingBottom();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public abstract Parcelable b1();
    
    public void c(View param1View) {
      d(param1View, -1);
    }
    
    public int c0() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingLeft();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void c1(int param1Int) {}
    
    public void d(View param1View, int param1Int) {
      e(param1View, param1Int, false);
    }
    
    public int d0() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingRight();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean d1(int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      return e1(recyclerView.b, recyclerView.f0, param1Int, param1Bundle);
    }
    
    public final void e(View param1View, int param1Int, boolean param1Boolean) {
      StringBuilder stringBuilder;
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (param1Boolean || z.u()) {
        this.b.f.b(z);
      } else {
        this.b.f.p(z);
      } 
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      if (z.K() || z.v()) {
        if (z.v()) {
          z.J();
        } else {
          z.e();
        } 
        this.a.c(param1View, param1Int, param1View.getLayoutParams(), false);
      } else if (param1View.getParent() == this.b) {
        int i = this.a.m(param1View);
        int j = param1Int;
        if (param1Int == -1)
          j = this.a.g(); 
        if (i != -1) {
          if (i != j)
            this.b.m.z0(i, j); 
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
          stringBuilder.append(this.b.indexOfChild(param1View));
          stringBuilder.append(this.b.P());
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } else {
        this.a.a(param1View, param1Int, false);
        ((RecyclerView.LayoutParams)stringBuilder).c = true;
      } 
      if (((RecyclerView.LayoutParams)stringBuilder).d) {
        z.a.invalidate();
        ((RecyclerView.LayoutParams)stringBuilder).d = false;
      } 
    }
    
    public int e0() {
      boolean bool;
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        bool = recyclerView.getPaddingTop();
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean e1(RecyclerView.t param1t, RecyclerView.w param1w, int param1Int, Bundle param1Bundle) {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   4: astore_1
      //   5: aload_1
      //   6: ifnonnull -> 11
      //   9: iconst_0
      //   10: ireturn
      //   11: iload_3
      //   12: sipush #4096
      //   15: if_icmpeq -> 96
      //   18: iload_3
      //   19: sipush #8192
      //   22: if_icmpeq -> 33
      //   25: iconst_0
      //   26: istore_3
      //   27: iload_3
      //   28: istore #5
      //   30: goto -> 163
      //   33: aload_1
      //   34: iconst_m1
      //   35: invokevirtual canScrollVertically : (I)Z
      //   38: ifeq -> 60
      //   41: aload_0
      //   42: invokevirtual V : ()I
      //   45: aload_0
      //   46: invokevirtual e0 : ()I
      //   49: isub
      //   50: aload_0
      //   51: invokevirtual b0 : ()I
      //   54: isub
      //   55: ineg
      //   56: istore_3
      //   57: goto -> 62
      //   60: iconst_0
      //   61: istore_3
      //   62: iload_3
      //   63: istore #6
      //   65: aload_0
      //   66: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   69: iconst_m1
      //   70: invokevirtual canScrollHorizontally : (I)Z
      //   73: ifeq -> 157
      //   76: aload_0
      //   77: invokevirtual m0 : ()I
      //   80: aload_0
      //   81: invokevirtual c0 : ()I
      //   84: isub
      //   85: aload_0
      //   86: invokevirtual d0 : ()I
      //   89: isub
      //   90: ineg
      //   91: istore #5
      //   93: goto -> 163
      //   96: aload_1
      //   97: iconst_1
      //   98: invokevirtual canScrollVertically : (I)Z
      //   101: ifeq -> 122
      //   104: aload_0
      //   105: invokevirtual V : ()I
      //   108: aload_0
      //   109: invokevirtual e0 : ()I
      //   112: isub
      //   113: aload_0
      //   114: invokevirtual b0 : ()I
      //   117: isub
      //   118: istore_3
      //   119: goto -> 124
      //   122: iconst_0
      //   123: istore_3
      //   124: iload_3
      //   125: istore #6
      //   127: aload_0
      //   128: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   131: iconst_1
      //   132: invokevirtual canScrollHorizontally : (I)Z
      //   135: ifeq -> 157
      //   138: aload_0
      //   139: invokevirtual m0 : ()I
      //   142: aload_0
      //   143: invokevirtual c0 : ()I
      //   146: isub
      //   147: aload_0
      //   148: invokevirtual d0 : ()I
      //   151: isub
      //   152: istore #5
      //   154: goto -> 163
      //   157: iconst_0
      //   158: istore #5
      //   160: iload #6
      //   162: istore_3
      //   163: iload_3
      //   164: ifne -> 174
      //   167: iload #5
      //   169: ifne -> 174
      //   172: iconst_0
      //   173: ireturn
      //   174: aload_0
      //   175: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   178: iload #5
      //   180: iload_3
      //   181: invokevirtual h1 : (II)V
      //   184: iconst_1
      //   185: ireturn
    }
    
    public void f(String param1String) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.n(param1String); 
    }
    
    public int f0(View param1View) {
      return ((RecyclerView.LayoutParams)param1View.getLayoutParams()).a();
    }
    
    public boolean f1(View param1View, int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      return g1(recyclerView.b, recyclerView.f0, param1View, param1Int, param1Bundle);
    }
    
    public void g(View param1View, int param1Int) {
      h(param1View, param1Int, (RecyclerView.LayoutParams)param1View.getLayoutParams());
    }
    
    public boolean g1(RecyclerView.t param1t, RecyclerView.w param1w, View param1View, int param1Int, Bundle param1Bundle) {
      return false;
    }
    
    public void h(View param1View, int param1Int, RecyclerView.LayoutParams param1LayoutParams) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z.u()) {
        this.b.f.b(z);
      } else {
        this.b.f.p(z);
      } 
      this.a.c(param1View, param1Int, (ViewGroup.LayoutParams)param1LayoutParams, z.u());
    }
    
    public int h0(View param1View) {
      return ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b.right;
    }
    
    public void h1(RecyclerView.t param1t) {
      for (int i = I() - 1; i >= 0; i--) {
        if (!RecyclerView.d0(H(i)).I())
          k1(i, param1t); 
      } 
    }
    
    public void i(View param1View, Rect param1Rect) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null) {
        param1Rect.set(0, 0, 0, 0);
        return;
      } 
      param1Rect.set(recyclerView.h0(param1View));
    }
    
    public int i0(RecyclerView.t param1t, RecyclerView.w param1w) {
      RecyclerView recyclerView = this.b;
      byte b1 = 1;
      int i = b1;
      if (recyclerView != null)
        if (recyclerView.l == null) {
          i = b1;
        } else {
          i = b1;
          if (k())
            i = this.b.l.c(); 
        }  
      return i;
    }
    
    public void i1(RecyclerView.t param1t) {
      int i = param1t.j();
      for (int j = i - 1; j >= 0; j--) {
        View view = param1t.n(j);
        RecyclerView.z z = RecyclerView.d0(view);
        if (!z.I()) {
          z.F(false);
          if (z.w())
            this.b.removeDetachedView(view, false); 
          RecyclerView.l l1 = this.b.L;
          if (l1 != null)
            l1.j(z); 
          z.F(true);
          param1t.y(view);
        } 
      } 
      param1t.e();
      if (i > 0)
        this.b.invalidate(); 
    }
    
    public abstract boolean j();
    
    public int j0(RecyclerView.t param1t, RecyclerView.w param1w) {
      return 0;
    }
    
    public void j1(View param1View, RecyclerView.t param1t) {
      m1(param1View);
      param1t.B(param1View);
    }
    
    public abstract boolean k();
    
    public int k0(View param1View) {
      return ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b.top;
    }
    
    public void k1(int param1Int, RecyclerView.t param1t) {
      View view = H(param1Int);
      n1(param1Int);
      param1t.B(view);
    }
    
    public boolean l(RecyclerView.LayoutParams param1LayoutParams) {
      boolean bool;
      if (param1LayoutParams != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void l0(View param1View, boolean param1Boolean, Rect param1Rect) {
      if (param1Boolean) {
        Rect rect = ((RecyclerView.LayoutParams)param1View.getLayoutParams()).b;
        param1Rect.set(-rect.left, -rect.top, param1View.getWidth() + rect.right, param1View.getHeight() + rect.bottom);
      } else {
        param1Rect.set(0, 0, param1View.getWidth(), param1View.getHeight());
      } 
      if (this.b != null) {
        Matrix matrix = param1View.getMatrix();
        if (matrix != null && !matrix.isIdentity()) {
          RectF rectF = this.b.k;
          rectF.set(param1Rect);
          matrix.mapRect(rectF);
          param1Rect.set((int)Math.floor(rectF.left), (int)Math.floor(rectF.top), (int)Math.ceil(rectF.right), (int)Math.ceil(rectF.bottom));
        } 
      } 
      param1Rect.offset(param1View.getLeft(), param1View.getTop());
    }
    
    public boolean l1(Runnable param1Runnable) {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.removeCallbacks(param1Runnable) : false;
    }
    
    public int m0() {
      return this.p;
    }
    
    public void m1(View param1View) {
      this.a.p(param1View);
    }
    
    public abstract void n(int param1Int1, int param1Int2, RecyclerView.w param1w, c param1c);
    
    public int n0() {
      return this.n;
    }
    
    public void n1(int param1Int) {
      if (H(param1Int) != null)
        this.a.q(param1Int); 
    }
    
    public void o(int param1Int, c param1c) {}
    
    public boolean o0() {
      int i = I();
      for (byte b1 = 0; b1 < i; b1++) {
        ViewGroup.LayoutParams layoutParams = H(b1).getLayoutParams();
        if (layoutParams.width < 0 && layoutParams.height < 0)
          return true; 
      } 
      return false;
    }
    
    public boolean o1(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean) {
      return p1(param1RecyclerView, param1View, param1Rect, param1Boolean, false);
    }
    
    public abstract int p(RecyclerView.w param1w);
    
    public boolean p0() {
      return this.h;
    }
    
    public boolean p1(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean1, boolean param1Boolean2) {
      int[] arrayOfInt = K(param1RecyclerView, param1View, param1Rect, param1Boolean1);
      int i = arrayOfInt[0];
      int j = arrayOfInt[1];
      if ((!param1Boolean2 || r0(param1RecyclerView, i, j)) && (i != 0 || j != 0)) {
        if (param1Boolean1) {
          param1RecyclerView.scrollBy(i, j);
        } else {
          param1RecyclerView.h1(i, j);
        } 
        return true;
      } 
      return false;
    }
    
    public abstract int q(RecyclerView.w param1w);
    
    public abstract boolean q0();
    
    public void q1() {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.requestLayout(); 
    }
    
    public abstract int r(RecyclerView.w param1w);
    
    public final boolean r0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      View view = param1RecyclerView.getFocusedChild();
      if (view == null)
        return false; 
      int i = c0();
      int j = e0();
      int k = m0();
      int m = d0();
      int n = V();
      int i1 = b0();
      Rect rect = this.b.i;
      O(view, rect);
      return !(rect.left - param1Int1 >= k - m || rect.right - param1Int1 <= i || rect.top - param1Int2 >= n - i1 || rect.bottom - param1Int2 <= j);
    }
    
    public void r1() {
      this.g = true;
    }
    
    public abstract int s(RecyclerView.w param1w);
    
    public final boolean s0() {
      return this.k;
    }
    
    public final void s1(RecyclerView.t param1t, int param1Int, View param1View) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z.I())
        return; 
      if (z.s() && !z.u() && !this.b.l.f()) {
        n1(param1Int);
        param1t.C(z);
      } else {
        w(param1Int);
        param1t.D(param1View);
        this.b.f.k(z);
      } 
    }
    
    public abstract int t(RecyclerView.w param1w);
    
    public boolean t0(RecyclerView.t param1t, RecyclerView.w param1w) {
      return false;
    }
    
    public abstract int t1(int param1Int, RecyclerView.t param1t, RecyclerView.w param1w);
    
    public abstract int u(RecyclerView.w param1w);
    
    public abstract int u1(int param1Int, RecyclerView.t param1t, RecyclerView.w param1w);
    
    public void v(RecyclerView.t param1t) {
      for (int i = I() - 1; i >= 0; i--)
        s1(param1t, i, H(i)); 
    }
    
    public boolean v0() {
      return false;
    }
    
    public void v1(RecyclerView param1RecyclerView) {
      w1(View.MeasureSpec.makeMeasureSpec(param1RecyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(param1RecyclerView.getHeight(), 1073741824));
    }
    
    public void w(int param1Int) {
      x(param1Int, H(param1Int));
    }
    
    public boolean w0(View param1View, boolean param1Boolean1, boolean param1Boolean2) {
      if (this.e.b(param1View, 24579) && this.f.b(param1View, 24579)) {
        param1Boolean2 = true;
      } else {
        param1Boolean2 = false;
      } 
      return param1Boolean1 ? param1Boolean2 : (param1Boolean2 ^ true);
    }
    
    public void w1(int param1Int1, int param1Int2) {
      this.p = View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int1);
      this.n = param1Int1;
      if (param1Int1 == 0 && !RecyclerView.z0)
        this.p = 0; 
      this.q = View.MeasureSpec.getSize(param1Int2);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      this.o = param1Int1;
      if (param1Int1 == 0 && !RecyclerView.z0)
        this.q = 0; 
    }
    
    public final void x(int param1Int, View param1View) {
      this.a.d(param1Int);
    }
    
    public void x0(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      Rect rect = layoutParams.b;
      param1View.layout(param1Int1 + rect.left + layoutParams.leftMargin, param1Int2 + rect.top + layoutParams.topMargin, param1Int3 - rect.right - layoutParams.rightMargin, param1Int4 - rect.bottom - layoutParams.bottomMargin);
    }
    
    public void x1(int param1Int1, int param1Int2) {
      RecyclerView.e(this.b, param1Int1, param1Int2);
    }
    
    public void y(RecyclerView param1RecyclerView) {
      this.h = true;
      E0(param1RecyclerView);
    }
    
    public void y0(View param1View, int param1Int1, int param1Int2) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      Rect rect = this.b.h0(param1View);
      int i = rect.left;
      int j = rect.right;
      int k = rect.top;
      int m = rect.bottom;
      param1Int1 = J(m0(), n0(), c0() + d0() + layoutParams.leftMargin + layoutParams.rightMargin + param1Int1 + i + j, layoutParams.width, j());
      param1Int2 = J(V(), W(), e0() + b0() + layoutParams.topMargin + layoutParams.bottomMargin + param1Int2 + k + m, layoutParams.height, k());
      if (B1(param1View, param1Int1, param1Int2, layoutParams))
        param1View.measure(param1Int1, param1Int2); 
    }
    
    public void y1(Rect param1Rect, int param1Int1, int param1Int2) {
      int i = param1Rect.width();
      int j = c0();
      int k = d0();
      int m = param1Rect.height();
      int n = e0();
      int i1 = b0();
      x1(m(param1Int1, i + j + k, a0()), m(param1Int2, m + n + i1, Z()));
    }
    
    public void z(RecyclerView param1RecyclerView, RecyclerView.t param1t) {
      this.h = false;
      G0(param1RecyclerView, param1t);
    }
    
    public void z0(int param1Int1, int param1Int2) {
      View view = H(param1Int1);
      if (view != null) {
        w(param1Int1);
        g(view, param1Int2);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot move a child from non-existing index:");
      stringBuilder.append(param1Int1);
      stringBuilder.append(this.b.toString());
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public void z1(int param1Int1, int param1Int2) {
      int i = I();
      if (i == 0) {
        this.b.v(param1Int1, param1Int2);
        return;
      } 
      int j = Integer.MIN_VALUE;
      int k = Integer.MAX_VALUE;
      byte b1 = 0;
      int m = Integer.MIN_VALUE;
      int n = k;
      while (b1 < i) {
        View view = H(b1);
        Rect rect = this.b.i;
        O(view, rect);
        int i1 = rect.left;
        int i2 = n;
        if (i1 < n)
          i2 = i1; 
        i1 = rect.right;
        n = j;
        if (i1 > j)
          n = i1; 
        j = rect.top;
        i1 = k;
        if (j < k)
          i1 = j; 
        j = rect.bottom;
        k = m;
        if (j > m)
          k = j; 
        b1++;
        j = n;
        m = k;
        n = i2;
        k = i1;
      } 
      this.b.i.set(n, k, j, m);
      y1(this.b.i, param1Int1, param1Int2);
    }
    
    public class a implements l.b {
      public a(RecyclerView.o this$0) {}
      
      public View a(int param2Int) {
        return this.a.H(param2Int);
      }
      
      public int b() {
        return this.a.m0() - this.a.d0();
      }
      
      public int c(View param2View) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param2View.getLayoutParams();
        return this.a.P(param2View) - layoutParams.leftMargin;
      }
      
      public int d() {
        return this.a.c0();
      }
      
      public int e(View param2View) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param2View.getLayoutParams();
        return this.a.S(param2View) + layoutParams.rightMargin;
      }
    }
    
    public class b implements l.b {
      public b(RecyclerView.o this$0) {}
      
      public View a(int param2Int) {
        return this.a.H(param2Int);
      }
      
      public int b() {
        return this.a.V() - this.a.b0();
      }
      
      public int c(View param2View) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param2View.getLayoutParams();
        return this.a.T(param2View) - layoutParams.topMargin;
      }
      
      public int d() {
        return this.a.e0();
      }
      
      public int e(View param2View) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param2View.getLayoutParams();
        return this.a.N(param2View) + layoutParams.bottomMargin;
      }
    }
    
    public static interface c {
      void a(int param2Int1, int param2Int2);
    }
    
    public static class d {
      public int a;
      
      public int b;
      
      public boolean c;
      
      public boolean d;
    }
  }
  
  public class a implements l.b {
    public a(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.H(param1Int);
    }
    
    public int b() {
      return this.a.m0() - this.a.d0();
    }
    
    public int c(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.P(param1View) - layoutParams.leftMargin;
    }
    
    public int d() {
      return this.a.c0();
    }
    
    public int e(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.S(param1View) + layoutParams.rightMargin;
    }
  }
  
  public class b implements l.b {
    public b(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.H(param1Int);
    }
    
    public int b() {
      return this.a.V() - this.a.b0();
    }
    
    public int c(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.T(param1View) - layoutParams.topMargin;
    }
    
    public int d() {
      return this.a.e0();
    }
    
    public int e(View param1View) {
      RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)param1View.getLayoutParams();
      return this.a.N(param1View) + layoutParams.bottomMargin;
    }
  }
  
  public static interface c {
    void a(int param1Int1, int param1Int2);
  }
  
  public static class d {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static abstract class p {}
  
  public static interface q {
    boolean a(RecyclerView param1RecyclerView, MotionEvent param1MotionEvent);
    
    void b(RecyclerView param1RecyclerView, MotionEvent param1MotionEvent);
    
    void c(boolean param1Boolean);
  }
  
  public static abstract class r {
    public void a(RecyclerView param1RecyclerView, int param1Int) {}
    
    public abstract void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2);
  }
  
  public static class s {
    public SparseArray a = new SparseArray();
    
    public int b = 0;
    
    public void a() {
      this.b++;
    }
    
    public void b() {
      for (byte b = 0; b < this.a.size(); b++)
        ((a)this.a.valueAt(b)).a.clear(); 
    }
    
    public void c() {
      this.b--;
    }
    
    public void d(int param1Int, long param1Long) {
      a a = g(param1Int);
      a.d = j(a.d, param1Long);
    }
    
    public void e(int param1Int, long param1Long) {
      a a = g(param1Int);
      a.c = j(a.c, param1Long);
    }
    
    public RecyclerView.z f(int param1Int) {
      a a = (a)this.a.get(param1Int);
      if (a != null && !a.a.isEmpty()) {
        ArrayList<RecyclerView.z> arrayList = a.a;
        return arrayList.remove(arrayList.size() - 1);
      } 
      return null;
    }
    
    public final a g(int param1Int) {
      a a1 = (a)this.a.get(param1Int);
      a a2 = a1;
      if (a1 == null) {
        a2 = new a();
        this.a.put(param1Int, a2);
      } 
      return a2;
    }
    
    public void h(RecyclerView.g param1g1, RecyclerView.g param1g2, boolean param1Boolean) {
      if (param1g1 != null)
        c(); 
      if (!param1Boolean && this.b == 0)
        b(); 
      if (param1g2 != null)
        a(); 
    }
    
    public void i(RecyclerView.z param1z) {
      int i = param1z.l();
      ArrayList<RecyclerView.z> arrayList = (g(i)).a;
      if (((a)this.a.get(i)).b <= arrayList.size())
        return; 
      param1z.C();
      arrayList.add(param1z);
    }
    
    public long j(long param1Long1, long param1Long2) {
      return (param1Long1 == 0L) ? param1Long2 : (param1Long1 / 4L * 3L + param1Long2 / 4L);
    }
    
    public boolean k(int param1Int, long param1Long1, long param1Long2) {
      long l = (g(param1Int)).d;
      return (l == 0L || param1Long1 + l < param1Long2);
    }
    
    public boolean l(int param1Int, long param1Long1, long param1Long2) {
      long l = (g(param1Int)).c;
      return (l == 0L || param1Long1 + l < param1Long2);
    }
    
    public static class a {
      public final ArrayList a = new ArrayList();
      
      public int b = 5;
      
      public long c = 0L;
      
      public long d = 0L;
    }
  }
  
  public static class a {
    public final ArrayList a = new ArrayList();
    
    public int b = 5;
    
    public long c = 0L;
    
    public long d = 0L;
  }
  
  public final class t {
    public final ArrayList a;
    
    public ArrayList b;
    
    public final ArrayList c;
    
    public final List d;
    
    public int e;
    
    public int f;
    
    public RecyclerView.s g;
    
    public t(RecyclerView this$0) {
      ArrayList<?> arrayList = new ArrayList();
      this.a = arrayList;
      this.b = null;
      this.c = new ArrayList();
      this.d = Collections.unmodifiableList(arrayList);
      this.e = 2;
      this.f = 2;
    }
    
    public void A(int param1Int) {
      a(this.c.get(param1Int), true);
      this.c.remove(param1Int);
    }
    
    public void B(View param1View) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z.w())
        this.h.removeDetachedView(param1View, false); 
      if (z.v()) {
        z.J();
      } else if (z.K()) {
        z.e();
      } 
      C(z);
    }
    
    public void C(RecyclerView.z param1z) {
      StringBuilder stringBuilder1;
      boolean bool1 = param1z.v();
      boolean bool2 = false;
      int i = 0;
      boolean bool = true;
      if (bool1 || param1z.a.getParent() != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scrapped or attached views may not be recycled. isScrap:");
        stringBuilder.append(param1z.v());
        stringBuilder.append(" isAttached:");
        if (param1z.a.getParent() != null)
          bool2 = true; 
        stringBuilder.append(bool2);
        stringBuilder.append(this.h.P());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (!param1z.w()) {
        if (!param1z.I()) {
          int j;
          bool2 = param1z.h();
          RecyclerView.g g = this.h.l;
          if (g != null && bool2 && g.m(param1z)) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j || param1z.t()) {
            if (this.f > 0 && !param1z.p(526)) {
              i = this.c.size();
              j = i;
              if (i >= this.f) {
                j = i;
                if (i > 0) {
                  A(0);
                  j = i - 1;
                } 
              } 
              i = j;
              if (RecyclerView.B0) {
                i = j;
                if (j > 0) {
                  i = j;
                  if (!this.h.e0.d(param1z.c)) {
                    while (--j >= 0) {
                      i = ((RecyclerView.z)this.c.get(j)).c;
                      if (!this.h.e0.d(i))
                        break; 
                      j--;
                    } 
                    i = j + 1;
                  } 
                } 
              } 
              this.c.add(i, param1z);
              j = 1;
            } else {
              j = 0;
            } 
            if (j == 0) {
              a(param1z, true);
              i = bool;
            } else {
              i = 0;
            } 
          } else {
            bool = false;
            j = i;
            i = bool;
          } 
          this.h.f.q(param1z);
          if (j == 0 && i == 0 && bool2)
            param1z.r = null; 
          return;
        } 
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.");
        stringBuilder1.append(this.h.P());
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
      stringBuilder2.append(stringBuilder1);
      stringBuilder2.append(this.h.P());
      throw new IllegalArgumentException(stringBuilder2.toString());
    }
    
    public void D(View param1View) {
      ArrayList<RecyclerView.z> arrayList;
      RecyclerView.z z = RecyclerView.d0(param1View);
      if (z.p(12) || !z.x() || this.h.o(z)) {
        if (!z.s() || z.u() || this.h.l.f()) {
          z.G(this, false);
          arrayList = this.a;
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
          stringBuilder.append(this.h.P());
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        if (this.b == null)
          this.b = new ArrayList(); 
        z.G(this, true);
        arrayList = this.b;
      } 
      arrayList.add(z);
    }
    
    public void E(RecyclerView.s param1s) {
      RecyclerView.s s1 = this.g;
      if (s1 != null)
        s1.c(); 
      this.g = param1s;
      if (param1s != null && this.h.getAdapter() != null)
        this.g.a(); 
    }
    
    public void F(RecyclerView.x param1x) {}
    
    public void G(int param1Int) {
      this.e = param1Int;
      K();
    }
    
    public final boolean H(RecyclerView.z param1z, int param1Int1, int param1Int2, long param1Long) {
      param1z.r = this.h;
      int i = param1z.l();
      long l = this.h.getNanoTime();
      if (param1Long != Long.MAX_VALUE && !this.g.k(i, l, param1Long))
        return false; 
      this.h.l.a(param1z, param1Int1);
      param1Long = this.h.getNanoTime();
      this.g.d(param1z.l(), param1Long - l);
      b(param1z);
      if (this.h.f0.e())
        param1z.g = param1Int2; 
      return true;
    }
    
    public RecyclerView.z I(int param1Int, boolean param1Boolean, long param1Long) {
      // Byte code:
      //   0: iload_1
      //   1: iflt -> 892
      //   4: iload_1
      //   5: aload_0
      //   6: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   9: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   12: invokevirtual b : ()I
      //   15: if_icmpge -> 892
      //   18: aload_0
      //   19: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   22: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   25: invokevirtual e : ()Z
      //   28: istore #5
      //   30: iconst_1
      //   31: istore #6
      //   33: iload #5
      //   35: ifeq -> 64
      //   38: aload_0
      //   39: iload_1
      //   40: invokevirtual h : (I)Landroidx/recyclerview/widget/RecyclerView$z;
      //   43: astore #7
      //   45: aload #7
      //   47: astore #8
      //   49: aload #7
      //   51: ifnull -> 67
      //   54: iconst_1
      //   55: istore #9
      //   57: aload #7
      //   59: astore #8
      //   61: goto -> 70
      //   64: aconst_null
      //   65: astore #8
      //   67: iconst_0
      //   68: istore #9
      //   70: aload #8
      //   72: astore #7
      //   74: iload #9
      //   76: istore #10
      //   78: aload #8
      //   80: ifnonnull -> 188
      //   83: aload_0
      //   84: iload_1
      //   85: iload_2
      //   86: invokevirtual m : (IZ)Landroidx/recyclerview/widget/RecyclerView$z;
      //   89: astore #8
      //   91: aload #8
      //   93: astore #7
      //   95: iload #9
      //   97: istore #10
      //   99: aload #8
      //   101: ifnull -> 188
      //   104: aload_0
      //   105: aload #8
      //   107: invokevirtual L : (Landroidx/recyclerview/widget/RecyclerView$z;)Z
      //   110: ifne -> 181
      //   113: iload_2
      //   114: ifne -> 171
      //   117: aload #8
      //   119: iconst_4
      //   120: invokevirtual b : (I)V
      //   123: aload #8
      //   125: invokevirtual v : ()Z
      //   128: ifeq -> 152
      //   131: aload_0
      //   132: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   135: aload #8
      //   137: getfield a : Landroid/view/View;
      //   140: iconst_0
      //   141: invokevirtual removeDetachedView : (Landroid/view/View;Z)V
      //   144: aload #8
      //   146: invokevirtual J : ()V
      //   149: goto -> 165
      //   152: aload #8
      //   154: invokevirtual K : ()Z
      //   157: ifeq -> 165
      //   160: aload #8
      //   162: invokevirtual e : ()V
      //   165: aload_0
      //   166: aload #8
      //   168: invokevirtual C : (Landroidx/recyclerview/widget/RecyclerView$z;)V
      //   171: aconst_null
      //   172: astore #7
      //   174: iload #9
      //   176: istore #10
      //   178: goto -> 188
      //   181: iconst_1
      //   182: istore #10
      //   184: aload #8
      //   186: astore #7
      //   188: aload #7
      //   190: astore #8
      //   192: iload #10
      //   194: istore #11
      //   196: aload #7
      //   198: ifnonnull -> 589
      //   201: aload_0
      //   202: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   205: getfield d : Landroidx/recyclerview/widget/a;
      //   208: iload_1
      //   209: invokevirtual m : (I)I
      //   212: istore #11
      //   214: iload #11
      //   216: iflt -> 487
      //   219: iload #11
      //   221: aload_0
      //   222: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   225: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
      //   228: invokevirtual c : ()I
      //   231: if_icmpge -> 487
      //   234: aload_0
      //   235: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   238: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
      //   241: iload #11
      //   243: invokevirtual e : (I)I
      //   246: istore #12
      //   248: aload #7
      //   250: astore #8
      //   252: iload #10
      //   254: istore #9
      //   256: aload_0
      //   257: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   260: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
      //   263: invokevirtual f : ()Z
      //   266: ifeq -> 317
      //   269: aload_0
      //   270: aload_0
      //   271: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   274: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
      //   277: iload #11
      //   279: invokevirtual d : (I)J
      //   282: iload #12
      //   284: iload_2
      //   285: invokevirtual l : (JIZ)Landroidx/recyclerview/widget/RecyclerView$z;
      //   288: astore #7
      //   290: aload #7
      //   292: astore #8
      //   294: iload #10
      //   296: istore #9
      //   298: aload #7
      //   300: ifnull -> 317
      //   303: aload #7
      //   305: iload #11
      //   307: putfield c : I
      //   310: iconst_1
      //   311: istore #9
      //   313: aload #7
      //   315: astore #8
      //   317: aload #8
      //   319: astore #7
      //   321: aload #8
      //   323: ifnonnull -> 359
      //   326: aload_0
      //   327: invokevirtual i : ()Landroidx/recyclerview/widget/RecyclerView$s;
      //   330: iload #12
      //   332: invokevirtual f : (I)Landroidx/recyclerview/widget/RecyclerView$z;
      //   335: astore #7
      //   337: aload #7
      //   339: ifnull -> 359
      //   342: aload #7
      //   344: invokevirtual C : ()V
      //   347: getstatic androidx/recyclerview/widget/RecyclerView.y0 : Z
      //   350: ifeq -> 359
      //   353: aload_0
      //   354: aload #7
      //   356: invokevirtual r : (Landroidx/recyclerview/widget/RecyclerView$z;)V
      //   359: aload #7
      //   361: astore #8
      //   363: iload #9
      //   365: istore #11
      //   367: aload #7
      //   369: ifnonnull -> 589
      //   372: aload_0
      //   373: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   376: invokevirtual getNanoTime : ()J
      //   379: lstore #13
      //   381: lload_3
      //   382: ldc2_w 9223372036854775807
      //   385: lcmp
      //   386: ifeq -> 406
      //   389: aload_0
      //   390: getfield g : Landroidx/recyclerview/widget/RecyclerView$s;
      //   393: iload #12
      //   395: lload #13
      //   397: lload_3
      //   398: invokevirtual l : (IJJ)Z
      //   401: ifne -> 406
      //   404: aconst_null
      //   405: areturn
      //   406: aload_0
      //   407: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   410: astore #7
      //   412: aload #7
      //   414: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
      //   417: aload #7
      //   419: iload #12
      //   421: invokevirtual b : (Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$z;
      //   424: astore #7
      //   426: getstatic androidx/recyclerview/widget/RecyclerView.B0 : Z
      //   429: ifeq -> 461
      //   432: aload #7
      //   434: getfield a : Landroid/view/View;
      //   437: invokestatic U : (Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView;
      //   440: astore #8
      //   442: aload #8
      //   444: ifnull -> 461
      //   447: aload #7
      //   449: new java/lang/ref/WeakReference
      //   452: dup
      //   453: aload #8
      //   455: invokespecial <init> : (Ljava/lang/Object;)V
      //   458: putfield b : Ljava/lang/ref/WeakReference;
      //   461: aload_0
      //   462: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   465: invokevirtual getNanoTime : ()J
      //   468: lstore #15
      //   470: aload_0
      //   471: getfield g : Landroidx/recyclerview/widget/RecyclerView$s;
      //   474: iload #12
      //   476: lload #15
      //   478: lload #13
      //   480: lsub
      //   481: invokevirtual e : (IJ)V
      //   484: goto -> 597
      //   487: new java/lang/StringBuilder
      //   490: dup
      //   491: invokespecial <init> : ()V
      //   494: astore #7
      //   496: aload #7
      //   498: ldc_w 'Inconsistency detected. Invalid item position '
      //   501: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   504: pop
      //   505: aload #7
      //   507: iload_1
      //   508: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   511: pop
      //   512: aload #7
      //   514: ldc_w '(offset:'
      //   517: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   520: pop
      //   521: aload #7
      //   523: iload #11
      //   525: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   528: pop
      //   529: aload #7
      //   531: ldc_w ').'
      //   534: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   537: pop
      //   538: aload #7
      //   540: ldc_w 'state:'
      //   543: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   546: pop
      //   547: aload #7
      //   549: aload_0
      //   550: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   553: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   556: invokevirtual b : ()I
      //   559: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   562: pop
      //   563: aload #7
      //   565: aload_0
      //   566: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   569: invokevirtual P : ()Ljava/lang/String;
      //   572: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   575: pop
      //   576: new java/lang/IndexOutOfBoundsException
      //   579: dup
      //   580: aload #7
      //   582: invokevirtual toString : ()Ljava/lang/String;
      //   585: invokespecial <init> : (Ljava/lang/String;)V
      //   588: athrow
      //   589: aload #8
      //   591: astore #7
      //   593: iload #11
      //   595: istore #9
      //   597: iload #9
      //   599: ifeq -> 700
      //   602: aload_0
      //   603: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   606: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   609: invokevirtual e : ()Z
      //   612: ifne -> 700
      //   615: aload #7
      //   617: sipush #8192
      //   620: invokevirtual p : (I)Z
      //   623: ifeq -> 700
      //   626: aload #7
      //   628: iconst_0
      //   629: sipush #8192
      //   632: invokevirtual E : (II)V
      //   635: aload_0
      //   636: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   639: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   642: getfield k : Z
      //   645: ifeq -> 700
      //   648: aload #7
      //   650: invokestatic e : (Landroidx/recyclerview/widget/RecyclerView$z;)I
      //   653: istore #10
      //   655: aload_0
      //   656: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   659: astore #8
      //   661: aload #8
      //   663: getfield L : Landroidx/recyclerview/widget/RecyclerView$l;
      //   666: aload #8
      //   668: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   671: aload #7
      //   673: iload #10
      //   675: sipush #4096
      //   678: ior
      //   679: aload #7
      //   681: invokevirtual o : ()Ljava/util/List;
      //   684: invokevirtual t : (Landroidx/recyclerview/widget/RecyclerView$w;Landroidx/recyclerview/widget/RecyclerView$z;ILjava/util/List;)Landroidx/recyclerview/widget/RecyclerView$l$b;
      //   687: astore #8
      //   689: aload_0
      //   690: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   693: aload #7
      //   695: aload #8
      //   697: invokevirtual O0 : (Landroidx/recyclerview/widget/RecyclerView$z;Landroidx/recyclerview/widget/RecyclerView$l$b;)V
      //   700: aload_0
      //   701: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   704: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   707: invokevirtual e : ()Z
      //   710: ifeq -> 730
      //   713: aload #7
      //   715: invokevirtual r : ()Z
      //   718: ifeq -> 730
      //   721: aload #7
      //   723: iload_1
      //   724: putfield g : I
      //   727: goto -> 757
      //   730: aload #7
      //   732: invokevirtual r : ()Z
      //   735: ifeq -> 762
      //   738: aload #7
      //   740: invokevirtual y : ()Z
      //   743: ifne -> 762
      //   746: aload #7
      //   748: invokevirtual s : ()Z
      //   751: ifeq -> 757
      //   754: goto -> 762
      //   757: iconst_0
      //   758: istore_2
      //   759: goto -> 782
      //   762: aload_0
      //   763: aload #7
      //   765: aload_0
      //   766: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   769: getfield d : Landroidx/recyclerview/widget/a;
      //   772: iload_1
      //   773: invokevirtual m : (I)I
      //   776: iload_1
      //   777: lload_3
      //   778: invokevirtual H : (Landroidx/recyclerview/widget/RecyclerView$z;IIJ)Z
      //   781: istore_2
      //   782: aload #7
      //   784: getfield a : Landroid/view/View;
      //   787: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   790: astore #8
      //   792: aload #8
      //   794: ifnonnull -> 826
      //   797: aload_0
      //   798: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   801: invokevirtual generateDefaultLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   804: astore #8
      //   806: aload #8
      //   808: checkcast androidx/recyclerview/widget/RecyclerView$LayoutParams
      //   811: astore #8
      //   813: aload #7
      //   815: getfield a : Landroid/view/View;
      //   818: aload #8
      //   820: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   823: goto -> 859
      //   826: aload_0
      //   827: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   830: aload #8
      //   832: invokevirtual checkLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)Z
      //   835: ifne -> 852
      //   838: aload_0
      //   839: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   842: aload #8
      //   844: invokevirtual generateLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
      //   847: astore #8
      //   849: goto -> 806
      //   852: aload #8
      //   854: checkcast androidx/recyclerview/widget/RecyclerView$LayoutParams
      //   857: astore #8
      //   859: aload #8
      //   861: aload #7
      //   863: putfield a : Landroidx/recyclerview/widget/RecyclerView$z;
      //   866: iload #9
      //   868: ifeq -> 881
      //   871: iload_2
      //   872: ifeq -> 881
      //   875: iload #6
      //   877: istore_2
      //   878: goto -> 883
      //   881: iconst_0
      //   882: istore_2
      //   883: aload #8
      //   885: iload_2
      //   886: putfield d : Z
      //   889: aload #7
      //   891: areturn
      //   892: new java/lang/StringBuilder
      //   895: dup
      //   896: invokespecial <init> : ()V
      //   899: astore #7
      //   901: aload #7
      //   903: ldc_w 'Invalid item position '
      //   906: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   909: pop
      //   910: aload #7
      //   912: iload_1
      //   913: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   916: pop
      //   917: aload #7
      //   919: ldc_w '('
      //   922: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   925: pop
      //   926: aload #7
      //   928: iload_1
      //   929: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   932: pop
      //   933: aload #7
      //   935: ldc_w '). Item count:'
      //   938: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   941: pop
      //   942: aload #7
      //   944: aload_0
      //   945: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   948: getfield f0 : Landroidx/recyclerview/widget/RecyclerView$w;
      //   951: invokevirtual b : ()I
      //   954: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   957: pop
      //   958: aload #7
      //   960: aload_0
      //   961: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   964: invokevirtual P : ()Ljava/lang/String;
      //   967: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   970: pop
      //   971: new java/lang/IndexOutOfBoundsException
      //   974: dup
      //   975: aload #7
      //   977: invokevirtual toString : ()Ljava/lang/String;
      //   980: invokespecial <init> : (Ljava/lang/String;)V
      //   983: athrow
    }
    
    public void J(RecyclerView.z param1z) {
      ArrayList arrayList;
      if (param1z.o) {
        arrayList = this.b;
      } else {
        arrayList = this.a;
      } 
      arrayList.remove(param1z);
      param1z.n = null;
      param1z.o = false;
      param1z.e();
    }
    
    public void K() {
      RecyclerView.o o = this.h.m;
      if (o != null) {
        i = o.l;
      } else {
        i = 0;
      } 
      this.f = this.e + i;
      for (int i = this.c.size() - 1; i >= 0 && this.c.size() > this.f; i--)
        A(i); 
    }
    
    public boolean L(RecyclerView.z param1z) {
      if (param1z.u())
        return this.h.f0.e(); 
      int i = param1z.c;
      if (i >= 0 && i < this.h.l.c()) {
        boolean bool = this.h.f0.e();
        boolean bool1 = false;
        if (!bool && this.h.l.e(param1z.c) != param1z.l())
          return false; 
        if (this.h.l.f()) {
          if (param1z.k() == this.h.l.d(param1z.c))
            bool1 = true; 
          return bool1;
        } 
        return true;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Inconsistency detected. Invalid view holder adapter position");
      stringBuilder.append(param1z);
      stringBuilder.append(this.h.P());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    public void M(int param1Int1, int param1Int2) {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.z z = this.c.get(i);
        if (z != null) {
          int j = z.c;
          if (j >= param1Int1 && j < param1Int2 + param1Int1) {
            z.b(2);
            A(i);
          } 
        } 
      } 
    }
    
    public void a(RecyclerView.z param1z, boolean param1Boolean) {
      RecyclerView.q(param1z);
      if (param1z.p(16384)) {
        param1z.E(0, 16384);
        n.j.A(param1z.a, null);
      } 
      if (param1Boolean)
        g(param1z); 
      param1z.r = null;
      i().i(param1z);
    }
    
    public final void b(RecyclerView.z param1z) {
      if (this.h.r0()) {
        View view = param1z.a;
        if (n.j.i(view) == 0)
          n.j.B(view, 1); 
        if (!n.j.o(view)) {
          param1z.b(16384);
          n.j.A(view, this.h.m0.n());
        } 
      } 
    }
    
    public void c() {
      this.a.clear();
      z();
    }
    
    public void d() {
      int i = this.c.size();
      boolean bool = false;
      byte b;
      for (b = 0; b < i; b++)
        ((RecyclerView.z)this.c.get(b)).c(); 
      i = this.a.size();
      for (b = 0; b < i; b++)
        ((RecyclerView.z)this.a.get(b)).c(); 
      ArrayList arrayList = this.b;
      if (arrayList != null) {
        i = arrayList.size();
        for (b = bool; b < i; b++)
          ((RecyclerView.z)this.b.get(b)).c(); 
      } 
    }
    
    public void e() {
      this.a.clear();
      ArrayList arrayList = this.b;
      if (arrayList != null)
        arrayList.clear(); 
    }
    
    public int f(int param1Int) {
      if (param1Int >= 0 && param1Int < this.h.f0.b())
        return !this.h.f0.e() ? param1Int : this.h.d.m(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("invalid position ");
      stringBuilder.append(param1Int);
      stringBuilder.append(". State ");
      stringBuilder.append("item count is ");
      stringBuilder.append(this.h.f0.b());
      stringBuilder.append(this.h.P());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    public void g(RecyclerView.z param1z) {
      this.h.getClass();
      RecyclerView.g g = this.h.l;
      if (g != null)
        g.p(param1z); 
      RecyclerView recyclerView = this.h;
      if (recyclerView.f0 != null)
        recyclerView.f.q(param1z); 
    }
    
    public RecyclerView.z h(int param1Int) {
      ArrayList arrayList = this.b;
      if (arrayList != null) {
        int i = arrayList.size();
        if (i != 0) {
          boolean bool = false;
          for (byte b = 0; b < i; b++) {
            RecyclerView.z z = this.b.get(b);
            if (!z.K() && z.m() == param1Int) {
              z.b(32);
              return z;
            } 
          } 
          if (this.h.l.f()) {
            param1Int = this.h.d.m(param1Int);
            if (param1Int > 0 && param1Int < this.h.l.c()) {
              long l = this.h.l.d(param1Int);
              for (param1Int = bool; param1Int < i; param1Int++) {
                RecyclerView.z z = this.b.get(param1Int);
                if (!z.K() && z.k() == l) {
                  z.b(32);
                  return z;
                } 
              } 
            } 
          } 
        } 
      } 
      return null;
    }
    
    public RecyclerView.s i() {
      if (this.g == null)
        this.g = new RecyclerView.s(); 
      return this.g;
    }
    
    public int j() {
      return this.a.size();
    }
    
    public List k() {
      return this.d;
    }
    
    public RecyclerView.z l(long param1Long, int param1Int, boolean param1Boolean) {
      int i;
      for (i = this.a.size() - 1; i >= 0; i--) {
        RecyclerView.z z = this.a.get(i);
        if (z.k() == param1Long && !z.K()) {
          if (param1Int == z.l()) {
            z.b(32);
            if (z.u() && !this.h.f0.e())
              z.E(2, 14); 
            return z;
          } 
          if (!param1Boolean) {
            this.a.remove(i);
            this.h.removeDetachedView(z.a, false);
            y(z.a);
          } 
        } 
      } 
      for (i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.z z = this.c.get(i);
        if (z.k() == param1Long) {
          if (param1Int == z.l()) {
            if (!param1Boolean)
              this.c.remove(i); 
            return z;
          } 
          if (!param1Boolean) {
            A(i);
            return null;
          } 
        } 
      } 
      return null;
    }
    
    public RecyclerView.z m(int param1Int, boolean param1Boolean) {
      int i = this.a.size();
      boolean bool = false;
      byte b;
      for (b = 0; b < i; b++) {
        RecyclerView.z z = this.a.get(b);
        if (!z.K() && z.m() == param1Int && !z.s() && (this.h.f0.h || !z.u())) {
          z.b(32);
          return z;
        } 
      } 
      if (!param1Boolean) {
        View view = this.h.e.e(param1Int);
        if (view != null) {
          RecyclerView.z z = RecyclerView.d0(view);
          this.h.e.s(view);
          param1Int = this.h.e.m(view);
          if (param1Int != -1) {
            this.h.e.d(param1Int);
            D(view);
            z.b(8224);
            return z;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("layout index should not be -1 after unhiding a view:");
          stringBuilder.append(z);
          stringBuilder.append(this.h.P());
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
      i = this.c.size();
      for (b = bool; b < i; b++) {
        RecyclerView.z z = this.c.get(b);
        if (!z.s() && z.m() == param1Int) {
          if (!param1Boolean)
            this.c.remove(b); 
          return z;
        } 
      } 
      return null;
    }
    
    public View n(int param1Int) {
      return ((RecyclerView.z)this.a.get(param1Int)).a;
    }
    
    public View o(int param1Int) {
      return p(param1Int, false);
    }
    
    public View p(int param1Int, boolean param1Boolean) {
      return (I(param1Int, param1Boolean, Long.MAX_VALUE)).a;
    }
    
    public final void q(ViewGroup param1ViewGroup, boolean param1Boolean) {
      int i;
      for (i = param1ViewGroup.getChildCount() - 1; i >= 0; i--) {
        View view = param1ViewGroup.getChildAt(i);
        if (view instanceof ViewGroup)
          q((ViewGroup)view, true); 
      } 
      if (!param1Boolean)
        return; 
      if (param1ViewGroup.getVisibility() == 4) {
        param1ViewGroup.setVisibility(0);
        param1ViewGroup.setVisibility(4);
      } else {
        i = param1ViewGroup.getVisibility();
        param1ViewGroup.setVisibility(4);
        param1ViewGroup.setVisibility(i);
      } 
    }
    
    public final void r(RecyclerView.z param1z) {
      View view = param1z.a;
      if (view instanceof ViewGroup)
        q((ViewGroup)view, false); 
    }
    
    public void s() {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)((RecyclerView.z)this.c.get(b)).a.getLayoutParams();
        if (layoutParams != null)
          layoutParams.c = true; 
      } 
    }
    
    public void t() {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        RecyclerView.z z = this.c.get(b);
        if (z != null) {
          z.b(6);
          z.a(null);
        } 
      } 
      RecyclerView.g g = this.h.l;
      if (g == null || !g.f())
        z(); 
    }
    
    public void u(int param1Int1, int param1Int2) {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        RecyclerView.z z = this.c.get(b);
        if (z != null && z.c >= param1Int1)
          z.z(param1Int2, true); 
      } 
    }
    
    public void v(int param1Int1, int param1Int2) {
      boolean bool;
      int i;
      int j;
      if (param1Int1 < param1Int2) {
        bool = true;
        i = param1Int1;
        j = param1Int2;
      } else {
        bool = true;
        j = param1Int1;
        i = param1Int2;
      } 
      int k = this.c.size();
      for (byte b = 0; b < k; b++) {
        RecyclerView.z z = this.c.get(b);
        if (z != null) {
          int m = z.c;
          if (m >= i && m <= j)
            if (m == param1Int1) {
              z.z(param1Int2 - param1Int1, false);
            } else {
              z.z(bool, false);
            }  
        } 
      } 
    }
    
    public void w(int param1Int1, int param1Int2, boolean param1Boolean) {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.z z = this.c.get(i);
        if (z != null) {
          int j = z.c;
          if (j >= param1Int1 + param1Int2) {
            z.z(-param1Int2, param1Boolean);
          } else if (j >= param1Int1) {
            z.b(8);
            A(i);
          } 
        } 
      } 
    }
    
    public void x(RecyclerView.g param1g1, RecyclerView.g param1g2, boolean param1Boolean) {
      c();
      i().h(param1g1, param1g2, param1Boolean);
    }
    
    public void y(View param1View) {
      RecyclerView.z z = RecyclerView.d0(param1View);
      z.n = null;
      z.o = false;
      z.e();
      C(z);
    }
    
    public void z() {
      for (int i = this.c.size() - 1; i >= 0; i--)
        A(i); 
      this.c.clear();
      if (RecyclerView.B0)
        this.h.e0.b(); 
    }
  }
  
  public static interface u {}
  
  public class v extends i {
    public v(RecyclerView this$0) {}
    
    public void a() {
      this.a.n(null);
      RecyclerView recyclerView = this.a;
      recyclerView.f0.g = true;
      recyclerView.M0(true);
      if (!this.a.d.p())
        this.a.requestLayout(); 
    }
  }
  
  public static class w {
    public int a = -1;
    
    public SparseArray b;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = 1;
    
    public int f = 0;
    
    public boolean g = false;
    
    public boolean h = false;
    
    public boolean i = false;
    
    public boolean j = false;
    
    public boolean k = false;
    
    public boolean l = false;
    
    public int m;
    
    public long n;
    
    public int o;
    
    public int p;
    
    public int q;
    
    public void a(int param1Int) {
      if ((this.e & param1Int) != 0)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Layout state should be one of ");
      stringBuilder.append(Integer.toBinaryString(param1Int));
      stringBuilder.append(" but it is ");
      stringBuilder.append(Integer.toBinaryString(this.e));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public int b() {
      int i;
      if (this.h) {
        i = this.c - this.d;
      } else {
        i = this.f;
      } 
      return i;
    }
    
    public int c() {
      return this.a;
    }
    
    public boolean d() {
      boolean bool;
      if (this.a != -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean e() {
      return this.h;
    }
    
    public void f(RecyclerView.g param1g) {
      this.e = 1;
      this.f = param1g.c();
      this.h = false;
      this.i = false;
      this.j = false;
    }
    
    public boolean g() {
      return this.l;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("State{mTargetPosition=");
      stringBuilder.append(this.a);
      stringBuilder.append(", mData=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mItemCount=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mIsMeasuring=");
      stringBuilder.append(this.j);
      stringBuilder.append(", mPreviousLayoutItemCount=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mStructureChanged=");
      stringBuilder.append(this.g);
      stringBuilder.append(", mInPreLayout=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mRunSimpleAnimations=");
      stringBuilder.append(this.k);
      stringBuilder.append(", mRunPredictiveAnimations=");
      stringBuilder.append(this.l);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static abstract class x {}
  
  public class y implements Runnable {
    public int a;
    
    public int b;
    
    public OverScroller c;
    
    public Interpolator d;
    
    public boolean e;
    
    public boolean f;
    
    public y(RecyclerView this$0) {
      Interpolator interpolator = RecyclerView.F0;
      this.d = interpolator;
      this.e = false;
      this.f = false;
      this.c = new OverScroller(this$0.getContext(), interpolator);
    }
    
    public final int a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool;
      int i = Math.abs(param1Int1);
      int j = Math.abs(param1Int2);
      if (i > j) {
        bool = true;
      } else {
        bool = false;
      } 
      param1Int3 = (int)Math.sqrt((param1Int3 * param1Int3 + param1Int4 * param1Int4));
      param1Int2 = (int)Math.sqrt((param1Int1 * param1Int1 + param1Int2 * param1Int2));
      RecyclerView recyclerView = this.g;
      if (bool) {
        param1Int1 = recyclerView.getWidth();
      } else {
        param1Int1 = recyclerView.getHeight();
      } 
      param1Int4 = param1Int1 / 2;
      float f1 = param1Int2;
      float f2 = param1Int1;
      float f3 = Math.min(1.0F, f1 * 1.0F / f2);
      f1 = param1Int4;
      f3 = c(f3);
      if (param1Int3 > 0) {
        param1Int1 = Math.round(Math.abs((f1 + f3 * f1) / param1Int3) * 1000.0F) * 4;
      } else {
        if (bool) {
          param1Int1 = i;
        } else {
          param1Int1 = j;
        } 
        param1Int1 = (int)((param1Int1 / f2 + 1.0F) * 300.0F);
      } 
      return Math.min(param1Int1, 2000);
    }
    
    public final void b() {
      this.f = false;
      this.e = true;
    }
    
    public final float c(float param1Float) {
      return (float)Math.sin(((param1Float - 0.5F) * 0.47123894F));
    }
    
    public final void d() {
      this.e = false;
      if (this.f)
        f(); 
    }
    
    public void e(int param1Int1, int param1Int2) {
      this.g.setScrollState(2);
      this.b = 0;
      this.a = 0;
      this.c.fling(0, 0, param1Int1, param1Int2, -2147483648, 2147483647, -2147483648, 2147483647);
      f();
    }
    
    public void f() {
      if (this.e) {
        this.f = true;
      } else {
        this.g.removeCallbacks(this);
        n.j.x((View)this.g, this);
      } 
    }
    
    public void g(int param1Int1, int param1Int2, int param1Int3, Interpolator param1Interpolator) {
      if (this.d != param1Interpolator) {
        this.d = param1Interpolator;
        this.c = new OverScroller(this.g.getContext(), param1Interpolator);
      } 
      this.g.setScrollState(2);
      this.b = 0;
      this.a = 0;
      this.c.startScroll(0, 0, param1Int1, param1Int2, param1Int3);
      f();
    }
    
    public void h(int param1Int1, int param1Int2, Interpolator param1Interpolator) {
      int i = a(param1Int1, param1Int2, 0, 0);
      Interpolator interpolator = param1Interpolator;
      if (param1Interpolator == null)
        interpolator = RecyclerView.F0; 
      g(param1Int1, param1Int2, i, interpolator);
    }
    
    public void i() {
      this.g.removeCallbacks(this);
      this.c.abortAnimation();
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   4: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
      //   7: ifnonnull -> 15
      //   10: aload_0
      //   11: invokevirtual i : ()V
      //   14: return
      //   15: aload_0
      //   16: invokevirtual b : ()V
      //   19: aload_0
      //   20: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   23: invokevirtual t : ()V
      //   26: aload_0
      //   27: getfield c : Landroid/widget/OverScroller;
      //   30: astore_1
      //   31: aload_0
      //   32: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   35: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
      //   38: invokevirtual getClass : ()Ljava/lang/Class;
      //   41: pop
      //   42: aload_1
      //   43: invokevirtual computeScrollOffset : ()Z
      //   46: ifeq -> 652
      //   49: aload_0
      //   50: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   53: getfield q0 : [I
      //   56: astore_2
      //   57: aload_1
      //   58: invokevirtual getCurrX : ()I
      //   61: istore_3
      //   62: aload_1
      //   63: invokevirtual getCurrY : ()I
      //   66: istore #4
      //   68: iload_3
      //   69: aload_0
      //   70: getfield a : I
      //   73: isub
      //   74: istore #5
      //   76: iload #4
      //   78: aload_0
      //   79: getfield b : I
      //   82: isub
      //   83: istore #6
      //   85: aload_0
      //   86: iload_3
      //   87: putfield a : I
      //   90: aload_0
      //   91: iload #4
      //   93: putfield b : I
      //   96: iload #5
      //   98: istore #7
      //   100: iload #6
      //   102: istore #8
      //   104: aload_0
      //   105: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   108: iload #5
      //   110: iload #6
      //   112: aload_2
      //   113: aconst_null
      //   114: iconst_1
      //   115: invokevirtual E : (II[I[II)Z
      //   118: ifeq -> 137
      //   121: iload #5
      //   123: aload_2
      //   124: iconst_0
      //   125: iaload
      //   126: isub
      //   127: istore #7
      //   129: iload #6
      //   131: aload_2
      //   132: iconst_1
      //   133: iaload
      //   134: isub
      //   135: istore #8
      //   137: aload_0
      //   138: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   141: astore_2
      //   142: aload_2
      //   143: getfield l : Landroidx/recyclerview/widget/RecyclerView$g;
      //   146: ifnull -> 196
      //   149: aload_2
      //   150: iload #7
      //   152: iload #8
      //   154: aload_2
      //   155: getfield s0 : [I
      //   158: invokevirtual d1 : (II[I)V
      //   161: aload_0
      //   162: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   165: getfield s0 : [I
      //   168: astore_2
      //   169: aload_2
      //   170: iconst_0
      //   171: iaload
      //   172: istore #9
      //   174: aload_2
      //   175: iconst_1
      //   176: iaload
      //   177: istore #10
      //   179: iload #7
      //   181: iload #9
      //   183: isub
      //   184: istore #11
      //   186: iload #8
      //   188: iload #10
      //   190: isub
      //   191: istore #12
      //   193: goto -> 219
      //   196: iconst_0
      //   197: istore #10
      //   199: iload #10
      //   201: istore #6
      //   203: iload #6
      //   205: istore #5
      //   207: iload #5
      //   209: istore #12
      //   211: iload #5
      //   213: istore #11
      //   215: iload #6
      //   217: istore #9
      //   219: aload_0
      //   220: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   223: getfield n : Ljava/util/ArrayList;
      //   226: invokevirtual isEmpty : ()Z
      //   229: ifne -> 239
      //   232: aload_0
      //   233: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   236: invokevirtual invalidate : ()V
      //   239: aload_0
      //   240: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   243: invokevirtual getOverScrollMode : ()I
      //   246: iconst_2
      //   247: if_icmpeq -> 261
      //   250: aload_0
      //   251: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   254: iload #7
      //   256: iload #8
      //   258: invokevirtual s : (II)V
      //   261: aload_0
      //   262: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   265: iload #9
      //   267: iload #10
      //   269: iload #11
      //   271: iload #12
      //   273: aconst_null
      //   274: iconst_1
      //   275: invokevirtual F : (IIII[II)Z
      //   278: ifne -> 426
      //   281: iload #11
      //   283: ifne -> 291
      //   286: iload #12
      //   288: ifeq -> 426
      //   291: aload_1
      //   292: invokevirtual getCurrVelocity : ()F
      //   295: f2i
      //   296: istore #5
      //   298: iload #11
      //   300: iload_3
      //   301: if_icmpeq -> 329
      //   304: iload #11
      //   306: ifge -> 317
      //   309: iload #5
      //   311: ineg
      //   312: istore #6
      //   314: goto -> 332
      //   317: iload #11
      //   319: ifle -> 329
      //   322: iload #5
      //   324: istore #6
      //   326: goto -> 332
      //   329: iconst_0
      //   330: istore #6
      //   332: iload #12
      //   334: iload #4
      //   336: if_icmpeq -> 360
      //   339: iload #12
      //   341: ifge -> 352
      //   344: iload #5
      //   346: ineg
      //   347: istore #5
      //   349: goto -> 363
      //   352: iload #12
      //   354: ifle -> 360
      //   357: goto -> 363
      //   360: iconst_0
      //   361: istore #5
      //   363: aload_0
      //   364: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   367: invokevirtual getOverScrollMode : ()I
      //   370: iconst_2
      //   371: if_icmpeq -> 385
      //   374: aload_0
      //   375: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   378: iload #6
      //   380: iload #5
      //   382: invokevirtual a : (II)V
      //   385: iload #6
      //   387: ifne -> 403
      //   390: iload #11
      //   392: iload_3
      //   393: if_icmpeq -> 403
      //   396: aload_1
      //   397: invokevirtual getFinalX : ()I
      //   400: ifne -> 426
      //   403: iload #5
      //   405: ifne -> 422
      //   408: iload #12
      //   410: iload #4
      //   412: if_icmpeq -> 422
      //   415: aload_1
      //   416: invokevirtual getFinalY : ()I
      //   419: ifne -> 426
      //   422: aload_1
      //   423: invokevirtual abortAnimation : ()V
      //   426: iload #9
      //   428: ifne -> 436
      //   431: iload #10
      //   433: ifeq -> 447
      //   436: aload_0
      //   437: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   440: iload #9
      //   442: iload #10
      //   444: invokevirtual J : (II)V
      //   447: aload_0
      //   448: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   451: invokestatic d : (Landroidx/recyclerview/widget/RecyclerView;)Z
      //   454: ifne -> 464
      //   457: aload_0
      //   458: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   461: invokevirtual invalidate : ()V
      //   464: iload #8
      //   466: ifeq -> 495
      //   469: aload_0
      //   470: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   473: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
      //   476: invokevirtual k : ()Z
      //   479: ifeq -> 495
      //   482: iload #10
      //   484: iload #8
      //   486: if_icmpne -> 495
      //   489: iconst_1
      //   490: istore #6
      //   492: goto -> 498
      //   495: iconst_0
      //   496: istore #6
      //   498: iload #7
      //   500: ifeq -> 529
      //   503: aload_0
      //   504: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   507: getfield m : Landroidx/recyclerview/widget/RecyclerView$o;
      //   510: invokevirtual j : ()Z
      //   513: ifeq -> 529
      //   516: iload #9
      //   518: iload #7
      //   520: if_icmpne -> 529
      //   523: iconst_1
      //   524: istore #5
      //   526: goto -> 532
      //   529: iconst_0
      //   530: istore #5
      //   532: iload #7
      //   534: ifne -> 542
      //   537: iload #8
      //   539: ifeq -> 561
      //   542: iload #5
      //   544: ifne -> 561
      //   547: iload #6
      //   549: ifeq -> 555
      //   552: goto -> 561
      //   555: iconst_0
      //   556: istore #6
      //   558: goto -> 564
      //   561: iconst_1
      //   562: istore #6
      //   564: aload_1
      //   565: invokevirtual isFinished : ()Z
      //   568: ifne -> 620
      //   571: iload #6
      //   573: ifne -> 590
      //   576: aload_0
      //   577: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   580: iconst_1
      //   581: invokevirtual j0 : (I)Z
      //   584: ifne -> 590
      //   587: goto -> 620
      //   590: aload_0
      //   591: invokevirtual f : ()V
      //   594: aload_0
      //   595: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   598: astore_2
      //   599: aload_2
      //   600: getfield d0 : Landroidx/recyclerview/widget/e;
      //   603: astore_1
      //   604: aload_1
      //   605: ifnull -> 652
      //   608: aload_1
      //   609: aload_2
      //   610: iload #7
      //   612: iload #8
      //   614: invokevirtual f : (Landroidx/recyclerview/widget/RecyclerView;II)V
      //   617: goto -> 652
      //   620: aload_0
      //   621: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   624: iconst_0
      //   625: invokevirtual setScrollState : (I)V
      //   628: getstatic androidx/recyclerview/widget/RecyclerView.B0 : Z
      //   631: ifeq -> 644
      //   634: aload_0
      //   635: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   638: getfield e0 : Landroidx/recyclerview/widget/e$b;
      //   641: invokevirtual b : ()V
      //   644: aload_0
      //   645: getfield g : Landroidx/recyclerview/widget/RecyclerView;
      //   648: iconst_1
      //   649: invokevirtual m1 : (I)V
      //   652: aload_0
      //   653: invokevirtual d : ()V
      //   656: return
    }
  }
  
  public static abstract class z {
    public static final List s = Collections.emptyList();
    
    public final View a;
    
    public WeakReference b;
    
    public int c = -1;
    
    public int d = -1;
    
    public long e = -1L;
    
    public int f = -1;
    
    public int g = -1;
    
    public z h = null;
    
    public z i = null;
    
    public int j;
    
    public List k = null;
    
    public List l = null;
    
    public int m = 0;
    
    public RecyclerView.t n = null;
    
    public boolean o = false;
    
    public int p = 0;
    
    public int q = -1;
    
    public RecyclerView r;
    
    public z(View param1View) {
      if (param1View != null) {
        this.a = param1View;
        return;
      } 
      throw new IllegalArgumentException("itemView may not be null");
    }
    
    public void A(RecyclerView param1RecyclerView) {
      int i = this.q;
      if (i == -1)
        i = n.j.i(this.a); 
      this.p = i;
      param1RecyclerView.f1(this, 4);
    }
    
    public void B(RecyclerView param1RecyclerView) {
      param1RecyclerView.f1(this, this.p);
      this.p = 0;
    }
    
    public void C() {
      this.j = 0;
      this.c = -1;
      this.d = -1;
      this.e = -1L;
      this.g = -1;
      this.m = 0;
      this.h = null;
      this.i = null;
      d();
      this.p = 0;
      this.q = -1;
      RecyclerView.q(this);
    }
    
    public void D() {
      if (this.d == -1)
        this.d = this.c; 
    }
    
    public void E(int param1Int1, int param1Int2) {
      this.j = param1Int1 & param1Int2 | this.j & param1Int2;
    }
    
    public final void F(boolean param1Boolean) {
      int i = this.m;
      if (param1Boolean) {
        i--;
      } else {
        i++;
      } 
      this.m = i;
      if (i < 0) {
        this.m = 0;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for ");
        stringBuilder.append(this);
        Log.e("View", stringBuilder.toString());
      } else {
        if (!param1Boolean && i == 1) {
          i = this.j | 0x10;
        } else if (param1Boolean && i == 0) {
          i = this.j & 0xFFFFFFEF;
        } else {
          return;
        } 
        this.j = i;
      } 
    }
    
    public void G(RecyclerView.t param1t, boolean param1Boolean) {
      this.n = param1t;
      this.o = param1Boolean;
    }
    
    public boolean H() {
      boolean bool;
      if ((this.j & 0x10) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean I() {
      boolean bool;
      if ((this.j & 0x80) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void J() {
      this.n.J(this);
    }
    
    public boolean K() {
      boolean bool;
      if ((this.j & 0x20) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void a(Object param1Object) {
      if (param1Object == null) {
        b(1024);
      } else if ((0x400 & this.j) == 0) {
        g();
        this.k.add(param1Object);
      } 
    }
    
    public void b(int param1Int) {
      this.j = param1Int | this.j;
    }
    
    public void c() {
      this.d = -1;
      this.g = -1;
    }
    
    public void d() {
      List list = this.k;
      if (list != null)
        list.clear(); 
      this.j &= 0xFFFFFBFF;
    }
    
    public void e() {
      this.j &= 0xFFFFFFDF;
    }
    
    public void f() {
      this.j &= 0xFFFFFEFF;
    }
    
    public final void g() {
      if (this.k == null) {
        ArrayList<?> arrayList = new ArrayList();
        this.k = arrayList;
        this.l = Collections.unmodifiableList(arrayList);
      } 
    }
    
    public boolean h() {
      boolean bool;
      if ((this.j & 0x10) == 0 && n.j.q(this.a)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void i(int param1Int1, int param1Int2, boolean param1Boolean) {
      b(8);
      z(param1Int2, param1Boolean);
      this.c = param1Int1;
    }
    
    public final int j() {
      RecyclerView recyclerView = this.r;
      return (recyclerView == null) ? -1 : recyclerView.a0(this);
    }
    
    public final long k() {
      return this.e;
    }
    
    public final int l() {
      return this.f;
    }
    
    public final int m() {
      int i = this.g;
      int j = i;
      if (i == -1)
        j = this.c; 
      return j;
    }
    
    public final int n() {
      return this.d;
    }
    
    public List o() {
      if ((this.j & 0x400) == 0) {
        List list = this.k;
        return (list == null || list.size() == 0) ? s : this.l;
      } 
      return s;
    }
    
    public boolean p(int param1Int) {
      boolean bool;
      if ((param1Int & this.j) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean q() {
      return ((this.j & 0x200) != 0 || s());
    }
    
    public boolean r() {
      int i = this.j;
      boolean bool = true;
      if ((i & 0x1) == 0)
        bool = false; 
      return bool;
    }
    
    public boolean s() {
      boolean bool;
      if ((this.j & 0x4) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public final boolean t() {
      boolean bool;
      if ((this.j & 0x10) == 0 && !n.j.q(this.a)) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public String toString() {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("ViewHolder{");
      stringBuilder1.append(Integer.toHexString(hashCode()));
      stringBuilder1.append(" position=");
      stringBuilder1.append(this.c);
      stringBuilder1.append(" id=");
      stringBuilder1.append(this.e);
      stringBuilder1.append(", oldPos=");
      stringBuilder1.append(this.d);
      stringBuilder1.append(", pLpos:");
      stringBuilder1.append(this.g);
      StringBuilder stringBuilder2 = new StringBuilder(stringBuilder1.toString());
      if (v()) {
        String str;
        stringBuilder2.append(" scrap ");
        if (this.o) {
          str = "[changeScrap]";
        } else {
          str = "[attachedScrap]";
        } 
        stringBuilder2.append(str);
      } 
      if (s())
        stringBuilder2.append(" invalid"); 
      if (!r())
        stringBuilder2.append(" unbound"); 
      if (y())
        stringBuilder2.append(" update"); 
      if (u())
        stringBuilder2.append(" removed"); 
      if (I())
        stringBuilder2.append(" ignored"); 
      if (w())
        stringBuilder2.append(" tmpDetached"); 
      if (!t()) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" not recyclable(");
        stringBuilder1.append(this.m);
        stringBuilder1.append(")");
        stringBuilder2.append(stringBuilder1.toString());
      } 
      if (q())
        stringBuilder2.append(" undefined adapter position"); 
      if (this.a.getParent() == null)
        stringBuilder2.append(" no parent"); 
      stringBuilder2.append("}");
      return stringBuilder2.toString();
    }
    
    public boolean u() {
      boolean bool;
      if ((this.j & 0x8) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean v() {
      boolean bool;
      if (this.n != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean w() {
      boolean bool;
      if ((this.j & 0x100) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean x() {
      boolean bool;
      if ((this.j & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean y() {
      boolean bool;
      if ((this.j & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void z(int param1Int, boolean param1Boolean) {
      if (this.d == -1)
        this.d = this.c; 
      if (this.g == -1)
        this.g = this.c; 
      if (param1Boolean)
        this.g += param1Int; 
      this.c += param1Int;
      if (this.a.getLayoutParams() != null)
        ((RecyclerView.LayoutParams)this.a.getLayoutParams()).c = true; 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/recyclerview/widget/RecyclerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */