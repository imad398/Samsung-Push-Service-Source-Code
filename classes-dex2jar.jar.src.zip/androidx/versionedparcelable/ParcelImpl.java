package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import y.b;
import y.c;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl implements Parcelable {
  public static final Parcelable.Creator<ParcelImpl> CREATOR = new a();
  
  private final c mParcel;
  
  public ParcelImpl(Parcel paramParcel) {
    this.mParcel = (new b(paramParcel)).u();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    (new b(paramParcel)).L(this.mParcel);
  }
  
  public static final class a implements Parcelable.Creator {
    public ParcelImpl a(Parcel param1Parcel) {
      return new ParcelImpl(param1Parcel);
    }
    
    public ParcelImpl[] b(int param1Int) {
      return new ParcelImpl[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/versionedparcelable/ParcelImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */