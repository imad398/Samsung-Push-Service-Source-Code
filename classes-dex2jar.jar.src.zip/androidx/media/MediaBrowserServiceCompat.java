package androidx.media;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public abstract class MediaBrowserServiceCompat extends Service {
  public static final boolean f = Log.isLoggable("MBServiceCompat", 3);
  
  public g a;
  
  public final f.a b = new f.a();
  
  public f c;
  
  public final p d = new p(this);
  
  public MediaSessionCompat.Token e;
  
  public void a(String paramString, f paramf, IBinder paramIBinder, Bundle paramBundle) {
    List<m.d> list1 = (List)paramf.g.get(paramString);
    List<m.d> list2 = list1;
    if (list1 == null)
      list2 = new ArrayList(); 
    for (m.d d : list2) {
      if (paramIBinder == d.a && q.d.a(paramBundle, (Bundle)d.b))
        return; 
    } 
    list2.add(new m.d(paramIBinder, paramBundle));
    paramf.g.put(paramString, list2);
    m(paramString, paramf, paramBundle, null);
    this.c = paramf;
    j(paramString, paramBundle);
    this.c = null;
  }
  
  public List b(List paramList, Bundle paramBundle) {
    if (paramList == null)
      return null; 
    int i = paramBundle.getInt("android.media.browse.extra.PAGE", -1);
    int j = paramBundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    if (i == -1 && j == -1)
      return paramList; 
    int k = j * i;
    int m = k + j;
    if (i < 0 || j < 1 || k >= paramList.size())
      return Collections.emptyList(); 
    i = m;
    if (m > paramList.size())
      i = paramList.size(); 
    return paramList.subList(k, i);
  }
  
  public boolean c(String paramString, int paramInt) {
    if (paramString == null)
      return false; 
    String[] arrayOfString = getPackageManager().getPackagesForUid(paramInt);
    int i = arrayOfString.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      if (arrayOfString[paramInt].equals(paramString))
        return true; 
    } 
    return false;
  }
  
  public void d(String paramString, Bundle paramBundle, l paraml) {
    paraml.e(null);
  }
  
  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {}
  
  public abstract e e(String paramString, int paramInt, Bundle paramBundle);
  
  public abstract void f(String paramString, l paraml);
  
  public void g(String paramString, l paraml, Bundle paramBundle) {
    paraml.g(1);
    f(paramString, paraml);
  }
  
  public void h(String paramString, l paraml) {
    paraml.g(2);
    paraml.f(null);
  }
  
  public void i(String paramString, Bundle paramBundle, l paraml) {
    paraml.g(4);
    paraml.f(null);
  }
  
  public void j(String paramString, Bundle paramBundle) {}
  
  public void k(String paramString) {}
  
  public void l(String paramString, Bundle paramBundle, f paramf, ResultReceiver paramResultReceiver) {
    d d = new d(this, paramString, paramResultReceiver);
    this.c = paramf;
    d(paramString, paramBundle, d);
    this.c = null;
    if (d.b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onCustomAction must call detach() or sendResult() or sendError() before returning for action=");
    stringBuilder.append(paramString);
    stringBuilder.append(" extras=");
    stringBuilder.append(paramBundle);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void m(String paramString, f paramf, Bundle paramBundle1, Bundle paramBundle2) {
    a a1 = new a(this, paramString, paramf, paramString, paramBundle1, paramBundle2);
    this.c = paramf;
    if (paramBundle1 == null) {
      f(paramString, a1);
    } else {
      g(paramString, a1, paramBundle1);
    } 
    this.c = null;
    if (a1.b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onLoadChildren must call detach() or sendResult() before returning for package=");
    stringBuilder.append(paramf.a);
    stringBuilder.append(" id=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void n(String paramString, f paramf, ResultReceiver paramResultReceiver) {
    b b = new b(this, paramString, paramResultReceiver);
    this.c = paramf;
    h(paramString, b);
    this.c = null;
    if (b.b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onLoadItem must call detach() or sendResult() before returning for id=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void o(String paramString, Bundle paramBundle, f paramf, ResultReceiver paramResultReceiver) {
    c c = new c(this, paramString, paramResultReceiver);
    this.c = paramf;
    i(paramString, paramBundle, c);
    this.c = null;
    if (c.b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onSearch must call detach() or sendResult() before returning for query=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public IBinder onBind(Intent paramIntent) {
    return this.a.d(paramIntent);
  }
  
  public void onCreate() {
    i i1;
    super.onCreate();
    int i = Build.VERSION.SDK_INT;
    if (i >= 28) {
      i1 = new k(this);
    } else if (i >= 26) {
      i1 = new j(this);
    } else {
      i1 = new i(this);
    } 
    this.a = i1;
    this.a.a();
  }
  
  public boolean p(String paramString, f paramf, IBinder paramIBinder) {
    boolean bool1 = true;
    boolean bool2 = false;
    boolean bool3 = false;
    if (paramIBinder == null)
      try {
        paramIBinder = (IBinder)paramf.g.remove(paramString);
        if (paramIBinder != null) {
          bool3 = bool1;
        } else {
          bool3 = false;
        } 
        return bool3;
      } finally {
        this.c = paramf;
        k(paramString);
        this.c = null;
      }  
    List list = (List)paramf.g.get(paramString);
    bool1 = bool2;
    if (list != null) {
      Iterator iterator = list.iterator();
      while (iterator.hasNext()) {
        if (paramIBinder == ((m.d)iterator.next()).a) {
          iterator.remove();
          bool3 = true;
        } 
      } 
      bool1 = bool3;
      if (list.size() == 0) {
        paramf.g.remove(paramString);
        bool1 = bool3;
      } 
    } 
    this.c = paramf;
    k(paramString);
    this.c = null;
    return bool1;
  }
  
  public class a extends l {
    public a(MediaBrowserServiceCompat this$0, Object param1Object, MediaBrowserServiceCompat.f param1f, String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {
      super(param1Object);
    }
    
    public void h(List param1List) {
      StringBuilder stringBuilder1;
      List list;
      if (this.j.b.get(this.f.f.asBinder()) != this.f) {
        if (MediaBrowserServiceCompat.f) {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Not sending onLoadChildren result for connection that has been disconnected. pkg=");
          stringBuilder1.append(this.f.a);
          stringBuilder1.append(" id=");
          stringBuilder1.append(this.g);
          Log.d("MBServiceCompat", stringBuilder1.toString());
        } 
        return;
      } 
      StringBuilder stringBuilder2 = stringBuilder1;
      if ((a() & 0x1) != 0)
        list = this.j.b((List)stringBuilder1, this.h); 
      try {
        this.f.f.b(this.g, list, this.h, this.i);
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Calling onLoadChildren() failed for id=");
        stringBuilder.append(this.g);
        stringBuilder.append(" package=");
        stringBuilder.append(this.f.a);
        Log.w("MBServiceCompat", stringBuilder.toString());
      } 
    }
  }
  
  public class b extends l {
    public b(MediaBrowserServiceCompat this$0, Object param1Object, ResultReceiver param1ResultReceiver) {
      super(param1Object);
    }
    
    public void h(MediaBrowserCompat.MediaItem param1MediaItem) {
      if ((a() & 0x2) != 0) {
        this.f.b(-1, null);
        return;
      } 
      Bundle bundle = new Bundle();
      bundle.putParcelable("media_item", (Parcelable)param1MediaItem);
      this.f.b(0, bundle);
    }
  }
  
  public class c extends l {
    public c(MediaBrowserServiceCompat this$0, Object param1Object, ResultReceiver param1ResultReceiver) {
      super(param1Object);
    }
    
    public void h(List param1List) {
      if ((a() & 0x4) != 0 || param1List == null) {
        this.f.b(-1, null);
        return;
      } 
      Bundle bundle = new Bundle();
      bundle.putParcelableArray("search_results", (Parcelable[])param1List.toArray((Object[])new MediaBrowserCompat.MediaItem[0]));
      this.f.b(0, bundle);
    }
  }
  
  public class d extends l {
    public d(MediaBrowserServiceCompat this$0, Object param1Object, ResultReceiver param1ResultReceiver) {
      super(param1Object);
    }
    
    public void c(Bundle param1Bundle) {
      this.f.b(-1, param1Bundle);
    }
    
    public void h(Bundle param1Bundle) {
      this.f.b(0, param1Bundle);
    }
  }
  
  public static final abstract class e {}
  
  public class f implements IBinder.DeathRecipient {
    public final String a;
    
    public final int b;
    
    public final int c;
    
    public final q.e d;
    
    public final Bundle e;
    
    public final MediaBrowserServiceCompat.n f;
    
    public final HashMap g = new HashMap<Object, Object>();
    
    public f(MediaBrowserServiceCompat this$0, String param1String, int param1Int1, int param1Int2, Bundle param1Bundle, MediaBrowserServiceCompat.n param1n) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
      this.d = new q.e(param1String, param1Int1, param1Int2);
      this.e = param1Bundle;
      this.f = param1n;
    }
    
    public void binderDied() {
      this.h.d.post(new a(this));
    }
    
    public class a implements Runnable {
      public a(MediaBrowserServiceCompat.f this$0) {}
      
      public void run() {
        MediaBrowserServiceCompat.f f1 = this.a;
        f1.h.b.remove(f1.f.asBinder());
      }
    }
  }
  
  public class a implements Runnable {
    public a(MediaBrowserServiceCompat this$0) {}
    
    public void run() {
      MediaBrowserServiceCompat.f f1 = this.a;
      f1.h.b.remove(f1.f.asBinder());
    }
  }
  
  public static interface g {
    void a();
    
    IBinder d(Intent param1Intent);
  }
  
  public abstract class h implements g, a.d {
    public final List a = new ArrayList();
    
    public Object b;
    
    public Messenger c;
    
    public h(MediaBrowserServiceCompat this$0) {}
    
    public void b(String param1String, a.c param1c) {
      a a = new a(this, param1String, param1c);
      this.d.f(param1String, a);
    }
    
    public IBinder d(Intent param1Intent) {
      return a.a(this.b, param1Intent);
    }
    
    public a.a f(String param1String, int param1Int, Bundle param1Bundle) {
      if (param1Bundle != null && param1Bundle.getInt("extra_client_version", 0) != 0) {
        param1Bundle.remove("extra_client_version");
        this.c = new Messenger(this.d.d);
        Bundle bundle = new Bundle();
        bundle.putInt("extra_service_version", 2);
        i.c.b(bundle, "extra_messenger", this.c.getBinder());
        MediaSessionCompat.Token token = this.d.e;
        if (token != null) {
          IBinder iBinder;
          android.support.v4.media.session.b b = token.c();
          if (b == null) {
            b = null;
          } else {
            iBinder = b.asBinder();
          } 
          i.c.b(bundle, "extra_session_binder", iBinder);
        } else {
          this.a.add(bundle);
        } 
      } 
      MediaBrowserServiceCompat mediaBrowserServiceCompat = this.d;
      mediaBrowserServiceCompat.c = new MediaBrowserServiceCompat.f(mediaBrowserServiceCompat, param1String, -1, param1Int, param1Bundle, null);
      this.d.e(param1String, param1Int, param1Bundle);
      this.d.c = null;
      return null;
    }
    
    public class a extends MediaBrowserServiceCompat.l {
      public a(MediaBrowserServiceCompat.h this$0, Object param2Object, a.c param2c) {
        super(param2Object);
      }
      
      public void h(List<Parcel> param2List) {
        if (param2List != null) {
          ArrayList<Parcel> arrayList = new ArrayList();
          Iterator<MediaBrowserCompat.MediaItem> iterator = param2List.iterator();
          while (true) {
            param2List = arrayList;
            if (iterator.hasNext()) {
              MediaBrowserCompat.MediaItem mediaItem = iterator.next();
              Parcel parcel = Parcel.obtain();
              mediaItem.writeToParcel(parcel, 0);
              arrayList.add(parcel);
              continue;
            } 
            break;
          } 
        } else {
          param2List = null;
        } 
        this.f.b(param2List);
      }
    }
  }
  
  public class a extends l {
    public a(MediaBrowserServiceCompat this$0, Object param1Object, a.c param1c) {
      super(param1Object);
    }
    
    public void h(List<Parcel> param1List) {
      if (param1List != null) {
        ArrayList<Parcel> arrayList = new ArrayList();
        Iterator<MediaBrowserCompat.MediaItem> iterator = param1List.iterator();
        while (true) {
          param1List = arrayList;
          if (iterator.hasNext()) {
            MediaBrowserCompat.MediaItem mediaItem = iterator.next();
            Parcel parcel = Parcel.obtain();
            mediaItem.writeToParcel(parcel, 0);
            arrayList.add(parcel);
            continue;
          } 
          break;
        } 
      } else {
        param1List = null;
      } 
      this.f.b(param1List);
    }
  }
  
  public class i extends h implements b.b {
    public i(MediaBrowserServiceCompat this$0) {
      super(this$0);
    }
    
    public void a() {
      Object object = b.a((Context)this.e, this);
      this.b = object;
      a.b(object);
    }
    
    public void c(String param1String, a.c param1c) {
      a a = new a(this, param1String, param1c);
      this.e.h(param1String, a);
    }
    
    public class a extends MediaBrowserServiceCompat.l {
      public a(MediaBrowserServiceCompat.i this$0, Object param2Object, a.c param2c) {
        super(param2Object);
      }
      
      public void h(MediaBrowserCompat.MediaItem param2MediaItem) {
        a.c c1;
        Parcel parcel;
        if (param2MediaItem == null) {
          c1 = this.f;
          parcel = null;
        } else {
          parcel = Parcel.obtain();
          c1.writeToParcel(parcel, 0);
          c1 = this.f;
        } 
        c1.b(parcel);
      }
    }
  }
  
  public class a extends l {
    public a(MediaBrowserServiceCompat this$0, Object param1Object, a.c param1c) {
      super(param1Object);
    }
    
    public void h(MediaBrowserCompat.MediaItem param1MediaItem) {
      a.c c1;
      Parcel parcel;
      if (param1MediaItem == null) {
        c1 = this.f;
        parcel = null;
      } else {
        parcel = Parcel.obtain();
        c1.writeToParcel(parcel, 0);
        c1 = this.f;
      } 
      c1.b(parcel);
    }
  }
  
  public class j extends i implements c.c {
    public j(MediaBrowserServiceCompat this$0) {
      super(this$0);
    }
    
    public void a() {
      Object object = c.a((Context)this.f, (c.c)this);
      this.b = object;
      a.b(object);
    }
    
    public void e(String param1String, c.b param1b, Bundle param1Bundle) {
      a a = new a(this, param1String, param1b);
      this.f.g(param1String, a, param1Bundle);
    }
    
    public class a extends MediaBrowserServiceCompat.l {
      public a(MediaBrowserServiceCompat.j this$0, Object param2Object, c.b param2b) {
        super(param2Object);
      }
      
      public void h(List<Parcel> param2List) {
        if (param2List != null) {
          ArrayList<Parcel> arrayList = new ArrayList();
          Iterator<MediaBrowserCompat.MediaItem> iterator = param2List.iterator();
          while (true) {
            param2List = arrayList;
            if (iterator.hasNext()) {
              MediaBrowserCompat.MediaItem mediaItem = iterator.next();
              Parcel parcel = Parcel.obtain();
              mediaItem.writeToParcel(parcel, 0);
              arrayList.add(parcel);
              continue;
            } 
            break;
          } 
        } else {
          param2List = null;
        } 
        this.f.b(param2List, a());
      }
    }
  }
  
  public class a extends l {
    public a(MediaBrowserServiceCompat this$0, Object param1Object, c.b param1b) {
      super(param1Object);
    }
    
    public void h(List<Parcel> param1List) {
      if (param1List != null) {
        ArrayList<Parcel> arrayList = new ArrayList();
        Iterator<MediaBrowserCompat.MediaItem> iterator = param1List.iterator();
        while (true) {
          param1List = arrayList;
          if (iterator.hasNext()) {
            MediaBrowserCompat.MediaItem mediaItem = iterator.next();
            Parcel parcel = Parcel.obtain();
            mediaItem.writeToParcel(parcel, 0);
            arrayList.add(parcel);
            continue;
          } 
          break;
        } 
      } else {
        param1List = null;
      } 
      this.f.b(param1List, a());
    }
  }
  
  public class k extends j {
    public k(MediaBrowserServiceCompat this$0) {
      super(this$0);
    }
  }
  
  public static abstract class l {
    public final Object a;
    
    public boolean b;
    
    public boolean c;
    
    public boolean d;
    
    public int e;
    
    public l(Object param1Object) {
      this.a = param1Object;
    }
    
    public int a() {
      return this.e;
    }
    
    public boolean b() {
      return (this.b || this.c || this.d);
    }
    
    public void c(Bundle param1Bundle) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("It is not supported to send an error for ");
      stringBuilder.append(this.a);
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
    
    public abstract void d(Object param1Object);
    
    public void e(Bundle param1Bundle) {
      if (!this.c && !this.d) {
        this.d = true;
        c(param1Bundle);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendError() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.a);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void f(Object param1Object) {
      if (!this.c && !this.d) {
        this.c = true;
        d(param1Object);
        return;
      } 
      param1Object = new StringBuilder();
      param1Object.append("sendResult() called when either sendResult() or sendError() had already been called for: ");
      param1Object.append(this.a);
      throw new IllegalStateException(param1Object.toString());
    }
    
    public void g(int param1Int) {
      this.e = param1Int;
    }
  }
  
  public class m {
    public m(MediaBrowserServiceCompat this$0) {}
    
    public void a(String param1String, IBinder param1IBinder, Bundle param1Bundle, MediaBrowserServiceCompat.n param1n) {
      this.a.d.a(new c(this, param1n, param1String, param1IBinder, param1Bundle));
    }
    
    public void b(String param1String, int param1Int1, int param1Int2, Bundle param1Bundle, MediaBrowserServiceCompat.n param1n) {
      if (this.a.c(param1String, param1Int2)) {
        this.a.d.a(new a(this, param1n, param1String, param1Int1, param1Int2, param1Bundle));
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Package/uid mismatch: uid=");
      stringBuilder.append(param1Int2);
      stringBuilder.append(" package=");
      stringBuilder.append(param1String);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public void c(MediaBrowserServiceCompat.n param1n) {
      this.a.d.a(new b(this, param1n));
    }
    
    public void d(String param1String, ResultReceiver param1ResultReceiver, MediaBrowserServiceCompat.n param1n) {
      if (!TextUtils.isEmpty(param1String) && param1ResultReceiver != null)
        this.a.d.a(new e(this, param1n, param1String, param1ResultReceiver)); 
    }
    
    public void e(MediaBrowserServiceCompat.n param1n, String param1String, int param1Int1, int param1Int2, Bundle param1Bundle) {
      this.a.d.a(new f(this, param1n, param1String, param1Int1, param1Int2, param1Bundle));
    }
    
    public void f(String param1String, IBinder param1IBinder, MediaBrowserServiceCompat.n param1n) {
      this.a.d.a(new d(this, param1n, param1String, param1IBinder));
    }
    
    public void g(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, MediaBrowserServiceCompat.n param1n) {
      if (!TextUtils.isEmpty(param1String) && param1ResultReceiver != null)
        this.a.d.a(new h(this, param1n, param1String, param1Bundle, param1ResultReceiver)); 
    }
    
    public void h(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, MediaBrowserServiceCompat.n param1n) {
      if (!TextUtils.isEmpty(param1String) && param1ResultReceiver != null)
        this.a.d.a(new i(this, param1n, param1String, param1Bundle, param1ResultReceiver)); 
    }
    
    public void i(MediaBrowserServiceCompat.n param1n) {
      this.a.d.a(new g(this, param1n));
    }
    
    public class a implements Runnable {
      public a(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, int param2Int1, int param2Int2, Bundle param2Bundle) {}
      
      public void run() {
        IBinder iBinder = this.a.asBinder();
        this.f.a.b.remove(iBinder);
        MediaBrowserServiceCompat.f f = new MediaBrowserServiceCompat.f(this.f.a, this.b, this.c, this.d, this.e, this.a);
        MediaBrowserServiceCompat mediaBrowserServiceCompat = this.f.a;
        mediaBrowserServiceCompat.c = f;
        mediaBrowserServiceCompat.e(this.b, this.d, this.e);
        this.f.a.c = null;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No root for client ");
        stringBuilder.append(this.b);
        stringBuilder.append(" from service ");
        stringBuilder.append(getClass().getName());
        Log.i("MBServiceCompat", stringBuilder.toString());
        try {
          this.a.a();
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Calling onConnectFailed() failed. Ignoring. pkg=");
          stringBuilder1.append(this.b);
          Log.w("MBServiceCompat", stringBuilder1.toString());
        } 
      }
    }
    
    public class b implements Runnable {
      public b(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n) {}
      
      public void run() {
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.b.a.b.remove(iBinder);
        if (f != null)
          f.f.asBinder().unlinkToDeath(f, 0); 
      }
    }
    
    public class c implements Runnable {
      public c(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, IBinder param2IBinder, Bundle param2Bundle) {}
      
      public void run() {
        StringBuilder stringBuilder;
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.e.a.b.get(iBinder);
        if (f == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("addSubscription for callback that isn't registered id=");
          stringBuilder.append(this.b);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        } 
        this.e.a.a(this.b, (MediaBrowserServiceCompat.f)stringBuilder, this.c, this.d);
      }
    }
    
    public class d implements Runnable {
      public d(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, IBinder param2IBinder) {}
      
      public void run() {
        StringBuilder stringBuilder;
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.d.a.b.get(iBinder);
        if (f == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("removeSubscription for callback that isn't registered id=");
          stringBuilder.append(this.b);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        } 
        if (!this.d.a.p(this.b, (MediaBrowserServiceCompat.f)stringBuilder, this.c)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("removeSubscription called for ");
          stringBuilder.append(this.b);
          stringBuilder.append(" which is not subscribed");
          Log.w("MBServiceCompat", stringBuilder.toString());
        } 
      }
    }
    
    public class e implements Runnable {
      public e(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, ResultReceiver param2ResultReceiver) {}
      
      public void run() {
        StringBuilder stringBuilder;
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.d.a.b.get(iBinder);
        if (f == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("getMediaItem for callback that isn't registered id=");
          stringBuilder.append(this.b);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        } 
        this.d.a.n(this.b, (MediaBrowserServiceCompat.f)stringBuilder, this.c);
      }
    }
    
    public class f implements Runnable {
      public f(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, int param2Int1, int param2Int2, Bundle param2Bundle) {}
      
      public void run() {
        IBinder iBinder = this.a.asBinder();
        this.f.a.b.remove(iBinder);
        MediaBrowserServiceCompat.f f1 = new MediaBrowserServiceCompat.f(this.f.a, this.b, this.c, this.d, this.e, this.a);
        this.f.a.b.put(iBinder, f1);
        try {
          iBinder.linkToDeath(f1, 0);
        } catch (RemoteException remoteException) {
          Log.w("MBServiceCompat", "IBinder is already dead.");
        } 
      }
    }
    
    public class g implements Runnable {
      public g(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n) {}
      
      public void run() {
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.b.a.b.remove(iBinder);
        if (f != null)
          iBinder.unlinkToDeath(f, 0); 
      }
    }
    
    public class h implements Runnable {
      public h(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, Bundle param2Bundle, ResultReceiver param2ResultReceiver) {}
      
      public void run() {
        StringBuilder stringBuilder;
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.e.a.b.get(iBinder);
        if (f == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("search for callback that isn't registered query=");
          stringBuilder.append(this.b);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        } 
        this.e.a.o(this.b, this.c, (MediaBrowserServiceCompat.f)stringBuilder, this.d);
      }
    }
    
    public class i implements Runnable {
      public i(MediaBrowserServiceCompat.m this$0, MediaBrowserServiceCompat.n param2n, String param2String, Bundle param2Bundle, ResultReceiver param2ResultReceiver) {}
      
      public void run() {
        StringBuilder stringBuilder;
        IBinder iBinder = this.a.asBinder();
        MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.e.a.b.get(iBinder);
        if (f == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("sendCustomAction for callback that isn't registered action=");
          stringBuilder.append(this.b);
          stringBuilder.append(", extras=");
          stringBuilder.append(this.c);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        } 
        this.e.a.l(this.b, this.c, (MediaBrowserServiceCompat.f)stringBuilder, this.d);
      }
    }
  }
  
  public class a implements Runnable {
    public a(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, int param1Int1, int param1Int2, Bundle param1Bundle) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      this.f.a.b.remove(iBinder);
      MediaBrowserServiceCompat.f f = new MediaBrowserServiceCompat.f(this.f.a, this.b, this.c, this.d, this.e, this.a);
      MediaBrowserServiceCompat mediaBrowserServiceCompat = this.f.a;
      mediaBrowserServiceCompat.c = f;
      mediaBrowserServiceCompat.e(this.b, this.d, this.e);
      this.f.a.c = null;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No root for client ");
      stringBuilder.append(this.b);
      stringBuilder.append(" from service ");
      stringBuilder.append(getClass().getName());
      Log.i("MBServiceCompat", stringBuilder.toString());
      try {
        this.a.a();
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Calling onConnectFailed() failed. Ignoring. pkg=");
        stringBuilder1.append(this.b);
        Log.w("MBServiceCompat", stringBuilder1.toString());
      } 
    }
  }
  
  public class b implements Runnable {
    public b(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.b.a.b.remove(iBinder);
      if (f != null)
        f.f.asBinder().unlinkToDeath(f, 0); 
    }
  }
  
  public class c implements Runnable {
    public c(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, IBinder param1IBinder, Bundle param1Bundle) {}
    
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.e.a.b.get(iBinder);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("addSubscription for callback that isn't registered id=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.e.a.a(this.b, (MediaBrowserServiceCompat.f)stringBuilder, this.c, this.d);
    }
  }
  
  public class d implements Runnable {
    public d(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, IBinder param1IBinder) {}
    
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.d.a.b.get(iBinder);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("removeSubscription for callback that isn't registered id=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      if (!this.d.a.p(this.b, (MediaBrowserServiceCompat.f)stringBuilder, this.c)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("removeSubscription called for ");
        stringBuilder.append(this.b);
        stringBuilder.append(" which is not subscribed");
        Log.w("MBServiceCompat", stringBuilder.toString());
      } 
    }
  }
  
  public class e implements Runnable {
    public e(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, ResultReceiver param1ResultReceiver) {}
    
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.d.a.b.get(iBinder);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("getMediaItem for callback that isn't registered id=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.d.a.n(this.b, (MediaBrowserServiceCompat.f)stringBuilder, this.c);
    }
  }
  
  public class f implements Runnable {
    public f(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, int param1Int1, int param1Int2, Bundle param1Bundle) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      this.f.a.b.remove(iBinder);
      MediaBrowserServiceCompat.f f1 = new MediaBrowserServiceCompat.f(this.f.a, this.b, this.c, this.d, this.e, this.a);
      this.f.a.b.put(iBinder, f1);
      try {
        iBinder.linkToDeath(f1, 0);
      } catch (RemoteException remoteException) {
        Log.w("MBServiceCompat", "IBinder is already dead.");
      } 
    }
  }
  
  public class g implements Runnable {
    public g(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.b.a.b.remove(iBinder);
      if (f != null)
        iBinder.unlinkToDeath(f, 0); 
    }
  }
  
  public class h implements Runnable {
    public h(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {}
    
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.e.a.b.get(iBinder);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("search for callback that isn't registered query=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.e.a.o(this.b, this.c, (MediaBrowserServiceCompat.f)stringBuilder, this.d);
    }
  }
  
  public class i implements Runnable {
    public i(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.n param1n, String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {}
    
    public void run() {
      StringBuilder stringBuilder;
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.f f = (MediaBrowserServiceCompat.f)this.e.a.b.get(iBinder);
      if (f == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("sendCustomAction for callback that isn't registered action=");
        stringBuilder.append(this.b);
        stringBuilder.append(", extras=");
        stringBuilder.append(this.c);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.e.a.l(this.b, this.c, (MediaBrowserServiceCompat.f)stringBuilder, this.d);
    }
  }
  
  public static interface n {
    void a();
    
    IBinder asBinder();
    
    void b(String param1String, List param1List, Bundle param1Bundle1, Bundle param1Bundle2);
  }
  
  public static class o implements n {
    public final Messenger a;
    
    public o(Messenger param1Messenger) {
      this.a = param1Messenger;
    }
    
    public void a() {
      c(2, null);
    }
    
    public IBinder asBinder() {
      return this.a.getBinder();
    }
    
    public void b(String param1String, List<?> param1List, Bundle param1Bundle1, Bundle param1Bundle2) {
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      bundle.putBundle("data_options", param1Bundle1);
      bundle.putBundle("data_notify_children_changed_options", param1Bundle2);
      if (param1List != null) {
        ArrayList arrayList;
        if (param1List instanceof ArrayList) {
          arrayList = (ArrayList)param1List;
        } else {
          arrayList = new ArrayList(param1List);
        } 
        bundle.putParcelableArrayList("data_media_item_list", arrayList);
      } 
      c(3, bundle);
    }
    
    public final void c(int param1Int, Bundle param1Bundle) {
      Message message = Message.obtain();
      message.what = param1Int;
      message.arg1 = 2;
      message.setData(param1Bundle);
      this.a.send(message);
    }
  }
  
  public final class p extends Handler {
    public final MediaBrowserServiceCompat.m a;
    
    public p(MediaBrowserServiceCompat this$0) {
      this.a = new MediaBrowserServiceCompat.m(this$0);
    }
    
    public void a(Runnable param1Runnable) {
      if (Thread.currentThread() == getLooper().getThread()) {
        param1Runnable.run();
      } else {
        post(param1Runnable);
      } 
    }
    
    public void handleMessage(Message param1Message) {
      StringBuilder stringBuilder;
      Bundle bundle1 = param1Message.getData();
      switch (param1Message.what) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unhandled message: ");
          stringBuilder.append(param1Message);
          stringBuilder.append("\n  Service version: ");
          stringBuilder.append(2);
          stringBuilder.append("\n  Client version: ");
          stringBuilder.append(param1Message.arg1);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        case 9:
          bundle2 = stringBuilder.getBundle("data_custom_action_extras");
          MediaSessionCompat.a(bundle2);
          this.a.h(stringBuilder.getString("data_custom_action"), bundle2, (ResultReceiver)stringBuilder.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 8:
          bundle2 = stringBuilder.getBundle("data_search_extras");
          MediaSessionCompat.a(bundle2);
          this.a.g(stringBuilder.getString("data_search_query"), bundle2, (ResultReceiver)stringBuilder.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 7:
          this.a.i(new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 6:
          bundle2 = stringBuilder.getBundle("data_root_hints");
          MediaSessionCompat.a(bundle2);
          this.a.e(new MediaBrowserServiceCompat.o(param1Message.replyTo), stringBuilder.getString("data_package_name"), stringBuilder.getInt("data_calling_pid"), stringBuilder.getInt("data_calling_uid"), bundle2);
          return;
        case 5:
          this.a.d(stringBuilder.getString("data_media_item_id"), (ResultReceiver)stringBuilder.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 4:
          this.a.f(stringBuilder.getString("data_media_item_id"), i.c.a((Bundle)stringBuilder, "data_callback_token"), new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 3:
          bundle2 = stringBuilder.getBundle("data_options");
          MediaSessionCompat.a(bundle2);
          this.a.a(stringBuilder.getString("data_media_item_id"), i.c.a((Bundle)stringBuilder, "data_callback_token"), bundle2, new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 2:
          this.a.c(new MediaBrowserServiceCompat.o(param1Message.replyTo));
          return;
        case 1:
          break;
      } 
      Bundle bundle2 = stringBuilder.getBundle("data_root_hints");
      MediaSessionCompat.a(bundle2);
      this.a.b(stringBuilder.getString("data_package_name"), stringBuilder.getInt("data_calling_pid"), stringBuilder.getInt("data_calling_uid"), bundle2, new MediaBrowserServiceCompat.o(param1Message.replyTo));
    }
    
    public boolean sendMessageAtTime(Message param1Message, long param1Long) {
      Bundle bundle = param1Message.getData();
      bundle.setClassLoader(MediaBrowserCompat.class.getClassLoader());
      bundle.putInt("data_calling_uid", Binder.getCallingUid());
      bundle.putInt("data_calling_pid", Binder.getCallingPid());
      return super.sendMessageAtTime(param1Message, param1Long);
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/media/MediaBrowserServiceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */