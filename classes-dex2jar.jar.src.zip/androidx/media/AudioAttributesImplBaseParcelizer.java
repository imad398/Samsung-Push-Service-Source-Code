package androidx.media;

import q.c;
import y.a;

public final class AudioAttributesImplBaseParcelizer {
  public static c read(a parama) {
    c c = new c();
    c.a = parama.p(c.a, 1);
    c.b = parama.p(c.b, 2);
    c.c = parama.p(c.c, 3);
    c.d = parama.p(c.d, 4);
    return c;
  }
  
  public static void write(c paramc, a parama) {
    parama.x(false, false);
    parama.F(paramc.a, 1);
    parama.F(paramc.b, 2);
    parama.F(paramc.c, 3);
    parama.F(paramc.d, 4);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/media/AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */