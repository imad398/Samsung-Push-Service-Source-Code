package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import q.b;
import y.a;

public final class AudioAttributesImplApi21Parcelizer {
  public static b read(a parama) {
    b b = new b();
    b.a = (AudioAttributes)parama.r((Parcelable)b.a, 1);
    b.b = parama.p(b.b, 2);
    return b;
  }
  
  public static void write(b paramb, a parama) {
    parama.x(false, false);
    parama.H((Parcelable)paramb.a, 1);
    parama.F(paramb.b, 2);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/media/AudioAttributesImplApi21Parcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */