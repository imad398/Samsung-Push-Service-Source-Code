package androidx.media;

import android.content.Context;
import android.service.media.MediaBrowserService;

public abstract class b {
  public static Object a(Context paramContext, b paramb) {
    return new a(paramContext, paramb);
  }
  
  public static class a extends a.b {
    public a(Context param1Context, b.b param1b) {
      super(param1Context, param1b);
    }
    
    public void onLoadItem(String param1String, MediaBrowserService.Result param1Result) {
      ((b.b)this.a).c(param1String, new a.c(param1Result));
    }
  }
  
  public static interface b extends a.d {
    void c(String param1String, a.c param1c);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/media/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */