package androidx.media;

import q.a;
import y.a;
import y.c;

public final class AudioAttributesCompatParcelizer {
  public static AudioAttributesCompat read(a parama) {
    AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
    audioAttributesCompat.a = (a)parama.v((c)audioAttributesCompat.a, 1);
    return audioAttributesCompat;
  }
  
  public static void write(AudioAttributesCompat paramAudioAttributesCompat, a parama) {
    parama.x(false, false);
    parama.M((c)paramAudioAttributesCompat.a, 1);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/media/AudioAttributesCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */