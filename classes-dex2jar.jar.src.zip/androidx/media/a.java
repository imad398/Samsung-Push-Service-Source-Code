package androidx.media;

import android.content.Context;
import android.content.Intent;
import android.media.browse.MediaBrowser;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.service.media.MediaBrowserService;
import android.support.v4.media.session.MediaSessionCompat;
import java.util.ArrayList;
import java.util.List;

public abstract class a {
  public static IBinder a(Object paramObject, Intent paramIntent) {
    return ((MediaBrowserService)paramObject).onBind(paramIntent);
  }
  
  public static void b(Object paramObject) {
    ((MediaBrowserService)paramObject).onCreate();
  }
  
  public static abstract class a {
    public final String a;
    
    public final Bundle b;
  }
  
  public static abstract class b extends MediaBrowserService {
    public final a.d a;
    
    public b(Context param1Context, a.d param1d) {
      attachBaseContext(param1Context);
      this.a = param1d;
    }
    
    public MediaBrowserService.BrowserRoot onGetRoot(String param1String, int param1Int, Bundle param1Bundle) {
      MediaBrowserService.BrowserRoot browserRoot;
      MediaSessionCompat.a(param1Bundle);
      a.d d1 = this.a;
      a.a a2 = null;
      if (param1Bundle == null) {
        param1Bundle = null;
      } else {
        param1Bundle = new Bundle(param1Bundle);
      } 
      a.a a1 = d1.f(param1String, param1Int, param1Bundle);
      if (a1 == null) {
        a1 = a2;
      } else {
        browserRoot = new MediaBrowserService.BrowserRoot(a1.a, a1.b);
      } 
      return browserRoot;
    }
    
    public void onLoadChildren(String param1String, MediaBrowserService.Result param1Result) {
      this.a.b(param1String, new a.c(param1Result));
    }
  }
  
  public static class c {
    public MediaBrowserService.Result a;
    
    public c(MediaBrowserService.Result param1Result) {
      this.a = param1Result;
    }
    
    public List a(List param1List) {
      if (param1List == null)
        return null; 
      ArrayList<Object> arrayList = new ArrayList();
      for (Parcel parcel : param1List) {
        parcel.setDataPosition(0);
        arrayList.add(MediaBrowser.MediaItem.CREATOR.createFromParcel(parcel));
        parcel.recycle();
      } 
      return arrayList;
    }
    
    public void b(Object param1Object) {
      if (param1Object instanceof List) {
        this.a.sendResult(a((List)param1Object));
      } else if (param1Object instanceof Parcel) {
        param1Object = param1Object;
        param1Object.setDataPosition(0);
        this.a.sendResult(MediaBrowser.MediaItem.CREATOR.createFromParcel((Parcel)param1Object));
        param1Object.recycle();
      } else {
        this.a.sendResult(null);
      } 
    }
  }
  
  public static interface d {
    void b(String param1String, a.c param1c);
    
    a.a f(String param1String, int param1Int, Bundle param1Bundle);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/media/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */