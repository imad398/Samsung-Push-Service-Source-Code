package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.lifecycle.d;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import f.g;
import i.b0;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

public abstract class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, d, m {
  public static final g W = new g();
  
  public static final Object X = new Object();
  
  public boolean A;
  
  public boolean B;
  
  public boolean C;
  
  public boolean D;
  
  public boolean E;
  
  public boolean F = true;
  
  public boolean G;
  
  public ViewGroup H;
  
  public View I;
  
  public View J;
  
  public boolean K;
  
  public boolean L = true;
  
  public d M;
  
  public boolean N;
  
  public boolean O;
  
  public float P;
  
  public LayoutInflater Q;
  
  public boolean R;
  
  public androidx.lifecycle.e S = new androidx.lifecycle.e(this);
  
  public androidx.lifecycle.e T;
  
  public d U;
  
  public androidx.lifecycle.f V = new androidx.lifecycle.f();
  
  public int a = 0;
  
  public Bundle b;
  
  public SparseArray c;
  
  public Boolean d;
  
  public int e = -1;
  
  public String f;
  
  public Bundle g;
  
  public Fragment h;
  
  public int i = -1;
  
  public int j;
  
  public boolean k;
  
  public boolean l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public int q;
  
  public g r;
  
  public e s;
  
  public g t;
  
  public h u;
  
  public l v;
  
  public Fragment w;
  
  public int x;
  
  public int y;
  
  public String z;
  
  public static Fragment H(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      g g1 = W;
      Class<?> clazz1 = (Class)g1.get(paramString);
      Class<?> clazz2 = clazz1;
      if (clazz1 == null) {
        clazz2 = paramContext.getClassLoader().loadClass(paramString);
        g1.put(paramString, clazz2);
      } 
      Fragment fragment = clazz2.getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.X0(paramBundle);
      } 
      return fragment;
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), classNotFoundException);
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an");
      stringBuilder.append(" empty constructor that is public");
      throw new e(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new e(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new e(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  public static boolean O(Context paramContext, String paramString) {
    try {
      g g1 = W;
      Class<?> clazz1 = (Class)g1.get(paramString);
      Class<?> clazz2 = clazz1;
      if (clazz1 == null) {
        clazz2 = paramContext.getClassLoader().loadClass(paramString);
        g1.put(paramString, clazz2);
      } 
      return Fragment.class.isAssignableFrom(clazz2);
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
  
  public final Resources A() {
    return S0().getResources();
  }
  
  public void A0(Bundle paramBundle) {
    g g1 = this.t;
    if (g1 != null)
      g1.H0(); 
    this.a = 1;
    this.G = false;
    W(paramBundle);
    this.R = true;
    if (this.G) {
      this.S.c(androidx.lifecycle.b.a.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new n(stringBuilder.toString());
  }
  
  public Object B() {
    d d1 = this.M;
    if (d1 == null)
      return null; 
    Object object2 = d1.h;
    Object object1 = object2;
    if (object2 == X)
      object1 = q(); 
    return object1;
  }
  
  public boolean B0(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool1 = this.A;
    boolean bool2 = false;
    boolean bool = false;
    if (!bool1) {
      bool1 = bool;
      if (this.E) {
        bool1 = bool;
        if (this.F) {
          Z(paramMenu, paramMenuInflater);
          bool1 = true;
        } 
      } 
      g g1 = this.t;
      bool2 = bool1;
      if (g1 != null)
        bool2 = bool1 | g1.y(paramMenu, paramMenuInflater); 
    } 
    return bool2;
  }
  
  public Object C() {
    d d1 = this.M;
    return (d1 == null) ? null : d1.k;
  }
  
  public void C0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    g g1 = this.t;
    if (g1 != null)
      g1.H0(); 
    this.p = true;
    this.U = new c(this);
    this.T = null;
    View view = a0(paramLayoutInflater, paramViewGroup, paramBundle);
    this.I = view;
    if (view != null) {
      this.U.e();
      this.V.f(this.U);
    } else {
      if (this.T == null) {
        this.U = null;
        return;
      } 
      throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
    } 
  }
  
  public Object D() {
    d d1 = this.M;
    if (d1 == null)
      return null; 
    Object object2 = d1.l;
    Object object1 = object2;
    if (object2 == X)
      object1 = C(); 
    return object1;
  }
  
  public void D0() {
    this.S.c(androidx.lifecycle.b.a.ON_DESTROY);
    g g1 = this.t;
    if (g1 != null)
      g1.z(); 
    this.a = 0;
    this.G = false;
    this.R = false;
    b0();
    if (this.G) {
      this.t = null;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new n(stringBuilder.toString());
  }
  
  public int E() {
    d d1 = this.M;
    return (d1 == null) ? 0 : d1.c;
  }
  
  public void E0() {
    if (this.I != null)
      this.T.c(androidx.lifecycle.b.a.ON_DESTROY); 
    g g1 = this.t;
    if (g1 != null)
      g1.A(); 
    this.a = 1;
    this.G = false;
    d0();
    if (this.G) {
      p.a.b(this).c();
      this.p = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new n(stringBuilder.toString());
  }
  
  public View F() {
    return this.I;
  }
  
  public void F0() {
    this.G = false;
    e0();
    this.Q = null;
    if (this.G) {
      g g1 = this.t;
      if (g1 != null)
        if (this.D) {
          g1.z();
          this.t = null;
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Child FragmentManager of ");
          stringBuilder1.append(this);
          stringBuilder1.append(" was not ");
          stringBuilder1.append(" destroyed and this fragment is not retaining instance");
          throw new IllegalStateException(stringBuilder1.toString());
        }  
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new n(stringBuilder.toString());
  }
  
  public void G() {
    this.e = -1;
    this.f = null;
    this.k = false;
    this.l = false;
    this.m = false;
    this.n = false;
    this.o = false;
    this.q = 0;
    this.r = null;
    this.t = null;
    this.s = null;
    this.x = 0;
    this.y = 0;
    this.z = null;
    this.A = false;
    this.B = false;
    this.D = false;
  }
  
  public LayoutInflater G0(Bundle paramBundle) {
    LayoutInflater layoutInflater = f0(paramBundle);
    this.Q = layoutInflater;
    return layoutInflater;
  }
  
  public void H0() {
    onLowMemory();
    g g1 = this.t;
    if (g1 != null)
      g1.B(); 
  }
  
  public void I() {
    if (this.s != null) {
      g g1 = new g();
      this.t = g1;
      g1.m(this.s, new b(this), this);
      return;
    } 
    throw new IllegalStateException("Fragment has not been attached yet.");
  }
  
  public void I0(boolean paramBoolean) {
    j0(paramBoolean);
    g g1 = this.t;
    if (g1 != null)
      g1.C(paramBoolean); 
  }
  
  public boolean J() {
    d d1 = this.M;
    return (d1 == null) ? false : d1.q;
  }
  
  public boolean J0(MenuItem paramMenuItem) {
    if (!this.A) {
      if (this.E && this.F && k0(paramMenuItem))
        return true; 
      g g1 = this.t;
      if (g1 != null && g1.R(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public final boolean K() {
    boolean bool;
    if (this.q > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void K0(Menu paramMenu) {
    if (!this.A) {
      if (this.E && this.F)
        l0(paramMenu); 
      g g1 = this.t;
      if (g1 != null)
        g1.S(paramMenu); 
    } 
  }
  
  public boolean L() {
    d d1 = this.M;
    return (d1 == null) ? false : d1.o;
  }
  
  public void L0() {
    if (this.I != null)
      this.T.c(androidx.lifecycle.b.a.ON_PAUSE); 
    this.S.c(androidx.lifecycle.b.a.ON_PAUSE);
    g g1 = this.t;
    if (g1 != null)
      g1.T(); 
    this.a = 3;
    this.G = false;
    m0();
    if (this.G)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new n(stringBuilder.toString());
  }
  
  public final boolean M() {
    return this.l;
  }
  
  public void M0(boolean paramBoolean) {
    n0(paramBoolean);
    g g1 = this.t;
    if (g1 != null)
      g1.U(paramBoolean); 
  }
  
  public final boolean N() {
    g g1 = this.r;
    return (g1 == null) ? false : g1.e();
  }
  
  public boolean N0(Menu paramMenu) {
    boolean bool1 = this.A;
    boolean bool2 = false;
    boolean bool = false;
    if (!bool1) {
      bool1 = bool;
      if (this.E) {
        bool1 = bool;
        if (this.F) {
          o0(paramMenu);
          bool1 = true;
        } 
      } 
      g g1 = this.t;
      bool2 = bool1;
      if (g1 != null)
        bool2 = bool1 | g1.V(paramMenu); 
    } 
    return bool2;
  }
  
  public void O0() {
    g g1 = this.t;
    if (g1 != null) {
      g1.H0();
      this.t.f0();
    } 
    this.a = 4;
    this.G = false;
    q0();
    if (this.G) {
      g1 = this.t;
      if (g1 != null) {
        g1.W();
        this.t.f0();
      } 
      androidx.lifecycle.e e1 = this.S;
      androidx.lifecycle.b.a a = androidx.lifecycle.b.a.ON_RESUME;
      e1.c(a);
      if (this.I != null)
        this.T.c(a); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new n(stringBuilder.toString());
  }
  
  public void P() {
    g g1 = this.t;
    if (g1 != null)
      g1.H0(); 
  }
  
  public void P0(Bundle paramBundle) {
    r0(paramBundle);
    g g1 = this.t;
    if (g1 != null) {
      Parcelable parcelable = g1.T0();
      if (parcelable != null)
        paramBundle.putParcelable("android:support:fragments", parcelable); 
    } 
  }
  
  public void Q(Bundle paramBundle) {
    this.G = true;
  }
  
  public void Q0() {
    g g1 = this.t;
    if (g1 != null) {
      g1.H0();
      this.t.f0();
    } 
    this.a = 3;
    this.G = false;
    s0();
    if (this.G) {
      g1 = this.t;
      if (g1 != null)
        g1.X(); 
      androidx.lifecycle.e e1 = this.S;
      androidx.lifecycle.b.a a = androidx.lifecycle.b.a.ON_START;
      e1.c(a);
      if (this.I != null)
        this.T.c(a); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new n(stringBuilder.toString());
  }
  
  public void R(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  public void R0() {
    if (this.I != null)
      this.T.c(androidx.lifecycle.b.a.ON_STOP); 
    this.S.c(androidx.lifecycle.b.a.ON_STOP);
    g g1 = this.t;
    if (g1 != null)
      g1.Z(); 
    this.a = 2;
    this.G = false;
    t0();
    if (this.G)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new n(stringBuilder.toString());
  }
  
  public void S(Activity paramActivity) {
    this.G = true;
  }
  
  public final Context S0() {
    Context context = p();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void T(Context paramContext) {
    Activity activity;
    this.G = true;
    e e1 = this.s;
    if (e1 == null) {
      e1 = null;
    } else {
      activity = e1.d();
    } 
    if (activity != null) {
      this.G = false;
      S(activity);
    } 
  }
  
  public void T0(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        if (this.t == null)
          I(); 
        this.t.Q0(parcelable, this.u);
        this.u = null;
        this.t.x();
      } 
    } 
  }
  
  public void U(Fragment paramFragment) {}
  
  public final void U0(Bundle paramBundle) {
    SparseArray sparseArray = this.c;
    if (sparseArray != null) {
      this.J.restoreHierarchyState(sparseArray);
      this.c = null;
    } 
    this.G = false;
    v0(paramBundle);
    if (this.G) {
      if (this.I != null)
        this.T.c(androidx.lifecycle.b.a.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new n(stringBuilder.toString());
  }
  
  public boolean V(MenuItem paramMenuItem) {
    return false;
  }
  
  public void V0(View paramView) {
    (h()).a = paramView;
  }
  
  public void W(Bundle paramBundle) {
    this.G = true;
    T0(paramBundle);
    g g1 = this.t;
    if (g1 != null && !g1.u0(1))
      this.t.x(); 
  }
  
  public void W0(Animator paramAnimator) {
    (h()).b = paramAnimator;
  }
  
  public Animation X(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public void X0(Bundle paramBundle) {
    if (this.e < 0 || !N()) {
      this.g = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already active and state has been saved");
  }
  
  public Animator Y(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public void Y0(boolean paramBoolean) {
    (h()).q = paramBoolean;
  }
  
  public void Z(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  public final void Z0(int paramInt, Fragment paramFragment) {
    String str;
    this.e = paramInt;
    StringBuilder stringBuilder = new StringBuilder();
    if (paramFragment != null) {
      this();
      stringBuilder.append(paramFragment.f);
      str = ":";
    } else {
      this();
      str = "android:fragment:";
    } 
    stringBuilder.append(str);
    stringBuilder.append(this.e);
    this.f = stringBuilder.toString();
  }
  
  public View a0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    return null;
  }
  
  public void a1(int paramInt) {
    if (this.M == null && paramInt == 0)
      return; 
    (h()).d = paramInt;
  }
  
  public l b() {
    if (p() != null) {
      if (this.v == null)
        this.v = new l(); 
      return this.v;
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public void b0() {
    boolean bool = true;
    this.G = true;
    FragmentActivity fragmentActivity = j();
    if (fragmentActivity == null || !fragmentActivity.isChangingConfigurations())
      bool = false; 
    l l1 = this.v;
    if (l1 != null && !bool)
      l1.a(); 
  }
  
  public void b1(int paramInt1, int paramInt2) {
    if (this.M == null && paramInt1 == 0 && paramInt2 == 0)
      return; 
    h();
    d d1 = this.M;
    d1.e = paramInt1;
    d1.f = paramInt2;
  }
  
  public void c0() {}
  
  public void c1(f paramf) {
    h();
    d d1 = this.M;
    f f1 = d1.p;
    if (paramf == f1)
      return; 
    if (paramf == null || f1 == null) {
      if (d1.o)
        d1.p = paramf; 
      if (paramf != null)
        paramf.b(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void d0() {
    this.G = true;
  }
  
  public void d1(int paramInt) {
    (h()).c = paramInt;
  }
  
  public androidx.lifecycle.b e() {
    return (androidx.lifecycle.b)this.S;
  }
  
  public void e0() {
    this.G = true;
  }
  
  public void e1(Intent paramIntent, int paramInt, Bundle paramBundle) {
    e e1 = this.s;
    if (e1 != null) {
      e1.n(this, paramIntent, paramInt, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public void f() {
    d d1 = this.M;
    f f1 = null;
    if (d1 != null) {
      d1.o = false;
      f1 = d1.p;
      d1.p = null;
    } 
    if (f1 != null)
      f1.a(); 
  }
  
  public LayoutInflater f0(Bundle paramBundle) {
    return v(paramBundle);
  }
  
  public void f1() {
    g g1 = this.r;
    if (g1 == null || g1.m == null) {
      (h()).o = false;
      return;
    } 
    if (Looper.myLooper() != this.r.m.g().getLooper()) {
      this.r.m.g().postAtFrontOfQueue(new a(this));
    } else {
      f();
    } 
  }
  
  public void g(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.x));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.y));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.z);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.a);
    paramPrintWriter.print(" mIndex=");
    paramPrintWriter.print(this.e);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.f);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.q);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.k);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.l);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.m);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.n);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.A);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.B);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.F);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.E);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.C);
    paramPrintWriter.print(" mRetaining=");
    paramPrintWriter.print(this.D);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.L);
    if (this.r != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.r);
    } 
    if (this.s != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.s);
    } 
    if (this.w != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.w);
    } 
    if (this.g != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.g);
    } 
    if (this.b != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.b);
    } 
    if (this.c != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.c);
    } 
    if (this.h != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(this.h);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.j);
    } 
    if (w() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(w());
    } 
    if (this.H != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.H);
    } 
    if (this.I != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.I);
    } 
    if (this.J != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.I);
    } 
    if (m() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(m());
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(E());
    } 
    if (p() != null)
      p.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    if (this.t != null) {
      paramPrintWriter.print(paramString);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Child ");
      stringBuilder1.append(this.t);
      stringBuilder1.append(":");
      paramPrintWriter.println(stringBuilder1.toString());
      g g1 = this.t;
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(paramString);
      stringBuilder2.append("  ");
      g1.b(stringBuilder2.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    } 
  }
  
  public void g0(boolean paramBoolean) {}
  
  public final d h() {
    if (this.M == null)
      this.M = new d(); 
    return this.M;
  }
  
  public void h0(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.G = true;
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  public Fragment i(String paramString) {
    if (paramString.equals(this.f))
      return this; 
    g g1 = this.t;
    return (g1 != null) ? g1.k0(paramString) : null;
  }
  
  public void i0(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.G = true;
    e e1 = this.s;
    if (e1 == null) {
      e1 = null;
    } else {
      activity = e1.d();
    } 
    if (activity != null) {
      this.G = false;
      h0(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  public final FragmentActivity j() {
    FragmentActivity fragmentActivity;
    e e1 = this.s;
    if (e1 == null) {
      e1 = null;
    } else {
      fragmentActivity = (FragmentActivity)e1.d();
    } 
    return fragmentActivity;
  }
  
  public void j0(boolean paramBoolean) {}
  
  public boolean k() {
    d d1 = this.M;
    if (d1 != null) {
      Boolean bool = d1.n;
      return (bool == null) ? true : bool.booleanValue();
    } 
    return true;
  }
  
  public boolean k0(MenuItem paramMenuItem) {
    return false;
  }
  
  public boolean l() {
    d d1 = this.M;
    if (d1 != null) {
      Boolean bool = d1.m;
      return (bool == null) ? true : bool.booleanValue();
    } 
    return true;
  }
  
  public void l0(Menu paramMenu) {}
  
  public View m() {
    d d1 = this.M;
    return (d1 == null) ? null : d1.a;
  }
  
  public void m0() {
    this.G = true;
  }
  
  public Animator n() {
    d d1 = this.M;
    return (d1 == null) ? null : d1.b;
  }
  
  public void n0(boolean paramBoolean) {}
  
  public final f o() {
    if (this.t == null) {
      I();
      int i = this.a;
      if (i >= 4) {
        this.t.W();
      } else if (i >= 3) {
        this.t.X();
      } else if (i >= 2) {
        this.t.u();
      } else if (i >= 1) {
        this.t.x();
      } 
    } 
    return this.t;
  }
  
  public void o0(Menu paramMenu) {}
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.G = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    j().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onLowMemory() {
    this.G = true;
  }
  
  public Context p() {
    Context context;
    e e1 = this.s;
    if (e1 == null) {
      e1 = null;
    } else {
      context = e1.e();
    } 
    return context;
  }
  
  public void p0(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  public Object q() {
    d d1 = this.M;
    return (d1 == null) ? null : d1.g;
  }
  
  public void q0() {
    this.G = true;
  }
  
  public b0 r() {
    d d1 = this.M;
    if (d1 == null)
      return null; 
    d1.getClass();
    return null;
  }
  
  public void r0(Bundle paramBundle) {}
  
  public Object s() {
    d d1 = this.M;
    return (d1 == null) ? null : d1.i;
  }
  
  public void s0() {
    this.G = true;
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    e1(paramIntent, paramInt, null);
  }
  
  public b0 t() {
    d d1 = this.M;
    if (d1 == null)
      return null; 
    d1.getClass();
    return null;
  }
  
  public void t0() {
    this.G = true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    m.a.a(this, stringBuilder);
    if (this.e >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.e);
    } 
    if (this.x != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.x));
    } 
    if (this.z != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.z);
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public final f u() {
    return this.r;
  }
  
  public void u0(View paramView, Bundle paramBundle) {}
  
  public LayoutInflater v(Bundle paramBundle) {
    e e1 = this.s;
    if (e1 != null) {
      LayoutInflater layoutInflater = e1.j();
      o();
      n.c.a(layoutInflater, this.t.r0());
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void v0(Bundle paramBundle) {
    this.G = true;
  }
  
  public int w() {
    d d1 = this.M;
    return (d1 == null) ? 0 : d1.d;
  }
  
  public f w0() {
    return this.t;
  }
  
  public int x() {
    d d1 = this.M;
    return (d1 == null) ? 0 : d1.e;
  }
  
  public void x0(Bundle paramBundle) {
    g g1 = this.t;
    if (g1 != null)
      g1.H0(); 
    this.a = 2;
    this.G = false;
    Q(paramBundle);
    if (this.G) {
      g g2 = this.t;
      if (g2 != null)
        g2.u(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new n(stringBuilder.toString());
  }
  
  public int y() {
    d d1 = this.M;
    return (d1 == null) ? 0 : d1.f;
  }
  
  public void y0(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    g g1 = this.t;
    if (g1 != null)
      g1.v(paramConfiguration); 
  }
  
  public Object z() {
    d d1 = this.M;
    if (d1 == null)
      return null; 
    Object object2 = d1.j;
    Object object1 = object2;
    if (object2 == X)
      object1 = s(); 
    return object1;
  }
  
  public boolean z0(MenuItem paramMenuItem) {
    if (!this.A) {
      if (V(paramMenuItem))
        return true; 
      g g1 = this.t;
      if (g1 != null && g1.w(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    final Bundle mState;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      Bundle bundle = param1Parcel.readBundle();
      this.mState = bundle;
      if (param1ClassLoader != null && bundle != null)
        bundle.setClassLoader(param1ClassLoader); 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeBundle(this.mState);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator {
      public Fragment.SavedState a(Parcel param2Parcel) {
        return new Fragment.SavedState(param2Parcel, null);
      }
      
      public Fragment.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Fragment.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public Fragment.SavedState[] c(int param2Int) {
        return new Fragment.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator {
    public Fragment.SavedState a(Parcel param1Parcel) {
      return new Fragment.SavedState(param1Parcel, null);
    }
    
    public Fragment.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Fragment.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public Fragment.SavedState[] c(int param1Int) {
      return new Fragment.SavedState[param1Int];
    }
  }
  
  public class a implements Runnable {
    public a(Fragment this$0) {}
    
    public void run() {
      this.a.f();
    }
  }
  
  public class b extends c {
    public b(Fragment this$0) {}
    
    public Fragment a(Context param1Context, String param1String, Bundle param1Bundle) {
      return this.a.s.a(param1Context, param1String, param1Bundle);
    }
    
    public View b(int param1Int) {
      View view = this.a.I;
      if (view != null)
        return view.findViewById(param1Int); 
      throw new IllegalStateException("Fragment does not have a view");
    }
    
    public boolean c() {
      boolean bool;
      if (this.a.I != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
  
  public class c implements d {
    public c(Fragment this$0) {}
    
    public androidx.lifecycle.b e() {
      Fragment fragment = this.a;
      if (fragment.T == null)
        fragment.T = new androidx.lifecycle.e(fragment.U); 
      return (androidx.lifecycle.b)this.a.T;
    }
  }
  
  public static class d {
    public View a;
    
    public Animator b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public Object g = null;
    
    public Object h;
    
    public Object i;
    
    public Object j;
    
    public Object k;
    
    public Object l;
    
    public Boolean m;
    
    public Boolean n;
    
    public boolean o;
    
    public Fragment.f p;
    
    public boolean q;
    
    public d() {
      Object object = Fragment.X;
      this.h = object;
      this.i = null;
      this.j = object;
      this.k = null;
      this.l = object;
    }
  }
  
  public static class e extends RuntimeException {
    public e(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  public static interface f {
    void a();
    
    void b();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */