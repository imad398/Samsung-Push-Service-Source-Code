package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class g extends f implements LayoutInflater.Factory2 {
  public static boolean E = false;
  
  public static Field F;
  
  public static final Interpolator G = (Interpolator)new DecelerateInterpolator(2.5F);
  
  public static final Interpolator H = (Interpolator)new DecelerateInterpolator(1.5F);
  
  public static final Interpolator I = (Interpolator)new AccelerateInterpolator(2.5F);
  
  public static final Interpolator J = (Interpolator)new AccelerateInterpolator(1.5F);
  
  public SparseArray A = null;
  
  public ArrayList B;
  
  public h C;
  
  public Runnable D = new a(this);
  
  public ArrayList a;
  
  public boolean b;
  
  public int c = 0;
  
  public final ArrayList d = new ArrayList();
  
  public SparseArray e;
  
  public ArrayList f;
  
  public ArrayList g;
  
  public ArrayList h;
  
  public ArrayList i;
  
  public ArrayList j;
  
  public final CopyOnWriteArrayList k = new CopyOnWriteArrayList();
  
  public int l = 0;
  
  public e m;
  
  public c n;
  
  public Fragment o;
  
  public Fragment p;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public boolean t;
  
  public String u;
  
  public boolean v;
  
  public ArrayList w;
  
  public ArrayList x;
  
  public ArrayList y;
  
  public Bundle z = null;
  
  public static boolean B0(Animator paramAnimator) {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (byte b = 0; b < arrayOfPropertyValuesHolder.length; b++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[b].getPropertyName()))
          return true; 
      } 
    } else if (arrayOfPropertyValuesHolder instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)arrayOfPropertyValuesHolder).getChildAnimations();
      for (byte b = 0; b < arrayList.size(); b++) {
        if (B0(arrayList.get(b)))
          return true; 
      } 
    } 
    return false;
  }
  
  public static boolean C0(g paramg) {
    List list;
    Animation animation = paramg.a;
    if (animation instanceof AlphaAnimation)
      return true; 
    if (animation instanceof AnimationSet) {
      list = ((AnimationSet)animation).getAnimations();
      for (byte b = 0; b < list.size(); b++) {
        if (list.get(b) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return B0(((g)list).b);
  }
  
  public static int S0(int paramInt) {
    char c1 = ' ';
    if (paramInt != 4097)
      if (paramInt != 4099) {
        if (paramInt != 8194) {
          c1 = Character.MIN_VALUE;
        } else {
          c1 = 'ခ';
        } 
      } else {
        c1 = 'ဃ';
      }  
    return c1;
  }
  
  public static void Z0(View paramView, g paramg) {
    if (paramView != null && paramg != null && c1(paramView, paramg)) {
      Animator animator = paramg.b;
      if (animator != null) {
        animator.addListener((Animator.AnimatorListener)new h(paramView));
      } else {
        Animation.AnimationListener animationListener = p0(paramg.a);
        paramView.setLayerType(2, null);
        paramg.a.setAnimationListener(new e(paramView, animationListener));
      } 
    } 
  }
  
  public static void b1(h paramh) {
    if (paramh == null)
      return; 
    List list2 = paramh.b();
    if (list2 != null) {
      Iterator iterator = list2.iterator();
      while (iterator.hasNext())
        ((Fragment)iterator.next()).D = true; 
    } 
    List list1 = paramh.a();
    if (list1 != null) {
      Iterator<h> iterator = list1.iterator();
      while (iterator.hasNext())
        b1(iterator.next()); 
    } 
  }
  
  public static boolean c1(View paramView, g paramg) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramView != null)
      if (paramg == null) {
        bool2 = bool1;
      } else {
        bool2 = bool1;
        if (paramView.getLayerType() == 0) {
          bool2 = bool1;
          if (n.j.p(paramView)) {
            bool2 = bool1;
            if (C0(paramg))
              bool2 = true; 
          } 
        } 
      }  
    return bool2;
  }
  
  public static void g0(ArrayList<a> paramArrayList1, ArrayList<Boolean> paramArrayList2, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      a a = paramArrayList1.get(paramInt1);
      boolean bool = ((Boolean)paramArrayList2.get(paramInt1)).booleanValue();
      boolean bool1 = true;
      if (bool) {
        a.g(-1);
        if (paramInt1 != paramInt2 - 1)
          bool1 = false; 
        a.m(bool1);
      } else {
        a.g(1);
        a.l();
      } 
      paramInt1++;
    } 
  }
  
  public static int g1(int paramInt, boolean paramBoolean) {
    if (paramInt != 4097) {
      if (paramInt != 4099) {
        if (paramInt != 8194) {
          paramInt = -1;
        } else if (paramBoolean) {
          paramInt = 3;
        } else {
          paramInt = 4;
        } 
      } else if (paramBoolean) {
        paramInt = 5;
      } else {
        paramInt = 6;
      } 
    } else if (paramBoolean) {
      paramInt = 1;
    } else {
      paramInt = 2;
    } 
    return paramInt;
  }
  
  public static Animation.AnimationListener p0(Animation paramAnimation) {
    try {
      if (F == null) {
        Field field = Animation.class.getDeclaredField("mListener");
        F = field;
        field.setAccessible(true);
      } 
      Animation.AnimationListener animationListener = (Animation.AnimationListener)F.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException) {
      String str = "No field with the name mListener is found in Animation class";
      Log.e("FragmentManager", str, noSuchFieldException);
      noSuchFieldException = null;
    } catch (IllegalAccessException illegalAccessException) {
      String str = "Cannot access Animation's mListener field";
    } 
    return (Animation.AnimationListener)illegalAccessException;
  }
  
  public static g x0(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(H);
    alphaAnimation.setDuration(220L);
    return new g((Animation)alphaAnimation);
  }
  
  public static g z0(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(G);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(H);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new g((Animation)animationSet);
  }
  
  public void A() {
    Y(1);
  }
  
  public final void A0(f.b paramb) {
    int i = paramb.size();
    for (byte b1 = 0; b1 < i; b1++) {
      Fragment fragment = (Fragment)paramb.j(b1);
      if (!fragment.k) {
        View view = fragment.F();
        fragment.P = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  public void B() {
    for (byte b = 0; b < this.d.size(); b++) {
      Fragment fragment = this.d.get(b);
      if (fragment != null)
        fragment.H0(); 
    } 
  }
  
  public void C(boolean paramBoolean) {
    for (int i = this.d.size() - 1; i >= 0; i--) {
      Fragment fragment = this.d.get(i);
      if (fragment != null)
        fragment.I0(paramBoolean); 
    } 
  }
  
  public void D(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).D(paramFragment, paramBundle, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void D0(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    int i = this.l;
    int j = i;
    if (paramFragment.l)
      if (paramFragment.K()) {
        j = Math.min(i, 1);
      } else {
        j = Math.min(i, 0);
      }  
    G0(paramFragment, j, paramFragment.x(), paramFragment.y(), false);
    if (paramFragment.I != null) {
      Fragment fragment = l0(paramFragment);
      if (fragment != null) {
        View view = fragment.I;
        ViewGroup viewGroup = paramFragment.H;
        i = viewGroup.indexOfChild(view);
        j = viewGroup.indexOfChild(paramFragment.I);
        if (j < i) {
          viewGroup.removeViewAt(j);
          viewGroup.addView(paramFragment.I, i);
        } 
      } 
      if (paramFragment.N && paramFragment.H != null) {
        float f1 = paramFragment.P;
        if (f1 > 0.0F)
          paramFragment.I.setAlpha(f1); 
        paramFragment.P = 0.0F;
        paramFragment.N = false;
        g g1 = v0(paramFragment, paramFragment.x(), true, paramFragment.y());
        if (g1 != null) {
          Z0(paramFragment.I, g1);
          Animation animation = g1.a;
          if (animation != null) {
            paramFragment.I.startAnimation(animation);
          } else {
            g1.b.setTarget(paramFragment.I);
            g1.b.start();
          } 
        } 
      } 
    } 
    if (paramFragment.O)
      s(paramFragment); 
  }
  
  public void E(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).E(paramFragment, paramContext, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void E0(int paramInt, boolean paramBoolean) {
    if (this.m != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.l)
        return; 
      this.l = paramInt;
      if (this.e != null) {
        int i = this.d.size();
        for (paramInt = 0; paramInt < i; paramInt++)
          D0(this.d.get(paramInt)); 
        i = this.e.size();
        for (paramInt = 0; paramInt < i; paramInt++) {
          Fragment fragment = (Fragment)this.e.valueAt(paramInt);
          if (fragment != null && (fragment.l || fragment.B) && !fragment.N)
            D0(fragment); 
        } 
        e1();
        if (this.q) {
          e e1 = this.m;
          if (e1 != null && this.l == 4) {
            e1.o();
            this.q = false;
          } 
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  public void F(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).F(paramFragment, paramBundle, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void F0(Fragment paramFragment) {
    G0(paramFragment, this.l, 0, 0, false);
  }
  
  public void G(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).G(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void G0(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield k : Z
    //   4: istore #6
    //   6: iconst_1
    //   7: istore #7
    //   9: iconst_1
    //   10: istore #8
    //   12: iload #6
    //   14: ifeq -> 30
    //   17: aload_1
    //   18: getfield B : Z
    //   21: ifeq -> 27
    //   24: goto -> 30
    //   27: goto -> 44
    //   30: iload_2
    //   31: istore #9
    //   33: iload #9
    //   35: istore_2
    //   36: iload #9
    //   38: iconst_1
    //   39: if_icmple -> 44
    //   42: iconst_1
    //   43: istore_2
    //   44: iload_2
    //   45: istore #9
    //   47: aload_1
    //   48: getfield l : Z
    //   51: ifeq -> 93
    //   54: aload_1
    //   55: getfield a : I
    //   58: istore #10
    //   60: iload_2
    //   61: istore #9
    //   63: iload_2
    //   64: iload #10
    //   66: if_icmple -> 93
    //   69: iload #10
    //   71: ifne -> 87
    //   74: aload_1
    //   75: invokevirtual K : ()Z
    //   78: ifeq -> 87
    //   81: iconst_1
    //   82: istore #9
    //   84: goto -> 93
    //   87: aload_1
    //   88: getfield a : I
    //   91: istore #9
    //   93: aload_1
    //   94: getfield K : Z
    //   97: ifeq -> 119
    //   100: aload_1
    //   101: getfield a : I
    //   104: iconst_3
    //   105: if_icmpge -> 119
    //   108: iload #9
    //   110: iconst_2
    //   111: if_icmple -> 119
    //   114: iconst_2
    //   115: istore_2
    //   116: goto -> 122
    //   119: iload #9
    //   121: istore_2
    //   122: aload_1
    //   123: getfield a : I
    //   126: istore #10
    //   128: iload #10
    //   130: iload_2
    //   131: if_icmpgt -> 1387
    //   134: aload_1
    //   135: getfield m : Z
    //   138: ifeq -> 149
    //   141: aload_1
    //   142: getfield n : Z
    //   145: ifne -> 149
    //   148: return
    //   149: aload_1
    //   150: invokevirtual m : ()Landroid/view/View;
    //   153: ifnonnull -> 163
    //   156: aload_1
    //   157: invokevirtual n : ()Landroid/animation/Animator;
    //   160: ifnull -> 185
    //   163: aload_1
    //   164: aconst_null
    //   165: invokevirtual V0 : (Landroid/view/View;)V
    //   168: aload_1
    //   169: aconst_null
    //   170: invokevirtual W0 : (Landroid/animation/Animator;)V
    //   173: aload_0
    //   174: aload_1
    //   175: aload_1
    //   176: invokevirtual E : ()I
    //   179: iconst_0
    //   180: iconst_0
    //   181: iconst_1
    //   182: invokevirtual G0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   185: aload_1
    //   186: getfield a : I
    //   189: istore #9
    //   191: iload #9
    //   193: ifeq -> 227
    //   196: iload_2
    //   197: istore_3
    //   198: iload #9
    //   200: iconst_1
    //   201: if_icmpeq -> 784
    //   204: iload_2
    //   205: istore #4
    //   207: iload #9
    //   209: iconst_2
    //   210: if_icmpeq -> 1245
    //   213: iload_2
    //   214: istore_3
    //   215: iload #9
    //   217: iconst_3
    //   218: if_icmpeq -> 1310
    //   221: iload_2
    //   222: istore #9
    //   224: goto -> 1996
    //   227: iload_2
    //   228: istore_3
    //   229: iload_2
    //   230: ifle -> 784
    //   233: getstatic androidx/fragment/app/g.E : Z
    //   236: ifeq -> 276
    //   239: new java/lang/StringBuilder
    //   242: dup
    //   243: invokespecial <init> : ()V
    //   246: astore #11
    //   248: aload #11
    //   250: ldc_w 'moveto CREATED: '
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload #11
    //   259: aload_1
    //   260: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   263: pop
    //   264: ldc_w 'FragmentManager'
    //   267: aload #11
    //   269: invokevirtual toString : ()Ljava/lang/String;
    //   272: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   275: pop
    //   276: aload_1
    //   277: getfield b : Landroid/os/Bundle;
    //   280: astore #11
    //   282: iload_2
    //   283: istore_3
    //   284: aload #11
    //   286: ifnull -> 423
    //   289: aload #11
    //   291: aload_0
    //   292: getfield m : Landroidx/fragment/app/e;
    //   295: invokevirtual e : ()Landroid/content/Context;
    //   298: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   301: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   304: aload_1
    //   305: aload_1
    //   306: getfield b : Landroid/os/Bundle;
    //   309: ldc_w 'android:view_state'
    //   312: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   315: putfield c : Landroid/util/SparseArray;
    //   318: aload_0
    //   319: aload_1
    //   320: getfield b : Landroid/os/Bundle;
    //   323: ldc_w 'android:target_state'
    //   326: invokevirtual q0 : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   329: astore #11
    //   331: aload_1
    //   332: aload #11
    //   334: putfield h : Landroidx/fragment/app/Fragment;
    //   337: aload #11
    //   339: ifnull -> 357
    //   342: aload_1
    //   343: aload_1
    //   344: getfield b : Landroid/os/Bundle;
    //   347: ldc_w 'android:target_req_state'
    //   350: iconst_0
    //   351: invokevirtual getInt : (Ljava/lang/String;I)I
    //   354: putfield j : I
    //   357: aload_1
    //   358: getfield d : Ljava/lang/Boolean;
    //   361: astore #11
    //   363: aload #11
    //   365: ifnull -> 385
    //   368: aload_1
    //   369: aload #11
    //   371: invokevirtual booleanValue : ()Z
    //   374: putfield L : Z
    //   377: aload_1
    //   378: aconst_null
    //   379: putfield d : Ljava/lang/Boolean;
    //   382: goto -> 400
    //   385: aload_1
    //   386: aload_1
    //   387: getfield b : Landroid/os/Bundle;
    //   390: ldc_w 'android:user_visible_hint'
    //   393: iconst_1
    //   394: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   397: putfield L : Z
    //   400: iload_2
    //   401: istore_3
    //   402: aload_1
    //   403: getfield L : Z
    //   406: ifne -> 423
    //   409: aload_1
    //   410: iconst_1
    //   411: putfield K : Z
    //   414: iload_2
    //   415: istore_3
    //   416: iload_2
    //   417: iconst_2
    //   418: if_icmple -> 423
    //   421: iconst_2
    //   422: istore_3
    //   423: aload_0
    //   424: getfield m : Landroidx/fragment/app/e;
    //   427: astore #12
    //   429: aload_1
    //   430: aload #12
    //   432: putfield s : Landroidx/fragment/app/e;
    //   435: aload_0
    //   436: getfield o : Landroidx/fragment/app/Fragment;
    //   439: astore #11
    //   441: aload_1
    //   442: aload #11
    //   444: putfield w : Landroidx/fragment/app/Fragment;
    //   447: aload #11
    //   449: ifnull -> 462
    //   452: aload #11
    //   454: getfield t : Landroidx/fragment/app/g;
    //   457: astore #11
    //   459: goto -> 469
    //   462: aload #12
    //   464: invokevirtual f : ()Landroidx/fragment/app/g;
    //   467: astore #11
    //   469: aload_1
    //   470: aload #11
    //   472: putfield r : Landroidx/fragment/app/g;
    //   475: aload_1
    //   476: getfield h : Landroidx/fragment/app/Fragment;
    //   479: astore #11
    //   481: aload #11
    //   483: ifnull -> 601
    //   486: aload_0
    //   487: getfield e : Landroid/util/SparseArray;
    //   490: aload #11
    //   492: getfield e : I
    //   495: invokevirtual get : (I)Ljava/lang/Object;
    //   498: astore #12
    //   500: aload_1
    //   501: getfield h : Landroidx/fragment/app/Fragment;
    //   504: astore #11
    //   506: aload #12
    //   508: aload #11
    //   510: if_acmpne -> 535
    //   513: aload #11
    //   515: getfield a : I
    //   518: iconst_1
    //   519: if_icmpge -> 601
    //   522: aload_0
    //   523: aload #11
    //   525: iconst_1
    //   526: iconst_0
    //   527: iconst_0
    //   528: iconst_1
    //   529: invokevirtual G0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   532: goto -> 601
    //   535: new java/lang/StringBuilder
    //   538: dup
    //   539: invokespecial <init> : ()V
    //   542: astore #11
    //   544: aload #11
    //   546: ldc_w 'Fragment '
    //   549: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   552: pop
    //   553: aload #11
    //   555: aload_1
    //   556: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   559: pop
    //   560: aload #11
    //   562: ldc_w ' declared target fragment '
    //   565: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   568: pop
    //   569: aload #11
    //   571: aload_1
    //   572: getfield h : Landroidx/fragment/app/Fragment;
    //   575: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   578: pop
    //   579: aload #11
    //   581: ldc_w ' that does not belong to this FragmentManager!'
    //   584: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   587: pop
    //   588: new java/lang/IllegalStateException
    //   591: dup
    //   592: aload #11
    //   594: invokevirtual toString : ()Ljava/lang/String;
    //   597: invokespecial <init> : (Ljava/lang/String;)V
    //   600: athrow
    //   601: aload_0
    //   602: aload_1
    //   603: aload_0
    //   604: getfield m : Landroidx/fragment/app/e;
    //   607: invokevirtual e : ()Landroid/content/Context;
    //   610: iconst_0
    //   611: invokevirtual J : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   614: aload_1
    //   615: iconst_0
    //   616: putfield G : Z
    //   619: aload_1
    //   620: aload_0
    //   621: getfield m : Landroidx/fragment/app/e;
    //   624: invokevirtual e : ()Landroid/content/Context;
    //   627: invokevirtual T : (Landroid/content/Context;)V
    //   630: aload_1
    //   631: getfield G : Z
    //   634: ifeq -> 737
    //   637: aload_1
    //   638: getfield w : Landroidx/fragment/app/Fragment;
    //   641: astore #11
    //   643: aload #11
    //   645: ifnonnull -> 659
    //   648: aload_0
    //   649: getfield m : Landroidx/fragment/app/e;
    //   652: aload_1
    //   653: invokevirtual h : (Landroidx/fragment/app/Fragment;)V
    //   656: goto -> 665
    //   659: aload #11
    //   661: aload_1
    //   662: invokevirtual U : (Landroidx/fragment/app/Fragment;)V
    //   665: aload_0
    //   666: aload_1
    //   667: aload_0
    //   668: getfield m : Landroidx/fragment/app/e;
    //   671: invokevirtual e : ()Landroid/content/Context;
    //   674: iconst_0
    //   675: invokevirtual E : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   678: aload_1
    //   679: getfield R : Z
    //   682: ifne -> 716
    //   685: aload_0
    //   686: aload_1
    //   687: aload_1
    //   688: getfield b : Landroid/os/Bundle;
    //   691: iconst_0
    //   692: invokevirtual K : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   695: aload_1
    //   696: aload_1
    //   697: getfield b : Landroid/os/Bundle;
    //   700: invokevirtual A0 : (Landroid/os/Bundle;)V
    //   703: aload_0
    //   704: aload_1
    //   705: aload_1
    //   706: getfield b : Landroid/os/Bundle;
    //   709: iconst_0
    //   710: invokevirtual F : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   713: goto -> 729
    //   716: aload_1
    //   717: aload_1
    //   718: getfield b : Landroid/os/Bundle;
    //   721: invokevirtual T0 : (Landroid/os/Bundle;)V
    //   724: aload_1
    //   725: iconst_1
    //   726: putfield a : I
    //   729: aload_1
    //   730: iconst_0
    //   731: putfield D : Z
    //   734: goto -> 784
    //   737: new java/lang/StringBuilder
    //   740: dup
    //   741: invokespecial <init> : ()V
    //   744: astore #11
    //   746: aload #11
    //   748: ldc_w 'Fragment '
    //   751: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: pop
    //   755: aload #11
    //   757: aload_1
    //   758: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   761: pop
    //   762: aload #11
    //   764: ldc_w ' did not call through to super.onAttach()'
    //   767: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   770: pop
    //   771: new androidx/fragment/app/n
    //   774: dup
    //   775: aload #11
    //   777: invokevirtual toString : ()Ljava/lang/String;
    //   780: invokespecial <init> : (Ljava/lang/String;)V
    //   783: athrow
    //   784: aload_0
    //   785: aload_1
    //   786: invokevirtual e0 : (Landroidx/fragment/app/Fragment;)V
    //   789: iload_3
    //   790: istore #4
    //   792: iload_3
    //   793: iconst_1
    //   794: if_icmple -> 1245
    //   797: getstatic androidx/fragment/app/g.E : Z
    //   800: ifeq -> 840
    //   803: new java/lang/StringBuilder
    //   806: dup
    //   807: invokespecial <init> : ()V
    //   810: astore #11
    //   812: aload #11
    //   814: ldc_w 'moveto ACTIVITY_CREATED: '
    //   817: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   820: pop
    //   821: aload #11
    //   823: aload_1
    //   824: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   827: pop
    //   828: ldc_w 'FragmentManager'
    //   831: aload #11
    //   833: invokevirtual toString : ()Ljava/lang/String;
    //   836: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   839: pop
    //   840: aload_1
    //   841: getfield m : Z
    //   844: ifne -> 1204
    //   847: aload_1
    //   848: getfield y : I
    //   851: istore_2
    //   852: iload_2
    //   853: ifeq -> 1057
    //   856: iload_2
    //   857: iconst_m1
    //   858: if_icmpne -> 911
    //   861: new java/lang/StringBuilder
    //   864: dup
    //   865: invokespecial <init> : ()V
    //   868: astore #11
    //   870: aload #11
    //   872: ldc_w 'Cannot create fragment '
    //   875: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   878: pop
    //   879: aload #11
    //   881: aload_1
    //   882: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   885: pop
    //   886: aload #11
    //   888: ldc_w ' for a container view with no id'
    //   891: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   894: pop
    //   895: aload_0
    //   896: new java/lang/IllegalArgumentException
    //   899: dup
    //   900: aload #11
    //   902: invokevirtual toString : ()Ljava/lang/String;
    //   905: invokespecial <init> : (Ljava/lang/String;)V
    //   908: invokevirtual f1 : (Ljava/lang/RuntimeException;)V
    //   911: aload_0
    //   912: getfield n : Landroidx/fragment/app/c;
    //   915: aload_1
    //   916: getfield y : I
    //   919: invokevirtual b : (I)Landroid/view/View;
    //   922: checkcast android/view/ViewGroup
    //   925: astore #12
    //   927: aload #12
    //   929: astore #11
    //   931: aload #12
    //   933: ifnonnull -> 1060
    //   936: aload #12
    //   938: astore #11
    //   940: aload_1
    //   941: getfield o : Z
    //   944: ifne -> 1060
    //   947: aload_1
    //   948: invokevirtual A : ()Landroid/content/res/Resources;
    //   951: aload_1
    //   952: getfield y : I
    //   955: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   958: astore #11
    //   960: goto -> 970
    //   963: astore #11
    //   965: ldc_w 'unknown'
    //   968: astore #11
    //   970: new java/lang/StringBuilder
    //   973: dup
    //   974: invokespecial <init> : ()V
    //   977: astore #13
    //   979: aload #13
    //   981: ldc_w 'No view found for id 0x'
    //   984: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   987: pop
    //   988: aload #13
    //   990: aload_1
    //   991: getfield y : I
    //   994: invokestatic toHexString : (I)Ljava/lang/String;
    //   997: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1000: pop
    //   1001: aload #13
    //   1003: ldc_w ' ('
    //   1006: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1009: pop
    //   1010: aload #13
    //   1012: aload #11
    //   1014: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1017: pop
    //   1018: aload #13
    //   1020: ldc_w ') for fragment '
    //   1023: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1026: pop
    //   1027: aload #13
    //   1029: aload_1
    //   1030: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1033: pop
    //   1034: aload_0
    //   1035: new java/lang/IllegalArgumentException
    //   1038: dup
    //   1039: aload #13
    //   1041: invokevirtual toString : ()Ljava/lang/String;
    //   1044: invokespecial <init> : (Ljava/lang/String;)V
    //   1047: invokevirtual f1 : (Ljava/lang/RuntimeException;)V
    //   1050: aload #12
    //   1052: astore #11
    //   1054: goto -> 1060
    //   1057: aconst_null
    //   1058: astore #11
    //   1060: aload_1
    //   1061: aload #11
    //   1063: putfield H : Landroid/view/ViewGroup;
    //   1066: aload_1
    //   1067: aload_1
    //   1068: aload_1
    //   1069: getfield b : Landroid/os/Bundle;
    //   1072: invokevirtual G0 : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1075: aload #11
    //   1077: aload_1
    //   1078: getfield b : Landroid/os/Bundle;
    //   1081: invokevirtual C0 : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1084: aload_1
    //   1085: getfield I : Landroid/view/View;
    //   1088: astore #12
    //   1090: aload #12
    //   1092: ifnull -> 1199
    //   1095: aload_1
    //   1096: aload #12
    //   1098: putfield J : Landroid/view/View;
    //   1101: aload #12
    //   1103: iconst_0
    //   1104: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1107: aload #11
    //   1109: ifnull -> 1121
    //   1112: aload #11
    //   1114: aload_1
    //   1115: getfield I : Landroid/view/View;
    //   1118: invokevirtual addView : (Landroid/view/View;)V
    //   1121: aload_1
    //   1122: getfield A : Z
    //   1125: ifeq -> 1137
    //   1128: aload_1
    //   1129: getfield I : Landroid/view/View;
    //   1132: bipush #8
    //   1134: invokevirtual setVisibility : (I)V
    //   1137: aload_1
    //   1138: aload_1
    //   1139: getfield I : Landroid/view/View;
    //   1142: aload_1
    //   1143: getfield b : Landroid/os/Bundle;
    //   1146: invokevirtual u0 : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1149: aload_0
    //   1150: aload_1
    //   1151: aload_1
    //   1152: getfield I : Landroid/view/View;
    //   1155: aload_1
    //   1156: getfield b : Landroid/os/Bundle;
    //   1159: iconst_0
    //   1160: invokevirtual P : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1163: aload_1
    //   1164: getfield I : Landroid/view/View;
    //   1167: invokevirtual getVisibility : ()I
    //   1170: ifne -> 1187
    //   1173: aload_1
    //   1174: getfield H : Landroid/view/ViewGroup;
    //   1177: ifnull -> 1187
    //   1180: iload #8
    //   1182: istore #5
    //   1184: goto -> 1190
    //   1187: iconst_0
    //   1188: istore #5
    //   1190: aload_1
    //   1191: iload #5
    //   1193: putfield N : Z
    //   1196: goto -> 1204
    //   1199: aload_1
    //   1200: aconst_null
    //   1201: putfield J : Landroid/view/View;
    //   1204: aload_1
    //   1205: aload_1
    //   1206: getfield b : Landroid/os/Bundle;
    //   1209: invokevirtual x0 : (Landroid/os/Bundle;)V
    //   1212: aload_0
    //   1213: aload_1
    //   1214: aload_1
    //   1215: getfield b : Landroid/os/Bundle;
    //   1218: iconst_0
    //   1219: invokevirtual D : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1222: aload_1
    //   1223: getfield I : Landroid/view/View;
    //   1226: ifnull -> 1237
    //   1229: aload_1
    //   1230: aload_1
    //   1231: getfield b : Landroid/os/Bundle;
    //   1234: invokevirtual U0 : (Landroid/os/Bundle;)V
    //   1237: aload_1
    //   1238: aconst_null
    //   1239: putfield b : Landroid/os/Bundle;
    //   1242: iload_3
    //   1243: istore #4
    //   1245: iload #4
    //   1247: istore_3
    //   1248: iload #4
    //   1250: iconst_2
    //   1251: if_icmple -> 1310
    //   1254: getstatic androidx/fragment/app/g.E : Z
    //   1257: ifeq -> 1297
    //   1260: new java/lang/StringBuilder
    //   1263: dup
    //   1264: invokespecial <init> : ()V
    //   1267: astore #11
    //   1269: aload #11
    //   1271: ldc_w 'moveto STARTED: '
    //   1274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1277: pop
    //   1278: aload #11
    //   1280: aload_1
    //   1281: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1284: pop
    //   1285: ldc_w 'FragmentManager'
    //   1288: aload #11
    //   1290: invokevirtual toString : ()Ljava/lang/String;
    //   1293: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1296: pop
    //   1297: aload_1
    //   1298: invokevirtual Q0 : ()V
    //   1301: aload_0
    //   1302: aload_1
    //   1303: iconst_0
    //   1304: invokevirtual N : (Landroidx/fragment/app/Fragment;Z)V
    //   1307: iload #4
    //   1309: istore_3
    //   1310: iload_3
    //   1311: istore #9
    //   1313: iload_3
    //   1314: iconst_3
    //   1315: if_icmple -> 1996
    //   1318: getstatic androidx/fragment/app/g.E : Z
    //   1321: ifeq -> 1361
    //   1324: new java/lang/StringBuilder
    //   1327: dup
    //   1328: invokespecial <init> : ()V
    //   1331: astore #11
    //   1333: aload #11
    //   1335: ldc_w 'moveto RESUMED: '
    //   1338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1341: pop
    //   1342: aload #11
    //   1344: aload_1
    //   1345: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1348: pop
    //   1349: ldc_w 'FragmentManager'
    //   1352: aload #11
    //   1354: invokevirtual toString : ()Ljava/lang/String;
    //   1357: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1360: pop
    //   1361: aload_1
    //   1362: invokevirtual O0 : ()V
    //   1365: aload_0
    //   1366: aload_1
    //   1367: iconst_0
    //   1368: invokevirtual L : (Landroidx/fragment/app/Fragment;Z)V
    //   1371: aload_1
    //   1372: aconst_null
    //   1373: putfield b : Landroid/os/Bundle;
    //   1376: aload_1
    //   1377: aconst_null
    //   1378: putfield c : Landroid/util/SparseArray;
    //   1381: iload_3
    //   1382: istore #9
    //   1384: goto -> 1996
    //   1387: iload_2
    //   1388: istore #9
    //   1390: iload #10
    //   1392: iload_2
    //   1393: if_icmple -> 1996
    //   1396: iload #10
    //   1398: iconst_1
    //   1399: if_icmpeq -> 1778
    //   1402: iload #10
    //   1404: iconst_2
    //   1405: if_icmpeq -> 1542
    //   1408: iload #10
    //   1410: iconst_3
    //   1411: if_icmpeq -> 1484
    //   1414: iload #10
    //   1416: iconst_4
    //   1417: if_icmpeq -> 1426
    //   1420: iload_2
    //   1421: istore #9
    //   1423: goto -> 1996
    //   1426: iload_2
    //   1427: iconst_4
    //   1428: if_icmpge -> 1484
    //   1431: getstatic androidx/fragment/app/g.E : Z
    //   1434: ifeq -> 1474
    //   1437: new java/lang/StringBuilder
    //   1440: dup
    //   1441: invokespecial <init> : ()V
    //   1444: astore #11
    //   1446: aload #11
    //   1448: ldc_w 'movefrom RESUMED: '
    //   1451: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1454: pop
    //   1455: aload #11
    //   1457: aload_1
    //   1458: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1461: pop
    //   1462: ldc_w 'FragmentManager'
    //   1465: aload #11
    //   1467: invokevirtual toString : ()Ljava/lang/String;
    //   1470: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1473: pop
    //   1474: aload_1
    //   1475: invokevirtual L0 : ()V
    //   1478: aload_0
    //   1479: aload_1
    //   1480: iconst_0
    //   1481: invokevirtual I : (Landroidx/fragment/app/Fragment;Z)V
    //   1484: iload_2
    //   1485: iconst_3
    //   1486: if_icmpge -> 1542
    //   1489: getstatic androidx/fragment/app/g.E : Z
    //   1492: ifeq -> 1532
    //   1495: new java/lang/StringBuilder
    //   1498: dup
    //   1499: invokespecial <init> : ()V
    //   1502: astore #11
    //   1504: aload #11
    //   1506: ldc_w 'movefrom STARTED: '
    //   1509: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1512: pop
    //   1513: aload #11
    //   1515: aload_1
    //   1516: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1519: pop
    //   1520: ldc_w 'FragmentManager'
    //   1523: aload #11
    //   1525: invokevirtual toString : ()Ljava/lang/String;
    //   1528: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1531: pop
    //   1532: aload_1
    //   1533: invokevirtual R0 : ()V
    //   1536: aload_0
    //   1537: aload_1
    //   1538: iconst_0
    //   1539: invokevirtual O : (Landroidx/fragment/app/Fragment;Z)V
    //   1542: iload_2
    //   1543: iconst_2
    //   1544: if_icmpge -> 1778
    //   1547: getstatic androidx/fragment/app/g.E : Z
    //   1550: ifeq -> 1590
    //   1553: new java/lang/StringBuilder
    //   1556: dup
    //   1557: invokespecial <init> : ()V
    //   1560: astore #11
    //   1562: aload #11
    //   1564: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1567: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1570: pop
    //   1571: aload #11
    //   1573: aload_1
    //   1574: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1577: pop
    //   1578: ldc_w 'FragmentManager'
    //   1581: aload #11
    //   1583: invokevirtual toString : ()Ljava/lang/String;
    //   1586: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1589: pop
    //   1590: aload_1
    //   1591: getfield I : Landroid/view/View;
    //   1594: ifnull -> 1620
    //   1597: aload_0
    //   1598: getfield m : Landroidx/fragment/app/e;
    //   1601: aload_1
    //   1602: invokevirtual m : (Landroidx/fragment/app/Fragment;)Z
    //   1605: ifeq -> 1620
    //   1608: aload_1
    //   1609: getfield c : Landroid/util/SparseArray;
    //   1612: ifnonnull -> 1620
    //   1615: aload_0
    //   1616: aload_1
    //   1617: invokevirtual V0 : (Landroidx/fragment/app/Fragment;)V
    //   1620: aload_1
    //   1621: invokevirtual E0 : ()V
    //   1624: aload_0
    //   1625: aload_1
    //   1626: iconst_0
    //   1627: invokevirtual Q : (Landroidx/fragment/app/Fragment;Z)V
    //   1630: aload_1
    //   1631: getfield I : Landroid/view/View;
    //   1634: astore #11
    //   1636: aload #11
    //   1638: ifnull -> 1745
    //   1641: aload_1
    //   1642: getfield H : Landroid/view/ViewGroup;
    //   1645: astore #12
    //   1647: aload #12
    //   1649: ifnull -> 1745
    //   1652: aload #12
    //   1654: aload #11
    //   1656: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1659: aload_1
    //   1660: getfield I : Landroid/view/View;
    //   1663: invokevirtual clearAnimation : ()V
    //   1666: aload_0
    //   1667: getfield l : I
    //   1670: ifle -> 1713
    //   1673: aload_0
    //   1674: getfield t : Z
    //   1677: ifne -> 1713
    //   1680: aload_1
    //   1681: getfield I : Landroid/view/View;
    //   1684: invokevirtual getVisibility : ()I
    //   1687: ifne -> 1713
    //   1690: aload_1
    //   1691: getfield P : F
    //   1694: fconst_0
    //   1695: fcmpl
    //   1696: iflt -> 1713
    //   1699: aload_0
    //   1700: aload_1
    //   1701: iload_3
    //   1702: iconst_0
    //   1703: iload #4
    //   1705: invokevirtual v0 : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/g$g;
    //   1708: astore #11
    //   1710: goto -> 1716
    //   1713: aconst_null
    //   1714: astore #11
    //   1716: aload_1
    //   1717: fconst_0
    //   1718: putfield P : F
    //   1721: aload #11
    //   1723: ifnull -> 1734
    //   1726: aload_0
    //   1727: aload_1
    //   1728: aload #11
    //   1730: iload_2
    //   1731: invokevirtual l : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/g$g;I)V
    //   1734: aload_1
    //   1735: getfield H : Landroid/view/ViewGroup;
    //   1738: aload_1
    //   1739: getfield I : Landroid/view/View;
    //   1742: invokevirtual removeView : (Landroid/view/View;)V
    //   1745: aload_1
    //   1746: aconst_null
    //   1747: putfield H : Landroid/view/ViewGroup;
    //   1750: aload_1
    //   1751: aconst_null
    //   1752: putfield I : Landroid/view/View;
    //   1755: aload_1
    //   1756: aconst_null
    //   1757: putfield U : Landroidx/lifecycle/d;
    //   1760: aload_1
    //   1761: getfield V : Landroidx/lifecycle/f;
    //   1764: aconst_null
    //   1765: invokevirtual f : (Ljava/lang/Object;)V
    //   1768: aload_1
    //   1769: aconst_null
    //   1770: putfield J : Landroid/view/View;
    //   1773: aload_1
    //   1774: iconst_0
    //   1775: putfield n : Z
    //   1778: iload_2
    //   1779: istore #9
    //   1781: iload_2
    //   1782: iconst_1
    //   1783: if_icmpge -> 1996
    //   1786: aload_0
    //   1787: getfield t : Z
    //   1790: ifeq -> 1842
    //   1793: aload_1
    //   1794: invokevirtual m : ()Landroid/view/View;
    //   1797: ifnull -> 1819
    //   1800: aload_1
    //   1801: invokevirtual m : ()Landroid/view/View;
    //   1804: astore #11
    //   1806: aload_1
    //   1807: aconst_null
    //   1808: invokevirtual V0 : (Landroid/view/View;)V
    //   1811: aload #11
    //   1813: invokevirtual clearAnimation : ()V
    //   1816: goto -> 1842
    //   1819: aload_1
    //   1820: invokevirtual n : ()Landroid/animation/Animator;
    //   1823: ifnull -> 1842
    //   1826: aload_1
    //   1827: invokevirtual n : ()Landroid/animation/Animator;
    //   1830: astore #11
    //   1832: aload_1
    //   1833: aconst_null
    //   1834: invokevirtual W0 : (Landroid/animation/Animator;)V
    //   1837: aload #11
    //   1839: invokevirtual cancel : ()V
    //   1842: aload_1
    //   1843: invokevirtual m : ()Landroid/view/View;
    //   1846: ifnonnull -> 1984
    //   1849: aload_1
    //   1850: invokevirtual n : ()Landroid/animation/Animator;
    //   1853: ifnull -> 1859
    //   1856: goto -> 1984
    //   1859: getstatic androidx/fragment/app/g.E : Z
    //   1862: ifeq -> 1902
    //   1865: new java/lang/StringBuilder
    //   1868: dup
    //   1869: invokespecial <init> : ()V
    //   1872: astore #11
    //   1874: aload #11
    //   1876: ldc_w 'movefrom CREATED: '
    //   1879: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1882: pop
    //   1883: aload #11
    //   1885: aload_1
    //   1886: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1889: pop
    //   1890: ldc_w 'FragmentManager'
    //   1893: aload #11
    //   1895: invokevirtual toString : ()Ljava/lang/String;
    //   1898: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1901: pop
    //   1902: aload_1
    //   1903: getfield D : Z
    //   1906: ifne -> 1922
    //   1909: aload_1
    //   1910: invokevirtual D0 : ()V
    //   1913: aload_0
    //   1914: aload_1
    //   1915: iconst_0
    //   1916: invokevirtual G : (Landroidx/fragment/app/Fragment;Z)V
    //   1919: goto -> 1927
    //   1922: aload_1
    //   1923: iconst_0
    //   1924: putfield a : I
    //   1927: aload_1
    //   1928: invokevirtual F0 : ()V
    //   1931: aload_0
    //   1932: aload_1
    //   1933: iconst_0
    //   1934: invokevirtual H : (Landroidx/fragment/app/Fragment;Z)V
    //   1937: iload_2
    //   1938: istore #9
    //   1940: iload #5
    //   1942: ifne -> 1996
    //   1945: aload_1
    //   1946: getfield D : Z
    //   1949: ifne -> 1963
    //   1952: aload_0
    //   1953: aload_1
    //   1954: invokevirtual y0 : (Landroidx/fragment/app/Fragment;)V
    //   1957: iload_2
    //   1958: istore #9
    //   1960: goto -> 1996
    //   1963: aload_1
    //   1964: aconst_null
    //   1965: putfield s : Landroidx/fragment/app/e;
    //   1968: aload_1
    //   1969: aconst_null
    //   1970: putfield w : Landroidx/fragment/app/Fragment;
    //   1973: aload_1
    //   1974: aconst_null
    //   1975: putfield r : Landroidx/fragment/app/g;
    //   1978: iload_2
    //   1979: istore #9
    //   1981: goto -> 1996
    //   1984: aload_1
    //   1985: iload_2
    //   1986: invokevirtual d1 : (I)V
    //   1989: iload #7
    //   1991: istore #9
    //   1993: goto -> 1996
    //   1996: aload_1
    //   1997: getfield a : I
    //   2000: iload #9
    //   2002: if_icmpeq -> 2093
    //   2005: new java/lang/StringBuilder
    //   2008: dup
    //   2009: invokespecial <init> : ()V
    //   2012: astore #11
    //   2014: aload #11
    //   2016: ldc_w 'moveToState: Fragment state for '
    //   2019: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2022: pop
    //   2023: aload #11
    //   2025: aload_1
    //   2026: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2029: pop
    //   2030: aload #11
    //   2032: ldc_w ' not updated inline; '
    //   2035: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2038: pop
    //   2039: aload #11
    //   2041: ldc_w 'expected state '
    //   2044: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2047: pop
    //   2048: aload #11
    //   2050: iload #9
    //   2052: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2055: pop
    //   2056: aload #11
    //   2058: ldc_w ' found '
    //   2061: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2064: pop
    //   2065: aload #11
    //   2067: aload_1
    //   2068: getfield a : I
    //   2071: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2074: pop
    //   2075: ldc_w 'FragmentManager'
    //   2078: aload #11
    //   2080: invokevirtual toString : ()Ljava/lang/String;
    //   2083: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2086: pop
    //   2087: aload_1
    //   2088: iload #9
    //   2090: putfield a : I
    //   2093: return
    // Exception table:
    //   from	to	target	type
    //   947	960	963	android/content/res/Resources$NotFoundException
  }
  
  public void H(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).H(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void H0() {
    this.C = null;
    byte b = 0;
    this.r = false;
    this.s = false;
    int i = this.d.size();
    while (b < i) {
      Fragment fragment = this.d.get(b);
      if (fragment != null)
        fragment.P(); 
      b++;
    } 
  }
  
  public void I(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).I(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void I0(Fragment paramFragment) {
    if (paramFragment.K) {
      if (this.b) {
        this.v = true;
        return;
      } 
      paramFragment.K = false;
      G0(paramFragment, this.l, 0, 0, false);
    } 
  }
  
  public void J(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).J(paramFragment, paramContext, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public final boolean J0(String paramString, int paramInt1, int paramInt2) {
    f0();
    d0(true);
    Fragment fragment = this.p;
    if (fragment != null && paramInt1 < 0 && paramString == null) {
      f f1 = fragment.w0();
      if (f1 != null && f1.g())
        return true; 
    } 
    boolean bool = K0(this.w, this.x, paramString, paramInt1, paramInt2);
    if (bool) {
      this.b = true;
      try {
        O0(this.w, this.x);
      } finally {
        q();
      } 
    } 
    a0();
    o();
    return bool;
  }
  
  public void K(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).K(paramFragment, paramBundle, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public boolean K0(ArrayList paramArrayList1, ArrayList paramArrayList2, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Ljava/util/ArrayList;
    //   4: astore #6
    //   6: aload #6
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 70
    //   17: iload #4
    //   19: ifge -> 70
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 70
    //   29: aload #6
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield f : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: goto -> 322
    //   70: aload_3
    //   71: ifnonnull -> 88
    //   74: iload #4
    //   76: iflt -> 82
    //   79: goto -> 88
    //   82: iconst_m1
    //   83: istore #4
    //   85: goto -> 260
    //   88: aload #6
    //   90: invokevirtual size : ()I
    //   93: iconst_1
    //   94: isub
    //   95: istore #7
    //   97: iload #7
    //   99: iflt -> 159
    //   102: aload_0
    //   103: getfield f : Ljava/util/ArrayList;
    //   106: iload #7
    //   108: invokevirtual get : (I)Ljava/lang/Object;
    //   111: checkcast androidx/fragment/app/a
    //   114: astore #6
    //   116: aload_3
    //   117: ifnull -> 135
    //   120: aload_3
    //   121: aload #6
    //   123: invokevirtual o : ()Ljava/lang/String;
    //   126: invokevirtual equals : (Ljava/lang/Object;)Z
    //   129: ifeq -> 135
    //   132: goto -> 159
    //   135: iload #4
    //   137: iflt -> 153
    //   140: iload #4
    //   142: aload #6
    //   144: getfield m : I
    //   147: if_icmpne -> 153
    //   150: goto -> 159
    //   153: iinc #7, -1
    //   156: goto -> 97
    //   159: iload #7
    //   161: ifge -> 166
    //   164: iconst_0
    //   165: ireturn
    //   166: iload #7
    //   168: istore #8
    //   170: iload #5
    //   172: iconst_1
    //   173: iand
    //   174: ifeq -> 256
    //   177: iload #7
    //   179: iconst_1
    //   180: isub
    //   181: istore #5
    //   183: iload #5
    //   185: istore #8
    //   187: iload #5
    //   189: iflt -> 256
    //   192: aload_0
    //   193: getfield f : Ljava/util/ArrayList;
    //   196: iload #5
    //   198: invokevirtual get : (I)Ljava/lang/Object;
    //   201: checkcast androidx/fragment/app/a
    //   204: astore #6
    //   206: aload_3
    //   207: ifnull -> 226
    //   210: iload #5
    //   212: istore #7
    //   214: aload_3
    //   215: aload #6
    //   217: invokevirtual o : ()Ljava/lang/String;
    //   220: invokevirtual equals : (Ljava/lang/Object;)Z
    //   223: ifne -> 177
    //   226: iload #5
    //   228: istore #8
    //   230: iload #4
    //   232: iflt -> 256
    //   235: iload #5
    //   237: istore #8
    //   239: iload #4
    //   241: aload #6
    //   243: getfield m : I
    //   246: if_icmpne -> 256
    //   249: iload #5
    //   251: istore #7
    //   253: goto -> 177
    //   256: iload #8
    //   258: istore #4
    //   260: iload #4
    //   262: aload_0
    //   263: getfield f : Ljava/util/ArrayList;
    //   266: invokevirtual size : ()I
    //   269: iconst_1
    //   270: isub
    //   271: if_icmpne -> 276
    //   274: iconst_0
    //   275: ireturn
    //   276: aload_0
    //   277: getfield f : Ljava/util/ArrayList;
    //   280: invokevirtual size : ()I
    //   283: iconst_1
    //   284: isub
    //   285: istore #5
    //   287: iload #5
    //   289: iload #4
    //   291: if_icmple -> 322
    //   294: aload_1
    //   295: aload_0
    //   296: getfield f : Ljava/util/ArrayList;
    //   299: iload #5
    //   301: invokevirtual remove : (I)Ljava/lang/Object;
    //   304: invokevirtual add : (Ljava/lang/Object;)Z
    //   307: pop
    //   308: aload_2
    //   309: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   312: invokevirtual add : (Ljava/lang/Object;)Z
    //   315: pop
    //   316: iinc #5, -1
    //   319: goto -> 287
    //   322: iconst_1
    //   323: ireturn
  }
  
  public void L(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).L(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public final int L0(ArrayList<a> paramArrayList1, ArrayList<Boolean> paramArrayList2, int paramInt1, int paramInt2, f.b paramb) {
    int i = paramInt2 - 1;
    int j;
    for (j = paramInt2; i >= paramInt1; j = k) {
      boolean bool1;
      a a = paramArrayList1.get(i);
      boolean bool = ((Boolean)paramArrayList2.get(i)).booleanValue();
      if (a.s() && !a.q(paramArrayList1, i + 1, paramInt2)) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      int k = j;
      if (bool1) {
        if (this.B == null)
          this.B = new ArrayList(); 
        m m = new m(a, bool);
        this.B.add(m);
        a.u(m);
        if (bool) {
          a.l();
        } else {
          a.m(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList1.remove(i);
          paramArrayList1.add(k, a);
        } 
        h(paramb);
      } 
      i--;
    } 
    return j;
  }
  
  public void M(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).M(paramFragment, paramBundle, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void M0(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.e < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      f1(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putInt(paramString, paramFragment.e);
  }
  
  public void N(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).N(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void N0(Fragment paramFragment) {
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.q);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.K();
    if (!paramFragment.B || (bool ^ true) != 0)
      synchronized (this.d) {
        this.d.remove(paramFragment);
        if (paramFragment.E && paramFragment.F)
          this.q = true; 
        paramFragment.k = false;
        paramFragment.l = true;
        return;
      }  
  }
  
  public void O(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).O(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public final void O0(ArrayList paramArrayList1, ArrayList<Boolean> paramArrayList2) {
    if (paramArrayList1 == null || paramArrayList1.isEmpty())
      return; 
    if (paramArrayList2 != null && paramArrayList1.size() == paramArrayList2.size()) {
      i0(paramArrayList1, paramArrayList2);
      int i = paramArrayList1.size();
      int j = 0;
      int k;
      for (k = 0; j < i; k = n) {
        int m = j;
        int n = k;
        if (!((a)paramArrayList1.get(j)).t) {
          if (k != j)
            h0(paramArrayList1, paramArrayList2, k, j); 
          k = j + 1;
          n = k;
          if (((Boolean)paramArrayList2.get(j)).booleanValue())
            while (true) {
              n = k;
              if (k < i) {
                n = k;
                if (((Boolean)paramArrayList2.get(k)).booleanValue()) {
                  n = k;
                  if (!((a)paramArrayList1.get(k)).t) {
                    k++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          h0(paramArrayList1, paramArrayList2, j, n);
          m = n - 1;
        } 
        j = m + 1;
      } 
      if (k != i)
        h0(paramArrayList1, paramArrayList2, k, i); 
      return;
    } 
    throw new IllegalStateException("Internal error with the back stack records");
  }
  
  public void P(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).P(paramFragment, paramView, paramBundle, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void P0() {
    ArrayList arrayList = this.j;
    if (arrayList == null || arrayList.size() <= 0)
      return; 
    android.support.v4.media.a.a(this.j.get(0));
    throw null;
  }
  
  public void Q(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.o;
    if (fragment != null) {
      f f1 = fragment.u();
      if (f1 instanceof g)
        ((g)f1).Q(paramFragment, true); 
    } 
    Iterator iterator = this.k.iterator();
    if (iterator.hasNext()) {
      android.support.v4.media.a.a(iterator.next());
      throw null;
    } 
  }
  
  public void Q0(Parcelable<h> paramParcelable, h paramh) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_1
    //   6: checkcast androidx/fragment/app/FragmentManagerState
    //   9: astore_3
    //   10: aload_3
    //   11: getfield mActive : [Landroidx/fragment/app/FragmentState;
    //   14: ifnonnull -> 18
    //   17: return
    //   18: aload_2
    //   19: ifnull -> 320
    //   22: aload_2
    //   23: invokevirtual b : ()Ljava/util/List;
    //   26: astore #4
    //   28: aload_2
    //   29: invokevirtual a : ()Ljava/util/List;
    //   32: astore #5
    //   34: aload_2
    //   35: invokevirtual c : ()Ljava/util/List;
    //   38: astore #6
    //   40: aload #4
    //   42: ifnull -> 57
    //   45: aload #4
    //   47: invokeinterface size : ()I
    //   52: istore #7
    //   54: goto -> 60
    //   57: iconst_0
    //   58: istore #7
    //   60: iconst_0
    //   61: istore #8
    //   63: aload #5
    //   65: astore #9
    //   67: aload #6
    //   69: astore_1
    //   70: iload #8
    //   72: iload #7
    //   74: if_icmpge -> 326
    //   77: aload #4
    //   79: iload #8
    //   81: invokeinterface get : (I)Ljava/lang/Object;
    //   86: checkcast androidx/fragment/app/Fragment
    //   89: astore_1
    //   90: getstatic androidx/fragment/app/g.E : Z
    //   93: ifeq -> 133
    //   96: new java/lang/StringBuilder
    //   99: dup
    //   100: invokespecial <init> : ()V
    //   103: astore #9
    //   105: aload #9
    //   107: ldc_w 'restoreAllState: re-attaching retained '
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: aload #9
    //   116: aload_1
    //   117: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: ldc_w 'FragmentManager'
    //   124: aload #9
    //   126: invokevirtual toString : ()Ljava/lang/String;
    //   129: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   132: pop
    //   133: iconst_0
    //   134: istore #10
    //   136: aload_3
    //   137: getfield mActive : [Landroidx/fragment/app/FragmentState;
    //   140: astore #9
    //   142: iload #10
    //   144: aload #9
    //   146: arraylength
    //   147: if_icmpge -> 171
    //   150: aload #9
    //   152: iload #10
    //   154: aaload
    //   155: getfield mIndex : I
    //   158: aload_1
    //   159: getfield e : I
    //   162: if_icmpeq -> 171
    //   165: iinc #10, 1
    //   168: goto -> 136
    //   171: iload #10
    //   173: aload #9
    //   175: arraylength
    //   176: if_icmpne -> 223
    //   179: new java/lang/StringBuilder
    //   182: dup
    //   183: invokespecial <init> : ()V
    //   186: astore #9
    //   188: aload #9
    //   190: ldc_w 'Could not find active fragment with index '
    //   193: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: pop
    //   197: aload #9
    //   199: aload_1
    //   200: getfield e : I
    //   203: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: aload_0
    //   208: new java/lang/IllegalStateException
    //   211: dup
    //   212: aload #9
    //   214: invokevirtual toString : ()Ljava/lang/String;
    //   217: invokespecial <init> : (Ljava/lang/String;)V
    //   220: invokevirtual f1 : (Ljava/lang/RuntimeException;)V
    //   223: aload_3
    //   224: getfield mActive : [Landroidx/fragment/app/FragmentState;
    //   227: iload #10
    //   229: aaload
    //   230: astore #11
    //   232: aload #11
    //   234: aload_1
    //   235: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   238: aload_1
    //   239: aconst_null
    //   240: putfield c : Landroid/util/SparseArray;
    //   243: aload_1
    //   244: iconst_0
    //   245: putfield q : I
    //   248: aload_1
    //   249: iconst_0
    //   250: putfield n : Z
    //   253: aload_1
    //   254: iconst_0
    //   255: putfield k : Z
    //   258: aload_1
    //   259: aconst_null
    //   260: putfield h : Landroidx/fragment/app/Fragment;
    //   263: aload #11
    //   265: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   268: astore #9
    //   270: aload #9
    //   272: ifnull -> 314
    //   275: aload #9
    //   277: aload_0
    //   278: getfield m : Landroidx/fragment/app/e;
    //   281: invokevirtual e : ()Landroid/content/Context;
    //   284: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   287: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   290: aload_1
    //   291: aload #11
    //   293: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   296: ldc_w 'android:view_state'
    //   299: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   302: putfield c : Landroid/util/SparseArray;
    //   305: aload_1
    //   306: aload #11
    //   308: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   311: putfield b : Landroid/os/Bundle;
    //   314: iinc #8, 1
    //   317: goto -> 63
    //   320: aconst_null
    //   321: astore #9
    //   323: aload #9
    //   325: astore_1
    //   326: aload_0
    //   327: new android/util/SparseArray
    //   330: dup
    //   331: aload_3
    //   332: getfield mActive : [Landroidx/fragment/app/FragmentState;
    //   335: arraylength
    //   336: invokespecial <init> : (I)V
    //   339: putfield e : Landroid/util/SparseArray;
    //   342: iconst_0
    //   343: istore #7
    //   345: aload_3
    //   346: getfield mActive : [Landroidx/fragment/app/FragmentState;
    //   349: astore #5
    //   351: iload #7
    //   353: aload #5
    //   355: arraylength
    //   356: if_icmpge -> 552
    //   359: aload #5
    //   361: iload #7
    //   363: aaload
    //   364: astore #4
    //   366: aload #4
    //   368: ifnull -> 546
    //   371: aload #9
    //   373: ifnull -> 405
    //   376: iload #7
    //   378: aload #9
    //   380: invokeinterface size : ()I
    //   385: if_icmpge -> 405
    //   388: aload #9
    //   390: iload #7
    //   392: invokeinterface get : (I)Ljava/lang/Object;
    //   397: checkcast androidx/fragment/app/h
    //   400: astore #5
    //   402: goto -> 408
    //   405: aconst_null
    //   406: astore #5
    //   408: aload_1
    //   409: ifnull -> 439
    //   412: iload #7
    //   414: aload_1
    //   415: invokeinterface size : ()I
    //   420: if_icmpge -> 439
    //   423: aload_1
    //   424: iload #7
    //   426: invokeinterface get : (I)Ljava/lang/Object;
    //   431: checkcast androidx/lifecycle/l
    //   434: astore #6
    //   436: goto -> 442
    //   439: aconst_null
    //   440: astore #6
    //   442: aload #4
    //   444: aload_0
    //   445: getfield m : Landroidx/fragment/app/e;
    //   448: aload_0
    //   449: getfield n : Landroidx/fragment/app/c;
    //   452: aload_0
    //   453: getfield o : Landroidx/fragment/app/Fragment;
    //   456: aload #5
    //   458: aload #6
    //   460: invokevirtual a : (Landroidx/fragment/app/e;Landroidx/fragment/app/c;Landroidx/fragment/app/Fragment;Landroidx/fragment/app/h;Landroidx/lifecycle/l;)Landroidx/fragment/app/Fragment;
    //   463: astore #5
    //   465: getstatic androidx/fragment/app/g.E : Z
    //   468: ifeq -> 526
    //   471: new java/lang/StringBuilder
    //   474: dup
    //   475: invokespecial <init> : ()V
    //   478: astore #6
    //   480: aload #6
    //   482: ldc_w 'restoreAllState: active #'
    //   485: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: pop
    //   489: aload #6
    //   491: iload #7
    //   493: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   496: pop
    //   497: aload #6
    //   499: ldc_w ': '
    //   502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   505: pop
    //   506: aload #6
    //   508: aload #5
    //   510: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   513: pop
    //   514: ldc_w 'FragmentManager'
    //   517: aload #6
    //   519: invokevirtual toString : ()Ljava/lang/String;
    //   522: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   525: pop
    //   526: aload_0
    //   527: getfield e : Landroid/util/SparseArray;
    //   530: aload #5
    //   532: getfield e : I
    //   535: aload #5
    //   537: invokevirtual put : (ILjava/lang/Object;)V
    //   540: aload #4
    //   542: aconst_null
    //   543: putfield mInstance : Landroidx/fragment/app/Fragment;
    //   546: iinc #7, 1
    //   549: goto -> 345
    //   552: aload_2
    //   553: ifnull -> 699
    //   556: aload_2
    //   557: invokevirtual b : ()Ljava/util/List;
    //   560: astore_2
    //   561: aload_2
    //   562: ifnull -> 576
    //   565: aload_2
    //   566: invokeinterface size : ()I
    //   571: istore #7
    //   573: goto -> 579
    //   576: iconst_0
    //   577: istore #7
    //   579: iconst_0
    //   580: istore #8
    //   582: iload #8
    //   584: iload #7
    //   586: if_icmpge -> 699
    //   589: aload_2
    //   590: iload #8
    //   592: invokeinterface get : (I)Ljava/lang/Object;
    //   597: checkcast androidx/fragment/app/Fragment
    //   600: astore_1
    //   601: aload_1
    //   602: getfield i : I
    //   605: istore #10
    //   607: iload #10
    //   609: iflt -> 693
    //   612: aload_0
    //   613: getfield e : Landroid/util/SparseArray;
    //   616: iload #10
    //   618: invokevirtual get : (I)Ljava/lang/Object;
    //   621: checkcast androidx/fragment/app/Fragment
    //   624: astore #9
    //   626: aload_1
    //   627: aload #9
    //   629: putfield h : Landroidx/fragment/app/Fragment;
    //   632: aload #9
    //   634: ifnonnull -> 693
    //   637: new java/lang/StringBuilder
    //   640: dup
    //   641: invokespecial <init> : ()V
    //   644: astore #9
    //   646: aload #9
    //   648: ldc_w 'Re-attaching retained fragment '
    //   651: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   654: pop
    //   655: aload #9
    //   657: aload_1
    //   658: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   661: pop
    //   662: aload #9
    //   664: ldc_w ' target no longer exists: '
    //   667: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   670: pop
    //   671: aload #9
    //   673: aload_1
    //   674: getfield i : I
    //   677: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   680: pop
    //   681: ldc_w 'FragmentManager'
    //   684: aload #9
    //   686: invokevirtual toString : ()Ljava/lang/String;
    //   689: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   692: pop
    //   693: iinc #8, 1
    //   696: goto -> 582
    //   699: aload_0
    //   700: getfield d : Ljava/util/ArrayList;
    //   703: invokevirtual clear : ()V
    //   706: aload_3
    //   707: getfield mAdded : [I
    //   710: ifnull -> 900
    //   713: iconst_0
    //   714: istore #7
    //   716: aload_3
    //   717: getfield mAdded : [I
    //   720: astore_1
    //   721: iload #7
    //   723: aload_1
    //   724: arraylength
    //   725: if_icmpge -> 900
    //   728: aload_0
    //   729: getfield e : Landroid/util/SparseArray;
    //   732: aload_1
    //   733: iload #7
    //   735: iaload
    //   736: invokevirtual get : (I)Ljava/lang/Object;
    //   739: checkcast androidx/fragment/app/Fragment
    //   742: astore_1
    //   743: aload_1
    //   744: ifnonnull -> 790
    //   747: new java/lang/StringBuilder
    //   750: dup
    //   751: invokespecial <init> : ()V
    //   754: astore_2
    //   755: aload_2
    //   756: ldc_w 'No instantiated fragment for index #'
    //   759: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   762: pop
    //   763: aload_2
    //   764: aload_3
    //   765: getfield mAdded : [I
    //   768: iload #7
    //   770: iaload
    //   771: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   774: pop
    //   775: aload_0
    //   776: new java/lang/IllegalStateException
    //   779: dup
    //   780: aload_2
    //   781: invokevirtual toString : ()Ljava/lang/String;
    //   784: invokespecial <init> : (Ljava/lang/String;)V
    //   787: invokevirtual f1 : (Ljava/lang/RuntimeException;)V
    //   790: aload_1
    //   791: iconst_1
    //   792: putfield k : Z
    //   795: getstatic androidx/fragment/app/g.E : Z
    //   798: ifeq -> 849
    //   801: new java/lang/StringBuilder
    //   804: dup
    //   805: invokespecial <init> : ()V
    //   808: astore_2
    //   809: aload_2
    //   810: ldc_w 'restoreAllState: added #'
    //   813: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   816: pop
    //   817: aload_2
    //   818: iload #7
    //   820: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   823: pop
    //   824: aload_2
    //   825: ldc_w ': '
    //   828: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   831: pop
    //   832: aload_2
    //   833: aload_1
    //   834: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   837: pop
    //   838: ldc_w 'FragmentManager'
    //   841: aload_2
    //   842: invokevirtual toString : ()Ljava/lang/String;
    //   845: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   848: pop
    //   849: aload_0
    //   850: getfield d : Ljava/util/ArrayList;
    //   853: aload_1
    //   854: invokevirtual contains : (Ljava/lang/Object;)Z
    //   857: ifne -> 889
    //   860: aload_0
    //   861: getfield d : Ljava/util/ArrayList;
    //   864: astore_2
    //   865: aload_2
    //   866: monitorenter
    //   867: aload_0
    //   868: getfield d : Ljava/util/ArrayList;
    //   871: aload_1
    //   872: invokevirtual add : (Ljava/lang/Object;)Z
    //   875: pop
    //   876: aload_2
    //   877: monitorexit
    //   878: iinc #7, 1
    //   881: goto -> 716
    //   884: astore_1
    //   885: aload_2
    //   886: monitorexit
    //   887: aload_1
    //   888: athrow
    //   889: new java/lang/IllegalStateException
    //   892: dup
    //   893: ldc_w 'Already added!'
    //   896: invokespecial <init> : (Ljava/lang/String;)V
    //   899: athrow
    //   900: aload_3
    //   901: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   904: ifnull -> 1082
    //   907: aload_0
    //   908: new java/util/ArrayList
    //   911: dup
    //   912: aload_3
    //   913: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   916: arraylength
    //   917: invokespecial <init> : (I)V
    //   920: putfield f : Ljava/util/ArrayList;
    //   923: iconst_0
    //   924: istore #7
    //   926: aload_3
    //   927: getfield mBackStack : [Landroidx/fragment/app/BackStackState;
    //   930: astore_1
    //   931: iload #7
    //   933: aload_1
    //   934: arraylength
    //   935: if_icmpge -> 1087
    //   938: aload_1
    //   939: iload #7
    //   941: aaload
    //   942: aload_0
    //   943: invokevirtual a : (Landroidx/fragment/app/g;)Landroidx/fragment/app/a;
    //   946: astore_1
    //   947: getstatic androidx/fragment/app/g.E : Z
    //   950: ifeq -> 1049
    //   953: new java/lang/StringBuilder
    //   956: dup
    //   957: invokespecial <init> : ()V
    //   960: astore_2
    //   961: aload_2
    //   962: ldc_w 'restoreAllState: back stack #'
    //   965: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   968: pop
    //   969: aload_2
    //   970: iload #7
    //   972: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   975: pop
    //   976: aload_2
    //   977: ldc_w ' (index '
    //   980: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   983: pop
    //   984: aload_2
    //   985: aload_1
    //   986: getfield m : I
    //   989: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   992: pop
    //   993: aload_2
    //   994: ldc_w '): '
    //   997: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1000: pop
    //   1001: aload_2
    //   1002: aload_1
    //   1003: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1006: pop
    //   1007: ldc_w 'FragmentManager'
    //   1010: aload_2
    //   1011: invokevirtual toString : ()Ljava/lang/String;
    //   1014: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1017: pop
    //   1018: new java/io/PrintWriter
    //   1021: dup
    //   1022: new m/b
    //   1025: dup
    //   1026: ldc_w 'FragmentManager'
    //   1029: invokespecial <init> : (Ljava/lang/String;)V
    //   1032: invokespecial <init> : (Ljava/io/Writer;)V
    //   1035: astore_2
    //   1036: aload_1
    //   1037: ldc_w '  '
    //   1040: aload_2
    //   1041: iconst_0
    //   1042: invokevirtual k : (Ljava/lang/String;Ljava/io/PrintWriter;Z)V
    //   1045: aload_2
    //   1046: invokevirtual close : ()V
    //   1049: aload_0
    //   1050: getfield f : Ljava/util/ArrayList;
    //   1053: aload_1
    //   1054: invokevirtual add : (Ljava/lang/Object;)Z
    //   1057: pop
    //   1058: aload_1
    //   1059: getfield m : I
    //   1062: istore #8
    //   1064: iload #8
    //   1066: iflt -> 1076
    //   1069: aload_0
    //   1070: iload #8
    //   1072: aload_1
    //   1073: invokevirtual Y0 : (ILandroidx/fragment/app/a;)V
    //   1076: iinc #7, 1
    //   1079: goto -> 926
    //   1082: aload_0
    //   1083: aconst_null
    //   1084: putfield f : Ljava/util/ArrayList;
    //   1087: aload_3
    //   1088: getfield mPrimaryNavActiveIndex : I
    //   1091: istore #7
    //   1093: iload #7
    //   1095: iflt -> 1114
    //   1098: aload_0
    //   1099: aload_0
    //   1100: getfield e : Landroid/util/SparseArray;
    //   1103: iload #7
    //   1105: invokevirtual get : (I)Ljava/lang/Object;
    //   1108: checkcast androidx/fragment/app/Fragment
    //   1111: putfield p : Landroidx/fragment/app/Fragment;
    //   1114: aload_0
    //   1115: aload_3
    //   1116: getfield mNextFragmentIndex : I
    //   1119: putfield c : I
    //   1122: return
    // Exception table:
    //   from	to	target	type
    //   867	878	884	finally
    //   885	887	884	finally
  }
  
  public boolean R(MenuItem paramMenuItem) {
    if (this.l < 1)
      return false; 
    for (byte b = 0; b < this.d.size(); b++) {
      Fragment fragment = this.d.get(b);
      if (fragment != null && fragment.J0(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public h R0() {
    b1(this.C);
    return this.C;
  }
  
  public void S(Menu paramMenu) {
    if (this.l < 1)
      return; 
    for (byte b = 0; b < this.d.size(); b++) {
      Fragment fragment = this.d.get(b);
      if (fragment != null)
        fragment.K0(paramMenu); 
    } 
  }
  
  public void T() {
    Y(3);
  }
  
  public Parcelable T0() {
    StringBuilder stringBuilder;
    m0();
    b0();
    f0();
    this.r = true;
    BackStackState[] arrayOfBackStackState1 = null;
    this.C = null;
    SparseArray sparseArray = this.e;
    if (sparseArray == null || sparseArray.size() <= 0)
      return null; 
    int i = this.e.size();
    FragmentState[] arrayOfFragmentState = new FragmentState[i];
    boolean bool = false;
    byte b = 0;
    int j = b;
    while (b < i) {
      Fragment fragment1 = (Fragment)this.e.valueAt(b);
      if (fragment1 != null) {
        if (fragment1.e < 0) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Failure saving state: active ");
          stringBuilder.append(fragment1);
          stringBuilder.append(" has cleared index: ");
          stringBuilder.append(fragment1.e);
          f1(new IllegalStateException(stringBuilder.toString()));
        } 
        FragmentState fragmentState = new FragmentState(fragment1);
        arrayOfFragmentState[b] = fragmentState;
        if (fragment1.a > 0 && fragmentState.mSavedFragmentState == null) {
          fragmentState.mSavedFragmentState = U0(fragment1);
          Fragment fragment2 = fragment1.h;
          if (fragment2 != null) {
            if (fragment2.e < 0) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failure saving state: ");
              stringBuilder1.append(fragment1);
              stringBuilder1.append(" has target not in fragment manager: ");
              stringBuilder1.append(fragment1.h);
              f1(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (fragmentState.mSavedFragmentState == null)
              fragmentState.mSavedFragmentState = new Bundle(); 
            M0(fragmentState.mSavedFragmentState, "android:target_state", fragment1.h);
            j = fragment1.j;
            if (j != 0)
              fragmentState.mSavedFragmentState.putInt("android:target_req_state", j); 
          } 
        } else {
          fragmentState.mSavedFragmentState = fragment1.b;
        } 
        if (E) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Saved state of ");
          stringBuilder1.append(fragment1);
          stringBuilder1.append(": ");
          stringBuilder1.append(fragmentState.mSavedFragmentState);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        j = 1;
      } 
      b++;
    } 
    if (j == 0) {
      if (E)
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    j = this.d.size();
    if (j > 0) {
      int[] arrayOfInt = new int[j];
      b = 0;
      while (true) {
        int[] arrayOfInt1 = arrayOfInt;
        if (b < j) {
          i = ((Fragment)this.d.get(b)).e;
          arrayOfInt[b] = i;
          if (i < 0) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Failure saving state: active ");
            stringBuilder1.append(this.d.get(b));
            stringBuilder1.append(" has cleared index: ");
            stringBuilder1.append(arrayOfInt[b]);
            f1(new IllegalStateException(stringBuilder1.toString()));
          } 
          if (E) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("saveAllState: adding fragment #");
            stringBuilder1.append(b);
            stringBuilder1.append(": ");
            stringBuilder1.append(this.d.get(b));
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          b++;
          continue;
        } 
        break;
      } 
    } else {
      sparseArray = null;
    } 
    ArrayList arrayList = this.f;
    BackStackState[] arrayOfBackStackState2 = arrayOfBackStackState1;
    if (arrayList != null) {
      j = arrayList.size();
      arrayOfBackStackState2 = arrayOfBackStackState1;
      if (j > 0) {
        arrayOfBackStackState1 = new BackStackState[j];
        b = bool;
        while (true) {
          arrayOfBackStackState2 = arrayOfBackStackState1;
          if (b < j) {
            arrayOfBackStackState1[b] = new BackStackState(this.f.get(b));
            if (E) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(b);
              stringBuilder.append(": ");
              stringBuilder.append(this.f.get(b));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            b++;
            continue;
          } 
          break;
        } 
      } 
    } 
    FragmentManagerState fragmentManagerState = new FragmentManagerState();
    fragmentManagerState.mActive = arrayOfFragmentState;
    fragmentManagerState.mAdded = (int[])sparseArray;
    fragmentManagerState.mBackStack = (BackStackState[])stringBuilder;
    Fragment fragment = this.p;
    if (fragment != null)
      fragmentManagerState.mPrimaryNavActiveIndex = fragment.e; 
    fragmentManagerState.mNextFragmentIndex = this.c;
    W0();
    return fragmentManagerState;
  }
  
  public void U(boolean paramBoolean) {
    for (int i = this.d.size() - 1; i >= 0; i--) {
      Fragment fragment = this.d.get(i);
      if (fragment != null)
        fragment.M0(paramBoolean); 
    } 
  }
  
  public Bundle U0(Fragment paramFragment) {
    if (this.z == null)
      this.z = new Bundle(); 
    paramFragment.P0(this.z);
    M(paramFragment, this.z, false);
    boolean bool = this.z.isEmpty();
    Bundle bundle1 = null;
    if (!bool) {
      bundle1 = this.z;
      this.z = null;
    } 
    if (paramFragment.I != null)
      V0(paramFragment); 
    Bundle bundle2 = bundle1;
    if (paramFragment.c != null) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putSparseParcelableArray("android:view_state", paramFragment.c);
    } 
    bundle1 = bundle2;
    if (!paramFragment.L) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putBoolean("android:user_visible_hint", paramFragment.L);
    } 
    return bundle1;
  }
  
  public boolean V(Menu paramMenu) {
    int i = this.l;
    byte b = 0;
    if (i < 1)
      return false; 
    boolean bool;
    for (bool = false; b < this.d.size(); bool = bool1) {
      Fragment fragment = this.d.get(b);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.N0(paramMenu))
          bool1 = true; 
      } 
      b++;
    } 
    return bool;
  }
  
  public void V0(Fragment paramFragment) {
    if (paramFragment.J == null)
      return; 
    SparseArray sparseArray = this.A;
    if (sparseArray == null) {
      this.A = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.J.saveHierarchyState(this.A);
    if (this.A.size() > 0) {
      paramFragment.c = this.A;
      this.A = null;
    } 
  }
  
  public void W() {
    this.r = false;
    this.s = false;
    Y(4);
  }
  
  public void W0() {
    List list1;
    List list2;
    List list3;
    if (this.e != null) {
      byte b = 0;
      ArrayList<Fragment> arrayList1 = null;
      ArrayList<Fragment> arrayList2 = arrayList1;
      ArrayList<Fragment> arrayList3 = arrayList2;
      while (true) {
        list1 = arrayList1;
        list2 = arrayList2;
        list3 = arrayList3;
        if (b < this.e.size()) {
          ArrayList<Fragment> arrayList4;
          Fragment fragment = (Fragment)this.e.valueAt(b);
          list1 = arrayList1;
          list2 = arrayList2;
          ArrayList<Fragment> arrayList5 = arrayList3;
          if (fragment != null) {
            h h1;
            list3 = arrayList1;
            if (fragment.C) {
              byte b1;
              list2 = arrayList1;
              if (arrayList1 == null)
                list2 = new ArrayList(); 
              list2.add(fragment);
              Fragment fragment1 = fragment.h;
              if (fragment1 != null) {
                b1 = fragment1.e;
              } else {
                b1 = -1;
              } 
              fragment.i = b1;
              list3 = list2;
              if (E) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("retainNonConfig: keeping retained ");
                stringBuilder.append(fragment);
                Log.v("FragmentManager", stringBuilder.toString());
                list3 = list2;
              } 
            } 
            g g1 = fragment.t;
            if (g1 != null) {
              g1.W0();
              h1 = fragment.t.C;
            } else {
              h1 = fragment.u;
            } 
            ArrayList<Fragment> arrayList = arrayList2;
            if (arrayList2 == null) {
              arrayList = arrayList2;
              if (h1 != null) {
                arrayList2 = new ArrayList<Fragment>(this.e.size());
                byte b1 = 0;
                while (true) {
                  arrayList = arrayList2;
                  if (b1 < b) {
                    arrayList2.add(null);
                    b1++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            if (arrayList != null)
              arrayList.add(h1); 
            arrayList2 = arrayList3;
            if (arrayList3 == null) {
              arrayList2 = arrayList3;
              if (fragment.v != null) {
                arrayList3 = new ArrayList<Fragment>(this.e.size());
                byte b1 = 0;
                while (true) {
                  arrayList2 = arrayList3;
                  if (b1 < b) {
                    arrayList3.add(null);
                    b1++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            list1 = list3;
            arrayList4 = arrayList;
            arrayList5 = arrayList2;
            if (arrayList2 != null) {
              arrayList2.add(fragment.v);
              arrayList5 = arrayList2;
              arrayList4 = arrayList;
              list1 = list3;
            } 
          } 
          b++;
          arrayList1 = (ArrayList<Fragment>)list1;
          arrayList2 = arrayList4;
          arrayList3 = arrayList5;
          continue;
        } 
        break;
      } 
    } else {
      list1 = null;
      List list = list1;
      list3 = list;
      list2 = list;
    } 
    if (list1 == null && list2 == null && list3 == null) {
      this.C = null;
    } else {
      this.C = new h(list1, list2, list3);
    } 
  }
  
  public void X() {
    this.r = false;
    this.s = false;
    Y(3);
  }
  
  public void X0() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield B : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: iconst_0
    //   8: istore_2
    //   9: aload_1
    //   10: ifnull -> 25
    //   13: aload_1
    //   14: invokevirtual isEmpty : ()Z
    //   17: ifne -> 25
    //   20: iconst_1
    //   21: istore_3
    //   22: goto -> 27
    //   25: iconst_0
    //   26: istore_3
    //   27: aload_0
    //   28: getfield a : Ljava/util/ArrayList;
    //   31: astore_1
    //   32: iload_2
    //   33: istore #4
    //   35: aload_1
    //   36: ifnull -> 53
    //   39: iload_2
    //   40: istore #4
    //   42: aload_1
    //   43: invokevirtual size : ()I
    //   46: iconst_1
    //   47: if_icmpne -> 53
    //   50: iconst_1
    //   51: istore #4
    //   53: iload_3
    //   54: ifne -> 62
    //   57: iload #4
    //   59: ifeq -> 91
    //   62: aload_0
    //   63: getfield m : Landroidx/fragment/app/e;
    //   66: invokevirtual g : ()Landroid/os/Handler;
    //   69: aload_0
    //   70: getfield D : Ljava/lang/Runnable;
    //   73: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   76: aload_0
    //   77: getfield m : Landroidx/fragment/app/e;
    //   80: invokevirtual g : ()Landroid/os/Handler;
    //   83: aload_0
    //   84: getfield D : Ljava/lang/Runnable;
    //   87: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   90: pop
    //   91: aload_0
    //   92: monitorexit
    //   93: return
    //   94: astore_1
    //   95: aload_0
    //   96: monitorexit
    //   97: aload_1
    //   98: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	94	finally
    //   13	20	94	finally
    //   27	32	94	finally
    //   42	50	94	finally
    //   62	91	94	finally
    //   91	93	94	finally
    //   95	97	94	finally
  }
  
  public final void Y(int paramInt) {
    try {
      this.b = true;
      E0(paramInt, false);
      this.b = false;
      return;
    } finally {
      this.b = false;
    } 
  }
  
  public void Y0(int paramInt, a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield h : Ljava/util/ArrayList;
    //   6: ifnonnull -> 22
    //   9: new java/util/ArrayList
    //   12: astore_3
    //   13: aload_3
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: aload_3
    //   19: putfield h : Ljava/util/ArrayList;
    //   22: aload_0
    //   23: getfield h : Ljava/util/ArrayList;
    //   26: invokevirtual size : ()I
    //   29: istore #4
    //   31: iload #4
    //   33: istore #5
    //   35: iload_1
    //   36: iload #4
    //   38: if_icmpge -> 107
    //   41: getstatic androidx/fragment/app/g.E : Z
    //   44: ifeq -> 94
    //   47: new java/lang/StringBuilder
    //   50: astore_3
    //   51: aload_3
    //   52: invokespecial <init> : ()V
    //   55: aload_3
    //   56: ldc_w 'Setting back stack index '
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: pop
    //   63: aload_3
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload_3
    //   70: ldc_w ' to '
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: pop
    //   77: aload_3
    //   78: aload_2
    //   79: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   82: pop
    //   83: ldc_w 'FragmentManager'
    //   86: aload_3
    //   87: invokevirtual toString : ()Ljava/lang/String;
    //   90: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   93: pop
    //   94: aload_0
    //   95: getfield h : Ljava/util/ArrayList;
    //   98: iload_1
    //   99: aload_2
    //   100: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   103: pop
    //   104: goto -> 263
    //   107: iload #5
    //   109: iload_1
    //   110: if_icmpge -> 201
    //   113: aload_0
    //   114: getfield h : Ljava/util/ArrayList;
    //   117: aconst_null
    //   118: invokevirtual add : (Ljava/lang/Object;)Z
    //   121: pop
    //   122: aload_0
    //   123: getfield i : Ljava/util/ArrayList;
    //   126: ifnonnull -> 142
    //   129: new java/util/ArrayList
    //   132: astore_3
    //   133: aload_3
    //   134: invokespecial <init> : ()V
    //   137: aload_0
    //   138: aload_3
    //   139: putfield i : Ljava/util/ArrayList;
    //   142: getstatic androidx/fragment/app/g.E : Z
    //   145: ifeq -> 182
    //   148: new java/lang/StringBuilder
    //   151: astore_3
    //   152: aload_3
    //   153: invokespecial <init> : ()V
    //   156: aload_3
    //   157: ldc_w 'Adding available back stack index '
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: pop
    //   164: aload_3
    //   165: iload #5
    //   167: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   170: pop
    //   171: ldc_w 'FragmentManager'
    //   174: aload_3
    //   175: invokevirtual toString : ()Ljava/lang/String;
    //   178: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   181: pop
    //   182: aload_0
    //   183: getfield i : Ljava/util/ArrayList;
    //   186: iload #5
    //   188: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   191: invokevirtual add : (Ljava/lang/Object;)Z
    //   194: pop
    //   195: iinc #5, 1
    //   198: goto -> 107
    //   201: getstatic androidx/fragment/app/g.E : Z
    //   204: ifeq -> 254
    //   207: new java/lang/StringBuilder
    //   210: astore_3
    //   211: aload_3
    //   212: invokespecial <init> : ()V
    //   215: aload_3
    //   216: ldc_w 'Adding back stack index '
    //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: pop
    //   223: aload_3
    //   224: iload_1
    //   225: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   228: pop
    //   229: aload_3
    //   230: ldc_w ' with '
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload_3
    //   238: aload_2
    //   239: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: ldc_w 'FragmentManager'
    //   246: aload_3
    //   247: invokevirtual toString : ()Ljava/lang/String;
    //   250: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   253: pop
    //   254: aload_0
    //   255: getfield h : Ljava/util/ArrayList;
    //   258: aload_2
    //   259: invokevirtual add : (Ljava/lang/Object;)Z
    //   262: pop
    //   263: aload_0
    //   264: monitorexit
    //   265: return
    //   266: astore_2
    //   267: aload_0
    //   268: monitorexit
    //   269: aload_2
    //   270: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	266	finally
    //   22	31	266	finally
    //   41	94	266	finally
    //   94	104	266	finally
    //   113	142	266	finally
    //   142	182	266	finally
    //   182	195	266	finally
    //   201	254	266	finally
    //   254	263	266	finally
    //   263	265	266	finally
    //   267	269	266	finally
  }
  
  public void Z() {
    this.s = true;
    Y(2);
  }
  
  public i a() {
    return new a(this);
  }
  
  public void a0() {
    if (this.v) {
      this.v = false;
      e1();
    } 
  }
  
  public void a1(Fragment paramFragment) {
    if (paramFragment == null || (this.e.get(paramFragment.e) == paramFragment && (paramFragment.s == null || paramFragment.u() == this))) {
      this.p = paramFragment;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload #5
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #5
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #5
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #5
    //   32: aload_0
    //   33: getfield e : Landroid/util/SparseArray;
    //   36: astore #6
    //   38: iconst_0
    //   39: istore #7
    //   41: aload #6
    //   43: ifnull -> 165
    //   46: aload #6
    //   48: invokevirtual size : ()I
    //   51: istore #8
    //   53: iload #8
    //   55: ifle -> 165
    //   58: aload_3
    //   59: aload_1
    //   60: invokevirtual print : (Ljava/lang/String;)V
    //   63: aload_3
    //   64: ldc_w 'Active Fragments in '
    //   67: invokevirtual print : (Ljava/lang/String;)V
    //   70: aload_3
    //   71: aload_0
    //   72: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   75: invokestatic toHexString : (I)Ljava/lang/String;
    //   78: invokevirtual print : (Ljava/lang/String;)V
    //   81: aload_3
    //   82: ldc_w ':'
    //   85: invokevirtual println : (Ljava/lang/String;)V
    //   88: iconst_0
    //   89: istore #9
    //   91: iload #9
    //   93: iload #8
    //   95: if_icmpge -> 165
    //   98: aload_0
    //   99: getfield e : Landroid/util/SparseArray;
    //   102: iload #9
    //   104: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   107: checkcast androidx/fragment/app/Fragment
    //   110: astore #6
    //   112: aload_3
    //   113: aload_1
    //   114: invokevirtual print : (Ljava/lang/String;)V
    //   117: aload_3
    //   118: ldc_w '  #'
    //   121: invokevirtual print : (Ljava/lang/String;)V
    //   124: aload_3
    //   125: iload #9
    //   127: invokevirtual print : (I)V
    //   130: aload_3
    //   131: ldc_w ': '
    //   134: invokevirtual print : (Ljava/lang/String;)V
    //   137: aload_3
    //   138: aload #6
    //   140: invokevirtual println : (Ljava/lang/Object;)V
    //   143: aload #6
    //   145: ifnull -> 159
    //   148: aload #6
    //   150: aload #5
    //   152: aload_2
    //   153: aload_3
    //   154: aload #4
    //   156: invokevirtual g : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   159: iinc #9, 1
    //   162: goto -> 91
    //   165: aload_0
    //   166: getfield d : Ljava/util/ArrayList;
    //   169: invokevirtual size : ()I
    //   172: istore #8
    //   174: iload #8
    //   176: ifle -> 255
    //   179: aload_3
    //   180: aload_1
    //   181: invokevirtual print : (Ljava/lang/String;)V
    //   184: aload_3
    //   185: ldc_w 'Added Fragments:'
    //   188: invokevirtual println : (Ljava/lang/String;)V
    //   191: iconst_0
    //   192: istore #9
    //   194: iload #9
    //   196: iload #8
    //   198: if_icmpge -> 255
    //   201: aload_0
    //   202: getfield d : Ljava/util/ArrayList;
    //   205: iload #9
    //   207: invokevirtual get : (I)Ljava/lang/Object;
    //   210: checkcast androidx/fragment/app/Fragment
    //   213: astore #6
    //   215: aload_3
    //   216: aload_1
    //   217: invokevirtual print : (Ljava/lang/String;)V
    //   220: aload_3
    //   221: ldc_w '  #'
    //   224: invokevirtual print : (Ljava/lang/String;)V
    //   227: aload_3
    //   228: iload #9
    //   230: invokevirtual print : (I)V
    //   233: aload_3
    //   234: ldc_w ': '
    //   237: invokevirtual print : (Ljava/lang/String;)V
    //   240: aload_3
    //   241: aload #6
    //   243: invokevirtual toString : ()Ljava/lang/String;
    //   246: invokevirtual println : (Ljava/lang/String;)V
    //   249: iinc #9, 1
    //   252: goto -> 194
    //   255: aload_0
    //   256: getfield g : Ljava/util/ArrayList;
    //   259: astore #6
    //   261: aload #6
    //   263: ifnull -> 354
    //   266: aload #6
    //   268: invokevirtual size : ()I
    //   271: istore #8
    //   273: iload #8
    //   275: ifle -> 354
    //   278: aload_3
    //   279: aload_1
    //   280: invokevirtual print : (Ljava/lang/String;)V
    //   283: aload_3
    //   284: ldc_w 'Fragments Created Menus:'
    //   287: invokevirtual println : (Ljava/lang/String;)V
    //   290: iconst_0
    //   291: istore #9
    //   293: iload #9
    //   295: iload #8
    //   297: if_icmpge -> 354
    //   300: aload_0
    //   301: getfield g : Ljava/util/ArrayList;
    //   304: iload #9
    //   306: invokevirtual get : (I)Ljava/lang/Object;
    //   309: checkcast androidx/fragment/app/Fragment
    //   312: astore #6
    //   314: aload_3
    //   315: aload_1
    //   316: invokevirtual print : (Ljava/lang/String;)V
    //   319: aload_3
    //   320: ldc_w '  #'
    //   323: invokevirtual print : (Ljava/lang/String;)V
    //   326: aload_3
    //   327: iload #9
    //   329: invokevirtual print : (I)V
    //   332: aload_3
    //   333: ldc_w ': '
    //   336: invokevirtual print : (Ljava/lang/String;)V
    //   339: aload_3
    //   340: aload #6
    //   342: invokevirtual toString : ()Ljava/lang/String;
    //   345: invokevirtual println : (Ljava/lang/String;)V
    //   348: iinc #9, 1
    //   351: goto -> 293
    //   354: aload_0
    //   355: getfield f : Ljava/util/ArrayList;
    //   358: astore #6
    //   360: aload #6
    //   362: ifnull -> 464
    //   365: aload #6
    //   367: invokevirtual size : ()I
    //   370: istore #8
    //   372: iload #8
    //   374: ifle -> 464
    //   377: aload_3
    //   378: aload_1
    //   379: invokevirtual print : (Ljava/lang/String;)V
    //   382: aload_3
    //   383: ldc_w 'Back Stack:'
    //   386: invokevirtual println : (Ljava/lang/String;)V
    //   389: iconst_0
    //   390: istore #9
    //   392: iload #9
    //   394: iload #8
    //   396: if_icmpge -> 464
    //   399: aload_0
    //   400: getfield f : Ljava/util/ArrayList;
    //   403: iload #9
    //   405: invokevirtual get : (I)Ljava/lang/Object;
    //   408: checkcast androidx/fragment/app/a
    //   411: astore #6
    //   413: aload_3
    //   414: aload_1
    //   415: invokevirtual print : (Ljava/lang/String;)V
    //   418: aload_3
    //   419: ldc_w '  #'
    //   422: invokevirtual print : (Ljava/lang/String;)V
    //   425: aload_3
    //   426: iload #9
    //   428: invokevirtual print : (I)V
    //   431: aload_3
    //   432: ldc_w ': '
    //   435: invokevirtual print : (Ljava/lang/String;)V
    //   438: aload_3
    //   439: aload #6
    //   441: invokevirtual toString : ()Ljava/lang/String;
    //   444: invokevirtual println : (Ljava/lang/String;)V
    //   447: aload #6
    //   449: aload #5
    //   451: aload_2
    //   452: aload_3
    //   453: aload #4
    //   455: invokevirtual j : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   458: iinc #9, 1
    //   461: goto -> 392
    //   464: aload_0
    //   465: monitorenter
    //   466: aload_0
    //   467: getfield h : Ljava/util/ArrayList;
    //   470: astore_2
    //   471: aload_2
    //   472: ifnull -> 557
    //   475: aload_2
    //   476: invokevirtual size : ()I
    //   479: istore #8
    //   481: iload #8
    //   483: ifle -> 557
    //   486: aload_3
    //   487: aload_1
    //   488: invokevirtual print : (Ljava/lang/String;)V
    //   491: aload_3
    //   492: ldc_w 'Back Stack Indices:'
    //   495: invokevirtual println : (Ljava/lang/String;)V
    //   498: iconst_0
    //   499: istore #9
    //   501: iload #9
    //   503: iload #8
    //   505: if_icmpge -> 557
    //   508: aload_0
    //   509: getfield h : Ljava/util/ArrayList;
    //   512: iload #9
    //   514: invokevirtual get : (I)Ljava/lang/Object;
    //   517: checkcast androidx/fragment/app/a
    //   520: astore_2
    //   521: aload_3
    //   522: aload_1
    //   523: invokevirtual print : (Ljava/lang/String;)V
    //   526: aload_3
    //   527: ldc_w '  #'
    //   530: invokevirtual print : (Ljava/lang/String;)V
    //   533: aload_3
    //   534: iload #9
    //   536: invokevirtual print : (I)V
    //   539: aload_3
    //   540: ldc_w ': '
    //   543: invokevirtual print : (Ljava/lang/String;)V
    //   546: aload_3
    //   547: aload_2
    //   548: invokevirtual println : (Ljava/lang/Object;)V
    //   551: iinc #9, 1
    //   554: goto -> 501
    //   557: aload_0
    //   558: getfield i : Ljava/util/ArrayList;
    //   561: astore_2
    //   562: aload_2
    //   563: ifnull -> 599
    //   566: aload_2
    //   567: invokevirtual size : ()I
    //   570: ifle -> 599
    //   573: aload_3
    //   574: aload_1
    //   575: invokevirtual print : (Ljava/lang/String;)V
    //   578: aload_3
    //   579: ldc_w 'mAvailBackStackIndices: '
    //   582: invokevirtual print : (Ljava/lang/String;)V
    //   585: aload_3
    //   586: aload_0
    //   587: getfield i : Ljava/util/ArrayList;
    //   590: invokevirtual toArray : ()[Ljava/lang/Object;
    //   593: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   596: invokevirtual println : (Ljava/lang/String;)V
    //   599: aload_0
    //   600: monitorexit
    //   601: aload_0
    //   602: getfield a : Ljava/util/ArrayList;
    //   605: astore_2
    //   606: aload_2
    //   607: ifnull -> 693
    //   610: aload_2
    //   611: invokevirtual size : ()I
    //   614: istore #8
    //   616: iload #8
    //   618: ifle -> 693
    //   621: aload_3
    //   622: aload_1
    //   623: invokevirtual print : (Ljava/lang/String;)V
    //   626: aload_3
    //   627: ldc_w 'Pending Actions:'
    //   630: invokevirtual println : (Ljava/lang/String;)V
    //   633: iload #7
    //   635: istore #9
    //   637: iload #9
    //   639: iload #8
    //   641: if_icmpge -> 693
    //   644: aload_0
    //   645: getfield a : Ljava/util/ArrayList;
    //   648: iload #9
    //   650: invokevirtual get : (I)Ljava/lang/Object;
    //   653: checkcast androidx/fragment/app/g$k
    //   656: astore_2
    //   657: aload_3
    //   658: aload_1
    //   659: invokevirtual print : (Ljava/lang/String;)V
    //   662: aload_3
    //   663: ldc_w '  #'
    //   666: invokevirtual print : (Ljava/lang/String;)V
    //   669: aload_3
    //   670: iload #9
    //   672: invokevirtual print : (I)V
    //   675: aload_3
    //   676: ldc_w ': '
    //   679: invokevirtual print : (Ljava/lang/String;)V
    //   682: aload_3
    //   683: aload_2
    //   684: invokevirtual println : (Ljava/lang/Object;)V
    //   687: iinc #9, 1
    //   690: goto -> 637
    //   693: aload_3
    //   694: aload_1
    //   695: invokevirtual print : (Ljava/lang/String;)V
    //   698: aload_3
    //   699: ldc_w 'FragmentManager misc state:'
    //   702: invokevirtual println : (Ljava/lang/String;)V
    //   705: aload_3
    //   706: aload_1
    //   707: invokevirtual print : (Ljava/lang/String;)V
    //   710: aload_3
    //   711: ldc_w '  mHost='
    //   714: invokevirtual print : (Ljava/lang/String;)V
    //   717: aload_3
    //   718: aload_0
    //   719: getfield m : Landroidx/fragment/app/e;
    //   722: invokevirtual println : (Ljava/lang/Object;)V
    //   725: aload_3
    //   726: aload_1
    //   727: invokevirtual print : (Ljava/lang/String;)V
    //   730: aload_3
    //   731: ldc_w '  mContainer='
    //   734: invokevirtual print : (Ljava/lang/String;)V
    //   737: aload_3
    //   738: aload_0
    //   739: getfield n : Landroidx/fragment/app/c;
    //   742: invokevirtual println : (Ljava/lang/Object;)V
    //   745: aload_0
    //   746: getfield o : Landroidx/fragment/app/Fragment;
    //   749: ifnull -> 772
    //   752: aload_3
    //   753: aload_1
    //   754: invokevirtual print : (Ljava/lang/String;)V
    //   757: aload_3
    //   758: ldc_w '  mParent='
    //   761: invokevirtual print : (Ljava/lang/String;)V
    //   764: aload_3
    //   765: aload_0
    //   766: getfield o : Landroidx/fragment/app/Fragment;
    //   769: invokevirtual println : (Ljava/lang/Object;)V
    //   772: aload_3
    //   773: aload_1
    //   774: invokevirtual print : (Ljava/lang/String;)V
    //   777: aload_3
    //   778: ldc_w '  mCurState='
    //   781: invokevirtual print : (Ljava/lang/String;)V
    //   784: aload_3
    //   785: aload_0
    //   786: getfield l : I
    //   789: invokevirtual print : (I)V
    //   792: aload_3
    //   793: ldc_w ' mStateSaved='
    //   796: invokevirtual print : (Ljava/lang/String;)V
    //   799: aload_3
    //   800: aload_0
    //   801: getfield r : Z
    //   804: invokevirtual print : (Z)V
    //   807: aload_3
    //   808: ldc_w ' mStopped='
    //   811: invokevirtual print : (Ljava/lang/String;)V
    //   814: aload_3
    //   815: aload_0
    //   816: getfield s : Z
    //   819: invokevirtual print : (Z)V
    //   822: aload_3
    //   823: ldc_w ' mDestroyed='
    //   826: invokevirtual print : (Ljava/lang/String;)V
    //   829: aload_3
    //   830: aload_0
    //   831: getfield t : Z
    //   834: invokevirtual println : (Z)V
    //   837: aload_0
    //   838: getfield q : Z
    //   841: ifeq -> 864
    //   844: aload_3
    //   845: aload_1
    //   846: invokevirtual print : (Ljava/lang/String;)V
    //   849: aload_3
    //   850: ldc_w '  mNeedMenuInvalidate='
    //   853: invokevirtual print : (Ljava/lang/String;)V
    //   856: aload_3
    //   857: aload_0
    //   858: getfield q : Z
    //   861: invokevirtual println : (Z)V
    //   864: aload_0
    //   865: getfield u : Ljava/lang/String;
    //   868: ifnull -> 891
    //   871: aload_3
    //   872: aload_1
    //   873: invokevirtual print : (Ljava/lang/String;)V
    //   876: aload_3
    //   877: ldc_w '  mNoTransactionsBecause='
    //   880: invokevirtual print : (Ljava/lang/String;)V
    //   883: aload_3
    //   884: aload_0
    //   885: getfield u : Ljava/lang/String;
    //   888: invokevirtual println : (Ljava/lang/String;)V
    //   891: return
    //   892: astore_1
    //   893: aload_0
    //   894: monitorexit
    //   895: aload_1
    //   896: athrow
    // Exception table:
    //   from	to	target	type
    //   466	471	892	finally
    //   475	481	892	finally
    //   486	498	892	finally
    //   508	551	892	finally
    //   557	562	892	finally
    //   566	599	892	finally
    //   599	601	892	finally
    //   893	895	892	finally
  }
  
  public final void b0() {
    int i;
    SparseArray sparseArray = this.e;
    byte b = 0;
    if (sparseArray == null) {
      i = 0;
    } else {
      i = sparseArray.size();
    } 
    while (b < i) {
      Fragment fragment = (Fragment)this.e.valueAt(b);
      if (fragment != null)
        if (fragment.m() != null) {
          int j = fragment.E();
          View view = fragment.m();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.V0(null);
          G0(fragment, j, 0, 0, false);
        } else if (fragment.n() != null) {
          fragment.n().end();
        }  
      b++;
    } 
  }
  
  public Fragment c(String paramString) {
    if (paramString != null)
      for (int i = this.d.size() - 1; i >= 0; i--) {
        Fragment fragment = this.d.get(i);
        if (fragment != null && paramString.equals(fragment.z))
          return fragment; 
      }  
    SparseArray sparseArray = this.e;
    if (sparseArray != null && paramString != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.e.valueAt(i);
        if (fragment != null && paramString.equals(fragment.z))
          return fragment; 
      }  
    return null;
  }
  
  public void c0(k paramk, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokevirtual p : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield t : Z
    //   14: ifne -> 63
    //   17: aload_0
    //   18: getfield m : Landroidx/fragment/app/e;
    //   21: ifnonnull -> 27
    //   24: goto -> 63
    //   27: aload_0
    //   28: getfield a : Ljava/util/ArrayList;
    //   31: ifnonnull -> 47
    //   34: new java/util/ArrayList
    //   37: astore_3
    //   38: aload_3
    //   39: invokespecial <init> : ()V
    //   42: aload_0
    //   43: aload_3
    //   44: putfield a : Ljava/util/ArrayList;
    //   47: aload_0
    //   48: getfield a : Ljava/util/ArrayList;
    //   51: aload_1
    //   52: invokevirtual add : (Ljava/lang/Object;)Z
    //   55: pop
    //   56: aload_0
    //   57: invokevirtual X0 : ()V
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: iload_2
    //   64: ifeq -> 70
    //   67: aload_0
    //   68: monitorexit
    //   69: return
    //   70: new java/lang/IllegalStateException
    //   73: astore_1
    //   74: aload_1
    //   75: ldc_w 'Activity has been destroyed'
    //   78: invokespecial <init> : (Ljava/lang/String;)V
    //   81: aload_1
    //   82: athrow
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	83	finally
    //   27	47	83	finally
    //   47	62	83	finally
    //   67	69	83	finally
    //   70	83	83	finally
    //   84	86	83	finally
  }
  
  public List d() {
    if (this.d.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.d) {
      return (List)this.d.clone();
    } 
  }
  
  public final void d0(boolean paramBoolean) {
    if (!this.b) {
      if (this.m != null) {
        if (Looper.myLooper() == this.m.g().getLooper()) {
          if (!paramBoolean)
            p(); 
          if (this.w == null) {
            this.w = new ArrayList();
            this.x = new ArrayList();
          } 
          this.b = true;
          try {
            i0(null, null);
            return;
          } finally {
            this.b = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  public void d1(Fragment paramFragment) {
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.A) {
      paramFragment.A = false;
      paramFragment.O ^= 0x1;
    } 
  }
  
  public boolean e() {
    return (this.r || this.s);
  }
  
  public void e0(Fragment paramFragment) {
    if (paramFragment.m && !paramFragment.p) {
      paramFragment.C0(paramFragment.G0(paramFragment.b), null, paramFragment.b);
      View view = paramFragment.I;
      if (view != null) {
        paramFragment.J = view;
        view.setSaveFromParentEnabled(false);
        if (paramFragment.A)
          paramFragment.I.setVisibility(8); 
        paramFragment.u0(paramFragment.I, paramFragment.b);
        P(paramFragment, paramFragment.I, paramFragment.b, false);
      } else {
        paramFragment.J = null;
      } 
    } 
  }
  
  public void e1() {
    if (this.e == null)
      return; 
    for (byte b = 0; b < this.e.size(); b++) {
      Fragment fragment = (Fragment)this.e.valueAt(b);
      if (fragment != null)
        I0(fragment); 
    } 
  }
  
  public void f(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      c0(new l(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean f0() {
    d0(true);
    boolean bool = false;
    while (o0(this.w, this.x)) {
      this.b = true;
      try {
        O0(this.w, this.x);
        q();
      } finally {
        q();
      } 
    } 
    a0();
    o();
    return bool;
  }
  
  public final void f1(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new m.b("FragmentManager"));
    e e1 = this.m;
    if (e1 != null) {
      try {
        e1.i("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      b("  ", null, printWriter, new String[0]);
    } 
    throw paramRuntimeException;
  }
  
  public boolean g() {
    p();
    return J0(null, -1, 0);
  }
  
  public final void h(f.b paramb) {
    int i = this.l;
    if (i < 1)
      return; 
    int j = Math.min(i, 3);
    int k = this.d.size();
    for (i = 0; i < k; i++) {
      Fragment fragment = this.d.get(i);
      if (fragment.a < j) {
        G0(fragment, j, fragment.w(), fragment.x(), false);
        if (fragment.I != null && !fragment.A && fragment.N)
          paramb.add(fragment); 
      } 
    } 
  }
  
  public final void h0(ArrayList<a> paramArrayList1, ArrayList<Boolean> paramArrayList2, int paramInt1, int paramInt2) {
    int k;
    int i = paramInt1;
    boolean bool = ((a)paramArrayList1.get(i)).t;
    ArrayList arrayList = this.y;
    if (arrayList == null) {
      this.y = new ArrayList();
    } else {
      arrayList.clear();
    } 
    this.y.addAll(this.d);
    Fragment fragment = s0();
    boolean bool1 = false;
    int j;
    for (j = i; j < paramInt2; j++) {
      a a = paramArrayList1.get(j);
      if (!((Boolean)paramArrayList2.get(j)).booleanValue()) {
        fragment = a.n(this.y, fragment);
      } else {
        fragment = a.v(this.y, fragment);
      } 
      if (bool1 || a.i) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
    } 
    this.y.clear();
    if (!bool)
      j.B(this, paramArrayList1, paramArrayList2, paramInt1, paramInt2, false); 
    g0(paramArrayList1, paramArrayList2, paramInt1, paramInt2);
    if (bool) {
      f.b b = new f.b();
      h(b);
      k = L0(paramArrayList1, paramArrayList2, paramInt1, paramInt2, b);
      A0(b);
    } else {
      k = paramInt2;
    } 
    j = i;
    if (k != i) {
      j = i;
      if (bool) {
        j.B(this, paramArrayList1, paramArrayList2, paramInt1, k, true);
        E0(this.l, true);
        j = i;
      } 
    } 
    while (j < paramInt2) {
      a a = paramArrayList1.get(j);
      if (((Boolean)paramArrayList2.get(j)).booleanValue()) {
        paramInt1 = a.m;
        if (paramInt1 >= 0) {
          n0(paramInt1);
          a.m = -1;
        } 
      } 
      a.t();
      j++;
    } 
    if (bool1)
      P0(); 
  }
  
  public void i(a parama) {
    if (this.f == null)
      this.f = new ArrayList(); 
    this.f.add(parama);
  }
  
  public final void i0(ArrayList paramArrayList1, ArrayList paramArrayList2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield B : Ljava/util/ArrayList;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnonnull -> 15
    //   9: iconst_0
    //   10: istore #4
    //   12: goto -> 21
    //   15: aload_3
    //   16: invokevirtual size : ()I
    //   19: istore #4
    //   21: iconst_0
    //   22: istore #5
    //   24: iload #5
    //   26: iload #4
    //   28: if_icmpge -> 230
    //   31: aload_0
    //   32: getfield B : Ljava/util/ArrayList;
    //   35: iload #5
    //   37: invokevirtual get : (I)Ljava/lang/Object;
    //   40: checkcast androidx/fragment/app/g$m
    //   43: astore_3
    //   44: aload_1
    //   45: ifnull -> 101
    //   48: aload_3
    //   49: getfield a : Z
    //   52: ifne -> 101
    //   55: aload_1
    //   56: aload_3
    //   57: getfield b : Landroidx/fragment/app/a;
    //   60: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   63: istore #6
    //   65: iload #6
    //   67: iconst_m1
    //   68: if_icmpeq -> 101
    //   71: aload_2
    //   72: iload #6
    //   74: invokevirtual get : (I)Ljava/lang/Object;
    //   77: checkcast java/lang/Boolean
    //   80: invokevirtual booleanValue : ()Z
    //   83: ifeq -> 101
    //   86: aload_3
    //   87: invokevirtual c : ()V
    //   90: iload #4
    //   92: istore #6
    //   94: iload #5
    //   96: istore #7
    //   98: goto -> 217
    //   101: aload_3
    //   102: invokevirtual e : ()Z
    //   105: ifne -> 144
    //   108: iload #4
    //   110: istore #6
    //   112: iload #5
    //   114: istore #7
    //   116: aload_1
    //   117: ifnull -> 217
    //   120: iload #4
    //   122: istore #6
    //   124: iload #5
    //   126: istore #7
    //   128: aload_3
    //   129: getfield b : Landroidx/fragment/app/a;
    //   132: aload_1
    //   133: iconst_0
    //   134: aload_1
    //   135: invokevirtual size : ()I
    //   138: invokevirtual q : (Ljava/util/ArrayList;II)Z
    //   141: ifeq -> 217
    //   144: aload_0
    //   145: getfield B : Ljava/util/ArrayList;
    //   148: iload #5
    //   150: invokevirtual remove : (I)Ljava/lang/Object;
    //   153: pop
    //   154: iinc #5, -1
    //   157: iinc #4, -1
    //   160: aload_1
    //   161: ifnull -> 205
    //   164: aload_3
    //   165: getfield a : Z
    //   168: ifne -> 205
    //   171: aload_1
    //   172: aload_3
    //   173: getfield b : Landroidx/fragment/app/a;
    //   176: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   179: istore #6
    //   181: iload #6
    //   183: iconst_m1
    //   184: if_icmpeq -> 205
    //   187: aload_2
    //   188: iload #6
    //   190: invokevirtual get : (I)Ljava/lang/Object;
    //   193: checkcast java/lang/Boolean
    //   196: invokevirtual booleanValue : ()Z
    //   199: ifeq -> 205
    //   202: goto -> 86
    //   205: aload_3
    //   206: invokevirtual d : ()V
    //   209: iload #5
    //   211: istore #7
    //   213: iload #4
    //   215: istore #6
    //   217: iload #7
    //   219: iconst_1
    //   220: iadd
    //   221: istore #5
    //   223: iload #6
    //   225: istore #4
    //   227: goto -> 24
    //   230: return
  }
  
  public void j(Fragment paramFragment, boolean paramBoolean) {
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    w0(paramFragment);
    if (!paramFragment.B)
      if (!this.d.contains(paramFragment)) {
        synchronized (this.d) {
          this.d.add(paramFragment);
          paramFragment.k = true;
          paramFragment.l = false;
          if (paramFragment.I == null)
            paramFragment.O = false; 
          if (paramFragment.E && paramFragment.F)
            this.q = true; 
          if (paramBoolean)
            F0(paramFragment); 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public Fragment j0(int paramInt) {
    int i;
    for (i = this.d.size() - 1; i >= 0; i--) {
      Fragment fragment = this.d.get(i);
      if (fragment != null && fragment.x == paramInt)
        return fragment; 
    } 
    SparseArray sparseArray = this.e;
    if (sparseArray != null)
      for (i = sparseArray.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.e.valueAt(i);
        if (fragment != null && fragment.x == paramInt)
          return fragment; 
      }  
    return null;
  }
  
  public int k(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Ljava/util/ArrayList;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 110
    //   11: aload_2
    //   12: invokevirtual size : ()I
    //   15: ifgt -> 21
    //   18: goto -> 110
    //   21: aload_0
    //   22: getfield i : Ljava/util/ArrayList;
    //   25: astore_2
    //   26: aload_2
    //   27: aload_2
    //   28: invokevirtual size : ()I
    //   31: iconst_1
    //   32: isub
    //   33: invokevirtual remove : (I)Ljava/lang/Object;
    //   36: checkcast java/lang/Integer
    //   39: invokevirtual intValue : ()I
    //   42: istore_3
    //   43: getstatic androidx/fragment/app/g.E : Z
    //   46: ifeq -> 96
    //   49: new java/lang/StringBuilder
    //   52: astore_2
    //   53: aload_2
    //   54: invokespecial <init> : ()V
    //   57: aload_2
    //   58: ldc_w 'Adding back stack index '
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: pop
    //   65: aload_2
    //   66: iload_3
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload_2
    //   72: ldc_w ' with '
    //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: pop
    //   79: aload_2
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc_w 'FragmentManager'
    //   88: aload_2
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: getfield h : Ljava/util/ArrayList;
    //   100: iload_3
    //   101: aload_1
    //   102: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: aload_0
    //   107: monitorexit
    //   108: iload_3
    //   109: ireturn
    //   110: aload_0
    //   111: getfield h : Ljava/util/ArrayList;
    //   114: ifnonnull -> 130
    //   117: new java/util/ArrayList
    //   120: astore_2
    //   121: aload_2
    //   122: invokespecial <init> : ()V
    //   125: aload_0
    //   126: aload_2
    //   127: putfield h : Ljava/util/ArrayList;
    //   130: aload_0
    //   131: getfield h : Ljava/util/ArrayList;
    //   134: invokevirtual size : ()I
    //   137: istore_3
    //   138: getstatic androidx/fragment/app/g.E : Z
    //   141: ifeq -> 191
    //   144: new java/lang/StringBuilder
    //   147: astore_2
    //   148: aload_2
    //   149: invokespecial <init> : ()V
    //   152: aload_2
    //   153: ldc_w 'Setting back stack index '
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: pop
    //   160: aload_2
    //   161: iload_3
    //   162: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload_2
    //   167: ldc_w ' to '
    //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: pop
    //   174: aload_2
    //   175: aload_1
    //   176: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: ldc_w 'FragmentManager'
    //   183: aload_2
    //   184: invokevirtual toString : ()Ljava/lang/String;
    //   187: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   190: pop
    //   191: aload_0
    //   192: getfield h : Ljava/util/ArrayList;
    //   195: aload_1
    //   196: invokevirtual add : (Ljava/lang/Object;)Z
    //   199: pop
    //   200: aload_0
    //   201: monitorexit
    //   202: iload_3
    //   203: ireturn
    //   204: astore_1
    //   205: aload_0
    //   206: monitorexit
    //   207: aload_1
    //   208: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	204	finally
    //   11	18	204	finally
    //   21	96	204	finally
    //   96	108	204	finally
    //   110	130	204	finally
    //   130	191	204	finally
    //   191	202	204	finally
    //   205	207	204	finally
  }
  
  public Fragment k0(String paramString) {
    SparseArray sparseArray = this.e;
    if (sparseArray != null && paramString != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.e.valueAt(i);
        if (fragment != null) {
          fragment = fragment.i(paramString);
          if (fragment != null)
            return fragment; 
        } 
      }  
    return null;
  }
  
  public final void l(Fragment paramFragment, g paramg, int paramInt) {
    View view = paramFragment.I;
    ViewGroup viewGroup = paramFragment.H;
    viewGroup.startViewTransition(view);
    paramFragment.d1(paramInt);
    if (paramg.a != null) {
      i i = new i(paramg.a, viewGroup, view);
      paramFragment.V0(paramFragment.I);
      i.setAnimationListener(new b(this, p0((Animation)i), viewGroup, paramFragment));
      Z0(view, paramg);
      paramFragment.I.startAnimation((Animation)i);
    } else {
      Animator animator = paramg.b;
      paramFragment.W0(animator);
      animator.addListener((Animator.AnimatorListener)new c(this, viewGroup, view, paramFragment));
      animator.setTarget(paramFragment.I);
      Z0(paramFragment.I, paramg);
      animator.start();
    } 
  }
  
  public final Fragment l0(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.H;
    View view = paramFragment.I;
    if (viewGroup != null && view != null)
      for (int i = this.d.indexOf(paramFragment) - 1; i >= 0; i--) {
        paramFragment = this.d.get(i);
        if (paramFragment.H == viewGroup && paramFragment.I != null)
          return paramFragment; 
      }  
    return null;
  }
  
  public void m(e parame, c paramc, Fragment paramFragment) {
    if (this.m == null) {
      this.m = parame;
      this.n = paramc;
      this.o = paramFragment;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public final void m0() {
    if (this.B != null)
      while (!this.B.isEmpty())
        ((m)this.B.remove(0)).d();  
  }
  
  public void n(Fragment paramFragment) {
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.B) {
      paramFragment.B = false;
      if (!paramFragment.k)
        if (!this.d.contains(paramFragment)) {
          if (E) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.d) {
            this.d.add(paramFragment);
            paramFragment.k = true;
            if (paramFragment.E && paramFragment.F)
              this.q = true; 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public void n0(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield h : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield i : Ljava/util/ArrayList;
    //   16: ifnonnull -> 32
    //   19: new java/util/ArrayList
    //   22: astore_2
    //   23: aload_2
    //   24: invokespecial <init> : ()V
    //   27: aload_0
    //   28: aload_2
    //   29: putfield i : Ljava/util/ArrayList;
    //   32: getstatic androidx/fragment/app/g.E : Z
    //   35: ifeq -> 71
    //   38: new java/lang/StringBuilder
    //   41: astore_2
    //   42: aload_2
    //   43: invokespecial <init> : ()V
    //   46: aload_2
    //   47: ldc_w 'Freeing back stack index '
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: pop
    //   54: aload_2
    //   55: iload_1
    //   56: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: ldc_w 'FragmentManager'
    //   63: aload_2
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   70: pop
    //   71: aload_0
    //   72: getfield i : Ljava/util/ArrayList;
    //   75: iload_1
    //   76: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   79: invokevirtual add : (Ljava/lang/Object;)Z
    //   82: pop
    //   83: aload_0
    //   84: monitorexit
    //   85: return
    //   86: astore_2
    //   87: aload_0
    //   88: monitorexit
    //   89: aload_2
    //   90: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	86	finally
    //   32	71	86	finally
    //   71	85	86	finally
    //   87	89	86	finally
  }
  
  public final void o() {
    SparseArray sparseArray = this.e;
    if (sparseArray != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        if (this.e.valueAt(i) == null) {
          sparseArray = this.e;
          sparseArray.delete(sparseArray.keyAt(i));
        } 
      }  
  }
  
  public final boolean o0(ArrayList paramArrayList1, ArrayList paramArrayList2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/ArrayList;
    //   6: astore_3
    //   7: iconst_0
    //   8: istore #4
    //   10: aload_3
    //   11: ifnull -> 99
    //   14: aload_3
    //   15: invokevirtual size : ()I
    //   18: ifne -> 24
    //   21: goto -> 99
    //   24: aload_0
    //   25: getfield a : Ljava/util/ArrayList;
    //   28: invokevirtual size : ()I
    //   31: istore #5
    //   33: iconst_0
    //   34: istore #6
    //   36: iload #4
    //   38: iload #5
    //   40: if_icmpge -> 73
    //   43: iload #6
    //   45: aload_0
    //   46: getfield a : Ljava/util/ArrayList;
    //   49: iload #4
    //   51: invokevirtual get : (I)Ljava/lang/Object;
    //   54: checkcast androidx/fragment/app/g$k
    //   57: aload_1
    //   58: aload_2
    //   59: invokeinterface a : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   64: ior
    //   65: istore #6
    //   67: iinc #4, 1
    //   70: goto -> 36
    //   73: aload_0
    //   74: getfield a : Ljava/util/ArrayList;
    //   77: invokevirtual clear : ()V
    //   80: aload_0
    //   81: getfield m : Landroidx/fragment/app/e;
    //   84: invokevirtual g : ()Landroid/os/Handler;
    //   87: aload_0
    //   88: getfield D : Ljava/lang/Runnable;
    //   91: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   94: aload_0
    //   95: monitorexit
    //   96: iload #6
    //   98: ireturn
    //   99: aload_0
    //   100: monitorexit
    //   101: iconst_0
    //   102: ireturn
    //   103: astore_1
    //   104: aload_0
    //   105: monitorexit
    //   106: aload_1
    //   107: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	103	finally
    //   14	21	103	finally
    //   24	33	103	finally
    //   43	67	103	finally
    //   73	96	103	finally
    //   99	101	103	finally
    //   104	106	103	finally
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (!"fragment".equals(paramString))
      return null; 
    paramString = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.a);
    int i = 0;
    String str1 = paramString;
    if (paramString == null)
      str1 = typedArray.getString(0); 
    int j = typedArray.getResourceId(1, -1);
    String str2 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.O(this.m.e(), str1))
      return null; 
    if (paramView != null)
      i = paramView.getId(); 
    if (i != -1 || j != -1 || str2 != null) {
      e e1;
      Fragment fragment2;
      e e2;
      if (j != -1) {
        Fragment fragment = j0(j);
      } else {
        paramView = null;
      } 
      View view2 = paramView;
      if (paramView == null) {
        view2 = paramView;
        if (str2 != null)
          fragment2 = c(str2); 
      } 
      Fragment fragment1 = fragment2;
      if (fragment2 == null) {
        fragment1 = fragment2;
        if (i != -1)
          fragment1 = j0(i); 
      } 
      if (E) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onCreateView: id=0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(" fname=");
        stringBuilder2.append(str1);
        stringBuilder2.append(" existing=");
        stringBuilder2.append(fragment1);
        Log.v("FragmentManager", stringBuilder2.toString());
      } 
      if (fragment1 == null) {
        int k;
        fragment2 = this.n.a(paramContext, str1, null);
        fragment2.m = true;
        if (j != 0) {
          k = j;
        } else {
          k = i;
        } 
        fragment2.x = k;
        fragment2.y = i;
        fragment2.z = str2;
        fragment2.n = true;
        fragment2.r = this;
        e1 = this.m;
        fragment2.s = e1;
        fragment2.i0(e1.e(), paramAttributeSet, fragment2.b);
        j(fragment2, true);
      } else if (!((Fragment)e1).n) {
        ((Fragment)e1).n = true;
        e e3 = this.m;
        ((Fragment)e1).s = e3;
        e2 = e1;
        if (!((Fragment)e1).D) {
          e1.i0(e3.e(), paramAttributeSet, ((Fragment)e1).b);
          e2 = e1;
        } 
      } else {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(paramAttributeSet.getPositionDescription());
        stringBuilder2.append(": Duplicate id 0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(", tag ");
        stringBuilder2.append(str2);
        stringBuilder2.append(", or parent id 0x");
        stringBuilder2.append(Integer.toHexString(i));
        stringBuilder2.append(" with another fragment for ");
        stringBuilder2.append(str1);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      if (this.l < 1 && ((Fragment)e2).m) {
        G0((Fragment)e2, 1, 0, 0, false);
      } else {
        F0((Fragment)e2);
      } 
      View view1 = ((Fragment)e2).I;
      if (view1 != null) {
        if (j != 0)
          view1.setId(j); 
        if (((Fragment)e2).I.getTag() == null)
          ((Fragment)e2).I.setTag(str2); 
        return ((Fragment)e2).I;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str1);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAttributeSet.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public final void p() {
    if (!e()) {
      if (this.u == null)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can not perform this action inside of ");
      stringBuilder.append(this.u);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public final void q() {
    this.b = false;
    this.x.clear();
    this.w.clear();
  }
  
  public Fragment q0(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    Fragment fragment = (Fragment)this.e.get(i);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": index ");
      stringBuilder.append(i);
      f1(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public void r(a parama, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      parama.m(paramBoolean3);
    } else {
      parama.l();
    } 
    ArrayList<a> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(parama);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      j.B(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      E0(this.l, true); 
    SparseArray sparseArray = this.e;
    if (sparseArray != null) {
      int i = sparseArray.size();
      for (byte b = 0; b < i; b++) {
        Fragment fragment = (Fragment)this.e.valueAt(b);
        if (fragment != null && fragment.I != null && fragment.N && parama.p(fragment.y)) {
          float f1 = fragment.P;
          if (f1 > 0.0F)
            fragment.I.setAlpha(f1); 
          if (paramBoolean3) {
            fragment.P = 0.0F;
          } else {
            fragment.P = -1.0F;
            fragment.N = false;
          } 
        } 
      } 
    } 
  }
  
  public LayoutInflater.Factory2 r0() {
    return this;
  }
  
  public void s(Fragment paramFragment) {
    // Byte code:
    //   0: aload_1
    //   1: getfield I : Landroid/view/View;
    //   4: ifnull -> 210
    //   7: aload_0
    //   8: aload_1
    //   9: aload_1
    //   10: invokevirtual x : ()I
    //   13: aload_1
    //   14: getfield A : Z
    //   17: iconst_1
    //   18: ixor
    //   19: aload_1
    //   20: invokevirtual y : ()I
    //   23: invokevirtual v0 : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/g$g;
    //   26: astore_2
    //   27: aload_2
    //   28: ifnull -> 135
    //   31: aload_2
    //   32: getfield b : Landroid/animation/Animator;
    //   35: astore_3
    //   36: aload_3
    //   37: ifnull -> 135
    //   40: aload_3
    //   41: aload_1
    //   42: getfield I : Landroid/view/View;
    //   45: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   48: aload_1
    //   49: getfield A : Z
    //   52: ifeq -> 109
    //   55: aload_1
    //   56: invokevirtual J : ()Z
    //   59: ifeq -> 70
    //   62: aload_1
    //   63: iconst_0
    //   64: invokevirtual Y0 : (Z)V
    //   67: goto -> 117
    //   70: aload_1
    //   71: getfield H : Landroid/view/ViewGroup;
    //   74: astore #4
    //   76: aload_1
    //   77: getfield I : Landroid/view/View;
    //   80: astore_3
    //   81: aload #4
    //   83: aload_3
    //   84: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   87: aload_2
    //   88: getfield b : Landroid/animation/Animator;
    //   91: new androidx/fragment/app/g$d
    //   94: dup
    //   95: aload_0
    //   96: aload #4
    //   98: aload_3
    //   99: aload_1
    //   100: invokespecial <init> : (Landroidx/fragment/app/g;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/Fragment;)V
    //   103: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   106: goto -> 117
    //   109: aload_1
    //   110: getfield I : Landroid/view/View;
    //   113: iconst_0
    //   114: invokevirtual setVisibility : (I)V
    //   117: aload_1
    //   118: getfield I : Landroid/view/View;
    //   121: aload_2
    //   122: invokestatic Z0 : (Landroid/view/View;Landroidx/fragment/app/g$g;)V
    //   125: aload_2
    //   126: getfield b : Landroid/animation/Animator;
    //   129: invokevirtual start : ()V
    //   132: goto -> 210
    //   135: aload_2
    //   136: ifnull -> 165
    //   139: aload_1
    //   140: getfield I : Landroid/view/View;
    //   143: aload_2
    //   144: invokestatic Z0 : (Landroid/view/View;Landroidx/fragment/app/g$g;)V
    //   147: aload_1
    //   148: getfield I : Landroid/view/View;
    //   151: aload_2
    //   152: getfield a : Landroid/view/animation/Animation;
    //   155: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   158: aload_2
    //   159: getfield a : Landroid/view/animation/Animation;
    //   162: invokevirtual start : ()V
    //   165: aload_1
    //   166: getfield A : Z
    //   169: ifeq -> 186
    //   172: aload_1
    //   173: invokevirtual J : ()Z
    //   176: ifne -> 186
    //   179: bipush #8
    //   181: istore #5
    //   183: goto -> 189
    //   186: iconst_0
    //   187: istore #5
    //   189: aload_1
    //   190: getfield I : Landroid/view/View;
    //   193: iload #5
    //   195: invokevirtual setVisibility : (I)V
    //   198: aload_1
    //   199: invokevirtual J : ()Z
    //   202: ifeq -> 210
    //   205: aload_1
    //   206: iconst_0
    //   207: invokevirtual Y0 : (Z)V
    //   210: aload_1
    //   211: getfield k : Z
    //   214: ifeq -> 236
    //   217: aload_1
    //   218: getfield E : Z
    //   221: ifeq -> 236
    //   224: aload_1
    //   225: getfield F : Z
    //   228: ifeq -> 236
    //   231: aload_0
    //   232: iconst_1
    //   233: putfield q : Z
    //   236: aload_1
    //   237: iconst_0
    //   238: putfield O : Z
    //   241: aload_1
    //   242: aload_1
    //   243: getfield A : Z
    //   246: invokevirtual g0 : (Z)V
    //   249: return
  }
  
  public Fragment s0() {
    return this.p;
  }
  
  public void t(Fragment paramFragment) {
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.B) {
      paramFragment.B = true;
      if (paramFragment.k) {
        if (E) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.d) {
          this.d.remove(paramFragment);
          if (paramFragment.E && paramFragment.F)
            this.q = true; 
          paramFragment.k = false;
        } 
      } 
    } 
  }
  
  public void t0(Fragment paramFragment) {
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.A) {
      paramFragment.A = true;
      paramFragment.O = true ^ paramFragment.O;
    } 
  }
  
  public String toString() {
    e e1;
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.o;
    if (fragment == null)
      e1 = this.m; 
    m.a.a(e1, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void u() {
    this.r = false;
    this.s = false;
    Y(2);
  }
  
  public boolean u0(int paramInt) {
    boolean bool;
    if (this.l >= paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void v(Configuration paramConfiguration) {
    for (byte b = 0; b < this.d.size(); b++) {
      Fragment fragment = this.d.get(b);
      if (fragment != null)
        fragment.y0(paramConfiguration); 
    } 
  }
  
  public g v0(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual w : ()I
    //   4: istore #5
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: iload #5
    //   11: invokevirtual X : (IZI)Landroid/view/animation/Animation;
    //   14: astore #6
    //   16: aload #6
    //   18: ifnull -> 31
    //   21: new androidx/fragment/app/g$g
    //   24: dup
    //   25: aload #6
    //   27: invokespecial <init> : (Landroid/view/animation/Animation;)V
    //   30: areturn
    //   31: aload_1
    //   32: iload_2
    //   33: iload_3
    //   34: iload #5
    //   36: invokevirtual Y : (IZI)Landroid/animation/Animator;
    //   39: astore_1
    //   40: aload_1
    //   41: ifnull -> 53
    //   44: new androidx/fragment/app/g$g
    //   47: dup
    //   48: aload_1
    //   49: invokespecial <init> : (Landroid/animation/Animator;)V
    //   52: areturn
    //   53: iload #5
    //   55: ifeq -> 193
    //   58: ldc_w 'anim'
    //   61: aload_0
    //   62: getfield m : Landroidx/fragment/app/e;
    //   65: invokevirtual e : ()Landroid/content/Context;
    //   68: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   71: iload #5
    //   73: invokevirtual getResourceTypeName : (I)Ljava/lang/String;
    //   76: invokevirtual equals : (Ljava/lang/Object;)Z
    //   79: istore #7
    //   81: iload #7
    //   83: ifeq -> 123
    //   86: aload_0
    //   87: getfield m : Landroidx/fragment/app/e;
    //   90: invokevirtual e : ()Landroid/content/Context;
    //   93: iload #5
    //   95: invokestatic loadAnimation : (Landroid/content/Context;I)Landroid/view/animation/Animation;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 114
    //   103: new androidx/fragment/app/g$g
    //   106: dup
    //   107: aload_1
    //   108: invokespecial <init> : (Landroid/view/animation/Animation;)V
    //   111: astore_1
    //   112: aload_1
    //   113: areturn
    //   114: iconst_1
    //   115: istore #8
    //   117: goto -> 126
    //   120: astore_1
    //   121: aload_1
    //   122: athrow
    //   123: iconst_0
    //   124: istore #8
    //   126: iload #8
    //   128: ifne -> 193
    //   131: aload_0
    //   132: getfield m : Landroidx/fragment/app/e;
    //   135: invokevirtual e : ()Landroid/content/Context;
    //   138: iload #5
    //   140: invokestatic loadAnimator : (Landroid/content/Context;I)Landroid/animation/Animator;
    //   143: astore_1
    //   144: aload_1
    //   145: ifnull -> 193
    //   148: new androidx/fragment/app/g$g
    //   151: dup
    //   152: aload_1
    //   153: invokespecial <init> : (Landroid/animation/Animator;)V
    //   156: astore_1
    //   157: aload_1
    //   158: areturn
    //   159: astore_1
    //   160: iload #7
    //   162: ifne -> 191
    //   165: aload_0
    //   166: getfield m : Landroidx/fragment/app/e;
    //   169: invokevirtual e : ()Landroid/content/Context;
    //   172: iload #5
    //   174: invokestatic loadAnimation : (Landroid/content/Context;I)Landroid/view/animation/Animation;
    //   177: astore_1
    //   178: aload_1
    //   179: ifnull -> 193
    //   182: new androidx/fragment/app/g$g
    //   185: dup
    //   186: aload_1
    //   187: invokespecial <init> : (Landroid/view/animation/Animation;)V
    //   190: areturn
    //   191: aload_1
    //   192: athrow
    //   193: aconst_null
    //   194: astore #6
    //   196: iload_2
    //   197: ifne -> 202
    //   200: aconst_null
    //   201: areturn
    //   202: iload_2
    //   203: iload_3
    //   204: invokestatic g1 : (IZ)I
    //   207: istore_2
    //   208: iload_2
    //   209: ifge -> 214
    //   212: aconst_null
    //   213: areturn
    //   214: iload_2
    //   215: tableswitch default -> 252, 1 -> 364, 2 -> 347, 3 -> 330, 4 -> 313, 5 -> 300, 6 -> 287
    //   252: aload #6
    //   254: astore_1
    //   255: iload #4
    //   257: ifne -> 381
    //   260: aload #6
    //   262: astore_1
    //   263: aload_0
    //   264: getfield m : Landroidx/fragment/app/e;
    //   267: invokevirtual l : ()Z
    //   270: ifeq -> 381
    //   273: aload_0
    //   274: getfield m : Landroidx/fragment/app/e;
    //   277: invokevirtual k : ()I
    //   280: pop
    //   281: aload #6
    //   283: astore_1
    //   284: goto -> 381
    //   287: aload_0
    //   288: getfield m : Landroidx/fragment/app/e;
    //   291: invokevirtual e : ()Landroid/content/Context;
    //   294: fconst_1
    //   295: fconst_0
    //   296: invokestatic x0 : (Landroid/content/Context;FF)Landroidx/fragment/app/g$g;
    //   299: areturn
    //   300: aload_0
    //   301: getfield m : Landroidx/fragment/app/e;
    //   304: invokevirtual e : ()Landroid/content/Context;
    //   307: fconst_0
    //   308: fconst_1
    //   309: invokestatic x0 : (Landroid/content/Context;FF)Landroidx/fragment/app/g$g;
    //   312: areturn
    //   313: aload_0
    //   314: getfield m : Landroidx/fragment/app/e;
    //   317: invokevirtual e : ()Landroid/content/Context;
    //   320: fconst_1
    //   321: ldc_w 1.075
    //   324: fconst_1
    //   325: fconst_0
    //   326: invokestatic z0 : (Landroid/content/Context;FFFF)Landroidx/fragment/app/g$g;
    //   329: areturn
    //   330: aload_0
    //   331: getfield m : Landroidx/fragment/app/e;
    //   334: invokevirtual e : ()Landroid/content/Context;
    //   337: ldc_w 0.975
    //   340: fconst_1
    //   341: fconst_0
    //   342: fconst_1
    //   343: invokestatic z0 : (Landroid/content/Context;FFFF)Landroidx/fragment/app/g$g;
    //   346: areturn
    //   347: aload_0
    //   348: getfield m : Landroidx/fragment/app/e;
    //   351: invokevirtual e : ()Landroid/content/Context;
    //   354: fconst_1
    //   355: ldc_w 0.975
    //   358: fconst_1
    //   359: fconst_0
    //   360: invokestatic z0 : (Landroid/content/Context;FFFF)Landroidx/fragment/app/g$g;
    //   363: areturn
    //   364: aload_0
    //   365: getfield m : Landroidx/fragment/app/e;
    //   368: invokevirtual e : ()Landroid/content/Context;
    //   371: ldc_w 1.125
    //   374: fconst_1
    //   375: fconst_0
    //   376: fconst_1
    //   377: invokestatic z0 : (Landroid/content/Context;FFFF)Landroidx/fragment/app/g$g;
    //   380: astore_1
    //   381: aload_1
    //   382: areturn
    //   383: astore_1
    //   384: goto -> 123
    // Exception table:
    //   from	to	target	type
    //   86	99	120	android/content/res/Resources$NotFoundException
    //   86	99	383	java/lang/RuntimeException
    //   103	112	120	android/content/res/Resources$NotFoundException
    //   103	112	383	java/lang/RuntimeException
    //   131	144	159	java/lang/RuntimeException
    //   148	157	159	java/lang/RuntimeException
  }
  
  public boolean w(MenuItem paramMenuItem) {
    if (this.l < 1)
      return false; 
    for (byte b = 0; b < this.d.size(); b++) {
      Fragment fragment = this.d.get(b);
      if (fragment != null && fragment.z0(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void w0(Fragment paramFragment) {
    if (paramFragment.e >= 0)
      return; 
    int i = this.c;
    this.c = i + 1;
    paramFragment.Z0(i, this.o);
    if (this.e == null)
      this.e = new SparseArray(); 
    this.e.put(paramFragment.e, paramFragment);
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Allocated fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void x() {
    this.r = false;
    this.s = false;
    Y(1);
  }
  
  public boolean y(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.l;
    byte b1 = 0;
    if (i < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    byte b2 = 0;
    for (i = b2; b2 < this.d.size(); i = j) {
      Fragment fragment = this.d.get(b2);
      ArrayList<Fragment> arrayList1 = arrayList;
      int j = i;
      if (fragment != null) {
        arrayList1 = arrayList;
        j = i;
        if (fragment.B0(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          j = 1;
        } 
      } 
      b2++;
      arrayList = arrayList1;
    } 
    if (this.g != null)
      for (byte b = b1; b < this.g.size(); b++) {
        Fragment fragment = this.g.get(b);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.c0(); 
      }  
    this.g = arrayList;
    return i;
  }
  
  public void y0(Fragment paramFragment) {
    if (paramFragment.e < 0)
      return; 
    if (E) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Freeing fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    this.e.put(paramFragment.e, null);
    paramFragment.G();
  }
  
  public void z() {
    this.t = true;
    f0();
    Y(0);
    this.m = null;
    this.n = null;
    this.o = null;
  }
  
  public class a implements Runnable {
    public a(g this$0) {}
    
    public void run() {
      this.a.f0();
    }
  }
  
  public class b extends f {
    public b(g this$0, Animation.AnimationListener param1AnimationListener, ViewGroup param1ViewGroup, Fragment param1Fragment) {
      super(param1AnimationListener);
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      super.onAnimationEnd(param1Animation);
      this.b.post(new a(this));
    }
    
    public class a implements Runnable {
      public a(g.b this$0) {}
      
      public void run() {
        if (this.a.c.m() != null) {
          this.a.c.V0(null);
          g.b b1 = this.a;
          g g = b1.d;
          Fragment fragment = b1.c;
          g.G0(fragment, fragment.E(), 0, 0, false);
        } 
      }
    }
  }
  
  public class a implements Runnable {
    public a(g this$0) {}
    
    public void run() {
      if (this.a.c.m() != null) {
        this.a.c.V0(null);
        g.b b1 = this.a;
        g g = b1.d;
        Fragment fragment = b1.c;
        g.G0(fragment, fragment.E(), 0, 0, false);
      } 
    }
  }
  
  public class c extends AnimatorListenerAdapter {
    public c(g this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.n();
      this.c.W0(null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0) {
        g g1 = this.d;
        Fragment fragment = this.c;
        g1.G0(fragment, fragment.E(), 0, 0, false);
      } 
    }
  }
  
  public class d extends AnimatorListenerAdapter {
    public d(g this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator.removeListener((Animator.AnimatorListener)this);
      View view = this.c.I;
      if (view != null)
        view.setVisibility(8); 
    }
  }
  
  public static class e extends f {
    public View b;
    
    public e(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.b = param1View;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      if (n.j.s(this.b) || Build.VERSION.SDK_INT >= 24) {
        this.b.post(new a(this));
      } else {
        this.b.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
    
    public class a implements Runnable {
      public a(g.e this$0) {}
      
      public void run() {
        this.a.b.setLayerType(0, null);
      }
    }
  }
  
  public class a implements Runnable {
    public a(g this$0) {}
    
    public void run() {
      this.a.b.setLayerType(0, null);
    }
  }
  
  public static abstract class f implements Animation.AnimationListener {
    public final Animation.AnimationListener a;
    
    public f(Animation.AnimationListener param1AnimationListener) {
      this.a = param1AnimationListener;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationEnd(param1Animation); 
    }
    
    public void onAnimationRepeat(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationRepeat(param1Animation); 
    }
    
    public void onAnimationStart(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.a;
      if (animationListener != null)
        animationListener.onAnimationStart(param1Animation); 
    }
  }
  
  public static class g {
    public final Animation a = null;
    
    public final Animator b;
    
    public g(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    public g(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  public static class h extends AnimatorListenerAdapter {
    public View a;
    
    public h(View param1View) {
      this.a = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.setLayerType(2, null);
    }
  }
  
  public static class i extends AnimationSet implements Runnable {
    public final ViewGroup a;
    
    public final View b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e = true;
    
    public i(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.a = param1ViewGroup;
      this.b = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.e = true;
      if (this.c)
        return this.d ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.c = true;
        m.a((View)this.a, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.e = true;
      if (this.c)
        return this.d ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.c = true;
        m.a((View)this.a, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.c && this.e) {
        this.e = false;
        this.a.post(this);
      } else {
        this.a.endViewTransition(this.b);
        this.d = true;
      } 
    }
  }
  
  public static abstract class j {
    public static final int[] a = new int[] { 16842755, 16842960, 16842961 };
  }
  
  public static interface k {
    boolean a(ArrayList param1ArrayList1, ArrayList param1ArrayList2);
  }
  
  public class l implements k {
    public final String a;
    
    public final int b;
    
    public final int c;
    
    public l(g this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean a(ArrayList param1ArrayList1, ArrayList param1ArrayList2) {
      Fragment fragment = this.d.p;
      if (fragment != null && this.b < 0 && this.a == null) {
        f f = fragment.w0();
        if (f != null && f.g())
          return false; 
      } 
      return this.d.K0(param1ArrayList1, param1ArrayList2, this.a, this.b, this.c);
    }
  }
  
  public static class m implements Fragment.f {
    public final boolean a;
    
    public final a b;
    
    public int c;
    
    public m(a param1a, boolean param1Boolean) {
      this.a = param1Boolean;
      this.b = param1a;
    }
    
    public void a() {
      int i = this.c - 1;
      this.c = i;
      if (i != 0)
        return; 
      this.b.a.X0();
    }
    
    public void b() {
      this.c++;
    }
    
    public void c() {
      a a1 = this.b;
      a1.a.r(a1, this.a, false, false);
    }
    
    public void d() {
      int i = this.c;
      byte b = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      g g = this.b.a;
      int j = g.d.size();
      while (b < j) {
        Fragment fragment = g.d.get(b);
        fragment.c1(null);
        if (i != 0 && fragment.L())
          fragment.f1(); 
        b++;
      } 
      a a1 = this.b;
      a1.a.r(a1, this.a, i ^ 0x1, true);
    }
    
    public boolean e() {
      boolean bool;
      if (this.c == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */