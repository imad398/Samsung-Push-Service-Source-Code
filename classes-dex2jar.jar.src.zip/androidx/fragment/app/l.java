package androidx.fragment.app;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import n.j;
import n.p;

public abstract class l {
  public static void d(List<View> paramList, View paramView) {
    int i = paramList.size();
    if (h(paramList, paramView, i))
      return; 
    paramList.add(paramView);
    for (int j = i; j < paramList.size(); j++) {
      paramView = paramList.get(j);
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int k = viewGroup.getChildCount();
        for (byte b = 0; b < k; b++) {
          paramView = viewGroup.getChildAt(b);
          if (!h(paramList, paramView, i))
            paramList.add(paramView); 
        } 
      } 
    } 
  }
  
  public static boolean h(List<View> paramList, View paramView, int paramInt) {
    for (byte b = 0; b < paramInt; b++) {
      if (paramList.get(b) == paramView)
        return true; 
    } 
    return false;
  }
  
  public static String i(Map paramMap, String paramString) {
    for (Map.Entry entry : paramMap.entrySet()) {
      if (paramString.equals(entry.getValue()))
        return (String)entry.getKey(); 
    } 
    return null;
  }
  
  public static boolean l(List paramList) {
    return (paramList == null || paramList.isEmpty());
  }
  
  public abstract Object A(Object paramObject);
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void b(Object paramObject, ArrayList paramArrayList);
  
  public abstract void c(ViewGroup paramViewGroup, Object paramObject);
  
  public abstract boolean e(Object paramObject);
  
  public void f(ArrayList<ViewGroup> paramArrayList, View paramView) {
    ViewGroup viewGroup;
    if (paramView.getVisibility() == 0) {
      View view = paramView;
      if (paramView instanceof ViewGroup) {
        viewGroup = (ViewGroup)paramView;
        if (p.a(viewGroup)) {
          paramArrayList.add(viewGroup);
          return;
        } 
        int i = viewGroup.getChildCount();
        for (byte b = 0; b < i; b++)
          f(paramArrayList, viewGroup.getChildAt(b)); 
        return;
      } 
    } else {
      return;
    } 
    paramArrayList.add(viewGroup);
  }
  
  public abstract Object g(Object paramObject);
  
  public void j(Map<String, View> paramMap, View paramView) {
    if (paramView.getVisibility() == 0) {
      String str = j.n(paramView);
      if (str != null)
        paramMap.put(str, paramView); 
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int i = viewGroup.getChildCount();
        for (byte b = 0; b < i; b++)
          j(paramMap, viewGroup.getChildAt(b)); 
      } 
    } 
  }
  
  public void k(View paramView, Rect paramRect) {
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    int i = arrayOfInt[0];
    paramRect.set(i, arrayOfInt[1], paramView.getWidth() + i, arrayOfInt[1] + paramView.getHeight());
  }
  
  public abstract Object m(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract Object n(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public ArrayList o(ArrayList<View> paramArrayList) {
    ArrayList<String> arrayList = new ArrayList();
    int i = paramArrayList.size();
    for (byte b = 0; b < i; b++) {
      View view = paramArrayList.get(b);
      arrayList.add(j.n(view));
      j.D(view, null);
    } 
    return arrayList;
  }
  
  public abstract void p(Object paramObject, View paramView);
  
  public abstract void q(Object paramObject, ArrayList paramArrayList1, ArrayList paramArrayList2);
  
  public abstract void r(Object paramObject, View paramView, ArrayList paramArrayList);
  
  public void s(ViewGroup paramViewGroup, ArrayList paramArrayList, Map paramMap) {
    m.a((View)paramViewGroup, new c(this, paramArrayList, paramMap));
  }
  
  public abstract void t(Object paramObject1, Object paramObject2, ArrayList paramArrayList1, Object paramObject3, ArrayList paramArrayList2, Object paramObject4, ArrayList paramArrayList3);
  
  public abstract void u(Object paramObject, Rect paramRect);
  
  public abstract void v(Object paramObject, View paramView);
  
  public void w(View paramView, ArrayList paramArrayList, Map paramMap) {
    m.a(paramView, new b(this, paramArrayList, paramMap));
  }
  
  public void x(View paramView, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, ArrayList paramArrayList3, Map paramMap) {
    int i = paramArrayList2.size();
    ArrayList<String> arrayList = new ArrayList();
    for (byte b = 0; b < i; b++) {
      View view = paramArrayList1.get(b);
      String str = j.n(view);
      arrayList.add(str);
      if (str != null) {
        j.D(view, null);
        String str1 = (String)paramMap.get(str);
        for (byte b1 = 0; b1 < i; b1++) {
          if (str1.equals(paramArrayList3.get(b1))) {
            j.D(paramArrayList2.get(b1), str);
            break;
          } 
        } 
      } 
    } 
    m.a(paramView, new a(this, i, paramArrayList2, paramArrayList3, paramArrayList1, arrayList));
  }
  
  public abstract void y(Object paramObject, View paramView, ArrayList paramArrayList);
  
  public abstract void z(Object paramObject, ArrayList paramArrayList1, ArrayList paramArrayList2);
  
  public class a implements Runnable {
    public a(l this$0, int param1Int, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, ArrayList param1ArrayList4) {}
    
    public void run() {
      for (byte b = 0; b < this.a; b++) {
        j.D(this.b.get(b), this.c.get(b));
        j.D(this.d.get(b), this.e.get(b));
      } 
    }
  }
  
  public class b implements Runnable {
    public b(l this$0, ArrayList param1ArrayList, Map param1Map) {}
    
    public void run() {
      int i = this.a.size();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = this.a.get(b1);
        String str = j.n(view);
        if (str != null)
          j.D(view, l.i(this.b, str)); 
      } 
    }
  }
  
  public class c implements Runnable {
    public c(l this$0, ArrayList param1ArrayList, Map param1Map) {}
    
    public void run() {
      int i = this.a.size();
      for (byte b = 0; b < i; b++) {
        View view = this.a.get(b);
        String str = j.n(view);
        j.D(view, (String)this.b.get(str));
      } 
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */