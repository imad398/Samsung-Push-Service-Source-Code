package androidx.fragment.app;

import android.graphics.Rect;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract class j {
  public static final int[] a = new int[] { 0, 3, 0, 1, 5, 4, 7, 6, 9, 8 };
  
  public static final l b = new k();
  
  public static final l c = w();
  
  public static void A(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = paramArrayList.size() - 1; i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  public static void B(g paramg, ArrayList<a> paramArrayList1, ArrayList<Boolean> paramArrayList2, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramg.l < 1)
      return; 
    SparseArray sparseArray = new SparseArray();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      a a = paramArrayList1.get(i);
      if (((Boolean)paramArrayList2.get(i)).booleanValue()) {
        e(a, sparseArray, paramBoolean);
      } else {
        c(a, sparseArray, paramBoolean);
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paramg.m.e());
      int k = sparseArray.size();
      for (i = 0; i < k; i++) {
        int m = sparseArray.keyAt(i);
        f.a a = d(m, paramArrayList1, paramArrayList2, paramInt1, paramInt2);
        e e = (e)sparseArray.valueAt(i);
        if (paramBoolean) {
          o(paramg, m, e, view, a);
        } else {
          n(paramg, m, e, view, a);
        } 
      } 
    } 
  }
  
  public static void a(ArrayList<View> paramArrayList, f.a parama, Collection paramCollection) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      View view = (View)parama.l(i);
      if (paramCollection.contains(n.j.n(view)))
        paramArrayList.add(view); 
    } 
  }
  
  public static void b(a parama, a.a parama1, SparseArray paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroidx/fragment/app/Fragment;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #5
    //   14: getfield y : I
    //   17: istore #6
    //   19: iload #6
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic androidx/fragment/app/j.a : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #7
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #7
    //   48: iconst_0
    //   49: istore #8
    //   51: iload #7
    //   53: iconst_1
    //   54: if_icmpeq -> 281
    //   57: iload #7
    //   59: iconst_3
    //   60: if_icmpeq -> 196
    //   63: iload #7
    //   65: iconst_4
    //   66: if_icmpeq -> 145
    //   69: iload #7
    //   71: iconst_5
    //   72: if_icmpeq -> 103
    //   75: iload #7
    //   77: bipush #6
    //   79: if_icmpeq -> 196
    //   82: iload #7
    //   84: bipush #7
    //   86: if_icmpeq -> 281
    //   89: iconst_0
    //   90: istore #7
    //   92: iload #7
    //   94: istore #9
    //   96: iload #9
    //   98: istore #10
    //   100: goto -> 331
    //   103: iload #4
    //   105: ifeq -> 135
    //   108: aload #5
    //   110: getfield O : Z
    //   113: ifeq -> 318
    //   116: aload #5
    //   118: getfield A : Z
    //   121: ifne -> 318
    //   124: aload #5
    //   126: getfield k : Z
    //   129: ifeq -> 318
    //   132: goto -> 312
    //   135: aload #5
    //   137: getfield A : Z
    //   140: istore #8
    //   142: goto -> 321
    //   145: iload #4
    //   147: ifeq -> 177
    //   150: aload #5
    //   152: getfield O : Z
    //   155: ifeq -> 246
    //   158: aload #5
    //   160: getfield k : Z
    //   163: ifeq -> 246
    //   166: aload #5
    //   168: getfield A : Z
    //   171: ifeq -> 246
    //   174: goto -> 240
    //   177: aload #5
    //   179: getfield k : Z
    //   182: ifeq -> 246
    //   185: aload #5
    //   187: getfield A : Z
    //   190: ifne -> 246
    //   193: goto -> 174
    //   196: aload #5
    //   198: getfield k : Z
    //   201: istore #11
    //   203: iload #4
    //   205: ifeq -> 252
    //   208: iload #11
    //   210: ifne -> 246
    //   213: aload #5
    //   215: getfield I : Landroid/view/View;
    //   218: astore_1
    //   219: aload_1
    //   220: ifnull -> 246
    //   223: aload_1
    //   224: invokevirtual getVisibility : ()I
    //   227: ifne -> 246
    //   230: aload #5
    //   232: getfield P : F
    //   235: fconst_0
    //   236: fcmpl
    //   237: iflt -> 246
    //   240: iconst_1
    //   241: istore #7
    //   243: goto -> 268
    //   246: iconst_0
    //   247: istore #7
    //   249: goto -> 268
    //   252: iload #11
    //   254: ifeq -> 246
    //   257: aload #5
    //   259: getfield A : Z
    //   262: ifne -> 246
    //   265: goto -> 240
    //   268: iload #7
    //   270: istore #10
    //   272: iconst_0
    //   273: istore #7
    //   275: iconst_1
    //   276: istore #9
    //   278: goto -> 331
    //   281: iload #4
    //   283: ifeq -> 296
    //   286: aload #5
    //   288: getfield N : Z
    //   291: istore #8
    //   293: goto -> 321
    //   296: aload #5
    //   298: getfield k : Z
    //   301: ifne -> 318
    //   304: aload #5
    //   306: getfield A : Z
    //   309: ifne -> 318
    //   312: iconst_1
    //   313: istore #8
    //   315: goto -> 321
    //   318: iconst_0
    //   319: istore #8
    //   321: iconst_0
    //   322: istore #9
    //   324: iload #9
    //   326: istore #10
    //   328: iconst_1
    //   329: istore #7
    //   331: aload_2
    //   332: iload #6
    //   334: invokevirtual get : (I)Ljava/lang/Object;
    //   337: checkcast androidx/fragment/app/j$e
    //   340: astore #12
    //   342: aload #12
    //   344: astore_1
    //   345: iload #8
    //   347: ifeq -> 375
    //   350: aload #12
    //   352: aload_2
    //   353: iload #6
    //   355: invokestatic p : (Landroidx/fragment/app/j$e;Landroid/util/SparseArray;I)Landroidx/fragment/app/j$e;
    //   358: astore_1
    //   359: aload_1
    //   360: aload #5
    //   362: putfield a : Landroidx/fragment/app/Fragment;
    //   365: aload_1
    //   366: iload_3
    //   367: putfield b : Z
    //   370: aload_1
    //   371: aload_0
    //   372: putfield c : Landroidx/fragment/app/a;
    //   375: iload #4
    //   377: ifne -> 452
    //   380: iload #7
    //   382: ifeq -> 452
    //   385: aload_1
    //   386: ifnull -> 403
    //   389: aload_1
    //   390: getfield d : Landroidx/fragment/app/Fragment;
    //   393: aload #5
    //   395: if_acmpne -> 403
    //   398: aload_1
    //   399: aconst_null
    //   400: putfield d : Landroidx/fragment/app/Fragment;
    //   403: aload_0
    //   404: getfield a : Landroidx/fragment/app/g;
    //   407: astore #12
    //   409: aload #5
    //   411: getfield a : I
    //   414: iconst_1
    //   415: if_icmpge -> 452
    //   418: aload #12
    //   420: getfield l : I
    //   423: iconst_1
    //   424: if_icmplt -> 452
    //   427: aload_0
    //   428: getfield t : Z
    //   431: ifne -> 452
    //   434: aload #12
    //   436: aload #5
    //   438: invokevirtual w0 : (Landroidx/fragment/app/Fragment;)V
    //   441: aload #12
    //   443: aload #5
    //   445: iconst_1
    //   446: iconst_0
    //   447: iconst_0
    //   448: iconst_0
    //   449: invokevirtual G0 : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   452: aload_1
    //   453: astore #12
    //   455: iload #10
    //   457: ifeq -> 502
    //   460: aload_1
    //   461: ifnull -> 474
    //   464: aload_1
    //   465: astore #12
    //   467: aload_1
    //   468: getfield d : Landroidx/fragment/app/Fragment;
    //   471: ifnonnull -> 502
    //   474: aload_1
    //   475: aload_2
    //   476: iload #6
    //   478: invokestatic p : (Landroidx/fragment/app/j$e;Landroid/util/SparseArray;I)Landroidx/fragment/app/j$e;
    //   481: astore #12
    //   483: aload #12
    //   485: aload #5
    //   487: putfield d : Landroidx/fragment/app/Fragment;
    //   490: aload #12
    //   492: iload_3
    //   493: putfield e : Z
    //   496: aload #12
    //   498: aload_0
    //   499: putfield f : Landroidx/fragment/app/a;
    //   502: iload #4
    //   504: ifne -> 533
    //   507: iload #9
    //   509: ifeq -> 533
    //   512: aload #12
    //   514: ifnull -> 533
    //   517: aload #12
    //   519: getfield a : Landroidx/fragment/app/Fragment;
    //   522: aload #5
    //   524: if_acmpne -> 533
    //   527: aload #12
    //   529: aconst_null
    //   530: putfield a : Landroidx/fragment/app/Fragment;
    //   533: return
  }
  
  public static void c(a parama, SparseArray paramSparseArray, boolean paramBoolean) {
    int i = parama.b.size();
    for (byte b = 0; b < i; b++)
      b(parama, parama.b.get(b), paramSparseArray, false, paramBoolean); 
  }
  
  public static f.a d(int paramInt1, ArrayList<a> paramArrayList1, ArrayList<Boolean> paramArrayList2, int paramInt2, int paramInt3) {
    f.a a = new f.a();
    while (--paramInt3 >= paramInt2) {
      a a1 = paramArrayList1.get(paramInt3);
      if (a1.p(paramInt1)) {
        boolean bool = ((Boolean)paramArrayList2.get(paramInt3)).booleanValue();
        ArrayList<String> arrayList = a1.r;
        if (arrayList != null) {
          ArrayList<String> arrayList1;
          int i = arrayList.size();
          if (bool) {
            arrayList = a1.r;
            arrayList1 = a1.s;
          } else {
            arrayList1 = a1.r;
            arrayList = a1.s;
          } 
          for (byte b = 0; b < i; b++) {
            String str2 = arrayList1.get(b);
            String str3 = arrayList.get(b);
            String str1 = (String)a.remove(str3);
            if (str1 != null) {
              a.put(str2, str1);
            } else {
              a.put(str2, str3);
            } 
          } 
        } 
      } 
      paramInt3--;
    } 
    return a;
  }
  
  public static void e(a parama, SparseArray paramSparseArray, boolean paramBoolean) {
    if (!parama.a.n.c())
      return; 
    for (int i = parama.b.size() - 1; i >= 0; i--)
      b(parama, parama.b.get(i), paramSparseArray, true, paramBoolean); 
  }
  
  public static void f(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, f.a parama, boolean paramBoolean2) {
    if (paramBoolean1) {
      paramFragment2.r();
    } else {
      paramFragment1.r();
    } 
  }
  
  public static boolean g(l paraml, List paramList) {
    int i = paramList.size();
    for (byte b = 0; b < i; b++) {
      if (!paraml.e(paramList.get(b)))
        return false; 
    } 
    return true;
  }
  
  public static f.a h(l paraml, f.a parama, Object paramObject, e parame) {
    ArrayList arrayList;
    Fragment fragment = parame.a;
    View view = fragment.F();
    if (parama.isEmpty() || paramObject == null || view == null) {
      parama.clear();
      return null;
    } 
    paramObject = new f.a();
    paraml.j((Map)paramObject, view);
    a a1 = parame.c;
    if (parame.b) {
      fragment.t();
      arrayList = a1.r;
    } else {
      fragment.r();
      arrayList = ((a)arrayList).s;
    } 
    if (arrayList != null) {
      paramObject.n(arrayList);
      paramObject.n(parama.values());
    } 
    x(parama, (f.a)paramObject);
    return (f.a)paramObject;
  }
  
  public static f.a i(l paraml, f.a parama, Object paramObject, e parame) {
    ArrayList arrayList;
    if (parama.isEmpty() || paramObject == null) {
      parama.clear();
      return null;
    } 
    Fragment fragment = parame.d;
    paramObject = new f.a();
    paraml.j((Map)paramObject, fragment.F());
    a a1 = parame.f;
    if (parame.e) {
      fragment.r();
      arrayList = a1.s;
    } else {
      fragment.t();
      arrayList = ((a)arrayList).r;
    } 
    paramObject.n(arrayList);
    parama.n(paramObject.keySet());
    return (f.a)paramObject;
  }
  
  public static l j(Fragment paramFragment1, Fragment paramFragment2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramFragment1 != null) {
      Object object2 = paramFragment1.s();
      if (object2 != null)
        arrayList.add(object2); 
      object2 = paramFragment1.B();
      if (object2 != null)
        arrayList.add(object2); 
      Object object1 = paramFragment1.D();
      if (object1 != null)
        arrayList.add(object1); 
    } 
    if (paramFragment2 != null) {
      Object object = paramFragment2.q();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.z();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.C();
      if (object != null)
        arrayList.add(object); 
    } 
    if (arrayList.isEmpty())
      return null; 
    l l1 = b;
    if (l1 != null && g(l1, arrayList))
      return l1; 
    l l2 = c;
    if (l2 != null && g(l2, arrayList))
      return l2; 
    if (l1 == null && l2 == null)
      return null; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  public static ArrayList k(l paraml, Object paramObject, Fragment paramFragment, ArrayList<?> paramArrayList, View paramView) {
    if (paramObject != null) {
      ArrayList<View> arrayList2 = new ArrayList();
      View view = paramFragment.F();
      if (view != null)
        paraml.f(arrayList2, view); 
      if (paramArrayList != null)
        arrayList2.removeAll(paramArrayList); 
      ArrayList<View> arrayList1 = arrayList2;
      if (!arrayList2.isEmpty()) {
        arrayList2.add(paramView);
        paraml.b(paramObject, arrayList2);
        arrayList1 = arrayList2;
      } 
    } else {
      paramFragment = null;
    } 
    return (ArrayList)paramFragment;
  }
  
  public static Object l(l paraml, ViewGroup paramViewGroup, View paramView, f.a parama, e parame, ArrayList paramArrayList1, ArrayList paramArrayList2, Object paramObject1, Object paramObject2) {
    Object object;
    Fragment fragment1 = parame.a;
    Fragment fragment2 = parame.d;
    if (fragment1 == null || fragment2 == null)
      return null; 
    boolean bool = parame.b;
    if (parama.isEmpty()) {
      object = null;
    } else {
      object = t(paraml, fragment1, fragment2, bool);
    } 
    f.a a1 = i(paraml, parama, object, parame);
    if (parama.isEmpty()) {
      object = null;
    } else {
      paramArrayList1.addAll(a1.values());
    } 
    if (paramObject1 == null && paramObject2 == null && object == null)
      return null; 
    f(fragment1, fragment2, bool, a1, true);
    if (object != null) {
      Rect rect = new Rect();
      paraml.y(object, paramView, paramArrayList1);
      z(paraml, object, paramObject2, a1, parame.e, parame.f);
      paramObject2 = rect;
      if (paramObject1 != null) {
        paraml.u(paramObject1, rect);
        paramObject2 = rect;
      } 
    } else {
      paramObject2 = null;
    } 
    m.a((View)paramViewGroup, new d(paraml, parama, object, parame, paramArrayList2, paramView, fragment1, fragment2, bool, paramArrayList1, paramObject1, (Rect)paramObject2));
    return object;
  }
  
  public static Object m(l paraml, ViewGroup paramViewGroup, View paramView, f.a parama, e parame, ArrayList paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    e e1;
    Object object1;
    Object object2;
    Fragment fragment1 = parame.a;
    Fragment fragment2 = parame.d;
    if (fragment1 != null)
      fragment1.F().setVisibility(0); 
    if (fragment1 == null || fragment2 == null)
      return null; 
    boolean bool = parame.b;
    if (parama.isEmpty()) {
      object2 = null;
    } else {
      object2 = t(paraml, fragment1, fragment2, bool);
    } 
    f.a a1 = i(paraml, parama, object2, parame);
    f.a a2 = h(paraml, parama, object2, parame);
    if (parama.isEmpty()) {
      if (a1 != null)
        a1.clear(); 
      if (a2 != null)
        a2.clear(); 
      parama = null;
    } else {
      a(paramArrayList1, a1, parama.keySet());
      a(paramArrayList2, a2, parama.values());
      object1 = object2;
    } 
    if (paramObject1 == null && paramObject2 == null && object1 == null)
      return null; 
    f(fragment1, fragment2, bool, a1, true);
    if (object1 != null) {
      paramArrayList2.add(paramView);
      paraml.y(object1, paramView, paramArrayList1);
      z(paraml, object1, paramObject2, a1, parame.e, parame.f);
      Rect rect = new Rect();
      View view = s(a2, parame, paramObject1, bool);
      if (view != null)
        paraml.u(paramObject1, rect); 
    } else {
      parame = null;
      e1 = parame;
    } 
    m.a((View)paramViewGroup, new c(fragment1, fragment2, bool, a2, (View)parame, paraml, (Rect)e1));
    return object1;
  }
  
  public static void n(g paramg, int paramInt, e parame, View paramView, f.a parama) {
    if (paramg.n.c()) {
      ViewGroup viewGroup = (ViewGroup)paramg.n.b(paramInt);
    } else {
      paramg = null;
    } 
    if (paramg == null)
      return; 
    Fragment fragment1 = parame.a;
    Fragment fragment2 = parame.d;
    l l1 = j(fragment2, fragment1);
    if (l1 == null)
      return; 
    boolean bool1 = parame.b;
    boolean bool2 = parame.e;
    Object object1 = q(l1, fragment1, bool1);
    Object object2 = r(l1, fragment2, bool2);
    ArrayList arrayList2 = new ArrayList();
    ArrayList arrayList3 = new ArrayList();
    Object object4 = l(l1, (ViewGroup)paramg, paramView, parama, parame, arrayList2, arrayList3, object1, object2);
    if (object1 == null && object4 == null && object2 == null)
      return; 
    ArrayList arrayList1 = k(l1, object2, fragment2, arrayList2, paramView);
    if (arrayList1 == null || arrayList1.isEmpty())
      object2 = null; 
    l1.a(object1, paramView);
    Object object3 = u(l1, object1, object2, object4, fragment1, parame.b);
    if (object3 != null) {
      ArrayList arrayList = new ArrayList();
      l1.t(object3, object1, arrayList, object2, arrayList1, object4, arrayList3);
      y(l1, (ViewGroup)paramg, fragment1, paramView, arrayList3, object1, arrayList, object2, arrayList1);
      l1.w((View)paramg, arrayList3, (Map)parama);
      l1.c((ViewGroup)paramg, object3);
      l1.s((ViewGroup)paramg, arrayList3, (Map)parama);
    } 
  }
  
  public static void o(g paramg, int paramInt, e parame, View paramView, f.a parama) {
    if (paramg.n.c()) {
      ViewGroup viewGroup = (ViewGroup)paramg.n.b(paramInt);
    } else {
      paramg = null;
    } 
    if (paramg == null)
      return; 
    Fragment fragment1 = parame.a;
    Fragment fragment2 = parame.d;
    l l1 = j(fragment2, fragment1);
    if (l1 == null)
      return; 
    boolean bool1 = parame.b;
    boolean bool2 = parame.e;
    ArrayList arrayList2 = new ArrayList();
    ArrayList arrayList3 = new ArrayList();
    Object object3 = q(l1, fragment1, bool1);
    Object object4 = r(l1, fragment2, bool2);
    Object object5 = m(l1, (ViewGroup)paramg, paramView, parama, parame, arrayList3, arrayList2, object3, object4);
    if (object3 == null && object5 == null && object4 == null)
      return; 
    Object object1 = object4;
    object4 = k(l1, object1, fragment2, arrayList3, paramView);
    ArrayList arrayList1 = k(l1, object3, fragment1, arrayList2, paramView);
    A(arrayList1, 4);
    Object object2 = u(l1, object3, object1, object5, fragment1, bool1);
    if (object2 != null) {
      v(l1, object1, fragment2, (ArrayList)object4);
      ArrayList arrayList = l1.o(arrayList2);
      l1.t(object2, object3, arrayList1, object1, (ArrayList)object4, object5, arrayList2);
      l1.c((ViewGroup)paramg, object2);
      l1.x((View)paramg, arrayList3, arrayList2, arrayList, (Map)parama);
      A(arrayList1, 0);
      l1.z(object5, arrayList3, arrayList2);
    } 
  }
  
  public static e p(e parame, SparseArray paramSparseArray, int paramInt) {
    e e1 = parame;
    if (parame == null) {
      e1 = new e();
      paramSparseArray.put(paramInt, e1);
    } 
    return e1;
  }
  
  public static Object q(l paraml, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.z();
    } else {
      object = object.q();
    } 
    return paraml.g(object);
  }
  
  public static Object r(l paraml, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.B();
    } else {
      object = object.s();
    } 
    return paraml.g(object);
  }
  
  public static View s(f.a parama, e parame, Object paramObject, boolean paramBoolean) {
    a a1 = parame.c;
    if (paramObject != null && parama != null) {
      paramObject = a1.r;
      if (paramObject != null && !paramObject.isEmpty()) {
        ArrayList<String> arrayList;
        if (paramBoolean) {
          arrayList = a1.r;
        } else {
          arrayList = ((a)arrayList).s;
        } 
        return (View)parama.get(arrayList.get(0));
      } 
    } 
    return null;
  }
  
  public static Object t(l paraml, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean) {
    Object object;
    if (paramFragment1 == null || paramFragment2 == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment2.D();
    } else {
      object = object.C();
    } 
    return paraml.A(paraml.g(object));
  }
  
  public static Object u(l paraml, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramObject1 != null && paramObject2 != null && paramFragment != null) {
      if (paramBoolean) {
        paramBoolean = paramFragment.l();
      } else {
        paramBoolean = paramFragment.k();
      } 
    } else {
      paramBoolean = true;
    } 
    if (paramBoolean) {
      object = paraml.n(paramObject2, paramObject1, paramObject3);
    } else {
      object = object.m(paramObject2, paramObject1, paramObject3);
    } 
    return object;
  }
  
  public static void v(l paraml, Object paramObject, Fragment paramFragment, ArrayList paramArrayList) {
    if (paramFragment != null && paramObject != null && paramFragment.k && paramFragment.A && paramFragment.O) {
      paramFragment.Y0(true);
      paraml.r(paramObject, paramFragment.F(), paramArrayList);
      m.a((View)paramFragment.H, new a(paramArrayList));
    } 
  }
  
  public static l w() {
    try {
      return Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static void x(f.a parama1, f.a parama2) {
    for (int i = parama1.size() - 1; i >= 0; i--) {
      if (!parama2.containsKey(parama1.l(i)))
        parama1.j(i); 
    } 
  }
  
  public static void y(l paraml, ViewGroup paramViewGroup, Fragment paramFragment, View paramView, ArrayList paramArrayList1, Object paramObject1, ArrayList paramArrayList2, Object paramObject2, ArrayList paramArrayList3) {
    m.a((View)paramViewGroup, new b(paramObject1, paraml, paramView, paramFragment, paramArrayList1, paramArrayList2, paramArrayList3, paramObject2));
  }
  
  public static void z(l paraml, Object paramObject1, Object paramObject2, f.a parama, boolean paramBoolean, a parama1) {
    ArrayList arrayList = parama1.r;
    if (arrayList != null && !arrayList.isEmpty()) {
      ArrayList<String> arrayList1;
      if (paramBoolean) {
        arrayList1 = parama1.s;
      } else {
        arrayList1 = ((a)arrayList1).r;
      } 
      View view = (View)parama.get(arrayList1.get(0));
      paraml.v(paramObject1, view);
      if (paramObject2 != null)
        paraml.v(paramObject2, view); 
    } 
  }
  
  public static final class a implements Runnable {
    public a(ArrayList param1ArrayList) {}
    
    public void run() {
      j.A(this.a, 4);
    }
  }
  
  public static final class b implements Runnable {
    public b(Object param1Object1, l param1l, View param1View, Fragment param1Fragment, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, Object param1Object2) {}
    
    public void run() {
      Object object = this.a;
      if (object != null) {
        this.b.p(object, this.c);
        object = j.k(this.b, this.a, this.d, this.e, this.c);
        this.f.addAll((Collection)object);
      } 
      if (this.g != null) {
        if (this.h != null) {
          object = new ArrayList();
          object.add(this.c);
          this.b.q(this.h, this.g, (ArrayList)object);
        } 
        this.g.clear();
        this.g.add(this.c);
      } 
    }
  }
  
  public static final class c implements Runnable {
    public c(Fragment param1Fragment1, Fragment param1Fragment2, boolean param1Boolean, f.a param1a, View param1View, l param1l, Rect param1Rect) {}
    
    public void run() {
      j.f(this.a, this.b, this.c, this.d, false);
      View view = this.e;
      if (view != null)
        this.f.k(view, this.g); 
    }
  }
  
  public static final class d implements Runnable {
    public d(l param1l, f.a param1a, Object param1Object1, j.e param1e, ArrayList param1ArrayList1, View param1View, Fragment param1Fragment1, Fragment param1Fragment2, boolean param1Boolean, ArrayList param1ArrayList2, Object param1Object2, Rect param1Rect) {}
    
    public void run() {
      f.a a1 = j.h(this.a, this.b, this.c, this.d);
      if (a1 != null) {
        this.e.addAll(a1.values());
        this.e.add(this.f);
      } 
      j.f(this.g, this.h, this.i, a1, false);
      Object object = this.c;
      if (object != null) {
        this.a.z(object, this.j, this.e);
        object = j.s(a1, this.d, this.k, this.i);
        if (object != null)
          this.a.k((View)object, this.l); 
      } 
    }
  }
  
  public static class e {
    public Fragment a;
    
    public boolean b;
    
    public a c;
    
    public Fragment d;
    
    public boolean e;
    
    public a f;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */