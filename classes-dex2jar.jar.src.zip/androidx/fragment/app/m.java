package androidx.fragment.app;

import android.view.View;
import android.view.ViewTreeObserver;

public class m implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  public final View a;
  
  public ViewTreeObserver b;
  
  public final Runnable c;
  
  public m(View paramView, Runnable paramRunnable) {
    this.a = paramView;
    this.b = paramView.getViewTreeObserver();
    this.c = paramRunnable;
  }
  
  public static m a(View paramView, Runnable paramRunnable) {
    m m1 = new m(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(m1);
    paramView.addOnAttachStateChangeListener(m1);
    return m1;
  }
  
  public void b() {
    ViewTreeObserver viewTreeObserver;
    if (this.b.isAlive()) {
      viewTreeObserver = this.b;
    } else {
      viewTreeObserver = this.a.getViewTreeObserver();
    } 
    viewTreeObserver.removeOnPreDrawListener(this);
    this.a.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.c.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.b = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */