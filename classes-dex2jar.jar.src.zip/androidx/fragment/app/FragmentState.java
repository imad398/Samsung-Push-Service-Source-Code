package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import androidx.lifecycle.l;

final class FragmentState implements Parcelable {
  public static final Parcelable.Creator<FragmentState> CREATOR = new a();
  
  final Bundle mArguments;
  
  final String mClassName;
  
  final int mContainerId;
  
  final boolean mDetached;
  
  final int mFragmentId;
  
  final boolean mFromLayout;
  
  final boolean mHidden;
  
  final int mIndex;
  
  Fragment mInstance;
  
  final boolean mRetainInstance;
  
  Bundle mSavedFragmentState;
  
  final String mTag;
  
  public FragmentState(Parcel paramParcel) {
    boolean bool2;
    this.mClassName = paramParcel.readString();
    this.mIndex = paramParcel.readInt();
    int i = paramParcel.readInt();
    boolean bool1 = true;
    if (i != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.mFromLayout = bool2;
    this.mFragmentId = paramParcel.readInt();
    this.mContainerId = paramParcel.readInt();
    this.mTag = paramParcel.readString();
    if (paramParcel.readInt() != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.mRetainInstance = bool2;
    if (paramParcel.readInt() != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.mDetached = bool2;
    this.mArguments = paramParcel.readBundle();
    if (paramParcel.readInt() != 0) {
      bool2 = bool1;
    } else {
      bool2 = false;
    } 
    this.mHidden = bool2;
    this.mSavedFragmentState = paramParcel.readBundle();
  }
  
  public FragmentState(Fragment paramFragment) {
    this.mClassName = paramFragment.getClass().getName();
    this.mIndex = paramFragment.e;
    this.mFromLayout = paramFragment.m;
    this.mFragmentId = paramFragment.x;
    this.mContainerId = paramFragment.y;
    this.mTag = paramFragment.z;
    this.mRetainInstance = paramFragment.C;
    this.mDetached = paramFragment.B;
    this.mArguments = paramFragment.g;
    this.mHidden = paramFragment.A;
  }
  
  public Fragment a(e parame, c paramc, Fragment paramFragment, h paramh, l paraml) {
    if (this.mInstance == null) {
      Fragment fragment2;
      Context context = parame.e();
      Bundle bundle2 = this.mArguments;
      if (bundle2 != null)
        bundle2.setClassLoader(context.getClassLoader()); 
      if (paramc != null) {
        fragment2 = paramc.a(context, this.mClassName, this.mArguments);
      } else {
        fragment2 = Fragment.H(context, this.mClassName, this.mArguments);
      } 
      this.mInstance = fragment2;
      Bundle bundle1 = this.mSavedFragmentState;
      if (bundle1 != null) {
        bundle1.setClassLoader(context.getClassLoader());
        this.mInstance.b = this.mSavedFragmentState;
      } 
      this.mInstance.Z0(this.mIndex, paramFragment);
      Fragment fragment1 = this.mInstance;
      fragment1.m = this.mFromLayout;
      fragment1.o = true;
      fragment1.x = this.mFragmentId;
      fragment1.y = this.mContainerId;
      fragment1.z = this.mTag;
      fragment1.C = this.mRetainInstance;
      fragment1.B = this.mDetached;
      fragment1.A = this.mHidden;
      fragment1.r = parame.e;
      if (g.E) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiated fragment ");
        stringBuilder.append(this.mInstance);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    Fragment fragment = this.mInstance;
    fragment.u = paramh;
    fragment.v = paraml;
    return fragment;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.mClassName);
    paramParcel.writeInt(this.mIndex);
    paramParcel.writeInt(this.mFromLayout);
    paramParcel.writeInt(this.mFragmentId);
    paramParcel.writeInt(this.mContainerId);
    paramParcel.writeString(this.mTag);
    paramParcel.writeInt(this.mRetainInstance);
    paramParcel.writeInt(this.mDetached);
    paramParcel.writeBundle(this.mArguments);
    paramParcel.writeInt(this.mHidden);
    paramParcel.writeBundle(this.mSavedFragmentState);
  }
  
  public static final class a implements Parcelable.Creator {
    public FragmentState a(Parcel param1Parcel) {
      return new FragmentState(param1Parcel);
    }
    
    public FragmentState[] b(int param1Int) {
      return new FragmentState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/FragmentState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */