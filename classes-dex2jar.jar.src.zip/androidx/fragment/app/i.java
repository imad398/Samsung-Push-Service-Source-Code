package androidx.fragment.app;

public abstract class i {
  public abstract i b(Fragment paramFragment, String paramString);
  
  public abstract int c();
  
  public abstract int d();
  
  public abstract i e(Fragment paramFragment);
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */