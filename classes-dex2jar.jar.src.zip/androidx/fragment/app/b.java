package androidx.fragment.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public abstract class b extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  public int Y = 0;
  
  public int Z = 0;
  
  public boolean a0 = true;
  
  public boolean b0 = true;
  
  public int c0 = -1;
  
  public Dialog d0;
  
  public boolean e0;
  
  public boolean f0;
  
  public boolean g0;
  
  public void Q(Bundle paramBundle) {
    super.Q(paramBundle);
    if (!this.b0)
      return; 
    View view = F();
    if (view != null)
      if (view.getParent() == null) {
        this.d0.setContentView(view);
      } else {
        throw new IllegalStateException("DialogFragment can not be attached to a container view");
      }  
    FragmentActivity fragmentActivity = j();
    if (fragmentActivity != null)
      this.d0.setOwnerActivity((Activity)fragmentActivity); 
    this.d0.setCancelable(this.a0);
    this.d0.setOnCancelListener(this);
    this.d0.setOnDismissListener(this);
    if (paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.d0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  public void T(Context paramContext) {
    super.T(paramContext);
    if (!this.g0)
      this.f0 = false; 
  }
  
  public void W(Bundle paramBundle) {
    boolean bool;
    super.W(paramBundle);
    if (this.y == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.b0 = bool;
    if (paramBundle != null) {
      this.Y = paramBundle.getInt("android:style", 0);
      this.Z = paramBundle.getInt("android:theme", 0);
      this.a0 = paramBundle.getBoolean("android:cancelable", true);
      this.b0 = paramBundle.getBoolean("android:showsDialog", this.b0);
      this.c0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public void d0() {
    super.d0();
    Dialog dialog = this.d0;
    if (dialog != null) {
      this.e0 = true;
      dialog.dismiss();
      this.d0 = null;
    } 
  }
  
  public void e0() {
    super.e0();
    if (!this.g0 && !this.f0)
      this.f0 = true; 
  }
  
  public LayoutInflater f0(Bundle paramBundle) {
    if (!this.b0)
      return super.f0(paramBundle); 
    Dialog dialog = h1(paramBundle);
    this.d0 = dialog;
    if (dialog != null) {
      j1(dialog, this.Y);
      Context context1 = this.d0.getContext();
      return (LayoutInflater)context1.getSystemService("layout_inflater");
    } 
    Context context = this.s.e();
    return (LayoutInflater)context.getSystemService("layout_inflater");
  }
  
  public void g1(boolean paramBoolean) {
    if (this.f0)
      return; 
    this.f0 = true;
    this.g0 = false;
    Dialog dialog = this.d0;
    if (dialog != null)
      dialog.dismiss(); 
    this.e0 = true;
    if (this.c0 >= 0) {
      u().f(this.c0, 1);
      this.c0 = -1;
    } else {
      i i = u().a();
      i.e(this);
      if (paramBoolean) {
        i.d();
      } else {
        i.c();
      } 
    } 
  }
  
  public abstract Dialog h1(Bundle paramBundle);
  
  public void i1(boolean paramBoolean) {
    this.b0 = paramBoolean;
  }
  
  public void j1(Dialog paramDialog, int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt != 3)
        return; 
      paramDialog.getWindow().addFlags(24);
    } 
    paramDialog.requestWindowFeature(1);
  }
  
  public void k1(f paramf, String paramString) {
    this.f0 = false;
    this.g0 = true;
    i i = paramf.a();
    i.b(this, paramString);
    i.c();
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.e0)
      g1(true); 
  }
  
  public void r0(Bundle paramBundle) {
    super.r0(paramBundle);
    Dialog dialog = this.d0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      if (bundle != null)
        paramBundle.putBundle("android:savedDialogState", bundle); 
    } 
    int i = this.Y;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.Z;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.a0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.b0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.c0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public void s0() {
    super.s0();
    Dialog dialog = this.d0;
    if (dialog != null) {
      this.e0 = false;
      dialog.show();
    } 
  }
  
  public void t0() {
    super.t0();
    Dialog dialog = this.d0;
    if (dialog != null)
      dialog.hide(); 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */