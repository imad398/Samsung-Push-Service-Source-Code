package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.core.app.ComponentActivity;
import androidx.lifecycle.d;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import f.h;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class FragmentActivity extends ComponentActivity implements m {
  public final Handler c = new a(this);
  
  public final d d = d.b(new b(this));
  
  public l e;
  
  public boolean f;
  
  public boolean g;
  
  public boolean h = true;
  
  public boolean i;
  
  public boolean j;
  
  public int k;
  
  public h l;
  
  public static void d(int paramInt) {
    if ((paramInt & 0xFFFF0000) == 0)
      return; 
    throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
  }
  
  public static boolean i(f paramf, androidx.lifecycle.b.b paramb) {
    Iterator<Fragment> iterator = paramf.d().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.e().a().a(androidx.lifecycle.b.b.d)) {
        fragment.S.e(paramb);
        bool1 = true;
      } 
      f f1 = fragment.w0();
      bool = bool1;
      if (f1 != null)
        bool = bool1 | i(f1, paramb); 
    } 
    return bool;
  }
  
  public l b() {
    if (getApplication() != null) {
      if (this.e == null) {
        c c = (c)getLastNonConfigurationInstance();
        if (c != null)
          this.e = c.b; 
        if (this.e == null)
          this.e = new l(); 
      } 
      return this.e;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final int c(Fragment paramFragment) {
    if (this.l.m() < 65534) {
      while (this.l.i(this.k) >= 0)
        this.k = (this.k + 1) % 65534; 
      int i = this.k;
      this.l.k(i, paramFragment.f);
      this.k = (this.k + 1) % 65534;
      return i;
    } 
    throw new IllegalStateException("Too many pending Fragment activity results.");
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.f);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.g);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.h);
    if (getApplication() != null)
      p.a.b((d)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.d.u().b(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public androidx.lifecycle.b e() {
    return super.e();
  }
  
  public final View f(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.d.w(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public f g() {
    return this.d.u();
  }
  
  public final void h() {
    do {
    
    } while (i(g(), androidx.lifecycle.b.b.c));
  }
  
  public void j(Fragment paramFragment) {}
  
  public boolean k(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  public void l() {
    this.d.p();
  }
  
  public Object m() {
    return null;
  }
  
  public void n(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    this.j = true;
    if (paramInt == -1)
      try {
        i.a.i((Activity)this, paramIntent, -1, paramBundle);
        return;
      } finally {
        this.j = false;
      }  
    d(paramInt);
    i.a.i((Activity)this, paramIntent, (c(paramFragment) + 1 << 16) + (paramInt & 0xFFFF), paramBundle);
    this.j = false;
  }
  
  public void o() {
    invalidateOptionsMenu();
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    this.d.v();
    int i = paramInt1 >> 16;
    if (i != 0) {
      String str = (String)this.l.g(--i);
      this.l.l(i);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      Fragment fragment = this.d.t(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
      } else {
        fragment.R(paramInt1 & 0xFFFF, paramInt2, (Intent)stringBuilder);
      } 
      return;
    } 
    i.a.h();
    super.onActivityResult(paramInt1, paramInt2, (Intent)stringBuilder);
  }
  
  public void onBackPressed() {
    f f = this.d.u();
    boolean bool = f.e();
    if (bool && Build.VERSION.SDK_INT <= 25)
      return; 
    if (bool || !f.g())
      super.onBackPressed(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.d.v();
    this.d.d(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    d d1 = this.d;
    h h1 = null;
    d1.a(null);
    super.onCreate(paramBundle);
    c c = (c)getLastNonConfigurationInstance();
    if (c != null) {
      l l1 = c.b;
      if (l1 != null && this.e == null)
        this.e = l1; 
    } 
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      d1 = this.d;
      if (c != null)
        h1 = c.c; 
      d1.x(parcelable, h1);
      if (paramBundle.containsKey("android:support:next_request_index")) {
        this.k = paramBundle.getInt("android:support:next_request_index");
        int[] arrayOfInt = paramBundle.getIntArray("android:support:request_indicies");
        String[] arrayOfString = paramBundle.getStringArray("android:support:request_fragment_who");
        if (arrayOfInt == null || arrayOfString == null || arrayOfInt.length != arrayOfString.length) {
          Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
        } else {
          this.l = new h(arrayOfInt.length);
          for (byte b = 0; b < arrayOfInt.length; b++)
            this.l.k(arrayOfInt[b], arrayOfString[b]); 
        } 
      } 
    } 
    if (this.l == null) {
      this.l = new h();
      this.k = 0;
    } 
    this.d.f();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.d.g(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = f(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = f(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  public void onDestroy() {
    super.onDestroy();
    if (this.e != null && !isChangingConfigurations())
      this.e.a(); 
    this.d.h();
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.d.i();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.d.e(paramMenuItem)) : this.d.k(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.d.j(paramBoolean);
  }
  
  public void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.d.v();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.d.l(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPause() {
    super.onPause();
    this.g = false;
    if (this.c.hasMessages(2)) {
      this.c.removeMessages(2);
      l();
    } 
    this.d.m();
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.d.n(paramBoolean);
  }
  
  public void onPostResume() {
    super.onPostResume();
    this.c.removeMessages(2);
    l();
    this.d.s();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0 && paramMenu != null) ? (k(paramView, paramMenu) | this.d.o(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.d.v();
    int i = paramInt >> 16 & 0xFFFF;
    if (i != 0) {
      StringBuilder stringBuilder;
      String str = (String)this.l.g(--i);
      this.l.l(i);
      if (str == null) {
        Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
        return;
      } 
      Fragment fragment = this.d.t(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result no fragment exists for who: ");
        stringBuilder.append(str);
        Log.w("FragmentActivity", stringBuilder.toString());
      } else {
        fragment.p0(paramInt & 0xFFFF, (String[])stringBuilder, paramArrayOfint);
      } 
    } 
  }
  
  public void onResume() {
    super.onResume();
    this.c.sendEmptyMessage(2);
    this.g = true;
    this.d.s();
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = m();
    h h1 = this.d.y();
    if (h1 == null && this.e == null && object == null)
      return null; 
    c c = new c();
    c.a = object;
    c.b = this.e;
    c.c = h1;
    return c;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    h();
    Parcelable parcelable = this.d.z();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
    if (this.l.m() > 0) {
      paramBundle.putInt("android:support:next_request_index", this.k);
      int[] arrayOfInt = new int[this.l.m()];
      String[] arrayOfString = new String[this.l.m()];
      for (byte b = 0; b < this.l.m(); b++) {
        arrayOfInt[b] = this.l.j(b);
        arrayOfString[b] = (String)this.l.n(b);
      } 
      paramBundle.putIntArray("android:support:request_indicies", arrayOfInt);
      paramBundle.putStringArray("android:support:request_fragment_who", arrayOfString);
    } 
  }
  
  public void onStart() {
    super.onStart();
    this.h = false;
    if (!this.f) {
      this.f = true;
      this.d.c();
    } 
    this.d.v();
    this.d.s();
    this.d.q();
  }
  
  public void onStateNotSaved() {
    this.d.v();
  }
  
  public void onStop() {
    super.onStop();
    this.h = true;
    h();
    this.d.r();
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    if (!this.j && paramInt != -1)
      d(paramInt); 
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (!this.j && paramInt != -1)
      d(paramInt); 
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.i && paramInt1 != -1)
      d(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    if (!this.i && paramInt1 != -1)
      d(paramInt1); 
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public class a extends Handler {
    public a(FragmentActivity this$0) {}
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what != 2) {
        super.handleMessage(param1Message);
      } else {
        this.a.l();
        this.a.d.s();
      } 
    }
  }
  
  public class b extends e {
    public b(FragmentActivity this$0) {
      super(this$0);
    }
    
    public View b(int param1Int) {
      return this.f.findViewById(param1Int);
    }
    
    public boolean c() {
      boolean bool;
      Window window = this.f.getWindow();
      if (window != null && window.peekDecorView() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public void h(Fragment param1Fragment) {
      this.f.j(param1Fragment);
    }
    
    public void i(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      this.f.dump(param1String, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
    }
    
    public LayoutInflater j() {
      return this.f.getLayoutInflater().cloneInContext((Context)this.f);
    }
    
    public int k() {
      int i;
      Window window = this.f.getWindow();
      if (window == null) {
        i = 0;
      } else {
        i = (window.getAttributes()).windowAnimations;
      } 
      return i;
    }
    
    public boolean l() {
      boolean bool;
      if (this.f.getWindow() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean m(Fragment param1Fragment) {
      return this.f.isFinishing() ^ true;
    }
    
    public void n(Fragment param1Fragment, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      this.f.n(param1Fragment, param1Intent, param1Int, param1Bundle);
    }
    
    public void o() {
      this.f.o();
    }
  }
  
  public static final class c {
    public Object a;
    
    public l b;
    
    public h c;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/FragmentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */