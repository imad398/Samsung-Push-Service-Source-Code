package androidx.fragment.app;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class f {
  public abstract i a();
  
  public abstract void b(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract Fragment c(String paramString);
  
  public abstract List d();
  
  public abstract boolean e();
  
  public abstract void f(int paramInt1, int paramInt2);
  
  public abstract boolean g();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */