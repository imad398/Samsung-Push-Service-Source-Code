package androidx.fragment.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class k extends l {
  public static boolean B(Transition paramTransition) {
    return (!l.l(paramTransition.getTargetIds()) || !l.l(paramTransition.getTargetNames()) || !l.l(paramTransition.getTargetTypes()));
  }
  
  public Object A(Object paramObject) {
    if (paramObject == null)
      return null; 
    TransitionSet transitionSet = new TransitionSet();
    transitionSet.addTransition((Transition)paramObject);
    return transitionSet;
  }
  
  public void a(Object paramObject, View paramView) {
    if (paramObject != null)
      ((Transition)paramObject).addTarget(paramView); 
  }
  
  public void b(Object paramObject, ArrayList<View> paramArrayList) {
    paramObject = paramObject;
    if (paramObject == null)
      return; 
    boolean bool = paramObject instanceof TransitionSet;
    int i = 0;
    int j = 0;
    if (bool) {
      paramObject = paramObject;
      i = paramObject.getTransitionCount();
      while (j < i) {
        b(paramObject.getTransitionAt(j), paramArrayList);
        j++;
      } 
    } else if (!B((Transition)paramObject) && l.l(paramObject.getTargets())) {
      int m = paramArrayList.size();
      for (j = i; j < m; j++)
        paramObject.addTarget(paramArrayList.get(j)); 
    } 
  }
  
  public void c(ViewGroup paramViewGroup, Object paramObject) {
    TransitionManager.beginDelayedTransition(paramViewGroup, (Transition)paramObject);
  }
  
  public boolean e(Object paramObject) {
    return paramObject instanceof Transition;
  }
  
  public Object g(Object paramObject) {
    if (paramObject != null) {
      paramObject = ((Transition)paramObject).clone();
    } else {
      paramObject = null;
    } 
    return paramObject;
  }
  
  public Object m(Object paramObject1, Object paramObject2, Object paramObject3) {
    paramObject1 = paramObject1;
    paramObject2 = paramObject2;
    paramObject3 = paramObject3;
    if (paramObject1 != null && paramObject2 != null) {
      paramObject1 = (new TransitionSet()).addTransition((Transition)paramObject1).addTransition((Transition)paramObject2).setOrdering(1);
    } else if (paramObject1 == null) {
      if (paramObject2 != null) {
        paramObject1 = paramObject2;
      } else {
        paramObject1 = null;
      } 
    } 
    if (paramObject3 != null) {
      paramObject2 = new TransitionSet();
      if (paramObject1 != null)
        paramObject2.addTransition((Transition)paramObject1); 
      paramObject2.addTransition((Transition)paramObject3);
      return paramObject2;
    } 
    return paramObject1;
  }
  
  public Object n(Object paramObject1, Object paramObject2, Object paramObject3) {
    TransitionSet transitionSet = new TransitionSet();
    if (paramObject1 != null)
      transitionSet.addTransition((Transition)paramObject1); 
    if (paramObject2 != null)
      transitionSet.addTransition((Transition)paramObject2); 
    if (paramObject3 != null)
      transitionSet.addTransition((Transition)paramObject3); 
    return transitionSet;
  }
  
  public void p(Object paramObject, View paramView) {
    if (paramObject != null)
      ((Transition)paramObject).removeTarget(paramView); 
  }
  
  public void q(Object paramObject, ArrayList<?> paramArrayList1, ArrayList<View> paramArrayList2) {
    paramObject = paramObject;
    boolean bool = paramObject instanceof TransitionSet;
    int i = 0;
    int j = 0;
    if (bool) {
      paramObject = paramObject;
      i = paramObject.getTransitionCount();
      while (j < i) {
        q(paramObject.getTransitionAt(j), paramArrayList1, paramArrayList2);
        j++;
      } 
    } else if (!B((Transition)paramObject)) {
      List list = paramObject.getTargets();
      if (list != null && list.size() == paramArrayList1.size() && list.containsAll(paramArrayList1)) {
        if (paramArrayList2 == null) {
          j = 0;
        } else {
          j = paramArrayList2.size();
        } 
        while (i < j) {
          paramObject.addTarget(paramArrayList2.get(i));
          i++;
        } 
        for (j = paramArrayList1.size() - 1; j >= 0; j--)
          paramObject.removeTarget((View)paramArrayList1.get(j)); 
      } 
    } 
  }
  
  public void r(Object paramObject, View paramView, ArrayList paramArrayList) {
    ((Transition)paramObject).addListener(new b(this, paramView, paramArrayList));
  }
  
  public void t(Object paramObject1, Object paramObject2, ArrayList paramArrayList1, Object paramObject3, ArrayList paramArrayList2, Object paramObject4, ArrayList paramArrayList3) {
    ((Transition)paramObject1).addListener(new c(this, paramObject2, paramArrayList1, paramObject3, paramArrayList2, paramObject4, paramArrayList3));
  }
  
  public void u(Object paramObject, Rect paramRect) {
    if (paramObject != null)
      ((Transition)paramObject).setEpicenterCallback(new d(this, paramRect)); 
  }
  
  public void v(Object paramObject, View paramView) {
    if (paramView != null) {
      paramObject = paramObject;
      Rect rect = new Rect();
      k(paramView, rect);
      paramObject.setEpicenterCallback(new a(this, rect));
    } 
  }
  
  public void y(Object paramObject, View paramView, ArrayList<View> paramArrayList) {
    paramObject = paramObject;
    List<View> list = paramObject.getTargets();
    list.clear();
    int i = paramArrayList.size();
    for (byte b = 0; b < i; b++)
      l.d(list, paramArrayList.get(b)); 
    list.add(paramView);
    paramArrayList.add(paramView);
    b(paramObject, paramArrayList);
  }
  
  public void z(Object paramObject, ArrayList paramArrayList1, ArrayList paramArrayList2) {
    paramObject = paramObject;
    if (paramObject != null) {
      paramObject.getTargets().clear();
      paramObject.getTargets().addAll(paramArrayList2);
      q(paramObject, paramArrayList1, paramArrayList2);
    } 
  }
  
  public class a extends Transition.EpicenterCallback {
    public a(k this$0, Rect param1Rect) {}
    
    public Rect onGetEpicenter(Transition param1Transition) {
      return this.a;
    }
  }
  
  public class b implements Transition.TransitionListener {
    public b(k this$0, View param1View, ArrayList param1ArrayList) {}
    
    public void onTransitionCancel(Transition param1Transition) {}
    
    public void onTransitionEnd(Transition param1Transition) {
      param1Transition.removeListener(this);
      this.a.setVisibility(8);
      int i = this.b.size();
      for (byte b1 = 0; b1 < i; b1++)
        ((View)this.b.get(b1)).setVisibility(0); 
    }
    
    public void onTransitionPause(Transition param1Transition) {}
    
    public void onTransitionResume(Transition param1Transition) {}
    
    public void onTransitionStart(Transition param1Transition) {}
  }
  
  public class c implements Transition.TransitionListener {
    public c(k this$0, Object param1Object1, ArrayList param1ArrayList1, Object param1Object2, ArrayList param1ArrayList2, Object param1Object3, ArrayList param1ArrayList3) {}
    
    public void onTransitionCancel(Transition param1Transition) {}
    
    public void onTransitionEnd(Transition param1Transition) {}
    
    public void onTransitionPause(Transition param1Transition) {}
    
    public void onTransitionResume(Transition param1Transition) {}
    
    public void onTransitionStart(Transition param1Transition) {
      Object object = this.a;
      if (object != null)
        this.g.q(object, this.b, null); 
      object = this.c;
      if (object != null)
        this.g.q(object, this.d, null); 
      object = this.e;
      if (object != null)
        this.g.q(object, this.f, null); 
    }
  }
  
  public class d extends Transition.EpicenterCallback {
    public d(k this$0, Rect param1Rect) {}
    
    public Rect onGetEpicenter(Transition param1Transition) {
      Rect rect = this.a;
      return (rect == null || rect.isEmpty()) ? null : this.a;
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */