package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
  public static final Parcelable.Creator<BackStackState> CREATOR = new a();
  
  final int mBreadCrumbShortTitleRes;
  
  final CharSequence mBreadCrumbShortTitleText;
  
  final int mBreadCrumbTitleRes;
  
  final CharSequence mBreadCrumbTitleText;
  
  final int mIndex;
  
  final String mName;
  
  final int[] mOps;
  
  final boolean mReorderingAllowed;
  
  final ArrayList<String> mSharedElementSourceNames;
  
  final ArrayList<String> mSharedElementTargetNames;
  
  final int mTransition;
  
  final int mTransitionStyle;
  
  public BackStackState(Parcel paramParcel) {
    boolean bool;
    this.mOps = paramParcel.createIntArray();
    this.mTransition = paramParcel.readInt();
    this.mTransitionStyle = paramParcel.readInt();
    this.mName = paramParcel.readString();
    this.mIndex = paramParcel.readInt();
    this.mBreadCrumbTitleRes = paramParcel.readInt();
    this.mBreadCrumbTitleText = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.mBreadCrumbShortTitleRes = paramParcel.readInt();
    this.mBreadCrumbShortTitleText = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.mSharedElementSourceNames = paramParcel.createStringArrayList();
    this.mSharedElementTargetNames = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mReorderingAllowed = bool;
  }
  
  public BackStackState(a parama) {
    int i = parama.b.size();
    this.mOps = new int[i * 6];
    if (parama.i) {
      byte b = 0;
      int j = 0;
      while (b < i) {
        a.a a1 = parama.b.get(b);
        int[] arrayOfInt = this.mOps;
        int k = j + 1;
        arrayOfInt[j] = a1.a;
        int m = k + 1;
        Fragment fragment = a1.b;
        if (fragment != null) {
          j = fragment.e;
        } else {
          j = -1;
        } 
        arrayOfInt[k] = j;
        j = m + 1;
        arrayOfInt[m] = a1.c;
        k = j + 1;
        arrayOfInt[j] = a1.d;
        m = k + 1;
        arrayOfInt[k] = a1.e;
        j = m + 1;
        arrayOfInt[m] = a1.f;
        b++;
      } 
      this.mTransition = parama.g;
      this.mTransitionStyle = parama.h;
      this.mName = parama.k;
      this.mIndex = parama.m;
      this.mBreadCrumbTitleRes = parama.n;
      this.mBreadCrumbTitleText = parama.o;
      this.mBreadCrumbShortTitleRes = parama.p;
      this.mBreadCrumbShortTitleText = parama.q;
      this.mSharedElementSourceNames = parama.r;
      this.mSharedElementTargetNames = parama.s;
      this.mReorderingAllowed = parama.t;
      return;
    } 
    throw new IllegalStateException("Not on back stack");
  }
  
  public a a(g paramg) {
    a a = new a(paramg);
    int i = 0;
    byte b = 0;
    while (i < this.mOps.length) {
      a.a a1 = new a.a();
      int[] arrayOfInt = this.mOps;
      int j = i + 1;
      a1.a = arrayOfInt[i];
      if (g.E) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiate ");
        stringBuilder.append(a);
        stringBuilder.append(" op #");
        stringBuilder.append(b);
        stringBuilder.append(" base fragment #");
        stringBuilder.append(this.mOps[j]);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      arrayOfInt = this.mOps;
      int k = j + 1;
      i = arrayOfInt[j];
      if (i >= 0) {
        Fragment fragment = (Fragment)paramg.e.get(i);
      } else {
        arrayOfInt = null;
      } 
      a1.b = (Fragment)arrayOfInt;
      arrayOfInt = this.mOps;
      i = k + 1;
      k = arrayOfInt[k];
      a1.c = k;
      int m = i + 1;
      j = arrayOfInt[i];
      a1.d = j;
      i = m + 1;
      m = arrayOfInt[m];
      a1.e = m;
      int n = arrayOfInt[i];
      a1.f = n;
      a.c = k;
      a.d = j;
      a.e = m;
      a.f = n;
      a.f(a1);
      b++;
      i++;
    } 
    a.g = this.mTransition;
    a.h = this.mTransitionStyle;
    a.k = this.mName;
    a.m = this.mIndex;
    a.i = true;
    a.n = this.mBreadCrumbTitleRes;
    a.o = this.mBreadCrumbTitleText;
    a.p = this.mBreadCrumbShortTitleRes;
    a.q = this.mBreadCrumbShortTitleText;
    a.r = this.mSharedElementSourceNames;
    a.s = this.mSharedElementTargetNames;
    a.t = this.mReorderingAllowed;
    a.g(1);
    return a;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeIntArray(this.mOps);
    paramParcel.writeInt(this.mTransition);
    paramParcel.writeInt(this.mTransitionStyle);
    paramParcel.writeString(this.mName);
    paramParcel.writeInt(this.mIndex);
    paramParcel.writeInt(this.mBreadCrumbTitleRes);
    TextUtils.writeToParcel(this.mBreadCrumbTitleText, paramParcel, 0);
    paramParcel.writeInt(this.mBreadCrumbShortTitleRes);
    TextUtils.writeToParcel(this.mBreadCrumbShortTitleText, paramParcel, 0);
    paramParcel.writeStringList(this.mSharedElementSourceNames);
    paramParcel.writeStringList(this.mSharedElementTargetNames);
    paramParcel.writeInt(this.mReorderingAllowed);
  }
  
  public static final class a implements Parcelable.Creator {
    public BackStackState a(Parcel param1Parcel) {
      return new BackStackState(param1Parcel);
    }
    
    public BackStackState[] b(int param1Int) {
      return new BackStackState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/BackStackState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */