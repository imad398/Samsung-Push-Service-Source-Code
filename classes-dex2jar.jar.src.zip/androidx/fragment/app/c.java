package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class c {
  public Fragment a(Context paramContext, String paramString, Bundle paramBundle) {
    return Fragment.H(paramContext, paramString, paramBundle);
  }
  
  public abstract View b(int paramInt);
  
  public abstract boolean c();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */