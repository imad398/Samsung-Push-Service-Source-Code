package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

class FragmentTabHost$SavedState extends View.BaseSavedState {
  public static final Parcelable.Creator<FragmentTabHost$SavedState> CREATOR = new a();
  
  String curTab;
  
  public FragmentTabHost$SavedState(Parcel paramParcel) {
    super(paramParcel);
    this.curTab = paramParcel.readString();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FragmentTabHost.SavedState{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" curTab=");
    stringBuilder.append(this.curTab);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeString(this.curTab);
  }
  
  public static final class a implements Parcelable.Creator {
    public FragmentTabHost$SavedState a(Parcel param1Parcel) {
      return new FragmentTabHost$SavedState(param1Parcel);
    }
    
    public FragmentTabHost$SavedState[] b(int param1Int) {
      return new FragmentTabHost$SavedState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/FragmentTabHost$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */