package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import m.g;

public abstract class e extends c {
  public final Activity a;
  
  public final Context b;
  
  public final Handler c;
  
  public final int d;
  
  public final g e = new g();
  
  public e(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.a = paramActivity;
    this.b = (Context)g.b(paramContext, "context == null");
    this.c = (Handler)g.b(paramHandler, "handler == null");
    this.d = paramInt;
  }
  
  public e(FragmentActivity paramFragmentActivity) {
    this((Activity)paramFragmentActivity, (Context)paramFragmentActivity, paramFragmentActivity.c, 0);
  }
  
  public Activity d() {
    return this.a;
  }
  
  public Context e() {
    return this.b;
  }
  
  public g f() {
    return this.e;
  }
  
  public Handler g() {
    return this.c;
  }
  
  public abstract void h(Fragment paramFragment);
  
  public abstract void i(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract LayoutInflater j();
  
  public abstract int k();
  
  public abstract boolean l();
  
  public abstract boolean m(Fragment paramFragment);
  
  public abstract void n(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle);
  
  public abstract void o();
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/fragment/app/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */