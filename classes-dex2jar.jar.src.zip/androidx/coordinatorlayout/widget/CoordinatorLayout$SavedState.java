package androidx.coordinatorlayout.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseArray;
import androidx.customview.view.AbsSavedState;

public class CoordinatorLayout$SavedState extends AbsSavedState {
  public static final Parcelable.Creator<CoordinatorLayout$SavedState> CREATOR = (Parcelable.Creator<CoordinatorLayout$SavedState>)new a();
  
  SparseArray<Parcelable> behaviorStates;
  
  public CoordinatorLayout$SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    int i = paramParcel.readInt();
    int[] arrayOfInt = new int[i];
    paramParcel.readIntArray(arrayOfInt);
    Parcelable[] arrayOfParcelable = paramParcel.readParcelableArray(paramClassLoader);
    this.behaviorStates = new SparseArray(i);
    for (byte b = 0; b < i; b++)
      this.behaviorStates.append(arrayOfInt[b], arrayOfParcelable[b]); 
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    byte b2;
    super.writeToParcel(paramParcel, paramInt);
    SparseArray<Parcelable> sparseArray = this.behaviorStates;
    byte b1 = 0;
    if (sparseArray != null) {
      b2 = sparseArray.size();
    } else {
      b2 = 0;
    } 
    paramParcel.writeInt(b2);
    int[] arrayOfInt = new int[b2];
    Parcelable[] arrayOfParcelable = new Parcelable[b2];
    while (b1 < b2) {
      arrayOfInt[b1] = this.behaviorStates.keyAt(b1);
      arrayOfParcelable[b1] = (Parcelable)this.behaviorStates.valueAt(b1);
      b1++;
    } 
    paramParcel.writeIntArray(arrayOfInt);
    paramParcel.writeParcelableArray(arrayOfParcelable, paramInt);
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator {
    public CoordinatorLayout$SavedState a(Parcel param1Parcel) {
      return new CoordinatorLayout$SavedState(param1Parcel, null);
    }
    
    public CoordinatorLayout$SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout$SavedState(param1Parcel, param1ClassLoader);
    }
    
    public CoordinatorLayout$SavedState[] c(int param1Int) {
      return new CoordinatorLayout$SavedState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/coordinatorlayout/widget/CoordinatorLayout$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */