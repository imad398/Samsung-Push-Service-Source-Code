package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import k.a;
import k.b;
import k.c;
import k.d;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode j = PorterDuff.Mode.SRC_IN;
  
  public int a;
  
  public Object b;
  
  public byte[] c;
  
  public Parcelable d;
  
  public int e;
  
  public int f;
  
  public ColorStateList g;
  
  public PorterDuff.Mode h;
  
  public String i;
  
  public IconCompat() {
    this.a = -1;
    this.c = null;
    this.d = null;
    this.e = 0;
    this.f = 0;
    this.g = null;
    this.h = j;
    this.i = null;
  }
  
  public IconCompat(int paramInt) {
    this.c = null;
    this.d = null;
    this.e = 0;
    this.f = 0;
    this.g = null;
    this.h = j;
    this.i = null;
    this.a = paramInt;
  }
  
  public static Bitmap a(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate((-(paramBitmap.getWidth() - i) / 2), (-(paramBitmap.getHeight() - i) / 2));
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat b(Resources paramResources, String paramString, int paramInt) {
    if (paramString != null) {
      if (paramInt != 0) {
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.e = paramInt;
        if (paramResources != null) {
          try {
            iconCompat.b = paramResources.getResourceName(paramInt);
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            throw new IllegalArgumentException("Icon resource cannot be found");
          } 
        } else {
          iconCompat.b = paramString;
        } 
        return iconCompat;
      } 
      throw new IllegalArgumentException("Drawable resource ID must not be 0");
    } 
    throw new IllegalArgumentException("Package must not be null.");
  }
  
  public static int d(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return b.a(paramIcon); 
    try {
      return ((Integer)paramIcon.getClass().getMethod("getResId", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
      return 0;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
      return 0;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
      return 0;
    } 
  }
  
  public static String f(Icon paramIcon) {
    if (Build.VERSION.SDK_INT >= 28)
      return a.a(paramIcon); 
    try {
      return (String)paramIcon.getClass().getMethod("getResPackage", new Class[0]).invoke(paramIcon, new Object[0]);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
      return null;
    } catch (InvocationTargetException invocationTargetException) {
      Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
      return null;
    } 
  }
  
  public static int h(Icon paramIcon) {
    StringBuilder stringBuilder;
    if (Build.VERSION.SDK_INT >= 28)
      return c.a(paramIcon); 
    try {
      return ((Integer)paramIcon.getClass().getMethod("getType", new Class[0]).invoke(paramIcon, new Object[0])).intValue();
    } catch (IllegalAccessException illegalAccessException) {
      stringBuilder = new StringBuilder();
    } catch (InvocationTargetException invocationTargetException) {
      stringBuilder = new StringBuilder();
    } catch (NoSuchMethodException noSuchMethodException) {
      stringBuilder = new StringBuilder();
    } 
    stringBuilder.append("Unable to get icon type ");
    stringBuilder.append(paramIcon);
    Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
    return -1;
  }
  
  public static String l(int paramInt) {
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? ((paramInt != 5) ? "UNKNOWN" : "BITMAP_MASKABLE") : "URI") : "DATA") : "RESOURCE") : "BITMAP";
  }
  
  public int c() {
    int i = this.a;
    if (i == -1)
      return d((Icon)this.b); 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String e() {
    int i = this.a;
    if (i == -1)
      return f((Icon)this.b); 
    if (i == 2)
      return ((String)this.b).split(":", -1)[0]; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int g() {
    int i = this.a;
    int j = i;
    if (i == -1)
      j = h((Icon)this.b); 
    return j;
  }
  
  public void i() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield i : Ljava/lang/String;
    //   5: invokestatic valueOf : (Ljava/lang/String;)Landroid/graphics/PorterDuff$Mode;
    //   8: putfield h : Landroid/graphics/PorterDuff$Mode;
    //   11: aload_0
    //   12: getfield a : I
    //   15: istore_1
    //   16: iload_1
    //   17: iconst_m1
    //   18: if_icmpeq -> 125
    //   21: iload_1
    //   22: iconst_1
    //   23: if_icmpeq -> 84
    //   26: iload_1
    //   27: iconst_2
    //   28: if_icmpeq -> 60
    //   31: iload_1
    //   32: iconst_3
    //   33: if_icmpeq -> 49
    //   36: iload_1
    //   37: iconst_4
    //   38: if_icmpeq -> 60
    //   41: iload_1
    //   42: iconst_5
    //   43: if_icmpeq -> 84
    //   46: goto -> 139
    //   49: aload_0
    //   50: aload_0
    //   51: getfield c : [B
    //   54: putfield b : Ljava/lang/Object;
    //   57: goto -> 139
    //   60: aload_0
    //   61: new java/lang/String
    //   64: dup
    //   65: aload_0
    //   66: getfield c : [B
    //   69: ldc_w 'UTF-16'
    //   72: invokestatic forName : (Ljava/lang/String;)Ljava/nio/charset/Charset;
    //   75: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
    //   78: putfield b : Ljava/lang/Object;
    //   81: goto -> 139
    //   84: aload_0
    //   85: getfield d : Landroid/os/Parcelable;
    //   88: astore_2
    //   89: aload_2
    //   90: ifnull -> 96
    //   93: goto -> 134
    //   96: aload_0
    //   97: getfield c : [B
    //   100: astore_2
    //   101: aload_0
    //   102: aload_2
    //   103: putfield b : Ljava/lang/Object;
    //   106: aload_0
    //   107: iconst_3
    //   108: putfield a : I
    //   111: aload_0
    //   112: iconst_0
    //   113: putfield e : I
    //   116: aload_0
    //   117: aload_2
    //   118: arraylength
    //   119: putfield f : I
    //   122: goto -> 139
    //   125: aload_0
    //   126: getfield d : Landroid/os/Parcelable;
    //   129: astore_2
    //   130: aload_2
    //   131: ifnull -> 140
    //   134: aload_0
    //   135: aload_2
    //   136: putfield b : Ljava/lang/Object;
    //   139: return
    //   140: new java/lang/IllegalArgumentException
    //   143: dup
    //   144: ldc_w 'Invalid icon'
    //   147: invokespecial <init> : (Ljava/lang/String;)V
    //   150: athrow
  }
  
  public void j(boolean paramBoolean) {
    this.i = this.h.name();
    int i = this.a;
    if (i != -1) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i != 5)
                return; 
            } else {
              this.c = this.b.toString().getBytes(Charset.forName("UTF-16"));
              return;
            } 
          } else {
            this.c = (byte[])this.b;
            return;
          } 
        } else {
          this.c = ((String)this.b).getBytes(Charset.forName("UTF-16"));
          return;
        }  
      if (paramBoolean) {
        Bitmap bitmap = (Bitmap)this.b;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
        this.c = byteArrayOutputStream.toByteArray();
        return;
      } 
    } else if (paramBoolean) {
      throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
    } 
    this.d = (Parcelable)this.b;
  }
  
  public Icon k() {
    int i = this.a;
    if (i != -1) {
      Icon icon;
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4) {
              if (i == 5) {
                if (Build.VERSION.SDK_INT >= 26) {
                  icon = d.a((Bitmap)this.b);
                } else {
                  Bitmap bitmap = a((Bitmap)this.b, false);
                  icon = Icon.createWithBitmap(bitmap);
                } 
              } else {
                throw new IllegalArgumentException("Unknown type");
              } 
            } else {
              icon = Icon.createWithContentUri((String)this.b);
            } 
          } else {
            icon = Icon.createWithData((byte[])this.b, this.e, this.f);
          } 
        } else {
          icon = Icon.createWithResource(e(), this.e);
        } 
      } else {
        Bitmap bitmap = (Bitmap)this.b;
        icon = Icon.createWithBitmap(bitmap);
      } 
      ColorStateList colorStateList = this.g;
      if (colorStateList != null)
        icon.setTintList(colorStateList); 
      PorterDuff.Mode mode = this.h;
      if (mode != j)
        icon.setTintMode(mode); 
      return icon;
    } 
    return (Icon)this.b;
  }
  
  public String toString() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : I
    //   4: iconst_m1
    //   5: if_icmpne -> 16
    //   8: aload_0
    //   9: getfield b : Ljava/lang/Object;
    //   12: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   15: areturn
    //   16: new java/lang/StringBuilder
    //   19: dup
    //   20: ldc_w 'Icon(typ='
    //   23: invokespecial <init> : (Ljava/lang/String;)V
    //   26: astore_1
    //   27: aload_1
    //   28: aload_0
    //   29: getfield a : I
    //   32: invokestatic l : (I)Ljava/lang/String;
    //   35: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   38: pop
    //   39: aload_0
    //   40: getfield a : I
    //   43: istore_2
    //   44: iload_2
    //   45: iconst_1
    //   46: if_icmpeq -> 185
    //   49: iload_2
    //   50: iconst_2
    //   51: if_icmpeq -> 132
    //   54: iload_2
    //   55: iconst_3
    //   56: if_icmpeq -> 92
    //   59: iload_2
    //   60: iconst_4
    //   61: if_icmpeq -> 72
    //   64: iload_2
    //   65: iconst_5
    //   66: if_icmpeq -> 185
    //   69: goto -> 233
    //   72: aload_1
    //   73: ldc_w ' uri='
    //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: aload_1
    //   81: aload_0
    //   82: getfield b : Ljava/lang/Object;
    //   85: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: goto -> 233
    //   92: aload_1
    //   93: ldc_w ' len='
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: aload_1
    //   101: aload_0
    //   102: getfield e : I
    //   105: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   108: pop
    //   109: aload_0
    //   110: getfield f : I
    //   113: ifeq -> 233
    //   116: aload_1
    //   117: ldc_w ' off='
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload_0
    //   125: getfield f : I
    //   128: istore_2
    //   129: goto -> 227
    //   132: aload_1
    //   133: ldc_w ' pkg='
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: pop
    //   140: aload_1
    //   141: aload_0
    //   142: invokevirtual e : ()Ljava/lang/String;
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: aload_1
    //   150: ldc_w ' id='
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: pop
    //   157: aload_1
    //   158: ldc_w '0x%08x'
    //   161: iconst_1
    //   162: anewarray java/lang/Object
    //   165: dup
    //   166: iconst_0
    //   167: aload_0
    //   168: invokevirtual c : ()I
    //   171: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   174: aastore
    //   175: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: goto -> 233
    //   185: aload_1
    //   186: ldc_w ' size='
    //   189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: pop
    //   193: aload_1
    //   194: aload_0
    //   195: getfield b : Ljava/lang/Object;
    //   198: checkcast android/graphics/Bitmap
    //   201: invokevirtual getWidth : ()I
    //   204: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   207: pop
    //   208: aload_1
    //   209: ldc_w 'x'
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: pop
    //   216: aload_0
    //   217: getfield b : Ljava/lang/Object;
    //   220: checkcast android/graphics/Bitmap
    //   223: invokevirtual getHeight : ()I
    //   226: istore_2
    //   227: aload_1
    //   228: iload_2
    //   229: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload_0
    //   234: getfield g : Landroid/content/res/ColorStateList;
    //   237: ifnull -> 257
    //   240: aload_1
    //   241: ldc_w ' tint='
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: pop
    //   248: aload_1
    //   249: aload_0
    //   250: getfield g : Landroid/content/res/ColorStateList;
    //   253: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload_0
    //   258: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   261: getstatic androidx/core/graphics/drawable/IconCompat.j : Landroid/graphics/PorterDuff$Mode;
    //   264: if_acmpeq -> 284
    //   267: aload_1
    //   268: ldc_w ' mode='
    //   271: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   274: pop
    //   275: aload_1
    //   276: aload_0
    //   277: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   280: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   283: pop
    //   284: aload_1
    //   285: ldc_w ')'
    //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   291: pop
    //   292: aload_1
    //   293: invokevirtual toString : ()Ljava/lang/String;
    //   296: areturn
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/core/graphics/drawable/IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */