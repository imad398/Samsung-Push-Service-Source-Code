package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import y.a;

public class IconCompatParcelizer {
  public static IconCompat read(a parama) {
    IconCompat iconCompat = new IconCompat();
    iconCompat.a = parama.p(iconCompat.a, 1);
    iconCompat.c = parama.j(iconCompat.c, 2);
    iconCompat.d = parama.r(iconCompat.d, 3);
    iconCompat.e = parama.p(iconCompat.e, 4);
    iconCompat.f = parama.p(iconCompat.f, 5);
    iconCompat.g = (ColorStateList)parama.r((Parcelable)iconCompat.g, 6);
    iconCompat.i = parama.t(iconCompat.i, 7);
    iconCompat.i();
    return iconCompat;
  }
  
  public static void write(IconCompat paramIconCompat, a parama) {
    parama.x(true, true);
    paramIconCompat.j(parama.f());
    int i = paramIconCompat.a;
    if (-1 != i)
      parama.F(i, 1); 
    byte[] arrayOfByte = paramIconCompat.c;
    if (arrayOfByte != null)
      parama.B(arrayOfByte, 2); 
    Parcelable parcelable = paramIconCompat.d;
    if (parcelable != null)
      parama.H(parcelable, 3); 
    i = paramIconCompat.e;
    if (i != 0)
      parama.F(i, 4); 
    i = paramIconCompat.f;
    if (i != 0)
      parama.F(i, 5); 
    ColorStateList colorStateList = paramIconCompat.g;
    if (colorStateList != null)
      parama.H((Parcelable)colorStateList, 6); 
    String str = paramIconCompat.i;
    if (str != null)
      parama.J(str, 7); 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/core/graphics/drawable/IconCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */