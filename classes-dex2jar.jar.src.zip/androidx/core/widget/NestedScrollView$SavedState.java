package androidx.core.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

class NestedScrollView$SavedState extends View.BaseSavedState {
  public static final Parcelable.Creator<NestedScrollView$SavedState> CREATOR = new a();
  
  public int scrollPosition;
  
  public NestedScrollView$SavedState(Parcel paramParcel) {
    super(paramParcel);
    this.scrollPosition = paramParcel.readInt();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("HorizontalScrollView.SavedState{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" scrollPosition=");
    stringBuilder.append(this.scrollPosition);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.scrollPosition);
  }
  
  public static final class a implements Parcelable.Creator {
    public NestedScrollView$SavedState a(Parcel param1Parcel) {
      return new NestedScrollView$SavedState(param1Parcel);
    }
    
    public NestedScrollView$SavedState[] b(int param1Int) {
      return new NestedScrollView$SavedState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/core/widget/NestedScrollView$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */