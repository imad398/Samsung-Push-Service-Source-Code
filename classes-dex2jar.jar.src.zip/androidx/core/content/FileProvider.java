package androidx.core.content;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.xmlpull.v1.XmlPullParserException;

public class FileProvider extends ContentProvider {
  public static final String[] b = new String[] { "_display_name", "_size" };
  
  public static final File c = new File("/");
  
  public static HashMap d = new HashMap<Object, Object>();
  
  public a a;
  
  public static File a(File paramFile, String... paramVarArgs) {
    int i = paramVarArgs.length;
    byte b = 0;
    File file;
    for (file = paramFile; b < i; file = paramFile) {
      String str = paramVarArgs[b];
      paramFile = file;
      if (str != null)
        paramFile = new File(file, str); 
      b++;
    } 
    return file;
  }
  
  public static Object[] b(Object[] paramArrayOfObject, int paramInt) {
    Object[] arrayOfObject = new Object[paramInt];
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject, 0, paramInt);
    return arrayOfObject;
  }
  
  public static String[] c(String[] paramArrayOfString, int paramInt) {
    String[] arrayOfString = new String[paramInt];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
    return arrayOfString;
  }
  
  public static a d(Context paramContext, String paramString) {
    synchronized (d) {
      a a1 = (a)d.get(paramString);
      a a2 = a1;
      if (a1 == null)
        try {
          a2 = g(paramContext, paramString);
          d.put(paramString, a2);
        } catch (IOException iOException) {
          IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
          this("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", iOException);
          throw illegalArgumentException;
        } catch (XmlPullParserException xmlPullParserException) {
          IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
          this("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", (Throwable)xmlPullParserException);
          throw illegalArgumentException;
        }  
      return a2;
    } 
  }
  
  public static Uri e(Context paramContext, String paramString, File paramFile) {
    return d(paramContext, paramString).b(paramFile);
  }
  
  public static int f(String paramString) {
    int i;
    if ("r".equals(paramString)) {
      i = 268435456;
    } else {
      if ("w".equals(paramString) || "wt".equals(paramString))
        return 738197504; 
      if ("wa".equals(paramString)) {
        i = 704643072;
      } else if ("rw".equals(paramString)) {
        i = 939524096;
      } else if ("rwt".equals(paramString)) {
        i = 1006632960;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid mode: ");
        stringBuilder.append(paramString);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return i;
  }
  
  public static a g(Context paramContext, String paramString) {
    File file;
    b b = new b(paramString);
    ProviderInfo providerInfo = paramContext.getPackageManager().resolveContentProvider(paramString, 128);
    if (providerInfo != null) {
      XmlResourceParser xmlResourceParser = providerInfo.loadXmlMetaData(paramContext.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
      if (xmlResourceParser != null)
        while (true) {
          int i = xmlResourceParser.next();
          if (i != 1) {
            if (i == 2) {
              String str1 = xmlResourceParser.getName();
              providerInfo = null;
              String str2 = xmlResourceParser.getAttributeValue(null, "name");
              String str3 = xmlResourceParser.getAttributeValue(null, "path");
              if ("root-path".equals(str1)) {
                file = c;
              } else if ("files-path".equals(str1)) {
                file = paramContext.getFilesDir();
              } else if ("cache-path".equals(str1)) {
                file = paramContext.getCacheDir();
              } else if ("external-path".equals(str1)) {
                file = Environment.getExternalStorageDirectory();
              } else {
                File[] arrayOfFile;
                if ("external-files-path".equals(str1)) {
                  arrayOfFile = j.b.e(paramContext, null);
                  ProviderInfo providerInfo1 = providerInfo;
                  if (arrayOfFile.length > 0)
                    file = arrayOfFile[0]; 
                } else if ("external-cache-path".equals(arrayOfFile)) {
                  arrayOfFile = j.b.d(paramContext);
                  ProviderInfo providerInfo1 = providerInfo;
                  if (arrayOfFile.length > 0)
                    file = arrayOfFile[0]; 
                } else {
                  ProviderInfo providerInfo1 = providerInfo;
                  if ("external-media-path".equals(arrayOfFile)) {
                    arrayOfFile = paramContext.getExternalMediaDirs();
                    providerInfo1 = providerInfo;
                    if (arrayOfFile.length > 0)
                      file = arrayOfFile[0]; 
                  } 
                } 
              } 
              if (file != null)
                b.c(str2, a(file, new String[] { str3 })); 
            } 
            continue;
          } 
          return b;
        }  
      throw new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Couldn't find meta-data for provider with authority ");
    stringBuilder.append((String)file);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    super.attachInfo(paramContext, paramProviderInfo);
    if (!paramProviderInfo.exported) {
      if (paramProviderInfo.grantUriPermissions) {
        this.a = d(paramContext, paramProviderInfo.authority);
        return;
      } 
      throw new SecurityException("Provider must grant uri permissions");
    } 
    throw new SecurityException("Provider must not be exported");
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return this.a.a(paramUri).delete();
  }
  
  public String getType(Uri paramUri) {
    File file = this.a.a(paramUri);
    int i = file.getName().lastIndexOf('.');
    if (i >= 0) {
      String str = file.getName().substring(i + 1);
      str = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str);
      if (str != null)
        return str; 
    } 
    return "application/octet-stream";
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new UnsupportedOperationException("No external inserts");
  }
  
  public boolean onCreate() {
    return true;
  }
  
  public ParcelFileDescriptor openFile(Uri paramUri, String paramString) {
    return ParcelFileDescriptor.open(this.a.a(paramUri), f(paramString));
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    Object object;
    int j;
    File file = this.a.a(paramUri);
    String[] arrayOfString1 = paramArrayOfString1;
    if (paramArrayOfString1 == null)
      arrayOfString1 = b; 
    String[] arrayOfString3 = new String[arrayOfString1.length];
    Object[] arrayOfObject2 = new Object[arrayOfString1.length];
    int i = arrayOfString1.length;
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      String str = arrayOfString1[b];
      if ("_display_name".equals(str)) {
        arrayOfString3[object] = "_display_name";
        int m = object + 1;
        arrayOfObject2[object] = file.getName();
        j = m;
      } else {
        int m = j;
        if ("_size".equals(str)) {
          arrayOfString3[j] = "_size";
          m = j + 1;
          arrayOfObject2[j] = Long.valueOf(file.length());
          j = m;
        } else {
          continue;
        } 
      } 
      int k = j;
      continue;
      b++;
      object = SYNTHETIC_LOCAL_VARIABLE_9;
    } 
    String[] arrayOfString2 = c(arrayOfString3, j);
    Object[] arrayOfObject1 = b(arrayOfObject2, j);
    MatrixCursor matrixCursor = new MatrixCursor(arrayOfString2, 1);
    matrixCursor.addRow(arrayOfObject1);
    return (Cursor)matrixCursor;
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new UnsupportedOperationException("No external updates");
  }
  
  public static interface a {
    File a(Uri param1Uri);
    
    Uri b(File param1File);
  }
  
  public static class b implements a {
    public final String a;
    
    public final HashMap b = new HashMap<Object, Object>();
    
    public b(String param1String) {
      this.a = param1String;
    }
    
    public File a(Uri param1Uri) {
      File file1;
      String str1 = param1Uri.getEncodedPath();
      int i = str1.indexOf('/', 1);
      String str2 = Uri.decode(str1.substring(1, i));
      str1 = Uri.decode(str1.substring(i + 1));
      File file2 = (File)this.b.get(str2);
      if (file2 != null) {
        file1 = new File(file2, str1);
        try {
          File file = file1.getCanonicalFile();
          if (file.getPath().startsWith(file2.getPath()))
            return file; 
          throw new SecurityException("Resolved path jumped beyond configured root");
        } catch (IOException iOException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Failed to resolve canonical path for ");
          stringBuilder1.append(file1);
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to find configured root for ");
      stringBuilder.append(file1);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Uri b(File param1File) {
      StringBuilder stringBuilder;
      try {
        Map.Entry entry;
        StringBuilder stringBuilder1;
        String str = param1File.getCanonicalPath();
        Iterator<Map.Entry> iterator = this.b.entrySet().iterator();
        param1File = null;
        while (iterator.hasNext()) {
          Map.Entry entry1 = iterator.next();
          String str1 = ((File)entry1.getValue()).getPath();
          if (str.startsWith(str1) && (param1File == null || str1.length() > ((File)param1File.getValue()).getPath().length()))
            entry = entry1; 
        } 
        if (entry != null) {
          String str2 = ((File)entry.getValue()).getPath();
          boolean bool = str2.endsWith("/");
          int i = str2.length();
          if (!bool)
            i++; 
          str2 = str.substring(i);
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append(Uri.encode((String)entry.getKey()));
          stringBuilder1.append('/');
          stringBuilder1.append(Uri.encode(str2, "/"));
          String str1 = stringBuilder1.toString();
          return (new Uri.Builder()).scheme("content").authority(this.a).encodedPath(str1).build();
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to find configured root that contains ");
        stringBuilder.append((String)stringBuilder1);
        throw new IllegalArgumentException(stringBuilder.toString());
      } catch (IOException iOException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to resolve canonical path for ");
        stringBuilder1.append(stringBuilder);
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
    }
    
    public void c(String param1String, File param1File) {
      if (!TextUtils.isEmpty(param1String))
        try {
          File file = param1File.getCanonicalFile();
          this.b.put(param1String, file);
          return;
        } catch (IOException iOException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to resolve canonical path for ");
          stringBuilder.append(param1File);
          throw new IllegalArgumentException(stringBuilder.toString(), iOException);
        }  
      throw new IllegalArgumentException("Name must not be empty");
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/core/content/FileProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */