package androidx.core.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.b;
import androidx.lifecycle.d;
import androidx.lifecycle.e;
import androidx.lifecycle.h;
import f.g;
import n.b;

public class ComponentActivity extends Activity implements d, b.a {
  public g a = new g();
  
  public e b = new e(this);
  
  public boolean a(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && b.d(view, paramKeyEvent)) ? true : b.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && b.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public b e() {
    return (b)this.b;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    h.f(this);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    this.b.e(b.b.c);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/core/app/ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */