package androidx.multidex;

import android.app.Application;
import android.content.Context;
import s.a;

public class MultiDexApplication extends Application {
  public void attachBaseContext(Context paramContext) {
    super.attachBaseContext(paramContext);
    a.k((Context)this);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/multidex/MultiDexApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */