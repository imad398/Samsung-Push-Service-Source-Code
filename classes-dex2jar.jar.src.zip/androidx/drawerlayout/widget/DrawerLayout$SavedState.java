package androidx.drawerlayout.widget;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.customview.view.AbsSavedState;

public class DrawerLayout$SavedState extends AbsSavedState {
  public static final Parcelable.Creator<DrawerLayout$SavedState> CREATOR = (Parcelable.Creator<DrawerLayout$SavedState>)new a();
  
  int lockModeEnd;
  
  int lockModeLeft;
  
  int lockModeRight;
  
  int lockModeStart;
  
  int openDrawerGravity = 0;
  
  public DrawerLayout$SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    this.openDrawerGravity = paramParcel.readInt();
    this.lockModeLeft = paramParcel.readInt();
    this.lockModeRight = paramParcel.readInt();
    this.lockModeStart = paramParcel.readInt();
    this.lockModeEnd = paramParcel.readInt();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.openDrawerGravity);
    paramParcel.writeInt(this.lockModeLeft);
    paramParcel.writeInt(this.lockModeRight);
    paramParcel.writeInt(this.lockModeStart);
    paramParcel.writeInt(this.lockModeEnd);
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator {
    public DrawerLayout$SavedState a(Parcel param1Parcel) {
      return new DrawerLayout$SavedState(param1Parcel, null);
    }
    
    public DrawerLayout$SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new DrawerLayout$SavedState(param1Parcel, param1ClassLoader);
    }
    
    public DrawerLayout$SavedState[] c(int param1Int) {
      return new DrawerLayout$SavedState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/drawerlayout/widget/DrawerLayout$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */