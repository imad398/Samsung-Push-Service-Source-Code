package androidx.slidingpanelayout.widget;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.customview.view.AbsSavedState;

class SlidingPaneLayout$SavedState extends AbsSavedState {
  public static final Parcelable.Creator<SlidingPaneLayout$SavedState> CREATOR = (Parcelable.Creator<SlidingPaneLayout$SavedState>)new a();
  
  boolean isOpen;
  
  public SlidingPaneLayout$SavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    super(paramParcel, paramClassLoader);
    boolean bool;
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.isOpen = bool;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeInt(this.isOpen);
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator {
    public SlidingPaneLayout$SavedState a(Parcel param1Parcel) {
      return new SlidingPaneLayout$SavedState(param1Parcel, null);
    }
    
    public SlidingPaneLayout$SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SlidingPaneLayout$SavedState(param1Parcel, null);
    }
    
    public SlidingPaneLayout$SavedState[] c(int param1Int) {
      return new SlidingPaneLayout$SavedState[param1Int];
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/androidx/slidingpanelayout/widget/SlidingPaneLayout$SavedState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */