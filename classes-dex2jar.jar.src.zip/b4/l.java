package b4;

import android.content.Intent;
import com.sec.spp.push.PushClientService;
import g3.a;
import l3.f;
import l3.h;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class l {
  public static String a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("sppeos_");
    stringBuilder.append(paramString);
    stringBuilder.append("_");
    stringBuilder.append(System.currentTimeMillis());
    return stringBuilder.toString();
  }
  
  public static void b(int paramInt) {
    try {
      JSONObject jSONObject1 = new JSONObject();
      this();
      jSONObject1.put("eosStandBy", paramInt);
      JSONObject jSONObject2 = new JSONObject();
      this();
      jSONObject2.put("spp", jSONObject1);
      jSONObject2.put("sppv", 0);
      Intent intent = new Intent();
      this("com.samsung.android.sdk.smp.SPS_POLICY_ACTION");
      intent.setPackage(a.a().getPackageName());
      intent.putExtra("sps_policy", jSONObject2.toString());
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("sendSppEosPolicyBroadcast : ");
      stringBuilder.append(jSONObject2.toString());
      f.a("PushServiceUtil", stringBuilder.toString());
      a.a().sendBroadcast(intent);
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
    } 
  }
  
  public static void c() {
    h.c(new Intent(a.a(), PushClientService.class));
  }
  
  public static void d(Intent paramIntent) {
    paramIntent.setClass(a.a(), PushClientService.class);
    h.c(paramIntent);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */