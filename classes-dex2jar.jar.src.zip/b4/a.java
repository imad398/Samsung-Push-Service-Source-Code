package b4;

import a4.c;
import android.content.Context;
import android.content.Intent;
import com.sec.spp.push.PushClientApplication;
import com.sec.spp.push.receiver.ProviderInfoReceiver;
import com.sec.spp.push.receiver.RandomDeviceIdReqReceiver;
import java.util.ArrayList;
import java.util.Iterator;
import l3.f;
import l3.l;

public abstract class a {
  public static final Object a = new Object();
  
  public static void a(Intent paramIntent, long paramLong) {
    // Byte code:
    //   0: ldc b4/a
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 18
    //   7: ldc 'BroadCastUtil'
    //   9: ldc '[sendBroadCast] notiIntent is null'
    //   11: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   14: ldc b4/a
    //   16: monitorexit
    //   17: return
    //   18: invokestatic c : ()Landroid/content/Context;
    //   21: astore_3
    //   22: aload_3
    //   23: ifnonnull -> 37
    //   26: ldc 'BroadCastUtil'
    //   28: ldc '[sendBroadCast] context is null. Can not send message to app'
    //   30: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   33: ldc b4/a
    //   35: monitorexit
    //   36: return
    //   37: aload_0
    //   38: bipush #32
    //   40: invokevirtual addFlags : (I)Landroid/content/Intent;
    //   43: pop
    //   44: invokestatic c : ()Landroid/content/Context;
    //   47: ldc 'user'
    //   49: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   52: checkcast android/os/UserManager
    //   55: lload_1
    //   56: invokevirtual getUserForSerialNumber : (J)Landroid/os/UserHandle;
    //   59: astore #4
    //   61: aload #4
    //   63: ifnull -> 126
    //   66: new java/lang/StringBuilder
    //   69: astore #5
    //   71: aload #5
    //   73: invokespecial <init> : ()V
    //   76: aload #5
    //   78: ldc 'sendBroadcastAsUser. Intent : '
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: pop
    //   84: aload #5
    //   86: aload_0
    //   87: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   90: pop
    //   91: aload #5
    //   93: ldc ', UserSN '
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: pop
    //   99: aload #5
    //   101: lload_1
    //   102: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: ldc 'BroadCastUtil'
    //   108: aload #5
    //   110: invokevirtual toString : ()Ljava/lang/String;
    //   113: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   116: aload_3
    //   117: aload_0
    //   118: aload #4
    //   120: invokevirtual sendBroadcastAsUser : (Landroid/content/Intent;Landroid/os/UserHandle;)V
    //   123: goto -> 146
    //   126: ldc 'BroadCastUtil'
    //   128: ldc 'sendBroadcastAsUser. User is null'
    //   130: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   133: goto -> 146
    //   136: astore_0
    //   137: ldc 'BroadCastUtil'
    //   139: aload_0
    //   140: invokevirtual getMessage : ()Ljava/lang/String;
    //   143: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   146: ldc b4/a
    //   148: monitorexit
    //   149: return
    //   150: astore_0
    //   151: ldc b4/a
    //   153: monitorexit
    //   154: aload_0
    //   155: athrow
    // Exception table:
    //   from	to	target	type
    //   7	14	150	finally
    //   18	22	150	finally
    //   26	33	150	finally
    //   37	44	150	finally
    //   44	61	136	java/lang/Exception
    //   44	61	150	finally
    //   66	123	136	java/lang/Exception
    //   66	123	150	finally
    //   126	133	136	java/lang/Exception
    //   126	133	150	finally
    //   137	146	150	finally
  }
  
  public static void b(Intent paramIntent, String paramString) {
    // Byte code:
    //   0: ldc b4/a
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 18
    //   7: ldc 'BroadCastUtil'
    //   9: ldc '[sendBroadCast] notiIntent is null'
    //   11: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   14: ldc b4/a
    //   16: monitorexit
    //   17: return
    //   18: invokestatic c : ()Landroid/content/Context;
    //   21: astore_2
    //   22: aload_2
    //   23: ifnonnull -> 37
    //   26: ldc 'BroadCastUtil'
    //   28: ldc 'broadcastNotiAckIntent. context is null. Can not send message to app'
    //   30: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   33: ldc b4/a
    //   35: monitorexit
    //   36: return
    //   37: aload_0
    //   38: bipush #32
    //   40: invokevirtual addFlags : (I)Landroid/content/Intent;
    //   43: pop
    //   44: aload_1
    //   45: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Long;
    //   48: invokevirtual longValue : ()J
    //   51: lstore_3
    //   52: goto -> 67
    //   55: astore_1
    //   56: ldc 'BroadCastUtil'
    //   58: aload_1
    //   59: invokevirtual getMessage : ()Ljava/lang/String;
    //   62: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   65: lconst_0
    //   66: lstore_3
    //   67: new java/lang/StringBuilder
    //   70: astore_1
    //   71: aload_1
    //   72: invokespecial <init> : ()V
    //   75: aload_1
    //   76: ldc '[sendBroadCast] intent : '
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload_1
    //   83: aload_0
    //   84: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   87: pop
    //   88: aload_1
    //   89: ldc ' userSN : '
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: pop
    //   95: aload_1
    //   96: lload_3
    //   97: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: ldc 'BroadCastUtil'
    //   103: aload_1
    //   104: invokevirtual toString : ()Ljava/lang/String;
    //   107: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   110: invokestatic c : ()Landroid/content/Context;
    //   113: ldc 'user'
    //   115: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   118: checkcast android/os/UserManager
    //   121: astore_1
    //   122: new java/lang/StringBuilder
    //   125: astore #5
    //   127: aload #5
    //   129: invokespecial <init> : ()V
    //   132: aload #5
    //   134: ldc 'sendBroadcastAsUser. Intent : '
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: pop
    //   140: aload #5
    //   142: aload_0
    //   143: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   146: pop
    //   147: aload #5
    //   149: ldc ', UserSN '
    //   151: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: pop
    //   155: aload #5
    //   157: lload_3
    //   158: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: ldc 'BroadCastUtil'
    //   164: aload #5
    //   166: invokevirtual toString : ()Ljava/lang/String;
    //   169: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   172: aload_1
    //   173: lload_3
    //   174: invokevirtual getUserForSerialNumber : (J)Landroid/os/UserHandle;
    //   177: astore_1
    //   178: aload_1
    //   179: ifnull -> 191
    //   182: aload_2
    //   183: aload_0
    //   184: aload_1
    //   185: invokevirtual sendBroadcastAsUser : (Landroid/content/Intent;Landroid/os/UserHandle;)V
    //   188: goto -> 211
    //   191: ldc 'BroadCastUtil'
    //   193: ldc 'sendBroadcastAsUser. user is null'
    //   195: invokestatic l : (Ljava/lang/String;Ljava/lang/String;)V
    //   198: goto -> 211
    //   201: astore_0
    //   202: ldc 'BroadCastUtil'
    //   204: aload_0
    //   205: invokevirtual getMessage : ()Ljava/lang/String;
    //   208: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   211: ldc b4/a
    //   213: monitorexit
    //   214: return
    //   215: astore_0
    //   216: ldc b4/a
    //   218: monitorexit
    //   219: aload_0
    //   220: athrow
    // Exception table:
    //   from	to	target	type
    //   7	14	215	finally
    //   18	22	215	finally
    //   26	33	215	finally
    //   37	44	215	finally
    //   44	52	55	java/lang/NumberFormatException
    //   44	52	215	finally
    //   56	65	215	finally
    //   67	110	215	finally
    //   110	178	201	java/lang/Exception
    //   110	178	215	finally
    //   182	188	201	java/lang/Exception
    //   182	188	215	finally
    //   191	198	201	java/lang/Exception
    //   191	198	215	finally
    //   202	211	215	finally
  }
  
  public static void c(Context paramContext) {
    synchronized (a) {
      Intent intent = new Intent();
      this(paramContext, RandomDeviceIdReqReceiver.class);
      intent.setAction("com.sec.spp.push.ACTION_DEVICE_ID_REQ");
      long l = l.G();
      intent.putExtra("userSN", l);
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("Device ID request from User ");
      stringBuilder.append(l);
      f.a("BroadCastUtil", stringBuilder.toString());
      a(intent, 0L);
      return;
    } 
  }
  
  public static void d(String paramString) {
    ArrayList arrayList = c.w().t();
    if (arrayList != null && !arrayList.isEmpty()) {
      Iterator<Long> iterator = arrayList.iterator();
      while (iterator.hasNext()) {
        long l = ((Long)iterator.next()).longValue();
        if (l == 0L)
          continue; 
        Intent intent = new Intent();
        intent.setClass(PushClientApplication.c(), ProviderInfoReceiver.class);
        intent.setAction("com.sec.spp.push.ACTION_VERSION_NOTI");
        intent.putExtra("new_version", paramString);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SendVersionInfo To : ");
        stringBuilder.append(l);
        f.a("BroadCastUtil", stringBuilder.toString());
        a(intent, l);
      } 
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */