package b4;

import java.io.UnsupportedEncodingException;

public abstract class q {
  static {
  
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, int paramInt) {
    return b(paramArrayOfbyte, 0, paramArrayOfbyte.length, paramInt);
  }
  
  public static byte[] b(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
    b b = new b(paramInt3, null);
    int i = paramInt2 / 3 * 4;
    boolean bool = b.f;
    byte b1 = 2;
    if (bool) {
      paramInt3 = i;
      if (paramInt2 % 3 > 0)
        paramInt3 = i + 4; 
    } else {
      paramInt3 = paramInt2 % 3;
      if (paramInt3 != 1) {
        if (paramInt3 != 2) {
          paramInt3 = i;
        } else {
          paramInt3 = i + 3;
        } 
      } else {
        paramInt3 = i + 2;
      } 
    } 
    i = paramInt3;
    if (b.g) {
      i = paramInt3;
      if (paramInt2 > 0) {
        int j = (paramInt2 - 1) / 57;
        if (b.h) {
          i = b1;
        } else {
          i = 1;
        } 
        i = paramInt3 + (j + 1) * i;
      } 
    } 
    b.a = new byte[i];
    b.a(paramArrayOfbyte, paramInt1, paramInt2, true);
    return b.a;
  }
  
  public static String c(byte[] paramArrayOfbyte, int paramInt) {
    try {
      return new String(a(paramArrayOfbyte, paramInt), "US-ASCII");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new AssertionError(unsupportedEncodingException);
    } 
  }
  
  public static abstract class a {
    public byte[] a;
    
    public int b;
  }
  
  public static class b extends a {
    public static final byte[] j = new byte[] { 
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 43, 47 };
    
    public static final byte[] k = new byte[] { 
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 45, 95 };
    
    public final byte[] c;
    
    public int d;
    
    public int e;
    
    public final boolean f;
    
    public final boolean g;
    
    public final boolean h;
    
    public final byte[] i;
    
    public b(int param1Int, byte[] param1ArrayOfbyte) {
      boolean bool2;
      this.a = param1ArrayOfbyte;
      boolean bool1 = true;
      if ((param1Int & 0x1) == 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.f = bool2;
      if ((param1Int & 0x2) == 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.g = bool2;
      if ((param1Int & 0x4) == 0)
        bool1 = false; 
      this.h = bool1;
      if ((param1Int & 0x8) == 0) {
        param1ArrayOfbyte = j;
      } else {
        param1ArrayOfbyte = k;
      } 
      this.i = param1ArrayOfbyte;
      this.c = new byte[2];
      this.d = 0;
      if (bool2) {
        param1Int = 19;
      } else {
        param1Int = -1;
      } 
      this.e = param1Int;
    }
    
    public boolean a(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, boolean param1Boolean) {
      // Byte code:
      //   0: aload_0
      //   1: getfield i : [B
      //   4: astore #5
      //   6: aload_0
      //   7: getfield a : [B
      //   10: astore #6
      //   12: aload_0
      //   13: getfield e : I
      //   16: istore #7
      //   18: iload_3
      //   19: iload_2
      //   20: iadd
      //   21: istore #8
      //   23: aload_0
      //   24: getfield d : I
      //   27: istore_3
      //   28: iconst_0
      //   29: istore #9
      //   31: iconst_0
      //   32: istore #10
      //   34: iload_3
      //   35: iconst_1
      //   36: if_icmpeq -> 107
      //   39: iload_3
      //   40: iconst_2
      //   41: if_icmpeq -> 47
      //   44: goto -> 173
      //   47: iload_2
      //   48: iconst_1
      //   49: iadd
      //   50: istore_3
      //   51: iload_3
      //   52: iload #8
      //   54: if_icmpgt -> 173
      //   57: aload_0
      //   58: getfield c : [B
      //   61: astore #11
      //   63: aload #11
      //   65: iconst_0
      //   66: baload
      //   67: istore #12
      //   69: aload #11
      //   71: iconst_1
      //   72: baload
      //   73: sipush #255
      //   76: iand
      //   77: bipush #8
      //   79: ishl
      //   80: iload #12
      //   82: sipush #255
      //   85: iand
      //   86: bipush #16
      //   88: ishl
      //   89: ior
      //   90: aload_1
      //   91: iload_2
      //   92: baload
      //   93: sipush #255
      //   96: iand
      //   97: ior
      //   98: istore_2
      //   99: aload_0
      //   100: iconst_0
      //   101: putfield d : I
      //   104: goto -> 181
      //   107: iload_2
      //   108: iconst_2
      //   109: iadd
      //   110: iload #8
      //   112: if_icmpgt -> 173
      //   115: aload_0
      //   116: getfield c : [B
      //   119: iconst_0
      //   120: baload
      //   121: istore #13
      //   123: iload_2
      //   124: iconst_1
      //   125: iadd
      //   126: istore #12
      //   128: aload_1
      //   129: iload_2
      //   130: baload
      //   131: istore_2
      //   132: iload #12
      //   134: iconst_1
      //   135: iadd
      //   136: istore_3
      //   137: aload_1
      //   138: iload #12
      //   140: baload
      //   141: sipush #255
      //   144: iand
      //   145: iload #13
      //   147: sipush #255
      //   150: iand
      //   151: bipush #16
      //   153: ishl
      //   154: iload_2
      //   155: sipush #255
      //   158: iand
      //   159: bipush #8
      //   161: ishl
      //   162: ior
      //   163: ior
      //   164: istore_2
      //   165: aload_0
      //   166: iconst_0
      //   167: putfield d : I
      //   170: goto -> 181
      //   173: iconst_m1
      //   174: istore #12
      //   176: iload_2
      //   177: istore_3
      //   178: iload #12
      //   180: istore_2
      //   181: iload_2
      //   182: iconst_m1
      //   183: if_icmpeq -> 299
      //   186: aload #6
      //   188: iconst_0
      //   189: aload #5
      //   191: iload_2
      //   192: bipush #18
      //   194: ishr
      //   195: bipush #63
      //   197: iand
      //   198: baload
      //   199: i2b
      //   200: bastore
      //   201: aload #6
      //   203: iconst_1
      //   204: aload #5
      //   206: iload_2
      //   207: bipush #12
      //   209: ishr
      //   210: bipush #63
      //   212: iand
      //   213: baload
      //   214: i2b
      //   215: bastore
      //   216: aload #6
      //   218: iconst_2
      //   219: aload #5
      //   221: iload_2
      //   222: bipush #6
      //   224: ishr
      //   225: bipush #63
      //   227: iand
      //   228: baload
      //   229: i2b
      //   230: bastore
      //   231: aload #6
      //   233: iconst_3
      //   234: aload #5
      //   236: iload_2
      //   237: bipush #63
      //   239: iand
      //   240: baload
      //   241: i2b
      //   242: bastore
      //   243: iinc #7, -1
      //   246: iload #7
      //   248: ifne -> 294
      //   251: aload_0
      //   252: getfield h : Z
      //   255: ifeq -> 270
      //   258: aload #6
      //   260: iconst_4
      //   261: bipush #13
      //   263: i2b
      //   264: bastore
      //   265: iconst_5
      //   266: istore_2
      //   267: goto -> 272
      //   270: iconst_4
      //   271: istore_2
      //   272: iload_2
      //   273: iconst_1
      //   274: iadd
      //   275: istore #7
      //   277: aload #6
      //   279: iload_2
      //   280: bipush #10
      //   282: i2b
      //   283: bastore
      //   284: iload #7
      //   286: istore_2
      //   287: bipush #19
      //   289: istore #7
      //   291: goto -> 301
      //   294: iconst_4
      //   295: istore_2
      //   296: goto -> 301
      //   299: iconst_0
      //   300: istore_2
      //   301: iload_3
      //   302: iconst_3
      //   303: iadd
      //   304: istore #12
      //   306: iload #12
      //   308: iload #8
      //   310: if_icmpgt -> 468
      //   313: aload_1
      //   314: iload_3
      //   315: baload
      //   316: istore #13
      //   318: aload_1
      //   319: iload_3
      //   320: iconst_1
      //   321: iadd
      //   322: baload
      //   323: sipush #255
      //   326: iand
      //   327: bipush #8
      //   329: ishl
      //   330: iload #13
      //   332: sipush #255
      //   335: iand
      //   336: bipush #16
      //   338: ishl
      //   339: ior
      //   340: aload_1
      //   341: iload_3
      //   342: iconst_2
      //   343: iadd
      //   344: baload
      //   345: sipush #255
      //   348: iand
      //   349: ior
      //   350: istore_3
      //   351: aload #6
      //   353: iload_2
      //   354: aload #5
      //   356: iload_3
      //   357: bipush #18
      //   359: ishr
      //   360: bipush #63
      //   362: iand
      //   363: baload
      //   364: i2b
      //   365: bastore
      //   366: aload #6
      //   368: iload_2
      //   369: iconst_1
      //   370: iadd
      //   371: aload #5
      //   373: iload_3
      //   374: bipush #12
      //   376: ishr
      //   377: bipush #63
      //   379: iand
      //   380: baload
      //   381: i2b
      //   382: bastore
      //   383: aload #6
      //   385: iload_2
      //   386: iconst_2
      //   387: iadd
      //   388: aload #5
      //   390: iload_3
      //   391: bipush #6
      //   393: ishr
      //   394: bipush #63
      //   396: iand
      //   397: baload
      //   398: i2b
      //   399: bastore
      //   400: aload #6
      //   402: iload_2
      //   403: iconst_3
      //   404: iadd
      //   405: aload #5
      //   407: iload_3
      //   408: bipush #63
      //   410: iand
      //   411: baload
      //   412: i2b
      //   413: bastore
      //   414: iinc #2, 4
      //   417: iinc #7, -1
      //   420: iload #7
      //   422: ifne -> 462
      //   425: iload_2
      //   426: istore_3
      //   427: aload_0
      //   428: getfield h : Z
      //   431: ifeq -> 445
      //   434: aload #6
      //   436: iload_2
      //   437: bipush #13
      //   439: i2b
      //   440: bastore
      //   441: iload_2
      //   442: iconst_1
      //   443: iadd
      //   444: istore_3
      //   445: aload #6
      //   447: iload_3
      //   448: bipush #10
      //   450: i2b
      //   451: bastore
      //   452: iload_3
      //   453: iconst_1
      //   454: iadd
      //   455: istore_2
      //   456: iload #12
      //   458: istore_3
      //   459: goto -> 287
      //   462: iload #12
      //   464: istore_3
      //   465: goto -> 301
      //   468: iload #4
      //   470: ifeq -> 944
      //   473: aload_0
      //   474: getfield d : I
      //   477: istore #13
      //   479: iload_3
      //   480: iload #13
      //   482: isub
      //   483: iload #8
      //   485: iconst_1
      //   486: isub
      //   487: if_icmpne -> 653
      //   490: iload #13
      //   492: ifle -> 508
      //   495: aload_0
      //   496: getfield c : [B
      //   499: iconst_0
      //   500: baload
      //   501: istore #12
      //   503: iconst_1
      //   504: istore_3
      //   505: goto -> 516
      //   508: aload_1
      //   509: iload_3
      //   510: baload
      //   511: istore #12
      //   513: iload #10
      //   515: istore_3
      //   516: iload #12
      //   518: sipush #255
      //   521: iand
      //   522: iconst_4
      //   523: ishl
      //   524: istore #12
      //   526: aload_0
      //   527: iload #13
      //   529: iload_3
      //   530: isub
      //   531: putfield d : I
      //   534: iload_2
      //   535: iconst_1
      //   536: iadd
      //   537: istore #10
      //   539: aload #6
      //   541: iload_2
      //   542: aload #5
      //   544: iload #12
      //   546: bipush #6
      //   548: ishr
      //   549: bipush #63
      //   551: iand
      //   552: baload
      //   553: i2b
      //   554: bastore
      //   555: iload #10
      //   557: iconst_1
      //   558: iadd
      //   559: istore_3
      //   560: aload #6
      //   562: iload #10
      //   564: aload #5
      //   566: iload #12
      //   568: bipush #63
      //   570: iand
      //   571: baload
      //   572: i2b
      //   573: bastore
      //   574: iload_3
      //   575: istore_2
      //   576: aload_0
      //   577: getfield f : Z
      //   580: ifeq -> 608
      //   583: iload_3
      //   584: iconst_1
      //   585: iadd
      //   586: istore #12
      //   588: aload #6
      //   590: iload_3
      //   591: bipush #61
      //   593: i2b
      //   594: bastore
      //   595: iload #12
      //   597: iconst_1
      //   598: iadd
      //   599: istore_2
      //   600: aload #6
      //   602: iload #12
      //   604: bipush #61
      //   606: i2b
      //   607: bastore
      //   608: iload_2
      //   609: istore_3
      //   610: aload_0
      //   611: getfield g : Z
      //   614: ifeq -> 647
      //   617: iload_2
      //   618: istore_3
      //   619: aload_0
      //   620: getfield h : Z
      //   623: ifeq -> 637
      //   626: aload #6
      //   628: iload_2
      //   629: bipush #13
      //   631: i2b
      //   632: bastore
      //   633: iload_2
      //   634: iconst_1
      //   635: iadd
      //   636: istore_3
      //   637: aload #6
      //   639: iload_3
      //   640: bipush #10
      //   642: i2b
      //   643: bastore
      //   644: iinc #3, 1
      //   647: iload_3
      //   648: istore #12
      //   650: goto -> 1047
      //   653: iload_3
      //   654: iload #13
      //   656: isub
      //   657: iload #8
      //   659: iconst_2
      //   660: isub
      //   661: if_icmpne -> 882
      //   664: iload #13
      //   666: iconst_1
      //   667: if_icmple -> 684
      //   670: aload_0
      //   671: getfield c : [B
      //   674: iconst_0
      //   675: baload
      //   676: istore #10
      //   678: iconst_1
      //   679: istore #12
      //   681: goto -> 696
      //   684: aload_1
      //   685: iload_3
      //   686: baload
      //   687: istore #10
      //   689: iinc #3, 1
      //   692: iload #9
      //   694: istore #12
      //   696: iload #13
      //   698: ifle -> 720
      //   701: aload_0
      //   702: getfield c : [B
      //   705: astore_1
      //   706: iload #12
      //   708: iconst_1
      //   709: iadd
      //   710: istore_3
      //   711: aload_1
      //   712: iload #12
      //   714: baload
      //   715: istore #12
      //   717: goto -> 732
      //   720: aload_1
      //   721: iload_3
      //   722: baload
      //   723: istore #9
      //   725: iload #12
      //   727: istore_3
      //   728: iload #9
      //   730: istore #12
      //   732: iload #10
      //   734: sipush #255
      //   737: iand
      //   738: bipush #10
      //   740: ishl
      //   741: iload #12
      //   743: sipush #255
      //   746: iand
      //   747: iconst_2
      //   748: ishl
      //   749: ior
      //   750: istore #12
      //   752: aload_0
      //   753: iload #13
      //   755: iload_3
      //   756: isub
      //   757: putfield d : I
      //   760: iload_2
      //   761: iconst_1
      //   762: iadd
      //   763: istore_3
      //   764: aload #6
      //   766: iload_2
      //   767: aload #5
      //   769: iload #12
      //   771: bipush #12
      //   773: ishr
      //   774: bipush #63
      //   776: iand
      //   777: baload
      //   778: i2b
      //   779: bastore
      //   780: iload_3
      //   781: iconst_1
      //   782: iadd
      //   783: istore_2
      //   784: aload #6
      //   786: iload_3
      //   787: aload #5
      //   789: iload #12
      //   791: bipush #6
      //   793: ishr
      //   794: bipush #63
      //   796: iand
      //   797: baload
      //   798: i2b
      //   799: bastore
      //   800: iload_2
      //   801: iconst_1
      //   802: iadd
      //   803: istore_3
      //   804: aload #6
      //   806: iload_2
      //   807: aload #5
      //   809: iload #12
      //   811: bipush #63
      //   813: iand
      //   814: baload
      //   815: i2b
      //   816: bastore
      //   817: iload_3
      //   818: istore_2
      //   819: aload_0
      //   820: getfield f : Z
      //   823: ifeq -> 837
      //   826: aload #6
      //   828: iload_3
      //   829: bipush #61
      //   831: i2b
      //   832: bastore
      //   833: iload_3
      //   834: iconst_1
      //   835: iadd
      //   836: istore_2
      //   837: iload_2
      //   838: istore_3
      //   839: aload_0
      //   840: getfield g : Z
      //   843: ifeq -> 876
      //   846: iload_2
      //   847: istore_3
      //   848: aload_0
      //   849: getfield h : Z
      //   852: ifeq -> 866
      //   855: aload #6
      //   857: iload_2
      //   858: bipush #13
      //   860: i2b
      //   861: bastore
      //   862: iload_2
      //   863: iconst_1
      //   864: iadd
      //   865: istore_3
      //   866: aload #6
      //   868: iload_3
      //   869: bipush #10
      //   871: i2b
      //   872: bastore
      //   873: iinc #3, 1
      //   876: iload_3
      //   877: istore #12
      //   879: goto -> 1047
      //   882: iload_2
      //   883: istore #12
      //   885: aload_0
      //   886: getfield g : Z
      //   889: ifeq -> 1047
      //   892: iload_2
      //   893: istore #12
      //   895: iload_2
      //   896: ifle -> 1047
      //   899: iload_2
      //   900: istore #12
      //   902: iload #7
      //   904: bipush #19
      //   906: if_icmpeq -> 1047
      //   909: iload_2
      //   910: istore_3
      //   911: aload_0
      //   912: getfield h : Z
      //   915: ifeq -> 929
      //   918: aload #6
      //   920: iload_2
      //   921: bipush #13
      //   923: i2b
      //   924: bastore
      //   925: iload_2
      //   926: iconst_1
      //   927: iadd
      //   928: istore_3
      //   929: aload #6
      //   931: iload_3
      //   932: bipush #10
      //   934: i2b
      //   935: bastore
      //   936: iload_3
      //   937: iconst_1
      //   938: iadd
      //   939: istore #12
      //   941: goto -> 1047
      //   944: iload_3
      //   945: iload #8
      //   947: iconst_1
      //   948: isub
      //   949: if_icmpne -> 987
      //   952: aload_0
      //   953: getfield c : [B
      //   956: astore #6
      //   958: aload_0
      //   959: getfield d : I
      //   962: istore #12
      //   964: aload_0
      //   965: iload #12
      //   967: iconst_1
      //   968: iadd
      //   969: putfield d : I
      //   972: aload #6
      //   974: iload #12
      //   976: aload_1
      //   977: iload_3
      //   978: baload
      //   979: i2b
      //   980: bastore
      //   981: iload_2
      //   982: istore #12
      //   984: goto -> 1047
      //   987: iload_2
      //   988: istore #12
      //   990: iload_3
      //   991: iload #8
      //   993: iconst_2
      //   994: isub
      //   995: if_icmpne -> 1047
      //   998: aload_0
      //   999: getfield c : [B
      //   1002: astore #6
      //   1004: aload_0
      //   1005: getfield d : I
      //   1008: istore #12
      //   1010: iload #12
      //   1012: iconst_1
      //   1013: iadd
      //   1014: istore #10
      //   1016: aload #6
      //   1018: iload #12
      //   1020: aload_1
      //   1021: iload_3
      //   1022: baload
      //   1023: i2b
      //   1024: bastore
      //   1025: aload_0
      //   1026: iload #10
      //   1028: iconst_1
      //   1029: iadd
      //   1030: putfield d : I
      //   1033: aload #6
      //   1035: iload #10
      //   1037: aload_1
      //   1038: iload_3
      //   1039: iconst_1
      //   1040: iadd
      //   1041: baload
      //   1042: i2b
      //   1043: bastore
      //   1044: iload_2
      //   1045: istore #12
      //   1047: aload_0
      //   1048: iload #12
      //   1050: putfield b : I
      //   1053: aload_0
      //   1054: iload #7
      //   1056: putfield e : I
      //   1059: iconst_1
      //   1060: ireturn
    }
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */