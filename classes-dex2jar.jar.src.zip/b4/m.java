package b4;

public class m extends g {
  public String c = null;
  
  public String d = null;
  
  public String e = null;
  
  public String f() {
    return this.e;
  }
  
  public String g() {
    return this.c;
  }
  
  public String h() {
    return this.d;
  }
  
  public void i(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4) {
    c(paramInt, paramString1);
    this.c = paramString2;
    this.d = paramString3;
    this.e = paramString4;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */