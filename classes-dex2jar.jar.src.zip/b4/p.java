package b4;

import android.text.TextUtils;
import l3.f;

public class p {
  public static final String e = "p";
  
  public String a = "";
  
  public int b = -1;
  
  public String c = "";
  
  public int d = -1;
  
  public String a() {
    return this.c;
  }
  
  public int b() {
    return this.b;
  }
  
  public String c() {
    return this.a;
  }
  
  public int d() {
    return this.d;
  }
  
  public void e() {
    if (!TextUtils.isEmpty(this.c) && this.c.equals(this.a)) {
      String str = e;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("handleMessage. Delete the WiFi AP:");
      stringBuilder.append(this.c);
      stringBuilder.append(" and port:");
      stringBuilder.append(this.d);
      stringBuilder.append(" from succeededWifiAPList.");
      f.a(str, stringBuilder.toString());
      i("");
      h(-1);
    } 
  }
  
  public void f(String paramString) {
    this.c = paramString;
  }
  
  public void g() {
    if (!TextUtils.isEmpty(this.c) && this.d != -1) {
      String str = e;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("setSucceedWifiInfo. ID : ");
      stringBuilder.append(this.c);
      stringBuilder.append(", Port : ");
      stringBuilder.append(this.d);
      f.a(str, stringBuilder.toString());
      i(this.c);
      h(this.d);
    } else {
      f.a(e, "setSucceedWifiInfo. error case");
    } 
    l3.p.p(this.c);
  }
  
  public void h(int paramInt) {
    this.b = paramInt;
  }
  
  public void i(String paramString) {
    this.a = paramString;
  }
  
  public void j(int paramInt) {
    this.d = paramInt;
  }
  
  public int k() {
    int i = this.d;
    this.d = 5229;
    return this.d;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */