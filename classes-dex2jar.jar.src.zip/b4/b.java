package b4;

import com.sec.spp.common.moduleinterface.CommonRunaInterface;
import com.sec.spp.push.PushClientService;
import com.sec.spp.push.RequestService;
import com.sec.spp.push.StartupReceiver;
import com.sec.spp.push.heartbeat.HeartBeat;
import com.sec.spp.push.monitor.SystemStateMonitor;
import com.sec.spp.push.monitor.SystemStateMonitorService;
import com.sec.spp.push.provider.PushClientProvider;
import com.sec.spp.push.receiver.AomMonitor;
import com.sec.spp.push.receiver.BackOffExpireReceiver;
import com.sec.spp.push.receiver.ConnectionStateCheckReceiver;
import com.sec.spp.push.receiver.PackageRemoveReceiver;
import com.sec.spp.push.receiver.ProvAlarmReceiver;
import com.sec.spp.push.receiver.ProviderInfoReceiver;
import com.sec.spp.push.receiver.RandomDeviceIdReqReceiver;
import com.sec.spp.push.receiver.RandomDeviceIdRespReceiver;
import com.sec.spp.push.receiver.RegistrationNotiReceiver;
import com.sec.spp.push.receiver.SendAckRequestReceiver;
import com.sec.spp.push.receiver.SessionRefreshRequestReceiver;
import com.sec.spp.smpc.receiver.SmpcSdkEventReceiver;
import com.sec.spp.smpc.receiver.SmpcSdkSppReceiver;
import com.sec.spp.smpc.receiver.SmpcSystemStateMonitor;
import com.sec.spp.smpc.service.SmpcSdkFcmService;
import l3.c;
import l3.f;

public abstract class b {
  public static final String a = "b";
  
  public static boolean b = false;
  
  public static boolean c = false;
  
  public static boolean d = false;
  
  public static boolean e = false;
  
  public static void a() {
    d(false);
    f(false);
    e(false);
  }
  
  public static void b() {
    d(true);
    f(true);
    e(true);
  }
  
  public static void c(boolean paramBoolean) {
    if (!paramBoolean && e)
      return; 
    e = paramBoolean ^ true;
    String str = a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("enablePushConnectionModule: ");
    stringBuilder.append(paramBoolean);
    f.a(str, stringBuilder.toString());
    c.c(paramBoolean, HeartBeat.class);
    c.c(paramBoolean, ProvAlarmReceiver.class);
    c.c(paramBoolean, AomMonitor.class);
    c.c(paramBoolean, ConnectionStateCheckReceiver.class);
    c.c(paramBoolean, RegistrationNotiReceiver.class);
    c.c(paramBoolean, ProviderInfoReceiver.class);
    c.c(paramBoolean, SendAckRequestReceiver.class);
    c.c(paramBoolean, RandomDeviceIdReqReceiver.class);
    c.c(paramBoolean, RandomDeviceIdRespReceiver.class);
    c.c(paramBoolean, BackOffExpireReceiver.class);
    c.c(paramBoolean, SessionRefreshRequestReceiver.class);
    c.c(paramBoolean, PackageRemoveReceiver.class);
  }
  
  public static void d(boolean paramBoolean) {
    if (!paramBoolean && b)
      return; 
    b = paramBoolean ^ true;
    c.c(paramBoolean, PushClientService.class);
    c.c(paramBoolean, RequestService.class);
    c.c(paramBoolean, SystemStateMonitorService.class);
    c.c(paramBoolean, SystemStateMonitor.class);
    c.c(paramBoolean, StartupReceiver.class);
    c.c(paramBoolean, PushClientProvider.class);
    c(paramBoolean);
  }
  
  public static void e(boolean paramBoolean) {
    if (!paramBoolean && d)
      return; 
    d = paramBoolean ^ true;
    CommonRunaInterface.componentEnable(paramBoolean);
  }
  
  public static void f(boolean paramBoolean) {
    if (!paramBoolean && c)
      return; 
    c = paramBoolean ^ true;
    c.c(paramBoolean, SmpcSdkEventReceiver.class);
    c.c(paramBoolean, SmpcSdkFcmService.class);
    c.c(paramBoolean, SmpcSdkSppReceiver.class);
    c.c(paramBoolean, SmpcSystemStateMonitor.class);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */