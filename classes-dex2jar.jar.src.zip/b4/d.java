package b4;

public class d extends g {
  public String c = null;
  
  public String d = null;
  
  public String f() {
    return this.d;
  }
  
  public String g() {
    return this.c;
  }
  
  public void h(int paramInt, String paramString1, String paramString2, String paramString3) {
    c(paramInt, paramString1);
    this.c = paramString2;
    this.d = paramString3;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */