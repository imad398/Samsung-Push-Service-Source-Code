package b4;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.Toast;
import com.sec.spp.push.PushClientApplication;
import com.sec.spp.push.provisioning.ProvisioningInfo;
import com.sec.spp.push.receiver.ConnectionStateCheckReceiver;
import l3.f;
import l3.l;
import l3.p;
import u3.b;

public class c {
  public static String k = "[ConnectionState]";
  
  public static c l;
  
  public a a = a.a;
  
  public long b = 0L;
  
  public long c = 0L;
  
  public long d = 0L;
  
  public long e = 0L;
  
  public long f = 0L;
  
  public long g = 0L;
  
  public long h = 0L;
  
  public boolean i = false;
  
  public final Object j = new Object();
  
  public c() {
    k();
  }
  
  public static void b() {
    // Byte code:
    //   0: ldc b4/c
    //   2: monitorenter
    //   3: aconst_null
    //   4: putstatic b4/c.l : Lb4/c;
    //   7: ldc b4/c
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc b4/c
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  public static c e() {
    // Byte code:
    //   0: ldc b4/c
    //   2: monitorenter
    //   3: getstatic b4/c.l : Lb4/c;
    //   6: ifnonnull -> 21
    //   9: new b4/c
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic b4/c.l : Lb4/c;
    //   21: getstatic b4/c.l : Lb4/c;
    //   24: astore_0
    //   25: ldc b4/c
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc b4/c
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  public boolean a() {
    if (!p.d().c())
      return false; 
    String str2 = k;
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("[Last Ping Time] ");
    stringBuilder3.append(this.g);
    f.g(str2, stringBuilder3.toString());
    str2 = k;
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append("[Next Ping Time] ");
    stringBuilder3.append(this.h);
    f.g(str2, stringBuilder3.toString());
    str2 = k;
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append("[Last Init Time] ");
    stringBuilder3.append(this.f);
    f.g(str2, stringBuilder3.toString());
    str2 = k;
    stringBuilder3 = new StringBuilder();
    stringBuilder3.append("[Last Init Start Time] ");
    stringBuilder3.append(this.e);
    f.g(str2, stringBuilder3.toString());
    String str3 = k;
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("[Last Prov Time] ");
    stringBuilder1.append(this.d);
    f.g(str3, stringBuilder1.toString());
    str3 = k;
    stringBuilder1 = new StringBuilder();
    stringBuilder1.append("[Last Prov Start Time] ");
    stringBuilder1.append(this.c);
    f.g(str3, stringBuilder1.toString());
    String str1 = k;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("[SPP Service Started] ");
    stringBuilder2.append(((PushClientApplication)PushClientApplication.c()).d());
    f.g(str1, stringBuilder2.toString());
    long l1 = SystemClock.elapsedRealtime();
    if (h() == true) {
      f.b(k, "[Abnormal State] ");
      return true;
    } 
    long l2 = this.f;
    long l3 = this.e;
    if (l2 < l3 && l3 + d() < l1) {
      f.b(k, "[Abnormal State] ");
      u3.c.n().z(false);
      return true;
    } 
    l2 = this.d;
    l3 = this.c;
    if (l2 < l3 && l3 + d() < l1) {
      f.b(k, "[Abnormal State] ");
      b.u().I(false);
      return true;
    } 
    return false;
  }
  
  public a c() {
    return this.a;
  }
  
  public int d() {
    return (a4.c.w().F() == true || (a4.c.w().G() && l.J())) ? 3600000 : 240000;
  }
  
  public int f() {
    int i = ProvisioningInfo.getCheckInterval() * 60000;
    int j = i;
    if (i < 240000)
      j = 240000; 
    String str = k;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Check Interval = ");
    stringBuilder.append(j);
    f.a(str, stringBuilder.toString());
    if (f.h) {
      Context context = PushClientApplication.c();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Check Interval = ");
      stringBuilder1.append(j);
      Toast.makeText(context, stringBuilder1.toString(), 1).show();
    } 
    return j;
  }
  
  public long g() {
    return this.g;
  }
  
  public boolean h() {
    return (this.c == 0L && this.e == 0L && this.d == 0L && this.f == 0L && this.g == 0L);
  }
  
  public void i(long paramLong) {
    synchronized (this.j) {
      t();
      Context context = PushClientApplication.c();
      Intent intent = new Intent();
      this("com.sec.spp.push.ACTION_CONNECTION_STATE_CHECK");
      intent.setClass(context, ConnectionStateCheckReceiver.class);
      intent.setPackage(context.getPackageName());
      PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, 67108864);
      String str = k;
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("CT : ");
      stringBuilder.append(SystemClock.elapsedRealtime());
      stringBuilder.append(", NT : ");
      stringBuilder.append(paramLong);
      f.a(str, stringBuilder.toString());
      l3.a.b(context, 3, paramLong, pendingIntent);
      s(true);
      return;
    } 
  }
  
  public void j(a parama) {
    this.a = parama;
  }
  
  public final void k() {
    a a1;
    if (a4.c.w().F() || a4.c.w().G()) {
      a1 = a.b;
    } else {
      a1 = a.a;
    } 
    j(a1);
  }
  
  public void l(long paramLong) {
    this.e = paramLong;
  }
  
  public void m(long paramLong) {
    this.f = paramLong;
  }
  
  public void n(long paramLong) {
    this.g = paramLong;
  }
  
  public void o(long paramLong) {
    this.c = paramLong;
  }
  
  public void p(long paramLong) {
    this.d = paramLong;
  }
  
  public void q(long paramLong) {
    this.h = paramLong;
  }
  
  public void r(long paramLong) {
    this.b = paramLong;
  }
  
  public final void s(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public void t() {
    synchronized (this.j) {
      Context context = PushClientApplication.c();
      AlarmManager alarmManager = (AlarmManager)context.getSystemService("alarm");
      Intent intent = new Intent();
      this("com.sec.spp.push.ACTION_CONNECTION_STATE_CHECK");
      intent.setClass(context, ConnectionStateCheckReceiver.class);
      intent.setPackage(context.getPackageName());
      PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, 67108864);
      f.a(k, "Alarm Unscheduled");
      alarmManager.cancel(pendingIntent);
      s(false);
      return;
    } 
  }
  
  public enum a {
    a, b;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */