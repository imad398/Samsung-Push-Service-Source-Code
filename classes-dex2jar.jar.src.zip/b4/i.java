package b4;

public class i extends g {
  public Long c = Long.valueOf(0L);
  
  public int d = 0;
  
  public void f(Long paramLong, int paramInt) {
    this.c = paramLong;
    this.d = paramInt;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */