package b4;

public class n {
  public String a;
  
  public String b;
  
  public String c;
  
  public String d;
  
  public String e;
  
  public n(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    this.a = paramString1;
    this.b = paramString2;
    f(paramString3);
    this.d = paramString4;
    this.e = paramString5;
  }
  
  public String a() {
    return this.a;
  }
  
  public String b() {
    return this.e;
  }
  
  public String c() {
    return this.c;
  }
  
  public String d() {
    return this.b;
  }
  
  public String e() {
    return this.d;
  }
  
  public void f(String paramString) {
    this.c = paramString;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */