package b4;

public class j extends g {
  public String c = null;
  
  public String d = null;
  
  public int e = 0;
  
  public String f = null;
  
  public int g = 0;
  
  public String h;
  
  public String i;
  
  public int j;
  
  public String k;
  
  public int l;
  
  public int m;
  
  public int n;
  
  public int o;
  
  public int p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public boolean t;
  
  public String u;
  
  public j() {
    B(null);
    A(null);
    this.j = 0;
    this.k = null;
    this.l = 0;
    this.m = 0;
    this.n = 0;
    this.o = 0;
    this.p = 0;
    this.r = 0;
    this.s = 0;
  }
  
  public void A(String paramString) {
    this.i = paramString;
  }
  
  public void B(String paramString) {
    this.h = paramString;
  }
  
  public int f() {
    return this.q;
  }
  
  public String g() {
    return this.c;
  }
  
  public int h() {
    return this.s;
  }
  
  public int i() {
    return this.r;
  }
  
  public String j() {
    return this.k;
  }
  
  public int k() {
    return this.p;
  }
  
  public int l() {
    return this.o;
  }
  
  public int m() {
    return this.j;
  }
  
  public int n() {
    return this.m;
  }
  
  public int o() {
    return this.n;
  }
  
  public String p() {
    return this.d;
  }
  
  public int q() {
    return this.e;
  }
  
  public String r() {
    return this.i;
  }
  
  public String s() {
    return this.h;
  }
  
  public String t() {
    return this.u;
  }
  
  public int u() {
    return this.l;
  }
  
  public String v() {
    return this.f;
  }
  
  public int w() {
    return this.g;
  }
  
  public boolean x() {
    return this.t;
  }
  
  public final void y(String paramString) {
    this.k = null;
    this.l = 80;
    byte b = 0;
    this.m = 0;
    this.n = 0;
    this.o = 0;
    this.p = 0;
    this.q = 0;
    this.r = 0;
    this.s = 0;
    String[] arrayOfString = paramString.split("&");
    if (arrayOfString != null) {
      int i = arrayOfString.length;
      while (b < i) {
        String str = arrayOfString[b];
        if (str.contains("latest_version=")) {
          this.k = str.replaceFirst("latest_version=", "");
        } else if (str.contains("wifi_port=")) {
          this.l = Integer.valueOf(str.replaceFirst("wifi_port=", "")).intValue();
        } else if (str.contains("ping_max=")) {
          this.m = Integer.valueOf(str.replaceFirst("ping_max=", "")).intValue();
        } else if (str.contains("ping_min=")) {
          this.n = Integer.valueOf(str.replaceFirst("ping_min=", "")).intValue();
        } else if (str.contains("ping_inc=")) {
          this.o = Integer.valueOf(str.replaceFirst("ping_inc=", "")).intValue();
        } else if (str.contains("ping_avg=")) {
          this.p = Integer.valueOf(str.replaceFirst("ping_avg=", "")).intValue();
        } else if (str.contains("ci=")) {
          this.q = Integer.valueOf(str.replaceFirst("ci=", "")).intValue();
        } else if (str.contains("fv=")) {
          this.r = Integer.valueOf(str.replaceFirst("fv=", "")).intValue();
        } else if (str.contains("ed=")) {
          this.s = Integer.valueOf(str.replaceFirst("ed=", "")).intValue();
        } else if (str.contains("sp=")) {
          this.t = true;
        } 
        b++;
      } 
    } 
  }
  
  public void z(int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3, int paramInt3, int paramInt4, String paramString4, String paramString5, String paramString6, String paramString7) {
    c(paramInt1, null);
    this.c = paramString1;
    this.d = paramString2;
    this.e = paramInt2;
    this.f = paramString3;
    this.g = paramInt3;
    this.j = paramInt4;
    this.h = paramString5;
    this.i = paramString6;
    this.u = paramString7;
    y(paramString4);
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */