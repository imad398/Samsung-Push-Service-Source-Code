package b4;

public class g {
  public int a;
  
  public String b;
  
  public g() {
    d(0);
    e(null);
  }
  
  public int a() {
    return this.a;
  }
  
  public String b() {
    return this.b;
  }
  
  public void c(int paramInt, String paramString) {
    d(paramInt);
    e(paramString);
  }
  
  public void d(int paramInt) {
    this.a = paramInt;
  }
  
  public void e(String paramString) {
    this.b = paramString;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */