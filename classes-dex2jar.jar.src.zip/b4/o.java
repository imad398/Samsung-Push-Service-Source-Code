package b4;

import a4.c;
import android.content.Intent;
import com.sec.spp.common.CommonConfig;
import com.sec.spp.common.pref.CommonPreferences;
import com.sec.spp.push.PushClientApplication;
import com.sec.spp.push.PushClientService;
import com.sec.spp.push.heartbeat.HeartBeat;
import l3.f;
import l3.h;
import l3.i;
import l3.l;
import u3.d;

public abstract class o {
  public static boolean a() {
    if (!CommonConfig.ENABLE_SPP_EOS)
      return false; 
    if (l.I()) {
      String str = "canEos false. support SPP";
      f.g("SppEosChecker", str);
      return false;
    } 
    if (h.b()) {
      String str = "canEos false. SppOnlyMode";
      f.g("SppEosChecker", str);
      return false;
    } 
    return true;
  }
  
  public static boolean b() {
    // Byte code:
    //   0: ldc b4/o
    //   2: monitorenter
    //   3: invokestatic a : ()Z
    //   6: istore_0
    //   7: iload_0
    //   8: ifne -> 16
    //   11: ldc b4/o
    //   13: monitorexit
    //   14: iconst_0
    //   15: ireturn
    //   16: invokestatic e : ()Z
    //   19: ifeq -> 34
    //   22: ldc 'SppEosChecker'
    //   24: ldc 'Already SPP EOSed. do nothing...'
    //   26: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   29: ldc b4/o
    //   31: monitorexit
    //   32: iconst_1
    //   33: ireturn
    //   34: invokestatic currentTimeMillis : ()J
    //   37: lstore_1
    //   38: getstatic android/os/Build$VERSION.SDK_INT : I
    //   41: istore_3
    //   42: iload_3
    //   43: getstatic com/sec/spp/common/CommonConfig.FORCE_EOS_OS_VERSION : I
    //   46: if_icmplt -> 131
    //   49: new java/lang/StringBuilder
    //   52: astore #4
    //   54: aload #4
    //   56: invokespecial <init> : ()V
    //   59: aload #4
    //   61: ldc 'SPP EOS. os:'
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: aload #4
    //   69: iload_3
    //   70: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   73: pop
    //   74: ldc 'SppEosChecker'
    //   76: aload #4
    //   78: invokevirtual toString : ()Ljava/lang/String;
    //   81: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   84: new java/lang/StringBuilder
    //   87: astore #4
    //   89: aload #4
    //   91: invokespecial <init> : ()V
    //   94: aload #4
    //   96: ldc 'Connection stop now '
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: pop
    //   102: aload #4
    //   104: lload_1
    //   105: invokestatic b : (J)Ljava/lang/String;
    //   108: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: pop
    //   112: ldc 'SppEosChecker'
    //   114: aload #4
    //   116: invokevirtual toString : ()Ljava/lang/String;
    //   119: invokestatic g : (Ljava/lang/String;Ljava/lang/String;)V
    //   122: lload_1
    //   123: invokestatic c : (J)V
    //   126: ldc b4/o
    //   128: monitorexit
    //   129: iconst_1
    //   130: ireturn
    //   131: invokestatic f : ()Z
    //   134: ifne -> 149
    //   137: ldc 'SppEosChecker'
    //   139: ldc 'SPP EOS Standby State : false. do not eos'
    //   141: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   144: ldc b4/o
    //   146: monitorexit
    //   147: iconst_0
    //   148: ireturn
    //   149: invokestatic getInstance : ()Lcom/sec/spp/common/pref/CommonPreferences;
    //   152: astore #4
    //   154: aload #4
    //   156: invokevirtual getSppEosStandBy : ()I
    //   159: i2l
    //   160: lstore #5
    //   162: aload #4
    //   164: invokevirtual getLastPushReceivedTime : ()J
    //   167: lload #5
    //   169: ldc2_w 86400000
    //   172: lmul
    //   173: ladd
    //   174: lstore #5
    //   176: lload #5
    //   178: lload_1
    //   179: lcmp
    //   180: ifge -> 231
    //   183: new java/lang/StringBuilder
    //   186: astore #4
    //   188: aload #4
    //   190: invokespecial <init> : ()V
    //   193: aload #4
    //   195: ldc 'SPP EOS will be at '
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: pop
    //   201: aload #4
    //   203: lload #5
    //   205: invokestatic b : (J)Ljava/lang/String;
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: pop
    //   212: ldc 'SppEosChecker'
    //   214: aload #4
    //   216: invokevirtual toString : ()Ljava/lang/String;
    //   219: invokestatic g : (Ljava/lang/String;Ljava/lang/String;)V
    //   222: lload_1
    //   223: invokestatic c : (J)V
    //   226: ldc b4/o
    //   228: monitorexit
    //   229: iconst_1
    //   230: ireturn
    //   231: ldc b4/o
    //   233: monitorexit
    //   234: iconst_0
    //   235: ireturn
    //   236: astore #4
    //   238: ldc b4/o
    //   240: monitorexit
    //   241: aload #4
    //   243: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	236	finally
    //   16	29	236	finally
    //   34	126	236	finally
    //   131	144	236	finally
    //   149	176	236	finally
    //   183	226	236	finally
  }
  
  public static void c(long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("doPushEos ");
    stringBuilder.append(i.b(paramLong));
    f.b("SppEosChecker", stringBuilder.toString());
    c.w().M();
    h(paramLong);
  }
  
  public static long d() {
    return !a() ? 0L : CommonPreferences.getInstance().getConnectionStopTime();
  }
  
  public static boolean e() {
    if (!a())
      return false; 
    long l = d();
    if (l > 0L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("isSppEos. Connection stopped at ");
      stringBuilder.append(i.b(l));
      f.g("SppEosChecker", stringBuilder.toString());
      return true;
    } 
    f.g("SppEosChecker", "isSppEos false");
    return false;
  }
  
  public static boolean f() {
    boolean bool;
    if (CommonPreferences.getInstance().getSppEosStandBy() >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static void g(long paramLong) {
    if (!a())
      return; 
    CommonPreferences.getInstance().setConnectionStopTime(paramLong);
  }
  
  public static void h(long paramLong) {
    g(paramLong);
    d.h().g(null, 0, 13);
    HeartBeat.sendStopHeartbeatIntent();
    b.c(false);
    f.b("SppEosChecker", "Connection Stopped. Stopping PUSH module.......");
    PushClientApplication.c().stopService(new Intent(PushClientApplication.c(), PushClientService.class));
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */