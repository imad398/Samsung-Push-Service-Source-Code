package b4;

import a4.c;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.sec.spp.push.provisioning.ProvisioningInfo;
import java.util.ArrayList;
import l3.f;
import l3.l;

public abstract class k extends f {
  public static final boolean k = l.L();
  
  public static String m(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("A>");
    stringBuilder.append(p(paramString));
    return stringBuilder.toString();
  }
  
  public static String n() {
    String str = ProvisioningInfo.getDeviceToken();
    if (TextUtils.isEmpty(str))
      return "e"; 
    int i = str.length();
    if (i >= 8) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("D>");
      stringBuilder.append(TextUtils.substring(str, 0, 4));
      stringBuilder.append(".");
      stringBuilder.append(TextUtils.substring(str, i - 4, i));
      return stringBuilder.toString();
    } 
    return "";
  }
  
  public static String o() {
    String str = ProvisioningInfo.getServerDeviceId();
    if (TextUtils.isEmpty(str))
      return "e"; 
    int i = str.length();
    if (i >= 4) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SD>");
      stringBuilder.append(TextUtils.substring(str, 0, 2));
      stringBuilder.append(".");
      stringBuilder.append(TextUtils.substring(str, i - 2, i));
      return stringBuilder.toString();
    } 
    return "";
  }
  
  public static String p(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return ""; 
    String str = paramString;
    if (paramString.length() >= 6)
      str = TextUtils.substring(paramString, 0, 6); 
    return str;
  }
  
  public static boolean q() {
    return f.h;
  }
  
  public static void r() {
    try {
      ArrayList arrayList = c.w().A();
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("T:");
      if (arrayList != null && !arrayList.isEmpty())
        for (Pair pair : arrayList) {
          stringBuilder.append((String)pair.first);
          stringBuilder.append(">");
          stringBuilder.append(TextUtils.substring((CharSequence)pair.second, 0, 1));
          stringBuilder.append(", ");
        }  
      Log.e("SPPC", stringBuilder.toString());
      f.e(stringBuilder.toString());
    } catch (Exception exception) {
      Log.e("SPPC", exception.getMessage());
    } 
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */