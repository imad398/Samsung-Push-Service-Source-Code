package b4;

import android.text.TextUtils;

public class h {
  public String a = null;
  
  public String b = null;
  
  public int c = -1;
  
  public int d;
  
  public String e = null;
  
  public Long f = Long.valueOf(0L);
  
  public int g = 0;
  
  public String h = null;
  
  public String i = null;
  
  public String j;
  
  public String k = null;
  
  public String l = null;
  
  public String a() {
    return this.e;
  }
  
  public String b() {
    return this.j;
  }
  
  public int c() {
    return this.g;
  }
  
  public String d() {
    return this.k;
  }
  
  public String e() {
    return this.a;
  }
  
  public String f() {
    return this.b;
  }
  
  public String g() {
    return this.i;
  }
  
  public int h() {
    return this.d;
  }
  
  public int i() {
    return this.c;
  }
  
  public String j() {
    return this.h;
  }
  
  public Long k() {
    return this.f;
  }
  
  public String l() {
    return TextUtils.isEmpty(this.l) ? "0" : this.l;
  }
  
  public long m() {
    long l;
    try {
      l = Long.valueOf(l()).longValue();
    } catch (Exception exception) {
      l = 0L;
    } 
    return l;
  }
  
  public void n(String paramString1, String paramString2, int paramInt1, int paramInt2, String paramString3, Long paramLong, int paramInt3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8) {
    this.a = paramString1;
    this.b = paramString2;
    this.d = paramInt2;
    this.c = paramInt1;
    this.e = paramString3;
    this.g = paramInt3;
    this.h = paramString4;
    this.f = paramLong;
    this.i = paramString5;
    this.j = paramString6;
    this.k = paramString7;
    this.l = paramString8;
  }
}


/* Location:              /home/kali/Desktop/Samsung Push Service_3.4.13.2_APKPure/classes-dex2jar.jar!/b4/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */